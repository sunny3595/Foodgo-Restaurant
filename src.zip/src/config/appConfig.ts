/**
 * FoodGo Customer - Application Configuration
 * Fully configurable branding, localization, currency, and feature flags.
 */

export interface AppConfig {
  appName: string;
  shortName: string;
  tagline: string;
  version: string;
  logoUrl: string;
  colors: {
    primary: string;
    primaryHover: string;
    secondary: string;
    accent: string;
    vegGreen: string;
    nonVegRed: string;
  };
  localization: {
    country: string;
    currency: string;
    currencySymbol: string;
    timezone: string;
    defaultLanguage: string;
    supportedLanguages: Array<{ code: string; label: string; native: string }>;
  };
  contact: {
    supportEmail: string;
    supportPhone: string;
    termsUrl: string;
    privacyPolicyUrl: string;
    helpCenterUrl: string;
  };
  featureFlags: {
    enablePayments: boolean;
    enableWallet: boolean;
    enableReferral: boolean;
    enableLoyalty: boolean;
    enableScheduledDelivery: boolean;
    enablePickup: boolean;
    enableLiveChat: boolean;
    enableRiderTracking: boolean;
    enableAppleLogin: boolean;
    enableGoogleLogin: boolean;
  };
  api: {
    baseUrl: string;
    timeoutMs: number;
    useMockApi: boolean;
  };
}

export const APP_CONFIG: AppConfig = {
  appName: 'FoodGo Customer',
  shortName: 'FoodGo',
  tagline: 'Delicious food delivered fast & fresh',
  version: '1.0.0',
  logoUrl: '/icon.svg',
  colors: {
    primary: '#E23744',
    primaryHover: '#CC2F3B',
    secondary: '#FF8F00',
    accent: '#2563EB',
    vegGreen: '#22C55E',
    nonVegRed: '#EF4444',
  },
  localization: {
    country: 'India',
    currency: 'INR',
    currencySymbol: '₹',
    timezone: 'Asia/Kolkata',
    defaultLanguage: 'en',
    supportedLanguages: [
      { code: 'en', label: 'English', native: 'English' },
      { code: 'hi', label: 'Hindi', native: 'हिन्दी' },
      { code: 'te', label: 'Telugu', native: 'తెలుగు' },
      { code: 'ta', label: 'Tamil', native: 'தமிழ்' },
      { code: 'kn', label: 'Kannada', native: 'ಕನ್ನಡ' },
      { code: 'ml', label: 'Malayalam', native: 'മലയാളം' },
    ],
  },
  contact: {
    supportEmail: 'support@foodgo.delivery',
    supportPhone: '+91 8000 123 456',
    termsUrl: 'https://foodgo.delivery/terms',
    privacyPolicyUrl: 'https://foodgo.delivery/privacy',
    helpCenterUrl: 'https://foodgo.delivery/help',
  },
  featureFlags: {
    enablePayments: true,
    enableWallet: true,
    enableReferral: true,
    enableLoyalty: false,
    enableScheduledDelivery: true,
    enablePickup: true,
    enableLiveChat: true,
    enableRiderTracking: true,
    enableAppleLogin: true,
    enableGoogleLogin: true,
  },
  api: {
    baseUrl: typeof process !== 'undefined' && process.env?.API_URL ? process.env.API_URL : 'https://api.foodgo.com/v1',
    timeoutMs: 15000,
    useMockApi: true, // Configured for Phase 1 development & demo
  },
};
