/**
 * Favorites Context & State Provider
 * Provides unified, reactive state for:
 * 1. Favorite Restaurants
 * 2. Favorite Food Items / Dishes
 * Persists to secure local storage and syncs across all screens in real-time.
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Restaurant, FoodItem } from '../types/restaurant';
import { MOCK_RESTAURANTS } from '../services/mock/mockData';

const RESTAURANTS_KEY = 'foodgo_favorite_restaurants_v2';
const ITEMS_KEY = 'foodgo_favorite_items_v2';

export interface FavoriteItemRecord {
  food: FoodItem;
  restaurant: Restaurant;
  addedAt: string;
}

interface FavoritesContextType {
  favoriteRestaurants: Restaurant[];
  favoriteItems: FavoriteItemRecord[];
  isRestaurantFavorite: (restaurantId: string) => boolean;
  toggleRestaurantFavorite: (restaurant: Restaurant) => boolean;
  removeRestaurantFavorite: (restaurantId: string) => void;
  isItemFavorite: (foodId: string) => boolean;
  toggleItemFavorite: (food: FoodItem, restaurant: Restaurant) => boolean;
  removeItemFavorite: (foodId: string) => void;
  clearFavorites: () => void;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

export const FavoritesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize restaurants from localStorage or initial seed (Paradise Biryani & Domino's)
  const [favoriteRestaurants, setFavoriteRestaurants] = useState<Restaurant[]>(() => {
    try {
      const stored = localStorage.getItem(RESTAURANTS_KEY);
      if (stored) return JSON.parse(stored);
    } catch {}
    return MOCK_RESTAURANTS.slice(0, 2);
  });

  // Initialize dishes from localStorage
  const [favoriteItems, setFavoriteItems] = useState<FavoriteItemRecord[]>(() => {
    try {
      const stored = localStorage.getItem(ITEMS_KEY);
      if (stored) return JSON.parse(stored);
    } catch {}
    // Initial sample dish from favorite restaurant
    if (MOCK_RESTAURANTS.length > 0) {
      return [
        {
          food: {
            id: 'dish_biryani_royal',
            restaurantId: MOCK_RESTAURANTS[0].id,
            name: 'Royal Hyderabadi Dum Biryani',
            description: 'Fragrant basmati rice slow-cooked with fresh marinated spices and tender pieces.',
            price: 320,
            imageUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500&auto=format&fit=crop&q=80',
            isVeg: false,
            rating: 4.8,
            ratingCount: 1240,
            category: 'Biryani',
            isBestseller: true,
            isAvailable: true,
          },
          restaurant: MOCK_RESTAURANTS[0],
          addedAt: new Date().toISOString(),
        },
      ];
    }
    return [];
  });

  // Sync restaurants to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(RESTAURANTS_KEY, JSON.stringify(favoriteRestaurants));
    } catch (e) {
      console.warn('Error saving favorite restaurants:', e);
    }
  }, [favoriteRestaurants]);

  // Sync dishes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(ITEMS_KEY, JSON.stringify(favoriteItems));
    } catch (e) {
      console.warn('Error saving favorite items:', e);
    }
  }, [favoriteItems]);

  const isRestaurantFavorite = (restaurantId: string): boolean => {
    return favoriteRestaurants.some((r) => r.id === restaurantId);
  };

  const toggleRestaurantFavorite = (restaurant: Restaurant): boolean => {
    const exists = favoriteRestaurants.some((r) => r.id === restaurant.id);
    if (exists) {
      setFavoriteRestaurants((prev) => prev.filter((r) => r.id !== restaurant.id));
      return false;
    } else {
      setFavoriteRestaurants((prev) => [restaurant, ...prev]);
      return true;
    }
  };

  const removeRestaurantFavorite = (restaurantId: string) => {
    setFavoriteRestaurants((prev) => prev.filter((r) => r.id !== restaurantId));
  };

  const isItemFavorite = (foodId: string): boolean => {
    return favoriteItems.some((item) => item.food.id === foodId);
  };

  const toggleItemFavorite = (food: FoodItem, restaurant: Restaurant): boolean => {
    const exists = favoriteItems.some((item) => item.food.id === food.id);
    if (exists) {
      setFavoriteItems((prev) => prev.filter((item) => item.food.id !== food.id));
      return false;
    } else {
      setFavoriteItems((prev) => [
        {
          food,
          restaurant,
          addedAt: new Date().toISOString(),
        },
        ...prev,
      ]);
      return true;
    }
  };

  const removeItemFavorite = (foodId: string) => {
    setFavoriteItems((prev) => prev.filter((item) => item.food.id !== foodId));
  };

  const clearFavorites = () => {
    setFavoriteRestaurants([]);
    setFavoriteItems([]);
  };

  return (
    <FavoritesContext.Provider
      value={{
        favoriteRestaurants,
        favoriteItems,
        isRestaurantFavorite,
        toggleRestaurantFavorite,
        removeRestaurantFavorite,
        isItemFavorite,
        toggleItemFavorite,
        removeItemFavorite,
        clearFavorites,
      }}
    >
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavorites = (): FavoritesContextType => {
  const context = useContext(FavoritesContext);
  if (!context) {
    throw new Error('useFavorites must be used within a FavoritesProvider');
  }
  return context;
};
