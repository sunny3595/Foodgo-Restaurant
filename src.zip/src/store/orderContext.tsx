/**
 * Order State & Lifecycle Context
 * Manages active orders, order history persistence, order placement simulation,
 * and delivery partner assignment.
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Order, OrderStatus, PaymentDetails, DeliveryRider } from '../types/order';
import { CartItem, BillBreakdown } from '../types/cart';
import { Restaurant } from '../types/restaurant';
import { Address } from '../types/location';
import { firestoreService } from '../services/firebase/firestoreService';

interface PlaceOrderParams {
  items: CartItem[];
  restaurant: Restaurant;
  deliveryAddress: Address;
  bill: BillBreakdown;
  payment: PaymentDetails;
  deliveryNotes?: string;
  selectedDeliveryTags?: string[];
}

interface OrderContextType {
  orders: Order[];
  activeOrder: Order | null;
  setActiveOrder: (order: Order | null) => void;
  placeOrder: (params: PlaceOrderParams) => Promise<Order>;
  cancelOrder: (orderId: string) => boolean;
}

const ORDER_STORAGE_KEY = 'foodgo_orders_history_v1';

const MOCK_RIDER: DeliveryRider = {
  id: 'rdr_101',
  name: 'Ramesh Naidu',
  phone: '+91 98480 22334',
  photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
  rating: 4.8,
  vehicleNumber: 'AP 03 AB 4592',
  vehicleModel: 'Honda Activa 6G (Red)',
  currentCoordinates: { latitude: 13.628, longitude: 79.42 },
};

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const stored = localStorage.getItem(ORDER_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {}
    return [];
  });

  const [activeOrder, setActiveOrder] = useState<Order | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(ORDER_STORAGE_KEY, JSON.stringify(orders));
    } catch {}
  }, [orders]);

  // Set the most recent non-delivered order as active order on load
  useEffect(() => {
    if (!activeOrder && orders.length > 0) {
      const ongoing = orders.find(
        (o) => o.status !== 'delivered' && o.status !== 'cancelled'
      );
      if (ongoing) {
        setActiveOrder(ongoing);
      }
    }
  }, [orders, activeOrder]);

  const placeOrder = async (params: PlaceOrderParams): Promise<Order> => {
    const randomId = `#FG-${Math.floor(10000 + Math.random() * 90000)}`;
    const now = new Date();
    const etaDate = new Date(now.getTime() + (params.restaurant.deliveryTimeMax || 30) * 60000);

    let summaryText = 'Paid via UPI';
    if (params.payment.method === 'upi_gpay') summaryText = 'Google Pay UPI';
    else if (params.payment.method === 'upi_phonepe') summaryText = 'PhonePe UPI';
    else if (params.payment.method === 'upi_paytm') summaryText = 'Paytm UPI';
    else if (params.payment.method === 'upi_custom') summaryText = `UPI ID (${params.payment.upiId})`;
    else if (params.payment.method === 'card_credit' || params.payment.method === 'card_debit') {
      const last4 = params.payment.card?.cardNumber.slice(-4) || '4242';
      summaryText = `Card ending in ••${last4}`;
    } else if (params.payment.method === 'netbanking') {
      summaryText = `Net Banking (${params.payment.bankName || 'HDFC Bank'})`;
    } else if (params.payment.method === 'wallet') {
      summaryText = `${params.payment.walletName || 'Paytm'} Wallet`;
    } else if (params.payment.method === 'cod') {
      summaryText = 'Cash on Delivery (Pay at Door)';
    }

    const newOrder: Order = {
      id: randomId,
      items: params.items,
      restaurant: params.restaurant,
      deliveryAddress: params.deliveryAddress,
      bill: params.bill,
      deliveryNotes: params.deliveryNotes,
      selectedDeliveryTags: params.selectedDeliveryTags,
      paymentMethod: params.payment.method,
      paymentDetailsSummary: summaryText,
      paymentStatus: params.payment.method === 'cod' ? 'pending_cod' : 'paid',
      status: 'placed',
      statusHistory: [{ status: 'placed', timestamp: now.toISOString() }],
      placedAt: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      estimatedDeliveryTimestamp: etaDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      estimatedDeliveryMinutes: params.restaurant.deliveryTimeMax || 30,
      rider: MOCK_RIDER,
    };

    setOrders((prev) => [newOrder, ...prev]);
    setActiveOrder(newOrder);

    // Sync to Firestore database
    let activeUserId = 'usr_customer_default';
    try {
      const raw = localStorage.getItem('foodgo_user_data');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.id) activeUserId = parsed.id;
      }
    } catch {}
    firestoreService.saveOrder(activeUserId, newOrder).catch((err) => {
      console.warn('Firestore order sync:', err);
    });

    // Simulate lifecycle progressions (placed -> confirmed -> preparing)
    setTimeout(() => {
      advanceOrderStatus(newOrder.id, 'confirmed');
    }, 8000);

    setTimeout(() => {
      advanceOrderStatus(newOrder.id, 'preparing');
    }, 20000);

    return newOrder;
  };

  const advanceOrderStatus = (orderId: string, nextStatus: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            status: nextStatus,
            statusHistory: [
              ...o.statusHistory,
              { status: nextStatus, timestamp: new Date().toISOString() },
            ],
          };
        }
        return o;
      })
    );

    setActiveOrder((prev) => {
      if (prev && prev.id === orderId) {
        return {
          ...prev,
          status: nextStatus,
          statusHistory: [
            ...prev.statusHistory,
            { status: nextStatus, timestamp: new Date().toISOString() },
          ],
        };
      }
      return prev;
    });
  };

  const cancelOrder = (orderId: string): boolean => {
    const target = orders.find((o) => o.id === orderId);
    if (!target) return false;

    // Check cancellation rule: Cannot cancel if preparing
    if (target.status === 'preparing' || target.status === 'out_for_delivery') {
      return false;
    }

    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'cancelled' } : o))
    );

    if (activeOrder?.id === orderId) {
      setActiveOrder(null);
    }

    return true;
  };

  return (
    <OrderContext.Provider
      value={{
        orders,
        activeOrder,
        setActiveOrder,
        placeOrder,
        cancelOrder,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
};

export const useOrder = (): OrderContextType => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrder must be used within an OrderProvider');
  }
  return context;
};
