/**
 * Shopping Cart Context & Provider
 * Enforces single-restaurant cart discipline (Section 24),
 * computes strict itemized billing (Section 25), handles coupon validation (Section 26),
 * and manages rider delivery instructions and tipping.
 */

import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import { CartItem, SelectedCustomization, BillBreakdown } from '../types/cart';
import { FoodItem, Restaurant, OfferBanner } from '../types/restaurant';
import { MOCK_OFFERS } from '../services/mock/mockData';
import { useApp } from './appContext';

interface PendingCartItem {
  food: FoodItem;
  customization: SelectedCustomization;
  restaurant: Restaurant;
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  restaurant: Restaurant | null;
  appliedCoupon: OfferBanner | null;
  tipAmount: number;
  deliveryNotes: string;
  selectedDeliveryTags: string[];
  bill: BillBreakdown;
  subtotal: number;
  totalItems: number;
  conflictModalOpen: boolean;
  pendingRestaurant: Restaurant | null;
  addItem: (
    food: FoodItem,
    customization: SelectedCustomization,
    restaurant: Restaurant,
    quantity?: number
  ) => void;
  updateQuantity: (cartItemId: string, newQuantity: number) => void;
  removeItem: (cartItemId: string) => void;
  clearCart: () => void;
  resolveConflict: (shouldReplace: boolean) => void;
  getItemQuantity: (foodId: string) => number;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  setTip: (amount: number) => void;
  setDeliveryNotes: (notes: string) => void;
  toggleDeliveryTag: (tag: string) => void;
}

const CART_STORAGE_KEY = 'foodgo_customer_cart_v2';

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { setCartItemCount, showToast } = useApp();

  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return parsed.items || [];
      }
    } catch {}
    return [];
  });

  const [restaurant, setRestaurant] = useState<Restaurant | null>(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return parsed.restaurant || null;
      }
    } catch {}
    return null;
  });

  const [appliedCoupon, setAppliedCoupon] = useState<OfferBanner | null>(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return parsed.appliedCoupon || null;
      }
    } catch {}
    return null;
  });

  const [tipAmount, setTipAmount] = useState<number>(0);
  const [deliveryNotes, setDeliveryNotes] = useState<string>('');
  const [selectedDeliveryTags, setSelectedDeliveryTags] = useState<string[]>([]);

  const [conflictModalOpen, setConflictModalOpen] = useState(false);
  const [pendingItem, setPendingItem] = useState<PendingCartItem | null>(null);

  // Sync cart count to global app badge & storage
  useEffect(() => {
    const totalCount = items.reduce((sum, item) => sum + item.quantity, 0);
    setCartItemCount(totalCount);

    try {
      localStorage.setItem(
        CART_STORAGE_KEY,
        JSON.stringify({ items, restaurant, appliedCoupon })
      );
    } catch {}
  }, [items, restaurant, appliedCoupon, setCartItemCount]);

  // Compute unit price based on variation and selected addons
  const calculateUnitPrice = (
    food: FoodItem,
    customization: SelectedCustomization
  ): number => {
    const base = customization.variation ? customization.variation.price : food.price;
    const addonsTotal = customization.addons.reduce((sum, a) => sum + a.price, 0);
    return base + addonsTotal;
  };

  // Generate unique item hash so distinct customizations don't collide
  const generateCartItemId = (
    food: FoodItem,
    customization: SelectedCustomization
  ): string => {
    const varKey = customization.variation ? customization.variation.id : 'default';
    const addonsKey = customization.addons
      .map((a) => a.id)
      .sort()
      .join('-');
    return `${food.id}_${varKey}_${addonsKey}`;
  };

  const addItem = (
    food: FoodItem,
    customization: SelectedCustomization,
    targetRestaurant: Restaurant,
    quantity = 1
  ) => {
    // Single-restaurant rule check (Section 24)
    if (restaurant && restaurant.id !== targetRestaurant.id && items.length > 0) {
      setPendingItem({ food, customization, restaurant: targetRestaurant, quantity });
      setConflictModalOpen(true);
      return;
    }

    const unitPrice = calculateUnitPrice(food, customization);
    const cartItemId = generateCartItemId(food, customization);

    setRestaurant(targetRestaurant);

    setItems((prev) => {
      const existingIndex = prev.findIndex((i) => i.id === cartItemId);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += quantity;
        return updated;
      }
      return [
        ...prev,
        {
          id: cartItemId,
          food,
          quantity,
          unitPrice,
          customization,
          restaurantId: targetRestaurant.id,
          restaurantName: targetRestaurant.name,
        },
      ];
    });

    showToast(`Added ${food.name} to cart`, 'success');
  };

  const resolveConflict = (shouldReplace: boolean) => {
    if (shouldReplace && pendingItem) {
      const unitPrice = calculateUnitPrice(pendingItem.food, pendingItem.customization);
      const cartItemId = generateCartItemId(pendingItem.food, pendingItem.customization);

      setRestaurant(pendingItem.restaurant);
      setItems([
        {
          id: cartItemId,
          food: pendingItem.food,
          quantity: pendingItem.quantity,
          unitPrice,
          customization: pendingItem.customization,
          restaurantId: pendingItem.restaurant.id,
          restaurantName: pendingItem.restaurant.name,
        },
      ]);
      setAppliedCoupon(null);
      showToast(`Cart replaced with items from ${pendingItem.restaurant.name}`, 'info');
    }
    setPendingItem(null);
    setConflictModalOpen(false);
  };

  const updateQuantity = (cartItemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeItem(cartItemId);
      return;
    }

    setItems((prev) =>
      prev.map((item) =>
        item.id === cartItemId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const removeItem = (cartItemId: string) => {
    setItems((prev) => {
      const filtered = prev.filter((i) => i.id !== cartItemId);
      if (filtered.length === 0) {
        setRestaurant(null);
        setAppliedCoupon(null);
      }
      return filtered;
    });
  };

  const clearCart = () => {
    setItems([]);
    setRestaurant(null);
    setAppliedCoupon(null);
    setTipAmount(0);
    setDeliveryNotes('');
    setSelectedDeliveryTags([]);
  };

  const getItemQuantity = (foodId: string): number => {
    return items
      .filter((i) => i.food.id === foodId)
      .reduce((sum, i) => sum + i.quantity, 0);
  };

  // Section 26: Coupon Management
  const applyCoupon = (code: string): { success: boolean; message: string } => {
    const trimmed = code.trim().toUpperCase();
    const found = MOCK_OFFERS.find((c) => c.code.toUpperCase() === trimmed);

    if (!found) {
      return { success: false, message: 'Invalid coupon code. Please try another.' };
    }

    const itemTotal = items.reduce((sum, i) => sum + i.unitPrice * i.quantity, 0);

    if (found.minOrder && itemTotal < found.minOrder) {
      return {
        success: false,
        message: `Add items worth ₹${found.minOrder - itemTotal} more to apply ${found.code}`,
      };
    }

    setAppliedCoupon(found);
    return {
      success: true,
      message: `Coupon ${found.code} applied successfully!`,
    };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    showToast('Coupon removed from order', 'info');
  };

  const toggleDeliveryTag = (tag: string) => {
    setSelectedDeliveryTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  // Itemized Bill Calculation (Section 25)
  const bill: BillBreakdown = useMemo(() => {
    const itemTotal = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);

    if (itemTotal === 0 || !restaurant) {
      return {
        itemTotal: 0,
        deliveryFee: 0,
        packagingFee: 0,
        platformFee: 0,
        gstAmount: 0,
        tipAmount: 0,
        discountAmount: 0,
        totalPayable: 0,
        totalSavings: 0,
      };
    }

    const standardDeliveryFee = restaurant.deliveryFee || 30;
    const isFreeDeliveryQualified =
      itemTotal >= 299 ||
      appliedCoupon?.code === 'FREEDEL' ||
      restaurant.deliveryFee === 0;

    const deliveryFee = isFreeDeliveryQualified ? 0 : standardDeliveryFee;
    const packagingFee = 25;
    const platformFee = 5;
    const gstAmount = Math.round(itemTotal * 0.05); // 5% GST

    // Calculate discount amount from applied coupon
    let discountAmount = 0;
    if (appliedCoupon) {
      if (appliedCoupon.code === 'FREEDEL') {
        discountAmount = standardDeliveryFee;
      } else if (appliedCoupon.discountPercentage) {
        const calculated = (itemTotal * appliedCoupon.discountPercentage) / 100;
        discountAmount = appliedCoupon.maxDiscount
          ? Math.min(calculated, appliedCoupon.maxDiscount)
          : calculated;
      } else if (appliedCoupon.maxDiscount) {
        discountAmount = Math.min(itemTotal, appliedCoupon.maxDiscount);
      }
    }

    const subtotalBeforeDiscount =
      itemTotal + deliveryFee + packagingFee + platformFee + gstAmount + tipAmount;

    const totalPayable = Math.max(0, Math.round(subtotalBeforeDiscount - (appliedCoupon?.code === 'FREEDEL' ? 0 : discountAmount)));
    const totalSavings = Math.round(discountAmount + (standardDeliveryFee - deliveryFee));

    return {
      itemTotal,
      deliveryFee,
      packagingFee,
      platformFee,
      gstAmount,
      tipAmount,
      discountAmount,
      totalPayable,
      totalSavings,
    };
  }, [items, restaurant, appliedCoupon, tipAmount]);

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        restaurant,
        appliedCoupon,
        tipAmount,
        deliveryNotes,
        selectedDeliveryTags,
        bill,
        subtotal: bill.itemTotal,
        totalItems,
        conflictModalOpen,
        pendingRestaurant: pendingItem?.restaurant || null,
        addItem,
        updateQuantity,
        removeItem,
        clearCart,
        resolveConflict,
        getItemQuantity,
        applyCoupon,
        removeCoupon,
        setTip: setTipAmount,
        setDeliveryNotes,
        toggleDeliveryTag,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = (): CartContextType => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
