/**
 * Authentication Context & Provider
 * Manages user sessions, tokens, guest mode, profile edits, and token rotation.
 */

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import {
  User,
  AuthTokens,
  LoginEmailCredentials,
  RegisterCredentials,
  SocialProvider,
  SessionDevice,
  VerifyOtpResult,
} from '../types/auth';
import { Address } from '../types/location';
import { secureStorage } from '../services/storage/secureStorage';
import { mockAuthApi } from '../services/api/mockApi';
import { firestoreService } from '../services/firebase/firestoreService';

interface AuthContextType {
  user: User | null;
  tokens: AuthTokens | null;
  isAuthenticated: boolean;
  isGuest: boolean;
  isLoading: boolean;
  activeSessions: SessionDevice[];
  guestPromptOpen: boolean;
  guestPromptContext: 'checkout' | 'favorites' | 'profile' | 'orders' | 'default';
  setGuestPromptOpen: (open: boolean) => void;
  triggerProtectedAction: (
    action: () => void,
    context?: 'checkout' | 'favorites' | 'profile' | 'orders' | 'default'
  ) => boolean;
  loginWithEmail: (creds: LoginEmailCredentials) => Promise<void>;
  register: (data: RegisterCredentials) => Promise<void>;
  sendPhoneOtp: (phone: string) => Promise<void>;
  verifyPhoneOtp: (
    phone: string,
    otp: string
  ) => Promise<{ isNewUser: boolean; user: User; addresses?: Address[] }>;
  completeNewProfile: (
    userId: string,
    profile: { firstName: string; lastName: string; email: string },
    address: Address
  ) => Promise<User>;
  socialLogin: (provider: SocialProvider) => Promise<void>;
  continueAsGuest: () => void;
  logout: () => Promise<void>;
  updateUser: (data: Partial<User>) => void;
  revokeSession: (sessionId: string) => Promise<void>;
  revokeAllOtherSessions: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [tokens, setTokens] = useState<AuthTokens | null>(null);
  const [isGuest, setIsGuest] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeSessions, setActiveSessions] = useState<SessionDevice[]>([]);

  // Guest action protection state
  const [guestPromptOpen, setGuestPromptOpen] = useState(false);
  const [guestPromptContext, setGuestPromptContext] = useState<
    'checkout' | 'favorites' | 'profile' | 'orders' | 'default'
  >('default');

  // Initialize session on startup
  useEffect(() => {
    const init = async () => {
      try {
        const storedToken = await secureStorage.getAccessToken();
        const storedRefreshToken = await secureStorage.getRefreshToken();
        let storedUser = await secureStorage.getUser();

        // Check if there is an updated profile in localStorage
        try {
          const custom = localStorage.getItem('foodgo_user_profile_custom');
          if (custom && storedUser) {
            storedUser = { ...storedUser, ...JSON.parse(custom) };
          }
        } catch {}

        if (storedToken && storedUser) {
          setUser(storedUser);
          setTokens({
            accessToken: storedToken,
            refreshToken: storedRefreshToken || '',
            expiresIn: 3600,
            issuedAt: Date.now(),
          });
          const sessions = await mockAuthApi.getActiveSessions();
          setActiveSessions(sessions);
        }
      } catch (err) {
        console.error('Session restore failed:', err);
      } finally {
        setIsLoading(false);
      }
    };

    init();
  }, []);

  // Listen for user profile updates from EditProfileModal
  useEffect(() => {
    const handleProfileUpdate = () => {
      try {
        const custom = localStorage.getItem('foodgo_user_profile_custom');
        if (custom) {
          const parsed = JSON.parse(custom);
          setUser((prev) => (prev ? { ...prev, ...parsed } : null));
        }
      } catch {}
    };

    window.addEventListener('user-profile-updated', handleProfileUpdate);
    return () => window.removeEventListener('user-profile-updated', handleProfileUpdate);
  }, []);

  // Background token refresh scheduler
  useEffect(() => {
    if (!tokens?.refreshToken || !user) return;

    const refreshInterval = setInterval(async () => {
      try {
        const freshTokens = await mockAuthApi.refreshToken(tokens.refreshToken);
        setTokens(freshTokens);
        await secureStorage.setTokens(freshTokens);
      } catch (err) {
        console.warn('Silent token renewal failed:', err);
      }
    }, 45 * 60 * 1000);

    return () => clearInterval(refreshInterval);
  }, [tokens?.refreshToken, user]);

  const loginWithEmail = async (creds: LoginEmailCredentials) => {
    setIsLoading(true);
    try {
      const response = await mockAuthApi.loginWithEmail(creds);
      setUser(response.user);
      setTokens(response.tokens);
      setIsGuest(false);
      await secureStorage.setTokens(response.tokens);
      await secureStorage.setUser(response.user);
      const sessions = await mockAuthApi.getActiveSessions();
      setActiveSessions(sessions);
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: RegisterCredentials) => {
    setIsLoading(true);
    try {
      const response = await mockAuthApi.register(data);
      setUser(response.user);
      setTokens(response.tokens);
      setIsGuest(false);
      await secureStorage.setTokens(response.tokens);
      await secureStorage.setUser(response.user);
      const sessions = await mockAuthApi.getActiveSessions();
      setActiveSessions(sessions);
    } finally {
      setIsLoading(false);
    }
  };

  const sendPhoneOtp = async (phone: string) => {
    await mockAuthApi.sendPhoneOtp(phone);
  };

  const verifyPhoneOtp = async (
    phone: string,
    otp: string
  ): Promise<{ isNewUser: boolean; user: User; addresses?: Address[] }> => {
    setIsLoading(true);
    try {
      const trimmed = otp.trim();
      if (!trimmed || (trimmed !== '1234' && trimmed.length < 4)) {
        throw new Error('Invalid verification code. Please enter 1234 to verify.');
      }

      const cleanDigits = phone.replace(/\D/g, '').slice(-10);
      const dbCheck = await firestoreService.getUserByPhone(cleanDigits);

      const tokens: AuthTokens = {
        accessToken: `fg_jwt_${Date.now()}_otp`,
        refreshToken: `fg_rt_${Date.now()}_otp`,
        expiresIn: 3600,
        issuedAt: Date.now(),
      };

      if (dbCheck.exists && dbCheck.isProfileComplete && dbCheck.user) {
        // Existing user with complete profile found in database!
        setUser(dbCheck.user);
        setTokens(tokens);
        setIsGuest(false);
        await secureStorage.setTokens(tokens);
        await secureStorage.setUser(dbCheck.user);
        const sessions = await mockAuthApi.getActiveSessions();
        setActiveSessions(sessions);

        return {
          isNewUser: false,
          user: dbCheck.user,
          addresses: dbCheck.addresses,
        };
      } else {
        // New mobile number login (or user without complete profile)
        // Create user document in database with their mobile number
        const newUser = await firestoreService.createNewUserWithPhone(cleanDigits);
        return {
          isNewUser: true,
          user: newUser,
        };
      }
    } finally {
      setIsLoading(false);
    }
  };

  const completeNewProfile = async (
    userId: string,
    profile: { firstName: string; lastName: string; email: string },
    address: Address
  ): Promise<User> => {
    setIsLoading(true);
    try {
      const { user: updatedUser } = await firestoreService.completeUserProfile(
        userId,
        profile,
        address
      );

      const tokens: AuthTokens = {
        accessToken: `fg_jwt_${Date.now()}_comp`,
        refreshToken: `fg_rt_${Date.now()}_comp`,
        expiresIn: 3600,
        issuedAt: Date.now(),
      };

      setUser(updatedUser);
      setTokens(tokens);
      setIsGuest(false);
      await secureStorage.setTokens(tokens);
      await secureStorage.setUser(updatedUser);
      const sessions = await mockAuthApi.getActiveSessions();
      setActiveSessions(sessions);

      return updatedUser;
    } finally {
      setIsLoading(false);
    }
  };

  const socialLogin = async (provider: SocialProvider) => {
    setIsLoading(true);
    try {
      const response = await mockAuthApi.socialLogin(provider);
      setUser(response.user);
      setTokens(response.tokens);
      setIsGuest(false);
      await secureStorage.setTokens(response.tokens);
      await secureStorage.setUser(response.user);
      const sessions = await mockAuthApi.getActiveSessions();
      setActiveSessions(sessions);
    } finally {
      setIsLoading(false);
    }
  };

  const continueAsGuest = () => {
    setIsGuest(true);
    setUser(null);
  };

  const updateUser = (data: Partial<User>) => {
    setUser((prev) => {
      if (!prev) return null;
      const updated = { ...prev, ...data };
      secureStorage.setUser(updated).catch(() => {});
      localStorage.setItem('foodgo_user_profile_custom', JSON.stringify(updated));
      return updated;
    });
  };

  const triggerProtectedAction = useCallback(
    (
      action: () => void,
      context: 'checkout' | 'favorites' | 'profile' | 'orders' | 'default' = 'default'
    ): boolean => {
      if (user && !isGuest) {
        action();
        return true;
      }
      setGuestPromptContext(context);
      setGuestPromptOpen(true);
      return false;
    },
    [user, isGuest]
  );

  const revokeSession = async (sessionId: string) => {
    const updated = await mockAuthApi.revokeSession(sessionId);
    setActiveSessions(updated);
  };

  const revokeAllOtherSessions = async () => {
    const updated = await mockAuthApi.revokeAllOtherSessions();
    setActiveSessions(updated);
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      await secureStorage.clearTokens();
      localStorage.removeItem('foodgo_user_profile_custom');
      setUser(null);
      setTokens(null);
      setIsGuest(false);
      setActiveSessions([]);
    } finally {
      setIsLoading(false);
    }
  };

  const isAuthenticated = !!user && !isGuest;

  return (
    <AuthContext.Provider
      value={{
        user,
        tokens,
        isAuthenticated,
        isGuest,
        isLoading,
        activeSessions,
        guestPromptOpen,
        guestPromptContext,
        setGuestPromptOpen,
        triggerProtectedAction,
        loginWithEmail,
        register,
        sendPhoneOtp,
        verifyPhoneOtp,
        completeNewProfile,
        socialLogin,
        continueAsGuest,
        logout,
        updateUser,
        revokeSession,
        revokeAllOtherSessions,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
