/**
 * Location Context & Provider
 * Manages active address, saved addresses list, map pinpoint addition,
 * address editing, deletions, and GPS permission state.
 */

import React, { createContext, useContext, useState } from 'react';
import { Address, LocationPermissionState } from '../types/location';
import { MOCK_ADDRESSES } from '../services/mock/mockData';
import { firestoreService } from '../services/firebase/firestoreService';

interface LocationContextType {
  currentAddress: Address;
  savedAddresses: Address[];
  permission: LocationPermissionState;
  selectAddress: (id: string) => void;
  setCurrentAddress: (address: Address) => void;
  addAddress: (address: Address) => void;
  updateAddress: (address: Address) => void;
  deleteAddress: (id: string) => void;
  requestCurrentLocation: () => Promise<boolean>;
  setPermission: (perm: LocationPermissionState) => void;
  loadUserAddresses: (addresses: Address[]) => void;
}

const LocationContext = createContext<LocationContextType | undefined>(undefined);

const getActiveUserId = (): string => {
  try {
    const raw = localStorage.getItem('foodgo_user_data');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed?.id) return parsed.id;
    }
  } catch {}
  return 'usr_customer_default';
};

export const LocationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [savedAddresses, setSavedAddresses] = useState<Address[]>(MOCK_ADDRESSES);
  const [currentAddress, setCurrentAddress] = useState<Address>(MOCK_ADDRESSES[0]);
  const [permission, setPermission] = useState<LocationPermissionState>('undetermined');

  const loadUserAddresses = (addresses: Address[]) => {
    if (addresses && addresses.length > 0) {
      setSavedAddresses(addresses);
      const defaultAddr = addresses.find((a) => a.isDefault) || addresses[0];
      setCurrentAddress(defaultAddr);
    }
  };

  const selectAddress = (id: string) => {
    const found = savedAddresses.find((a) => a.id === id);
    if (found) {
      setCurrentAddress(found);
    }
  };

  const addAddress = (address: Address) => {
    setSavedAddresses((prev) => [address, ...prev.filter((a) => a.id !== address.id)]);
    firestoreService.saveAddress(getActiveUserId(), address).catch((err) => {
      console.warn('Firestore address sync:', err);
    });
  };

  const updateAddress = (address: Address) => {
    setSavedAddresses((prev) => prev.map((a) => (a.id === address.id ? address : a)));
    if (currentAddress.id === address.id) {
      setCurrentAddress(address);
    }
    firestoreService.saveAddress(getActiveUserId(), address).catch((err) => {
      console.warn('Firestore address update sync:', err);
    });
  };

  const deleteAddress = (id: string) => {
    setSavedAddresses((prev) => {
      const remaining = prev.filter((a) => a.id !== id);
      if (currentAddress.id === id && remaining.length > 0) {
        setCurrentAddress(remaining[0]);
      }
      return remaining;
    });
    firestoreService.deleteAddress(getActiveUserId(), id).catch((err) => {
      console.warn('Firestore address delete sync:', err);
    });
  };

  const requestCurrentLocation = async (): Promise<boolean> => {
    try {
      if (typeof navigator !== 'undefined' && 'geolocation' in navigator) {
        return new Promise((resolve) => {
          navigator.geolocation.getCurrentPosition(
            () => {
              setPermission('granted');
              resolve(true);
            },
            () => {
              setPermission('denied');
              resolve(false);
            },
            { timeout: 8000 }
          );
        });
      }
      setPermission('denied');
      return false;
    } catch {
      setPermission('denied');
      return false;
    }
  };

  return (
    <LocationContext.Provider
      value={{
        currentAddress,
        savedAddresses,
        permission,
        selectAddress,
        setCurrentAddress,
        addAddress,
        updateAddress,
        deleteAddress,
        requestCurrentLocation,
        setPermission,
        loadUserAddresses,
      }}
    >
      {children}
    </LocationContext.Provider>
  );
};

export const useLocation = (): LocationContextType => {
  const context = useContext(LocationContext);
  if (!context) {
    throw new Error('useLocation must be used within a LocationProvider');
  }
  return context;
};
