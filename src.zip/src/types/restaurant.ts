/**
 * Restaurant, Category, Dish, and Offer Types
 */

import { Coordinates } from './location';

export interface FoodAddon {
  id: string;
  name: string;
  price: number;
  isVeg: boolean;
}

export interface FoodVariation {
  id: string;
  name: string;
  price: number;
  isDefault?: boolean;
}

export interface FoodItem {
  id: string;
  restaurantId: string;
  name: string;
  description: string;
  price: number;
  discountPrice?: number;
  imageUrl: string;
  isVeg: boolean;
  rating: number;
  ratingCount: number;
  category: string;
  isBestseller?: boolean;
  isAvailable: boolean;
  calories?: number;
  prepTimeMinutes?: number;
  variations?: FoodVariation[];
  addons?: FoodAddon[];
}

export interface Restaurant {
  id: string;
  name: string;
  tagline?: string;
  logoUrl: string;
  coverImageUrl: string;
  rating: number;
  ratingCount: number;
  cuisines: string[];
  deliveryTimeMin: number;
  deliveryTimeMax: number;
  distanceKm: number;
  deliveryFee: number;
  minOrderAmount: number;
  priceForTwo: number;
  isPureVeg: boolean;
  isOpen: boolean;
  openingHoursText: string;
  openingHour?: number;
  closingHour?: number;
  offers: string[];
  address: string;
  phone: string;
  coordinates: Coordinates;
  deliveryRadiusKm?: number;
  isFeatured?: boolean;
  isPopular?: boolean;
  isTopRated?: boolean;
  isFastDelivery?: boolean;
}

export interface Category {
  id: string;
  name: string;
  iconName: string;
  imageUrl: string;
  badge?: string;
  itemCount?: number;
}

export interface OfferBanner {
  id: string;
  title: string;
  subtitle: string;
  code: string;
  discountPercentage?: number;
  maxDiscount?: number;
  minOrder?: number;
  bgGradient: string;
  textColor: string;
  expiresInText: string;
  badge?: string;
  targetCategory?: string;
}
