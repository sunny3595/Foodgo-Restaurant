/**
 * Profile, Review, and Notification Types
 */

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'promo' | 'system' | 'motivation';
  timestamp: string;
  read: boolean;
  dateGroup: 'today' | 'yesterday' | 'earlier';
}

export interface UserReview {
  id: string;
  orderId: string;
  restaurantId: string;
  restaurantName: string;
  overallRating: number;
  foodRating: number;
  deliveryRating: number;
  comment: string;
  createdAt: string;
}

export interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  orderNotifications: boolean;
  promotionalNotifications: boolean;
  smsAlerts: boolean;
  soundEffects: boolean;
  language: 'en' | 'te' | 'hi' | 'ta';
}
