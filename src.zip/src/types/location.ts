/**
 * Location and Address Types for FoodGo Customer
 */

export type AddressLabel = 'Home' | 'Work' | 'Other';

export interface Coordinates {
  latitude: number;
  longitude: number;
}

export interface Address {
  id: string;
  label: AddressLabel;
  receiverName: string;
  phone: string;
  flatBuilding: string;
  streetArea: string;
  landmark?: string;
  city: string;
  state: string;
  postalCode: string;
  isDefault: boolean;
  coordinates: Coordinates;
}

export type LocationPermissionState = 'undetermined' | 'granted' | 'denied';
