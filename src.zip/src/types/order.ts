/**
 * Order, Payment, and Tracking Types
 */

import { CartItem, BillBreakdown } from './cart';
import { Restaurant } from './restaurant';
import { Address, Coordinates } from './location';

export type PaymentMethodType =
  | 'upi_gpay'
  | 'upi_phonepe'
  | 'upi_paytm'
  | 'upi_custom'
  | 'card_credit'
  | 'card_debit'
  | 'netbanking'
  | 'wallet'
  | 'cod';

export interface CardFormData {
  cardNumber: string;
  expiry: string;
  cvv: string;
  cardHolderName: string;
  saveCard: boolean;
}

export interface PaymentDetails {
  method: PaymentMethodType;
  upiId?: string;
  card?: CardFormData;
  bankName?: string;
  walletName?: string;
}

export type OrderStatus =
  | 'placed'
  | 'confirmed'
  | 'preparing'
  | 'ready'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled';

export interface DeliveryRider {
  id: string;
  name: string;
  phone: string;
  photoUrl: string;
  rating: number;
  vehicleNumber: string;
  vehicleModel: string;
  currentCoordinates: Coordinates;
}

export interface Order {
  id: string; // e.g. #FG-84291
  items: CartItem[];
  restaurant: Restaurant;
  deliveryAddress: Address;
  bill: BillBreakdown;
  deliveryNotes?: string;
  selectedDeliveryTags?: string[];
  paymentMethod: PaymentMethodType;
  paymentDetailsSummary: string;
  paymentStatus: 'paid' | 'pending_cod';
  status: OrderStatus;
  statusHistory: Array<{ status: OrderStatus; timestamp: string }>;
  placedAt: string;
  estimatedDeliveryTimestamp: string;
  estimatedDeliveryMinutes: number;
  rider?: DeliveryRider;
}
