/**
 * Shopping Cart & Customization Types
 */

import { FoodItem, FoodVariation, FoodAddon, Restaurant, OfferBanner } from './restaurant';

export interface SelectedCustomization {
  variation?: FoodVariation;
  addons: FoodAddon[];
  specialInstructions?: string;
}

export interface CartItem {
  id: string; // Unique cart item ID (hash of foodId + selected customizations)
  food: FoodItem;
  quantity: number;
  unitPrice: number;
  customization: SelectedCustomization;
  restaurantId: string;
  restaurantName: string;
}

export interface BillBreakdown {
  itemTotal: number;
  deliveryFee: number;
  packagingFee: number;
  platformFee: number;
  gstAmount: number;
  tipAmount: number;
  discountAmount: number;
  totalPayable: number;
  totalSavings: number;
}

export interface CartState {
  items: CartItem[];
  restaurant: Restaurant | null;
  appliedCoupon: OfferBanner | null;
  tipAmount: number;
  deliveryNotes: string;
  selectedDeliveryTags: string[];
  bill: BillBreakdown;
  totalItems: number;
}
