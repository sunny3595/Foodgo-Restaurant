/**
 * Navigation Types for FoodGo Customer
 */

export type ScreenType =
  | 'splash'
  | 'onboarding'
  | 'auth'
  | 'main';

export type MainTabType = 'home' | 'search' | 'orders' | 'favorites' | 'profile';

export interface NavigationState {
  currentScreen: ScreenType;
  activeTab: MainTabType;
  showLocationPrompt: boolean;
  selectedRestaurantId: string | null;
}
