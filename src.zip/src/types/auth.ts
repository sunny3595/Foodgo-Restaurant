/**
 * Authentication and User Types for FoodGo Customer
 */

export type SocialProvider = 'google' | 'apple' | 'facebook';

export interface SessionDevice {
  id: string;
  deviceName: string;
  platform: 'ios' | 'android' | 'web';
  lastActive: string;
  location: string;
  isCurrent: boolean;
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  avatarUrl?: string;
  role: 'customer';
  isPhoneVerified: boolean;
  isEmailVerified: boolean;
  isProfileComplete?: boolean;
  createdAt: string;
  defaultAddressId?: string;
  preferences?: {
    isPureVeg: boolean;
    notificationsEnabled: boolean;
    language: string;
    theme: 'system' | 'light' | 'dark';
  };
}

export interface VerifyOtpResult {
  isNewUser: boolean;
  user: User;
  addresses?: any[];
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number; // in seconds
  issuedAt: number;  // timestamp in ms
}

export interface AuthSession {
  user: User | null;
  tokens: AuthTokens | null;
  isAuthenticated: boolean;
  isGuest: boolean;
  activeSessions: SessionDevice[];
}

export interface LoginEmailCredentials {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface RegisterCredentials {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword?: string;
  referralCode?: string;
}

export interface PhoneOtpRequest {
  phone: string;
  countryCode: string;
}

export interface PhoneOtpVerify {
  phone: string;
  countryCode: string;
  otp: string;
}

export interface ForgotPasswordRequest {
  email: string;
}

export interface ResetPasswordRequest {
  email: string;
  code: string;
  newPassword: string;
}
