/**
 * Customer Notifications & Push Broadcast Persistence Service
 * Supports:
 * - Local storage caching of user notifications
 * - Firestore database persistence for Admin Broadcasts & Morning Motivation
 * - Real-time listeners for live push notification alerts (Flipkart / Amazon style)
 */

import {
  collection,
  doc,
  setDoc,
  onSnapshot,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db } from './firebase/firebase';
import { handleFirestoreError, OperationType } from './firebase/firestoreError';
import { NotificationItem } from '../types/profile';

const STORAGE_KEY = 'foodgo_user_notifications_v1';
const BROADCAST_COLLECTION = 'broadcast_notifications';

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_motivation_1',
    title: '☀️ Morning Motivation & Healthy Fuel',
    message: 'Start your day with positive energy! Fresh steamed Idlis, Crispy Ghee Roast Dosas & Filter Coffee are hot & ready.',
    type: 'motivation',
    timestamp: 'Just now',
    read: false,
    dateGroup: 'today',
  },
  {
    id: 'notif_1',
    title: 'Order Status Update 🛵',
    message: 'Your rider Ramesh Naidu has picked up your meal from Paradise Biryani and is on the way!',
    type: 'order',
    timestamp: '15 mins ago',
    read: false,
    dateGroup: 'today',
  },
  {
    id: 'notif_2',
    title: 'Weekend Biryani Fest 50% OFF 🥘',
    message: 'Use coupon FOODGO50 to get up to ₹100 off on all royal biryani orders this weekend.',
    type: 'promo',
    timestamp: '3 hours ago',
    read: false,
    dateGroup: 'today',
  },
  {
    id: 'notif_3',
    title: 'New Dark Mode Live 🌙',
    message: 'FoodGo now features automatic system dark mode for battery savings and comfortable night ordering.',
    type: 'system',
    timestamp: 'Yesterday, 6:30 PM',
    read: true,
    dateGroup: 'yesterday',
  },
];

export const notificationService = {
  getNotifications(): NotificationItem[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {}
    return INITIAL_NOTIFICATIONS;
  },

  addNotification(notif: NotificationItem, triggerBanner: boolean = true): NotificationItem[] {
    const current = this.getNotifications();
    // Prevent duplicate notification IDs
    if (current.some((n) => n.id === notif.id)) return current;

    const updated = [notif, ...current];
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch {}

    if (triggerBanner) {
      this.triggerPushBanner(notif);
    }

    // Trigger badge update
    window.dispatchEvent(new CustomEvent('foodgo-notifications-updated'));
    return updated;
  },

  markAsRead(id: string): NotificationItem[] {
    const current = this.getNotifications();
    const updated = current.map((n) => (n.id === id ? { ...n, read: true } : n));
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch {}
    window.dispatchEvent(new CustomEvent('foodgo-notifications-updated'));
    return updated;
  },

  markAllAsRead(): NotificationItem[] {
    const current = this.getNotifications();
    const updated = current.map((n) => ({ ...n, read: true }));
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch {}
    window.dispatchEvent(new CustomEvent('foodgo-notifications-updated'));
    return updated;
  },

  clearAll(): NotificationItem[] {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify([]));
    } catch {}
    window.dispatchEvent(new CustomEvent('foodgo-notifications-updated'));
    return [];
  },

  getUnreadCount(): number {
    return this.getNotifications().filter((n) => !n.read).length;
  },

  /**
   * Broadcasts a notification as Admin to Firestore
   * Saves to Firestore and immediately triggers the mobile phone push notification banner!
   */
  async broadcastNotification(data: {
    title: string;
    message: string;
    type?: 'motivation' | 'promo' | 'order' | 'system';
  }): Promise<NotificationItem> {
    const newId = `broadcast_${Date.now()}`;
    const path = `${BROADCAST_COLLECTION}/${newId}`;

    const item: NotificationItem = {
      id: newId,
      title: data.title,
      message: data.message,
      type: data.type || 'motivation',
      timestamp: 'Just now',
      read: false,
      dateGroup: 'today',
    };

    try {
      const docRef = doc(db, BROADCAST_COLLECTION, newId);
      await setDoc(docRef, {
        ...item,
        createdAt: new Date().toISOString(),
      });
    } catch (error) {
      console.warn('Firestore broadcast error (fallback local):', error);
      handleFirestoreError(error, OperationType.WRITE, path);
    }

    // Add to local user notifications list and show push notification banner
    this.addNotification(item, true);
    return item;
  },

  /**
   * Dispatches a custom window event to trigger the Flipkart/Amazon style push notification banner
   */
  triggerPushBanner(item: NotificationItem) {
    window.dispatchEvent(
      new CustomEvent('foodgo-push-notification', {
        detail: item,
      })
    );
  },

  /**
   * Listen to real-time broadcast notifications from Firestore
   */
  subscribeBroadcasts(onNewItem?: (item: NotificationItem) => void): () => void {
    try {
      const q = query(
        collection(db, BROADCAST_COLLECTION),
        orderBy('createdAt', 'desc'),
        limit(10)
      );

      return onSnapshot(
        q,
        (snapshot) => {
          snapshot.docChanges().forEach((change) => {
            if (change.type === 'added') {
              const data = change.doc.data() as NotificationItem;
              this.addNotification(data, true);
              if (onNewItem) onNewItem(data);
            }
          });
        },
        (error) => {
          console.warn('Broadcast listener notice:', error);
        }
      );
    } catch {
      return () => {};
    }
  },
};
