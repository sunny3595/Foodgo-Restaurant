/**
 * FoodGo Customer - Mock API Services
 * Comprehensive authentication, session management, social login, and token refresh.
 */

import {
  User,
  AuthTokens,
  LoginEmailCredentials,
  RegisterCredentials,
  SocialProvider,
  SessionDevice,
} from '../../types/auth';
import { Restaurant, Category, OfferBanner } from '../../types/restaurant';
import { Address } from '../../types/location';
import { MOCK_USER, MOCK_RESTAURANTS, MOCK_CATEGORIES, MOCK_OFFERS, MOCK_ADDRESSES } from '../mock/mockData';
import { ApiError } from './client';

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const INITIAL_SESSIONS: SessionDevice[] = [
  {
    id: 'sess_curr_1',
    deviceName: 'iPhone 16 Pro',
    platform: 'ios',
    lastActive: 'Active now',
    location: 'Tirupati, India',
    isCurrent: true,
  },
  {
    id: 'sess_prev_2',
    deviceName: 'Chrome Web (MacBook)',
    platform: 'web',
    lastActive: 'Yesterday, 8:45 PM',
    location: 'Bangalore, India',
    isCurrent: false,
  },
];

let mockSessions: SessionDevice[] = [...INITIAL_SESSIONS];
let activeResetCode: { email: string; code: string; expiresAt: number } | null = null;

export const mockAuthApi = {
  async loginWithEmail(credentials: LoginEmailCredentials): Promise<{ user: User; tokens: AuthTokens }> {
    await delay(600);

    const email = credentials.email.trim().toLowerCase();
    if (!email || !credentials.password) {
      throw new ApiError('Email and password are required', 400, 'VALIDATION_ERROR');
    }

    if (credentials.password.length < 6) {
      throw new ApiError('Invalid email or password. Please verify your credentials.', 401, 'INVALID_CREDENTIALS');
    }

    const tokens: AuthTokens = {
      accessToken: `fg_jwt_${Date.now()}_acc`,
      refreshToken: `fg_rt_${Date.now()}_ref`,
      expiresIn: 3600,
      issuedAt: Date.now(),
    };

    const user: User = {
      ...MOCK_USER,
      email,
      firstName: email.includes('nithin') ? 'Nithin' : email.split('@')[0],
    };

    return { user, tokens };
  },

  async register(data: RegisterCredentials): Promise<{ user: User; tokens: AuthTokens }> {
    await delay(700);

    if (!data.email || !data.password || !data.firstName || !data.phone) {
      throw new ApiError('All required fields must be filled', 400, 'VALIDATION_ERROR');
    }

    if (data.confirmPassword && data.password !== data.confirmPassword) {
      throw new ApiError('Passwords do not match', 400, 'PASSWORD_MISMATCH');
    }

    const tokens: AuthTokens = {
      accessToken: `fg_jwt_${Date.now()}_acc`,
      refreshToken: `fg_rt_${Date.now()}_ref`,
      expiresIn: 3600,
      issuedAt: Date.now(),
    };

    const user: User = {
      id: `usr_fg_${Date.now()}`,
      firstName: data.firstName.trim(),
      lastName: data.lastName?.trim() || '',
      email: data.email.trim().toLowerCase(),
      phone: data.phone.trim(),
      role: 'customer',
      isPhoneVerified: true,
      isEmailVerified: false,
      createdAt: new Date().toISOString(),
    };

    return { user, tokens };
  },

  async sendPhoneOtp(phone: string): Promise<{ success: boolean; message: string; testCode: string }> {
    await delay(500);

    const cleaned = phone.replace(/\D/g, '');
    if (!cleaned || cleaned.length < 10) {
      throw new ApiError('Please provide a valid 10-digit mobile number', 400, 'INVALID_PHONE');
    }

    return {
      success: true,
      message: `Verification code sent to +91 ${cleaned.slice(-10)}`,
      testCode: '1234',
    };
  },

  async verifyPhoneOtp(phone: string, otp: string): Promise<{ user: User; tokens: AuthTokens }> {
    await delay(600);

    const trimmed = otp.trim();
    if (!trimmed || (trimmed !== '1234' && trimmed.length < 4)) {
      throw new ApiError('Invalid verification code. Please check and try again (Test code: 1234).', 400, 'INVALID_OTP');
    }

    const tokens: AuthTokens = {
      accessToken: `fg_jwt_${Date.now()}_otp`,
      refreshToken: `fg_rt_${Date.now()}_otp`,
      expiresIn: 3600,
      issuedAt: Date.now(),
    };

    const user: User = {
      ...MOCK_USER,
      phone: `+91 ${phone.replace(/\D/g, '').slice(-10)}`,
      isPhoneVerified: true,
    };

    return { user, tokens };
  },

  async socialLogin(provider: SocialProvider): Promise<{ user: User; tokens: AuthTokens }> {
    await delay(700);

    const tokens: AuthTokens = {
      accessToken: `fg_jwt_${provider}_${Date.now()}`,
      refreshToken: `fg_rt_${provider}_${Date.now()}`,
      expiresIn: 3600,
      issuedAt: Date.now(),
    };

    const providerProfiles: Record<SocialProvider, Partial<User>> = {
      google: {
        firstName: 'Nithin',
        lastName: 'Ojili',
        email: 'ojilinithinnithin@gmail.com',
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80',
      },
      apple: {
        firstName: 'Nithin',
        lastName: 'Ojili',
        email: 'nithin.ojili@privaterelay.appleid.com',
      },
      facebook: {
        firstName: 'Nithin',
        lastName: 'Kumar',
        email: 'nithin.social@facebook.com',
      },
    };

    const user: User = {
      ...MOCK_USER,
      ...providerProfiles[provider],
      isEmailVerified: true,
    };

    return { user, tokens };
  },

  async forgotPassword(email: string): Promise<{ success: boolean; message: string; code: string }> {
    await delay(600);

    const trimmed = email.trim().toLowerCase();
    if (!trimmed) {
      throw new ApiError('Please enter your registered email address', 400, 'VALIDATION_ERROR');
    }

    const testCode = '849201';
    activeResetCode = {
      email: trimmed,
      code: testCode,
      expiresAt: Date.now() + 10 * 60 * 1000, // 10 minutes
    };

    return {
      success: true,
      message: `A 6-digit password reset code has been sent to ${trimmed}`,
      code: testCode,
    };
  },

  async resetPassword(params: {
    email: string;
    code: string;
    newPassword: string;
  }): Promise<{ success: boolean; message: string }> {
    await delay(700);

    if (!activeResetCode || activeResetCode.email !== params.email.trim().toLowerCase()) {
      throw new ApiError('No pending password reset request found for this email', 400, 'NO_RESET_REQUEST');
    }

    if (Date.now() > activeResetCode.expiresAt) {
      activeResetCode = null;
      throw new ApiError('Password reset code has expired. Please request a new one.', 400, 'CODE_EXPIRED');
    }

    if (activeResetCode.code !== params.code.trim()) {
      throw new ApiError('Invalid reset code. Please check your email.', 400, 'INVALID_CODE');
    }

    if (params.newPassword.length < 8) {
      throw new ApiError('New password must be at least 8 characters long', 400, 'WEAK_PASSWORD');
    }

    activeResetCode = null;
    return {
      success: true,
      message: 'Your password has been reset successfully. Please sign in with your new password.',
    };
  },

  async refreshToken(oldRefreshToken: string): Promise<AuthTokens> {
    await delay(400);

    if (!oldRefreshToken) {
      throw new ApiError('Invalid or expired session token', 401, 'INVALID_REFRESH_TOKEN');
    }

    return {
      accessToken: `fg_jwt_${Date.now()}_refreshed`,
      refreshToken: `fg_rt_${Date.now()}_refreshed`,
      expiresIn: 3600,
      issuedAt: Date.now(),
    };
  },

  async getActiveSessions(): Promise<SessionDevice[]> {
    await delay(250);
    return mockSessions;
  },

  async revokeSession(sessionId: string): Promise<SessionDevice[]> {
    await delay(400);
    mockSessions = mockSessions.filter((s) => s.id !== sessionId || s.isCurrent);
    return mockSessions;
  },

  async revokeAllOtherSessions(): Promise<SessionDevice[]> {
    await delay(400);
    mockSessions = mockSessions.filter((s) => s.isCurrent);
    return mockSessions;
  },
};

export const mockRestaurantApi = {
  async getRestaurants(options?: {
    search?: string;
    cuisine?: string;
    pureVeg?: boolean;
    sortBy?: string;
  }): Promise<Restaurant[]> {
    await delay(400);
    let list = [...MOCK_RESTAURANTS];

    if (options?.pureVeg) {
      list = list.filter((r) => r.isPureVeg);
    }

    if (options?.cuisine && options.cuisine !== 'All') {
      list = list.filter((r) =>
        r.cuisines.some((c) => c.toLowerCase().includes(options.cuisine!.toLowerCase()))
      );
    }

    if (options?.search) {
      const q = options.search.toLowerCase();
      list = list.filter(
        (r) =>
          r.name.toLowerCase().includes(q) ||
          r.cuisines.some((c) => c.toLowerCase().includes(q))
      );
    }

    if (options?.sortBy === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    } else if (options?.sortBy === 'deliveryTime') {
      list.sort((a, b) => a.deliveryTimeMin - b.deliveryTimeMin);
    } else if (options?.sortBy === 'priceLow') {
      list.sort((a, b) => a.priceForTwo - b.priceForTwo);
    }

    return list;
  },

  async getCategories(): Promise<Category[]> {
    await delay(250);
    return MOCK_CATEGORIES;
  },

  async getOffers(): Promise<OfferBanner[]> {
    await delay(250);
    return MOCK_OFFERS;
  },
};

export const mockLocationApi = {
  async getAddresses(): Promise<Address[]> {
    await delay(300);
    return MOCK_ADDRESSES;
  },
};
