/**
 * Normalized API Client for FoodGo Customer
 * Manages request headers, bearer tokens, error serialization, and mock delegation.
 */

import { APP_CONFIG } from '../../config/appConfig';
import { secureStorage } from '../storage/secureStorage';

export interface ApiResponse<T> {
  data: T;
  status: number;
  message?: string;
  success: boolean;
}

export class ApiError extends Error {
  status: number;
  code: string;
  details?: unknown;

  constructor(message: string, status = 500, code = 'API_ERROR', details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export const apiClient = {
  async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const url = `${APP_CONFIG.api.baseUrl}${endpoint}`;
    const token = await secureStorage.getAccessToken();

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), APP_CONFIG.api.timeoutMs);

    try {
      const response = await fetch(url, {
        ...options,
        headers,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      const data = await response.json();

      if (!response.ok) {
        throw new ApiError(
          data.message || `Request failed with status ${response.status}`,
          response.status,
          data.code || 'HTTP_ERROR',
          data
        );
      }

      return {
        data: data.data || data,
        status: response.status,
        message: data.message,
        success: true,
      };
    } catch (err: unknown) {
      clearTimeout(timeoutId);

      if (err instanceof ApiError) {
        throw err;
      }

      if ((err as Error)?.name === 'AbortError') {
        throw new ApiError('Request timed out. Please check your internet connection.', 408, 'TIMEOUT');
      }

      throw new ApiError(
        (err as Error)?.message || 'A network error occurred. Please try again.',
        0,
        'NETWORK_ERROR'
      );
    }
  },
};
