/**
 * Restaurant Discovery & Filtering Service
 * Implements real-time distance calculation relative to the user's active address,
 * operating hours status, and comprehensive sorting algorithms.
 */

import { Restaurant } from '../types/restaurant';
import { Coordinates } from '../types/location';
import { MOCK_RESTAURANTS } from './mock/mockData';
import {
  calculateDistanceKm,
  estimateDeliveryTime,
  calculateDeliveryFee,
  isRestaurantOpenNow,
} from '../utils/geo';

export interface RestaurantFilterOptions {
  searchQuery?: string;
  category?: string;
  pureVegOnly?: boolean;
  ratingMin?: number; // e.g. 4.0 or 4.5
  maxDeliveryTime?: number; // e.g. 25
  maxDistanceKm?: number; // e.g. 5
  openNowOnly?: boolean;
  freeDeliveryOnly?: boolean;
  offersOnly?: boolean;
  sortBy?: 'recommended' | 'rating' | 'deliveryTime' | 'distance' | 'priceLow' | 'priceHigh';
}

export const restaurantService = {
  /**
   * Prepares restaurants with dynamic distance, ETA, delivery fees, and open/closed status
   * calculated relative to the customer's current delivery location.
   */
  getProcessedRestaurants(userLocation: Coordinates): Restaurant[] {
    return MOCK_RESTAURANTS.map((restaurant) => {
      // Calculate true distance using Haversine formula
      const distance = calculateDistanceKm(userLocation, restaurant.coordinates);
      const eta = estimateDeliveryTime(distance);
      const deliveryFee = restaurant.deliveryFee === 0 ? 0 : calculateDeliveryFee(distance);
      const openStatus = isRestaurantOpenNow(restaurant.openingHour, restaurant.closingHour);

      return {
        ...restaurant,
        distanceKm: distance,
        deliveryTimeMin: eta.min,
        deliveryTimeMax: eta.max,
        deliveryFee,
        isOpen: openStatus.isOpen,
        openingHoursText: openStatus.statusText,
        isFastDelivery: eta.max <= 25,
      };
    });
  },

  /**
   * Retrieves a specific restaurant by its unique ID.
   */
  getRestaurantById(id: string, userLocation?: Coordinates): Restaurant | undefined {
    const list = userLocation ? this.getProcessedRestaurants(userLocation) : MOCK_RESTAURANTS;
    return list.find((r) => r.id === id);
  },

  /**
   * Filters and sorts restaurants according to user criteria.
   */
  filterAndSortRestaurants(
    restaurants: Restaurant[],
    options: RestaurantFilterOptions = {}
  ): Restaurant[] {
    let result = [...restaurants];

    // 1. Search Query (Matches restaurant name, cuisines, or address)
    if (options.searchQuery && options.searchQuery.trim()) {
      const q = options.searchQuery.toLowerCase().trim();
      result = result.filter(
        (r) =>
          r.name.toLowerCase().includes(q) ||
          r.cuisines.some((c) => c.toLowerCase().includes(q)) ||
          r.address.toLowerCase().includes(q)
      );
    }

    // 2. Category / Cuisine
    if (options.category && options.category !== 'All') {
      const cat = options.category.toLowerCase();
      result = result.filter((r) =>
        r.cuisines.some((c) => c.toLowerCase().includes(cat))
      );
    }

    // 3. Pure Veg Only
    if (options.pureVegOnly) {
      result = result.filter((r) => r.isPureVeg);
    }

    // 4. Rating Threshold
    if (options.ratingMin !== undefined && options.ratingMin > 0) {
      result = result.filter((r) => r.rating >= options.ratingMin!);
    }

    // 5. Max Delivery Time
    if (options.maxDeliveryTime !== undefined && options.maxDeliveryTime > 0) {
      result = result.filter((r) => r.deliveryTimeMax <= options.maxDeliveryTime!);
    }

    // 6. Max Distance Radius
    if (options.maxDistanceKm !== undefined && options.maxDistanceKm > 0) {
      result = result.filter((r) => r.distanceKm <= options.maxDistanceKm!);
    }

    // 7. Open Now
    if (options.openNowOnly) {
      result = result.filter((r) => r.isOpen);
    }

    // 8. Free Delivery Only
    if (options.freeDeliveryOnly) {
      result = result.filter((r) => r.deliveryFee === 0);
    }

    // 9. Special Offers
    if (options.offersOnly) {
      result = result.filter((r) => r.offers.length > 0);
    }

    // 10. Sorting
    const sort = options.sortBy || 'recommended';
    result.sort((a, b) => {
      switch (sort) {
        case 'rating':
          return b.rating - a.rating;

        case 'deliveryTime':
          return a.deliveryTimeMin - b.deliveryTimeMin;

        case 'distance':
          return a.distanceKm - b.distanceKm;

        case 'priceLow':
          return a.priceForTwo - b.priceForTwo;

        case 'priceHigh':
          return b.priceForTwo - a.priceForTwo;

        case 'recommended':
        default: {
          // Smart composite score: High rating + short distance + featured bonus
          const scoreA = a.rating * 1.5 - a.distanceKm * 0.3 + (a.isFeatured ? 1 : 0);
          const scoreB = b.rating * 1.5 - b.distanceKm * 0.3 + (b.isFeatured ? 1 : 0);
          return scoreB - scoreA;
        }
      }
    });

    return result;
  },
};
