/**
 * Customer Reviews & Ratings Persistence Service
 * Persists locally and synchronizes to Firestore database.
 */

import { UserReview } from '../types/profile';
import { firestoreService } from './firebase/firestoreService';

const STORAGE_KEY = 'foodgo_user_reviews_v1';

const INITIAL_REVIEWS: UserReview[] = [
  {
    id: 'rev_1',
    orderId: '#FG-78219',
    restaurantId: 'rest_1',
    restaurantName: 'Paradise Biryani Palace',
    overallRating: 5,
    foodRating: 5,
    deliveryRating: 5,
    comment: 'Authentic Hyderabadi flavors! Chicken was juicy and tender, delivered piping hot within 25 minutes.',
    createdAt: 'Yesterday, 8:40 PM',
  },
  {
    id: 'rev_2',
    orderId: '#FG-64102',
    restaurantId: 'rest_3',
    restaurantName: 'Truffles American Bistro',
    overallRating: 4,
    foodRating: 4,
    deliveryRating: 5,
    comment: 'Smashed burger was delicious. Extra caramelized onions were generous.',
    createdAt: '3 days ago',
  },
];

export const reviewService = {
  getReviews(): UserReview[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {}
    return INITIAL_REVIEWS;
  },

  addReview(review: Omit<UserReview, 'id' | 'createdAt'>): UserReview {
    const current = this.getReviews();
    const newRev: UserReview = {
      ...review,
      id: `rev_${Date.now()}`,
      createdAt: 'Just now',
    };
    const updated = [newRev, ...current];
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch {}

    // Synchronize to Firestore
    firestoreService.saveReview(newRev).catch((err) => {
      console.warn('Firestore review sync:', err);
    });

    return newRev;
  },

  deleteReview(id: string): UserReview[] {
    const current = this.getReviews();
    const updated = current.filter((r) => r.id !== id);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch {}
    return updated;
  },
};
