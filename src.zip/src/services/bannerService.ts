/**
 * Banner Management Service
 * Manages admin-customizable homepage promotional banners via Firestore database.
 * Supports real-time subscriptions, seeding defaults, add, edit, and delete operations.
 */

import {
  collection,
  doc,
  setDoc,
  getDocs,
  deleteDoc,
  onSnapshot,
} from 'firebase/firestore';
import { db } from './firebase/firebase';
import { handleFirestoreError, OperationType } from './firebase/firestoreError';
import { OfferBanner } from '../types/restaurant';
import { MOCK_OFFERS } from './mock/mockData';

const COLLECTION_NAME = 'banners';

export const bannerService = {
  /**
   * Fetch all active banners from Firestore with fallback to default mock offers
   */
  async getBanners(): Promise<OfferBanner[]> {
    try {
      const colRef = collection(db, COLLECTION_NAME);
      const snapshot = await getDocs(colRef);

      if (!snapshot.empty) {
        const banners: OfferBanner[] = [];
        snapshot.forEach((docSnap) => {
          banners.push(docSnap.data() as OfferBanner);
        });
        return banners;
      }

      // If empty in Firestore, seed default banners
      await this.seedInitialBanners();
      return MOCK_OFFERS;
    } catch (error) {
      console.warn('Could not fetch banners from Firestore, falling back to defaults:', error);
      return MOCK_OFFERS;
    }
  },

  /**
   * Real-time listener for homepage banners
   */
  subscribeBanners(callback: (banners: OfferBanner[]) => void): () => void {
    try {
      const colRef = collection(db, COLLECTION_NAME);
      return onSnapshot(
        colRef,
        (snapshot) => {
          if (!snapshot.empty) {
            const list: OfferBanner[] = [];
            snapshot.forEach((d) => list.push(d.data() as OfferBanner));
            callback(list);
          } else {
            callback(MOCK_OFFERS);
          }
        },
        (error) => {
          console.warn('Banner real-time listener error:', error);
          callback(MOCK_OFFERS);
        }
      );
    } catch {
      callback(MOCK_OFFERS);
      return () => {};
    }
  },

  /**
   * Add or update a homepage banner in Firestore
   */
  async saveBanner(banner: OfferBanner): Promise<void> {
    const path = `${COLLECTION_NAME}/${banner.id}`;
    try {
      const docRef = doc(db, COLLECTION_NAME, banner.id);
      await setDoc(docRef, {
        ...banner,
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  /**
   * Delete a banner from Firestore
   */
  async deleteBanner(id: string): Promise<void> {
    const path = `${COLLECTION_NAME}/${id}`;
    try {
      const docRef = doc(db, COLLECTION_NAME, id);
      await deleteDoc(docRef);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  /**
   * Seeds initial default banners to Firestore if collection is empty
   */
  async seedInitialBanners(): Promise<void> {
    try {
      for (const banner of MOCK_OFFERS) {
        const docRef = doc(db, COLLECTION_NAME, banner.id);
        await setDoc(docRef, {
          ...banner,
          createdAt: new Date().toISOString(),
        });
      }
    } catch (err) {
      console.warn('Error seeding initial banners:', err);
    }
  },
};
