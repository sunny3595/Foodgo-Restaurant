/**
 * Secure Storage Service
 * Provides secure token storage, session retrieval, and persistence.
 * Designed to cleanly map to react-native-keychain / expo-secure-store in native builds,
 * and memory/obfuscated storage in web environments.
 */

import { AuthTokens, User } from '../../types/auth';

const STORAGE_KEYS = {
  ACCESS_TOKEN: 'foodgo_secure_access_token',
  REFRESH_TOKEN: 'foodgo_secure_refresh_token',
  USER_DATA: 'foodgo_user_data',
  ONBOARDING_COMPLETED: 'foodgo_onboarding_completed',
  THEME_PREFERENCE: 'foodgo_theme_preference',
  SAVED_ADDRESSES: 'foodgo_saved_addresses',
  SELECTED_ADDRESS_ID: 'foodgo_selected_address_id',
} as const;

// Base64 helper for light obfuscation on web (in React Native, Expo SecureStore is used)
const encode = (val: string): string => {
  try {
    return btoa(unescape(encodeURIComponent(val)));
  } catch {
    return val;
  }
};

const decode = (val: string): string => {
  try {
    return decodeURIComponent(escape(atob(val)));
  } catch {
    return val;
  }
};

export const secureStorage = {
  async setTokens(tokens: AuthTokens): Promise<void> {
    try {
      localStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, encode(tokens.accessToken));
      localStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, encode(tokens.refreshToken));
    } catch (err) {
      console.error('Failed to store secure tokens', err);
    }
  },

  async getAccessToken(): Promise<string | null> {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
      return raw ? decode(raw) : null;
    } catch {
      return null;
    }
  },

  async getRefreshToken(): Promise<string | null> {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.REFRESH_TOKEN);
      return raw ? decode(raw) : null;
    } catch {
      return null;
    }
  },

  async clearTokens(): Promise<void> {
    try {
      localStorage.removeItem(STORAGE_KEYS.ACCESS_TOKEN);
      localStorage.removeItem(STORAGE_KEYS.REFRESH_TOKEN);
      localStorage.removeItem(STORAGE_KEYS.USER_DATA);
    } catch (err) {
      console.error('Failed to clear secure storage', err);
    }
  },

  async setUser(user: User): Promise<void> {
    try {
      localStorage.setItem(STORAGE_KEYS.USER_DATA, JSON.stringify(user));
    } catch (err) {
      console.error('Failed to store user profile', err);
    }
  },

  async getUser(): Promise<User | null> {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.USER_DATA);
      return raw ? (JSON.parse(raw) as User) : null;
    } catch {
      return null;
    }
  },

  async setOnboardingCompleted(completed: boolean): Promise<void> {
    try {
      localStorage.setItem(STORAGE_KEYS.ONBOARDING_COMPLETED, completed ? 'true' : 'false');
    } catch {}
  },

  async isOnboardingCompleted(): Promise<boolean> {
    try {
      return localStorage.getItem(STORAGE_KEYS.ONBOARDING_COMPLETED) === 'true';
    } catch {
      return false;
    }
  },

  async setTheme(theme: 'system' | 'light' | 'dark'): Promise<void> {
    try {
      localStorage.setItem(STORAGE_KEYS.THEME_PREFERENCE, theme);
    } catch {}
  },

  async getTheme(): Promise<'system' | 'light' | 'dark' | null> {
    try {
      const theme = localStorage.getItem(STORAGE_KEYS.THEME_PREFERENCE);
      if (theme === 'light' || theme === 'dark' || theme === 'system') {
        return theme;
      }
      return null;
    } catch {
      return null;
    }
  },
};
