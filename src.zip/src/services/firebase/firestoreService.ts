/**
 * Firestore Database Services for FoodGo Customer
 * Handles persistence for:
 * 1. Customer User Profile & Profile Edits
 * 2. Saved Delivery Addresses
 * 3. Previous and Active Food Orders
 * 4. Reviews and Ratings
 */

import {
  doc,
  setDoc,
  getDoc,
  getDocs,
  collection,
  deleteDoc,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db } from './firebase';
import { handleFirestoreError, OperationType } from './firestoreError';
import { User } from '../../types/auth';
import { Address } from '../../types/location';
import { Order } from '../../types/order';
import { UserReview } from '../../types/profile';

export const firestoreService = {
  // ==========================================
  // 1. CUSTOMER PROFILE
  // ==========================================
  async saveUserProfile(user: User): Promise<void> {
    const path = `users/${user.id}`;
    try {
      const userRef = doc(db, 'users', user.id);
      await setDoc(
        userRef,
        {
          id: user.id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          phone: user.phone,
          avatarUrl: user.avatarUrl || '',
          defaultAddressId: user.defaultAddressId || '',
          role: 'customer',
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  async getUserProfile(userId: string): Promise<Partial<User> | null> {
    const path = `users/${userId}`;
    try {
      const userRef = doc(db, 'users', userId);
      const snap = await getDoc(userRef);
      if (snap.exists()) {
        return snap.data() as Partial<User>;
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
    }
  },

  /**
   * Check if a user with this mobile number already exists in Firestore database
   */
  async getUserByPhone(phone: string): Promise<{
    exists: boolean;
    isProfileComplete: boolean;
    user?: User;
    addresses?: Address[];
  }> {
    const cleanDigits = phone.replace(/\D/g, '').slice(-10);
    const userId = `user_${cleanDigits}`;
    const path = `users/${userId}`;
    try {
      const userRef = doc(db, 'users', userId);
      const snap = await getDoc(userRef);
      if (snap.exists()) {
        const data = snap.data();
        const hasCompletedProfile = Boolean(
          (data.isProfileComplete || (data.firstName && data.email)) &&
            data.firstName.trim().length > 0
        );

        const user: User = {
          id: userId,
          firstName: data.firstName || '',
          lastName: data.lastName || '',
          email: data.email || '',
          phone: data.phone || `+91 ${cleanDigits}`,
          avatarUrl: data.avatarUrl || '',
          defaultAddressId: data.defaultAddressId || '',
          role: 'customer',
          isPhoneVerified: true,
          isEmailVerified: Boolean(data.isEmailVerified),
          isProfileComplete: hasCompletedProfile,
          createdAt: data.createdAt || new Date().toISOString(),
        };

        // Fetch user's saved delivery addresses if existing
        let addresses: Address[] = [];
        try {
          const addrColl = collection(db, 'users', userId, 'addresses');
          const addrSnap = await getDocs(addrColl);
          addresses = addrSnap.docs.map((d) => d.data() as Address);
        } catch (err) {
          console.warn('Could not fetch user addresses:', err);
        }

        return {
          exists: true,
          isProfileComplete: hasCompletedProfile,
          user,
          addresses,
        };
      }
      return { exists: false, isProfileComplete: false };
    } catch (error) {
      console.warn('Error fetching user by phone from Firestore:', error);
      return { exists: false, isProfileComplete: false };
    }
  },

  /**
   * Creates an initial new account record in Firestore when a new mobile number logs in
   */
  async createNewUserWithPhone(phone: string): Promise<User> {
    const cleanDigits = phone.replace(/\D/g, '').slice(-10);
    const userId = `user_${cleanDigits}`;
    const path = `users/${userId}`;

    const newUser: User = {
      id: userId,
      firstName: '',
      lastName: '',
      email: '',
      phone: `+91 ${cleanDigits}`,
      role: 'customer',
      isPhoneVerified: true,
      isEmailVerified: false,
      isProfileComplete: false,
      createdAt: new Date().toISOString(),
    };

    try {
      const userRef = doc(db, 'users', userId);
      await setDoc(
        userRef,
        {
          ...newUser,
          isProfileComplete: false,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
      return newUser;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
      return newUser;
    }
  },

  /**
   * Completes a new user's profile with name, email, and doorstep address in Firestore
   */
  async completeUserProfile(
    userId: string,
    profile: { firstName: string; lastName: string; email: string },
    address: Address
  ): Promise<{ user: User; address: Address }> {
    const path = `users/${userId}`;
    try {
      const userRef = doc(db, 'users', userId);
      const userSnap = await getDoc(userRef);
      const existingData = userSnap.exists() ? userSnap.data() : {};

      const updatedUser: User = {
        id: userId,
        firstName: profile.firstName.trim(),
        lastName: profile.lastName.trim(),
        email: profile.email.trim().toLowerCase(),
        phone: existingData.phone || `+91 ${userId.replace('user_', '')}`,
        role: 'customer',
        defaultAddressId: address.id,
        isPhoneVerified: true,
        isEmailVerified: false,
        isProfileComplete: true,
        createdAt: existingData.createdAt || new Date().toISOString(),
      };

      await setDoc(
        userRef,
        {
          ...updatedUser,
          isProfileComplete: true,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );

      // Save delivery address under user's addresses subcollection
      const addrPath = `users/${userId}/addresses/${address.id}`;
      try {
        const addrRef = doc(db, 'users', userId, 'addresses', address.id);
        await setDoc(addrRef, {
          id: address.id,
          userId,
          label: address.label,
          receiverName: address.receiverName,
          phone: address.phone,
          flatBuilding: address.flatBuilding,
          streetArea: address.streetArea,
          landmark: address.landmark || '',
          city: address.city,
          state: address.state,
          postalCode: address.postalCode,
          isDefault: address.isDefault,
          coordinates: address.coordinates,
          updatedAt: new Date().toISOString(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, addrPath);
      }

      return { user: updatedUser, address };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
      throw error;
    }
  },

  // ==========================================
  // 2. SAVED ADDRESSES
  // ==========================================
  async saveAddress(userId: string, address: Address): Promise<void> {
    const path = `users/${userId}/addresses/${address.id}`;
    try {
      const addrRef = doc(db, 'users', userId, 'addresses', address.id);
      await setDoc(addrRef, {
        id: address.id,
        userId,
        label: address.label,
        receiverName: address.receiverName,
        phone: address.phone,
        flatBuilding: address.flatBuilding,
        streetArea: address.streetArea,
        landmark: address.landmark || '',
        city: address.city,
        state: address.state,
        postalCode: address.postalCode,
        isDefault: address.isDefault,
        coordinates: address.coordinates,
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  async getUserAddresses(userId: string): Promise<Address[]> {
    const path = `users/${userId}/addresses`;
    try {
      const colRef = collection(db, 'users', userId, 'addresses');
      const snap = await getDocs(colRef);
      return snap.docs.map((d) => d.data() as Address);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  async deleteAddress(userId: string, addressId: string): Promise<void> {
    const path = `users/${userId}/addresses/${addressId}`;
    try {
      await deleteDoc(doc(db, 'users', userId, 'addresses', addressId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // ==========================================
  // 3. PREVIOUS & ACTIVE ORDERS
  // ==========================================
  async saveOrder(userId: string, order: Order): Promise<void> {
    const cleanOrderId = order.id.replace(/[^a-zA-Z0-9_-]/g, '') || `ord_${Date.now()}`;
    const path = `users/${userId}/orders/${cleanOrderId}`;
    try {
      const orderRef = doc(db, 'users', userId, 'orders', cleanOrderId);
      await setDoc(orderRef, {
        id: order.id,
        userId,
        restaurantId: order.restaurant.id,
        restaurantName: order.restaurant.name,
        status: order.status,
        paymentMethod: order.paymentMethod,
        paymentStatus: order.paymentStatus,
        paymentDetailsSummary: order.paymentDetailsSummary,
        totalAmount: order.bill.totalPayable,
        itemsCount: order.items.reduce((s, i) => s + i.quantity, 0),
        items: order.items.map((i) => ({
          id: i.id,
          foodId: i.food.id,
          name: i.food.name,
          quantity: i.quantity,
          unitPrice: i.unitPrice,
          variation: i.customization.variation?.name || null,
          addons: i.customization.addons.map((a) => a.name),
        })),
        deliveryAddressSummary: `${order.deliveryAddress.flatBuilding}, ${order.deliveryAddress.streetArea}`,
        placedAt: order.placedAt,
        estimatedDeliveryTimestamp: order.estimatedDeliveryTimestamp,
        estimatedDeliveryMinutes: order.estimatedDeliveryMinutes,
        updatedAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  async getUserOrders(userId: string): Promise<Order[]> {
    const path = `users/${userId}/orders`;
    try {
      const colRef = collection(db, 'users', userId, 'orders');
      const snap = await getDocs(colRef);
      return snap.docs.map((d) => d.data() as unknown as Order);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  // ==========================================
  // 4. REVIEWS & RATINGS
  // ==========================================
  async saveReview(review: UserReview): Promise<void> {
    const path = `reviews/${review.id}`;
    try {
      // Save to public reviews collection
      const revRef = doc(db, 'reviews', review.id);
      await setDoc(revRef, {
        id: review.id,
        userId: review.id.startsWith('rev_') ? 'usr_customer_default' : review.id,
        orderId: review.orderId,
        restaurantId: review.restaurantId,
        restaurantName: review.restaurantName,
        overallRating: review.overallRating,
        foodRating: review.foodRating,
        deliveryRating: review.deliveryRating,
        comment: review.comment,
        createdAt: review.createdAt,
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  async getAllReviews(): Promise<UserReview[]> {
    const path = 'reviews';
    try {
      const colRef = collection(db, 'reviews');
      const snap = await getDocs(query(colRef, limit(25)));
      return snap.docs.map((d) => d.data() as UserReview);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },
};
