/**
 * Search History Persistence Service
 * Stores recent queries with deduplication, individual deletion, and persistence.
 */

const STORAGE_KEY = 'foodgo_recent_searches';
const MAX_SEARCHES = 10;

const DEFAULT_RECENT_SEARCHES = [
  'Paradise Biryani',
  'Butter Chicken',
  'Ghee Roast Dosa',
  'Truffles Burger',
];

export const searchHistoryService = {
  getRecentSearches(): string[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return DEFAULT_RECENT_SEARCHES;
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : DEFAULT_RECENT_SEARCHES;
    } catch {
      return DEFAULT_RECENT_SEARCHES;
    }
  },

  addSearch(query: string): string[] {
    const trimmed = query.trim();
    if (!trimmed) return this.getRecentSearches();

    try {
      const current = this.getRecentSearches();
      // Remove duplicate and unshift to front
      const filtered = current.filter((q) => q.toLowerCase() !== trimmed.toLowerCase());
      const updated = [trimmed, ...filtered].slice(0, MAX_SEARCHES);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    } catch {
      return [trimmed];
    }
  },

  removeSearch(query: string): string[] {
    try {
      const current = this.getRecentSearches();
      const updated = current.filter((q) => q.toLowerCase() !== query.toLowerCase());
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    } catch {
      return [];
    }
  },

  clearAll(): string[] {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {}
    return [];
  },
};
