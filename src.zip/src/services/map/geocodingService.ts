/**
 * FoodGo Customer - Google Maps Geocoding & Reverse Geocoding Service
 * Complies with Google Maps Platform standards and supports server-proxied requests.
 */

export interface ReverseGeocodeResult {
  formattedAddress: string;
  streetArea: string;
  city: string;
  state: string;
  postalCode: string;
  landmark?: string;
  flatBuilding?: string;
}

function parseAddressComponents(
  components: any[],
  formattedAddress?: string
): {
  city: string;
  state: string;
  postalCode: string;
  streetArea: string;
  flatBuilding?: string;
  landmark?: string;
} {
  let streetNumber = '';
  let route = '';
  let sublocality = '';
  let sublocality2 = '';
  let locality = '';
  let adminArea2 = '';
  let adminArea1 = '';
  let postalCode = '';
  let premise = '';
  let subpremise = '';
  let neighborhood = '';
  let pointOfInterest = '';

  for (const comp of components) {
    const types: string[] = comp.types || [];
    if (types.includes('street_number')) streetNumber = comp.long_name;
    if (types.includes('route')) route = comp.long_name;
    if (types.includes('sublocality_level_1')) sublocality = comp.long_name;
    if (types.includes('sublocality') && !sublocality) sublocality = comp.long_name;
    if (types.includes('sublocality_level_2')) sublocality2 = comp.long_name;
    if (types.includes('neighborhood')) neighborhood = comp.long_name;
    if (types.includes('premise')) premise = comp.long_name;
    if (types.includes('subpremise')) subpremise = comp.long_name;
    if (types.includes('point_of_interest') || types.includes('establishment')) {
      pointOfInterest = comp.long_name;
    }
    if (types.includes('locality')) locality = comp.long_name;
    if (types.includes('administrative_area_level_2')) adminArea2 = comp.long_name;
    if (types.includes('administrative_area_level_1')) adminArea1 = comp.long_name;
    if (types.includes('postal_code')) postalCode = comp.long_name;
  }

  const city = locality || adminArea2 || 'Tirupati';
  const state = adminArea1 || 'Andhra Pradesh';
  const streetArea =
    [sublocality, route].filter(Boolean).join(', ') ||
    [neighborhood, sublocality2].filter(Boolean).join(', ') ||
    (formattedAddress ? formattedAddress.split(',')[0].trim() : 'Pinned Location');

  // Build a distinct flat/building/house identifier
  let flatBuilding = '';
  if (premise) {
    flatBuilding = subpremise ? `${subpremise}, ${premise}` : premise;
  } else if (pointOfInterest) {
    flatBuilding = pointOfInterest;
  } else if (streetNumber) {
    flatBuilding = `House #${streetNumber}`;
  } else if (formattedAddress) {
    const firstPart = formattedAddress.split(',')[0].trim();
    if (firstPart && firstPart !== streetArea && !firstPart.includes(city)) {
      flatBuilding = firstPart;
    } else {
      flatBuilding = `Doorstep, ${streetArea.split(',')[0]}`;
    }
  } else {
    flatBuilding = 'Doorstep Location';
  }

  const landmark =
    pointOfInterest ||
    sublocality2 ||
    neighborhood ||
    (sublocality ? `Near ${sublocality}` : undefined);

  return {
    city,
    state,
    postalCode: postalCode || '517501',
    streetArea: streetArea || 'Pinned Location',
    flatBuilding: flatBuilding || 'Doorstep Location',
    landmark: landmark || (streetArea ? `Near ${streetArea.split(',')[0]}` : undefined),
  };
}

export async function reverseGeocodeCoords(
  lat: number,
  lng: number,
  apiKey: string
): Promise<ReverseGeocodeResult | null> {
  // 1. Try Google Maps JavaScript Geocoder if available on window
  try {
    if (typeof window !== 'undefined' && (window as any).google?.maps?.Geocoder) {
      const geocoder = new (window as any).google.maps.Geocoder();
      const res = await new Promise<{ results: any[]; status: string }>((resolve) => {
        geocoder.geocode({ location: { lat, lng } }, (results: any[], status: string) => {
          resolve({ results: results || [], status });
        });
      });

      if (res.status === 'OK' && res.results.length > 0) {
        const first = res.results[0];
        const parsed = parseAddressComponents(first.address_components || [], first.formatted_address);
        return {
          formattedAddress: first.formatted_address || `${parsed.streetArea}, ${parsed.city}`,
          streetArea: parsed.streetArea,
          city: parsed.city,
          state: parsed.state,
          postalCode: parsed.postalCode,
          flatBuilding: parsed.flatBuilding,
          landmark: parsed.landmark,
        };
      }
    }
  } catch (err) {
    console.warn('In-browser Geocoder attempt failed, falling back to proxy:', err);
  }

  // 2. Fallback to server/vite-proxied REST geocode request
  if (!apiKey) {
    return {
      formattedAddress: `Pinned Location (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
      streetArea: `Bypass Road, Tirupati`,
      city: 'Tirupati',
      state: 'Andhra Pradesh',
      postalCode: '517501',
      flatBuilding: 'Doorstep Location',
      landmark: 'Near Alipiri Gate',
    };
  }

  try {
    const url = `/api/maps/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`;
    const response = await fetch(url);

    if (response.status === 429) {
      window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
      return null;
    }

    const data = await response.json();

    if (data.status === 'RESOURCE_EXHAUSTED' || data.status === 'OVER_QUERY_LIMIT') {
      window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
      return null;
    }

    if (data.status !== 'OK' || !data.results || data.results.length === 0) {
      return null;
    }

    const firstResult = data.results[0];
    const components = firstResult.address_components || [];
    const parsed = parseAddressComponents(components, firstResult.formatted_address);

    return {
      formattedAddress: firstResult.formatted_address,
      streetArea: parsed.streetArea,
      city: parsed.city,
      state: parsed.state,
      postalCode: parsed.postalCode,
      flatBuilding: parsed.flatBuilding,
      landmark: parsed.landmark,
    };
  } catch (err) {
    console.warn('Reverse geocode request failed:', err);
    return null;
  }
}
