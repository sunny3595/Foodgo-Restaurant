/**
 * Geolocation & Distance Calculation Utilities
 * Uses the Haversine formula to compute true geographical distance,
 * estimates delivery ETA based on distance and traffic, and calculates delivery fees.
 */

import { Coordinates } from '../types/location';

/**
 * Calculates the great-circle distance between two coordinates in kilometers (Haversine formula).
 */
export const calculateDistanceKm = (coord1: Coordinates, coord2: Coordinates): number => {
  const R = 6371; // Earth's mean radius in km
  const dLat = toRad(coord2.latitude - coord1.latitude);
  const dLon = toRad(coord2.longitude - coord1.longitude);

  const lat1 = toRad(coord1.latitude);
  const lat2 = toRad(coord2.latitude);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;

  return Math.round(distance * 10) / 10; // Round to 1 decimal place
};

const toRad = (deg: number): number => {
  return (deg * Math.PI) / 180;
};

/**
 * Calculates estimated delivery time window in minutes based on distance.
 * Base prep time = 15-20 min + 3-4 min per km.
 */
export const estimateDeliveryTime = (distanceKm: number): { min: number; max: number } => {
  const basePrep = 15;
  const transitTime = Math.round(distanceKm * 3.5);
  const min = basePrep + transitTime;
  const max = min + 8;
  return { min, max };
};

/**
 * Calculates delivery fee based on distance and order subtotal.
 * Free delivery for orders over ₹299 or within 1.5 km.
 */
export const calculateDeliveryFee = (distanceKm: number, subtotal = 0): number => {
  if (subtotal >= 299) return 0;
  if (distanceKm <= 1.5) return 20;
  if (distanceKm <= 3.0) return 30;
  if (distanceKm <= 5.0) return 40;
  return 50; // standard cap for deliveries up to 10 km
};

/**
 * Verifies if current time falls within restaurant operating hours.
 */
export const isRestaurantOpenNow = (
  openingHour = 10, // 10:00 AM
  closingHour = 23  // 11:00 PM
): { isOpen: boolean; statusText: string } => {
  const now = new Date();
  const currentHour = now.getHours();

  const isOpen = currentHour >= openingHour && currentHour < closingHour;

  if (isOpen) {
    const formattedClose = closingHour > 12 ? `${closingHour - 12}:00 PM` : `${closingHour}:00 AM`;
    return { isOpen: true, statusText: `Open until ${formattedClose}` };
  } else {
    const formattedOpen = openingHour > 12 ? `${openingHour - 12}:00 AM` : `${openingHour}:00 AM`;
    return { isOpen: false, statusText: `Opens at ${formattedOpen}` };
  }
};
