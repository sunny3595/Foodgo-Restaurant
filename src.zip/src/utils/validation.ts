/**
 * Authentication and Input Validation Utilities
 * Strict validation for email, Indian phone numbers, password strength, and referral codes.
 */

export interface ValidationResult {
  isValid: boolean;
  error?: string;
}

export interface PasswordStrength {
  score: number; // 0 to 4
  label: 'Too Weak' | 'Weak' | 'Medium' | 'Strong';
  color: string;
}

export const validateEmail = (email: string): ValidationResult => {
  if (!email || !email.trim()) {
    return { isValid: false, error: 'Email address is required' };
  }
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(email.trim())) {
    return { isValid: false, error: 'Please enter a valid email address (e.g. name@example.com)' };
  }
  return { isValid: true };
};

export const validatePhone = (phone: string): ValidationResult => {
  const cleaned = phone.replace(/\D/g, '');
  if (!cleaned) {
    return { isValid: false, error: 'Mobile number is required' };
  }
  // Standard 10-digit Indian mobile number starting with 6, 7, 8, or 9
  const phoneRegex = /^[6-9]\d{9}$/;
  if (!phoneRegex.test(cleaned)) {
    return {
      isValid: false,
      error: 'Please enter a valid 10-digit Indian mobile number (e.g. 9876543210)',
    };
  }
  return { isValid: true };
};

export const evaluatePasswordStrength = (password: string): PasswordStrength => {
  if (!password) {
    return { score: 0, label: 'Too Weak', color: 'bg-slate-300 dark:bg-slate-700' };
  }

  let score = 0;
  if (password.length >= 8) score += 1;
  if (/[A-Z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;

  if (score <= 1) {
    return { score: 1, label: 'Too Weak', color: 'bg-red-500' };
  }
  if (score === 2) {
    return { score: 2, label: 'Weak', color: 'bg-amber-500' };
  }
  if (score === 3) {
    return { score: 3, label: 'Medium', color: 'bg-blue-500' };
  }
  return { score: 4, label: 'Strong', color: 'bg-emerald-500' };
};

export const validatePassword = (password: string): ValidationResult => {
  if (!password) {
    return { isValid: false, error: 'Password is required' };
  }
  if (password.length < 8) {
    return { isValid: false, error: 'Password must be at least 8 characters long' };
  }
  if (!/[0-9]/.test(password) && !/[^A-Za-z0-9]/.test(password)) {
    return { isValid: false, error: 'Password must include at least one number or special symbol' };
  }
  return { isValid: true };
};

export const validateReferralCode = (code: string): ValidationResult => {
  if (!code || !code.trim()) return { isValid: true };
  const trimmed = code.trim().toUpperCase();
  if (!/^[A-Z0-9]{5,12}$/.test(trimmed)) {
    return { isValid: false, error: 'Referral code must be 5-12 alphanumeric characters' };
  }
  return { isValid: true };
};
