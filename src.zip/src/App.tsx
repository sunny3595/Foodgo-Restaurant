/**
 * FoodGo Customer - Master Application Orchestrator
 * Phase 8 Order Tracking & Interactive Map Integration:
 * - Splash -> Onboarding -> Location Permission -> Auth -> Home
 * - Real-time animated Delivery Tracking Map with rider movement simulation
 * - Interactive Map Address Pinpoint Picker
 * - In-App Rider Chat with automatic responses & Phone Dialer modal
 * - Order Confirmation -> Live Order Tracking Screen
 * - Single-Restaurant Cart Conflict Detection & Modal
 * - Guest action protection and session management
 */

import React, { useState, useEffect } from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';
import { ThemeProvider } from './store/themeContext';
import { AuthProvider, useAuth } from './store/authContext';
import { LocationProvider, useLocation } from './store/locationContext';
import { AppProvider, useApp } from './store/appContext';
import { CartProvider, useCart } from './store/cartContext';
import { OrderProvider, useOrder } from './store/orderContext';
import { FavoritesProvider } from './store/favoritesContext';

import { SplashScreen } from './screens/Splash/SplashScreen';
import { OnboardingScreen } from './screens/Onboarding/OnboardingScreen';
import { LocationPermissionModal } from './screens/Location/LocationPermissionModal';
import { LoginScreen } from './screens/Auth/LoginScreen';
import { GuestLoginPromptModal } from './screens/Auth/GuestLoginPromptModal';
import { HomeScreen } from './screens/Home/HomeScreen';
import { SearchScreen } from './screens/Tabs/SearchScreen';
import { OrdersScreen } from './screens/Tabs/OrdersScreen';
import { FavoritesScreen } from './screens/Tabs/FavoritesScreen';
import { ProfileScreen } from './screens/Tabs/ProfileScreen';
import { AddressPickerModal } from './screens/Home/AddressPickerModal';
import { RestaurantDetailScreen } from './screens/Restaurant/RestaurantDetailScreen';
import { CartScreen } from './screens/Cart/CartScreen';
import { PaymentScreen } from './screens/Payment/PaymentScreen';
import { OrderConfirmationScreen } from './screens/Order/OrderConfirmationScreen';
import { OrderTrackingScreen } from './screens/Order/OrderTrackingScreen';
import { CartConflictModal } from './components/cart/CartConflictModal';

import { BottomTabBar } from './components/navigation/BottomTabBar';
import { OfflineBanner } from './components/feedback/OfflineBanner';
import { ToastContainer } from './components/feedback/Toast';
import { DeviceFrame } from './components/preview/DeviceFrame';

import { ScreenType, MainTabType } from './types/navigation';
import { Restaurant } from './types/restaurant';
import { Order } from './types/order';
import { restaurantService } from './services/restaurantService';
import { secureStorage } from './services/storage/secureStorage';

const FoodGoAppContent: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('splash');
  const [activeTab, setActiveTab] = useState<MainTabType>('home');
  const [showLocationPrompt, setShowLocationPrompt] = useState<boolean>(false);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState<boolean>(false);

  // Screen overlay & tracking states
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState<boolean>(false);
  const [isOrderConfirmedOpen, setIsOrderConfirmedOpen] = useState<boolean>(false);
  const [trackingOrder, setTrackingOrder] = useState<Order | null>(null);

  const { guestPromptOpen, guestPromptContext, setGuestPromptOpen } = useAuth();
  const { currentAddress } = useLocation();
  const { totalItems, subtotal } = useCart();
  const { activeOrder } = useOrder();
  const { showToast } = useApp();

  const [quotaExceeded, setQuotaExceeded] = useState<boolean>(false);

  useEffect(() => {
    const handleQuota = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handleQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuota);
  }, []);

  // Restart entire journey for review & testing
  const handleResetFlow = async () => {
    await secureStorage.setOnboardingCompleted(false);
    await secureStorage.clearTokens();
    setSelectedRestaurant(null);
    setIsCartOpen(false);
    setIsPaymentOpen(false);
    setIsOrderConfirmedOpen(false);
    setTrackingOrder(null);
    setCurrentScreen('splash');
    setActiveTab('home');
  };

  // Splash Finish Handler
  const handleSplashFinish = (nextScreen: 'onboarding' | 'auth' | 'main') => {
    if (nextScreen === 'onboarding') {
      setCurrentScreen('onboarding');
    } else if (nextScreen === 'auth') {
      setCurrentScreen('auth');
    } else {
      setCurrentScreen('main');
    }
  };

  // Onboarding Finish Handler
  const handleOnboardingFinish = () => {
    setShowLocationPrompt(true);
  };

  const handleLocationResolved = () => {
    setShowLocationPrompt(false);
    setCurrentScreen('auth');
  };

  const handleOpenRestaurant = (restaurantId: string) => {
    const list = restaurantService.getProcessedRestaurants(currentAddress.coordinates);
    const found = list.find((r) => r.id === restaurantId);
    if (found) {
      setSelectedRestaurant(found);
    }
  };

  return (
    <DeviceFrame onResetFlow={handleResetFlow}>
      {/* Google Maps Quota Warning Banner */}
      {quotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* Offline Status Alert */}
      <OfflineBanner />

      {/* Global Toast Alerts */}
      <ToastContainer />

      {/* Single-Restaurant Cart Conflict Warning Modal */}
      <CartConflictModal />

      {/* Screen Router */}
      {currentScreen === 'splash' && (
        <SplashScreen onFinish={handleSplashFinish} />
      )}

      {currentScreen === 'onboarding' && (
        <>
          <OnboardingScreen onComplete={handleOnboardingFinish} />
          <LocationPermissionModal
            isOpen={showLocationPrompt}
            onResolved={handleLocationResolved}
          />
        </>
      )}

      {currentScreen === 'auth' && (
        <LoginScreen onLoginSuccess={() => setCurrentScreen('main')} />
      )}

      {currentScreen === 'main' && (
        <div className="flex-1 flex flex-col relative min-h-full">
          {/* Live Order Tracking Screen */}
          {trackingOrder ? (
            <OrderTrackingScreen
              order={trackingOrder}
              onBack={() => setTrackingOrder(null)}
            />
          ) : isOrderConfirmedOpen && activeOrder ? (
            /* Order Placed Confirmation Screen */
            <OrderConfirmationScreen
              order={activeOrder}
              onTrackOrder={() => {
                setIsOrderConfirmedOpen(false);
                setIsPaymentOpen(false);
                setIsCartOpen(false);
                setSelectedRestaurant(null);
                setTrackingOrder(activeOrder);
              }}
              onGoHome={() => {
                setIsOrderConfirmedOpen(false);
                setIsPaymentOpen(false);
                setIsCartOpen(false);
                setSelectedRestaurant(null);
                setActiveTab('home');
              }}
            />
          ) : isPaymentOpen ? (
            /* Payment Screen View */
            <PaymentScreen
              onBack={() => setIsPaymentOpen(false)}
              onPaymentSuccess={() => {
                setIsPaymentOpen(false);
                setIsCartOpen(false);
                setIsOrderConfirmedOpen(true);
              }}
            />
          ) : isCartOpen ? (
            /* Cart Screen View */
            <CartScreen
              onBack={() => setIsCartOpen(false)}
              onAddMoreItems={() => setIsCartOpen(false)}
              onProceedToPayment={() => {
                setIsPaymentOpen(true);
              }}
            />
          ) : selectedRestaurant ? (
            /* Restaurant Details & Menu View */
            <RestaurantDetailScreen
              restaurant={selectedRestaurant}
              onBack={() => setSelectedRestaurant(null)}
              onViewCart={() => setIsCartOpen(true)}
            />
          ) : (
            <>
              {/* Main Tab Views */}
              {activeTab === 'home' && (
                <HomeScreen
                  onRestaurantClick={handleOpenRestaurant}
                  onProfileClick={() => setActiveTab('profile')}
                />
              )}

              {activeTab === 'search' && (
                <SearchScreen
                  onRestaurantClick={handleOpenRestaurant}
                  onViewCart={() => setIsCartOpen(true)}
                />
              )}

              {activeTab === 'orders' && (
                <OrdersScreen
                  onExplore={() => setActiveTab('home')}
                  onTrackOrder={(order) => {
                    setTrackingOrder(order);
                  }}
                />
              )}

              {activeTab === 'favorites' && (
                <FavoritesScreen
                  onExplore={() => setActiveTab('home')}
                  onRestaurantClick={(restaurantId) => {
                    const r = restaurantService.getRestaurantById(restaurantId);
                    if (r) setSelectedRestaurant(r);
                  }}
                />
              )}

              {activeTab === 'profile' && (
                <ProfileScreen
                  onLoginPrompt={() => setCurrentScreen('auth')}
                  onAddressClick={() => setIsAddressModalOpen(true)}
                />
              )}

              {/* Persistent Bottom Tab Navigation */}
              <BottomTabBar activeTab={activeTab} onTabChange={setActiveTab} />

              {/* Floating Bottom Cart Bar (if items in cart) */}
              {totalItems > 0 && !isCartOpen && !selectedRestaurant && !trackingOrder && (
                <aside
                  aria-label="Current Cart Summary"
                  className="fixed bottom-20 inset-x-4 z-40 max-w-md mx-auto"
                >
                  <div
                    onClick={() => setIsCartOpen(true)}
                    className="p-3.5 bg-[#E23744] text-white rounded-2xl shadow-xl flex items-center justify-between cursor-pointer active:scale-[0.99] transition-transform"
                  >
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider block">
                        {totalItems} {totalItems === 1 ? 'item' : 'items'} in cart
                      </span>
                      <p className="text-[11px] text-white/80 tabular-nums">
                        Subtotal: ₹{subtotal}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 font-bold text-xs bg-white text-[#E23744] px-3.5 py-1.5 rounded-xl shadow-xs">
                      <span>View Cart</span>
                    </div>
                  </div>
                </aside>
              )}
            </>
          )}

          {/* Shared Address Switcher Modal */}
          <AddressPickerModal
            isOpen={isAddressModalOpen}
            onClose={() => setIsAddressModalOpen(false)}
          />

          {/* Guest Action Protection Modal */}
          <GuestLoginPromptModal
            isOpen={guestPromptOpen}
            onClose={() => setGuestPromptOpen(false)}
            actionContext={guestPromptContext}
            onProceedToLogin={() => {
              setIsCartOpen(false);
              setIsPaymentOpen(false);
              setTrackingOrder(null);
              setCurrentScreen('auth');
            }}
          />
        </div>
      )}
    </DeviceFrame>
  );
};

export default function App() {
  const mapsApiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

  return (
    <APIProvider apiKey={mapsApiKey} libraries={['places', 'marker', 'geometry']}>
      <ThemeProvider>
        <AuthProvider>
          <LocationProvider>
            <AppProvider>
              <CartProvider>
                <OrderProvider>
                  <FavoritesProvider>
                    <FoodGoAppContent />
                  </FavoritesProvider>
                </OrderProvider>
              </CartProvider>
            </AppProvider>
          </LocationProvider>
        </AuthProvider>
      </ThemeProvider>
    </APIProvider>
  );
}
