/**
 * Slidable Interactive Promotional Banner Carousel
 * Supports:
 * - Touch swipe gestures (left/right drag)
 * - Mouse drag sliding
 * - Left/Right navigation arrows
 * - Clickable dot indicators
 * - Auto-rotation with pause on touch/hover
 * - Tap-to-apply coupon codes & category jump
 */

import React, { useState, useEffect, useRef } from 'react';
import { Tag, Copy, Check, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { OfferBanner } from '../../types/restaurant';

export interface BannerCarouselProps {
  banners: OfferBanner[];
  onApplyCoupon: (code: string) => void;
  onCategoryJump?: (categoryName: string) => void;
}

export const BannerCarousel: React.FC<BannerCarouselProps> = ({
  banners,
  onApplyCoupon,
  onCategoryJump,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);

  // Swipe / Drag gesture tracking
  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const [touchEndX, setTouchEndX] = useState<number | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const autoPlayRef = useRef<NodeJS.Timeout | null>(null);

  // Auto-play timer
  useEffect(() => {
    if (banners.length <= 1 || isPaused) return;

    autoPlayRef.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % banners.length);
    }, 4500);

    return () => {
      if (autoPlayRef.current) clearInterval(autoPlayRef.current);
    };
  }, [banners.length, isPaused]);

  // Touch Handlers for sliding
  const handleTouchStart = (e: React.TouchEvent) => {
    setIsPaused(true);
    setTouchStartX(e.targetTouches[0].clientX);
    setTouchEndX(null);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEndX(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    setIsPaused(false);
    if (!touchStartX || !touchEndX) return;
    const diff = touchStartX - touchEndX;

    if (diff > 45) {
      // Swiped Left -> Next Banner
      goToNext();
    } else if (diff < -45) {
      // Swiped Right -> Previous Banner
      goToPrev();
    }

    setTouchStartX(null);
    setTouchEndX(null);
  };

  // Mouse drag handlers for desktop sliding
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setIsPaused(true);
    setTouchStartX(e.clientX);
    setTouchEndX(null);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setTouchEndX(e.clientX);
  };

  const handleMouseUp = () => {
    if (isDragging && touchStartX && touchEndX) {
      const diff = touchStartX - touchEndX;
      if (diff > 40) {
        goToNext();
      } else if (diff < -40) {
        goToPrev();
      }
    }
    setIsDragging(false);
    setIsPaused(false);
    setTouchStartX(null);
    setTouchEndX(null);
  };

  const goToNext = () => {
    if (banners.length <= 1) return;
    setCurrentIndex((prev) => (prev + 1) % banners.length);
  };

  const goToPrev = () => {
    if (banners.length <= 1) return;
    setCurrentIndex((prev) => (prev - 1 + banners.length) % banners.length);
  };

  const handleCopy = (e: React.MouseEvent, code: string) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(code);
    setCopiedCode(code);
    onApplyCoupon(code);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const handleCardClick = (banner: OfferBanner) => {
    if (banner.targetCategory && onCategoryJump) {
      onCategoryJump(banner.targetCategory);
    }
  };

  if (!banners || banners.length === 0) return null;

  const currentBanner = banners[currentIndex];

  return (
    <div
      className="relative w-full overflow-hidden rounded-3xl select-none shadow-md group cursor-grab active:cursor-grabbing"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => {
        setIsPaused(false);
        setIsDragging(false);
      }}
    >
      {/* Active Banner Slide */}
      <div
        onClick={() => handleCardClick(currentBanner)}
        className={`relative w-full p-4 sm:p-5 bg-gradient-to-r ${currentBanner.bgGradient} text-white min-h-[148px] flex flex-col justify-between transition-all duration-300 ease-out`}
      >
        {/* Decorative Background Rings */}
        <div className="absolute -right-6 -bottom-8 w-36 h-36 rounded-full bg-white/10 pointer-events-none" />
        <div className="absolute right-16 -top-10 w-24 h-24 rounded-full bg-white/10 pointer-events-none" />

        {/* Top Badges */}
        <div className="flex items-center justify-between relative z-10">
          <div className="inline-flex items-center gap-1.5 bg-black/25 backdrop-blur-md px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>{currentBanner.badge || currentBanner.expiresInText || 'SPECIAL OFFER'}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[10px] bg-black/20 backdrop-blur-md px-2 py-0.5 rounded-full font-medium text-white/90">
              Slide to explore
            </span>
            <span className="text-[11px] font-bold text-white/90 tabular-nums">
              {currentIndex + 1} / {banners.length}
            </span>
          </div>
        </div>

        {/* Center Title & Subtitle */}
        <div className="my-2 relative z-10">
          <h3 className="text-lg font-black tracking-tight leading-tight">
            {currentBanner.title}
          </h3>
          <p className="text-xs text-white/90 mt-0.5 line-clamp-1 max-w-xs font-medium">
            {currentBanner.subtitle}
          </p>
        </div>

        {/* Bottom Bar: Promo Code & Action */}
        <div className="flex items-center justify-between relative z-10 pt-1">
          <div className="flex items-center gap-1.5 bg-white/20 backdrop-blur-md px-3 py-1 rounded-xl font-mono text-xs font-bold tracking-wider">
            <Tag className="w-3 h-3 text-amber-300" />
            <span>{currentBanner.code}</span>
          </div>

          <button
            type="button"
            onClick={(e) => handleCopy(e, currentBanner.code)}
            className="min-h-[34px] px-3.5 rounded-xl bg-white text-slate-900 text-xs font-bold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all cursor-pointer hover:bg-slate-50"
          >
            {copiedCode === currentBanner.code ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-700" />
                <span>Apply Code</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Manual Sliding Arrow Buttons */}
      {banners.length > 1 && (
        <>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              goToPrev();
            }}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/35 hover:bg-black/60 text-white backdrop-blur-md flex items-center justify-center transition-all opacity-80 group-hover:opacity-100 z-20 cursor-pointer shadow-md"
            aria-label="Previous Banner"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              goToNext();
            }}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/35 hover:bg-black/60 text-white backdrop-blur-md flex items-center justify-center transition-all opacity-80 group-hover:opacity-100 z-20 cursor-pointer shadow-md"
            aria-label="Next Banner"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </>
      )}

      {/* Clickable Pagination Dot Navigation */}
      {banners.length > 1 && (
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-20">
          {banners.map((_, idx) => (
            <button
              key={idx}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setCurrentIndex(idx);
              }}
              className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                idx === currentIndex
                  ? 'w-5 bg-white shadow-xs'
                  : 'w-1.5 bg-white/40 hover:bg-white/70'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
};
