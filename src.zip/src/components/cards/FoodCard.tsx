/**
 * Food Dish Card Component
 * Displays dish details, veg/non-veg status, price, rating, originating restaurant, and quick add action.
 */

import React, { useState } from 'react';
import { Plus, Check, Star } from 'lucide-react';
import { FoodItem, Restaurant } from '../../types/restaurant';

export interface FoodCardProps {
  food: FoodItem;
  restaurant?: Restaurant;
  onAdd?: (food: FoodItem) => void;
  onClick?: () => void;
  quantityInCart?: number;
}

export const FoodCard: React.FC<FoodCardProps> = ({
  food,
  restaurant,
  onAdd,
  onClick,
  quantityInCart,
}) => {
  const [imgError, setImgError] = useState(false);
  const [isAdded, setIsAdded] = useState(false);

  const hasCustomization =
    (food.variations && food.variations.length > 0) ||
    (food.addons && food.addons.length > 0);

  const handleAddClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!hasCustomization) {
      setIsAdded(true);
      setTimeout(() => setIsAdded(false), 1500);
    }
    onAdd?.(food);
  };

  return (
    <article
      onClick={onClick}
      className="p-3.5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 flex items-start justify-between gap-3.5 hover:shadow-xs transition-shadow cursor-pointer select-none"
    >
      {/* Left Info Column */}
      <div className="flex-1 min-w-0 space-y-1">
        {/* Veg / Non-Veg Indicator & Bestseller tag */}
        <div className="flex items-center gap-2">
          <div
            className={`w-4 h-4 border-2 flex items-center justify-center rounded-xs shrink-0 ${
              food.isVeg ? 'border-emerald-600' : 'border-red-600'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                food.isVeg ? 'bg-emerald-600' : 'bg-red-600'
              }`}
            />
          </div>

          {food.isBestseller && (
            <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
              ★ Bestseller
            </span>
          )}
        </div>

        {/* Dish Title */}
        <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
          {food.name}
        </h4>

        {/* Originating Restaurant Link */}
        {restaurant && (
          <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
            From <span className="font-semibold text-slate-700 dark:text-slate-300">{restaurant.name}</span> · {restaurant.deliveryTimeMin}-{restaurant.deliveryTimeMax} min
          </p>
        )}

        {/* Price & Rating */}
        <div className="flex items-center gap-2 pt-0.5 text-xs">
          <span className="font-extrabold text-slate-900 dark:text-slate-100 tabular-nums">
            ₹{food.price}
          </span>

          <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>

          <div className="flex items-center gap-1 text-[11px] text-emerald-600 font-bold">
            <Star className="w-3 h-3 fill-current" />
            <span className="tabular-nums">{food.rating.toFixed(1)}</span>
            <span className="text-slate-400 font-normal">({food.ratingCount})</span>
          </div>
        </div>

        {/* Short Description */}
        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 pt-0.5 leading-relaxed">
          {food.description}
        </p>
      </div>

      {/* Right Column: Image and Add CTA */}
      <div className="relative shrink-0 flex flex-col items-center">
        <div className="w-24 h-24 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800">
          {!imgError ? (
            <img
              src={food.imageUrl}
              alt={food.name}
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-2xl">
              🥘
            </div>
          )}
        </div>

        {/* Add Button pinned over bottom edge */}
        <div className="-mt-3.5 relative z-10 flex flex-col items-center">
          <button
            type="button"
            onClick={handleAddClick}
            className={`min-h-[34px] min-w-[76px] px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1 shadow-md transition-all active:scale-95 cursor-pointer ${
              quantityInCart && quantityInCart > 0
                ? 'bg-[#E23744] border-[#E23744] text-white'
                : isAdded
                ? 'bg-emerald-600 border-emerald-600 text-white'
                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-[#E23744] hover:bg-red-50 dark:hover:bg-red-950/30'
            }`}
          >
            {quantityInCart && quantityInCart > 0 ? (
              <>
                <Plus className="w-3.5 h-3.5" />
                <span>ADD ({quantityInCart})</span>
              </>
            ) : isAdded ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5" />
                <span>ADD</span>
              </>
            )}
          </button>

          {hasCustomization && (
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter mt-0.5">
              Customisable
            </span>
          )}
        </div>
      </div>
    </article>
  );
};
