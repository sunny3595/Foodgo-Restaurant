/**
 * Category Card Component
 * Compact circular/rounded visual icon button for cuisine navigation.
 */

import React, { useState } from 'react';
import { Category } from '../../types/restaurant';

export interface CategoryCardProps {
  category: Category;
  isSelected?: boolean;
  onClick?: () => void;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({
  category,
  isSelected = false,
  onClick,
}) => {
  const [imgError, setImgError] = useState(false);

  return (
    <button
      type="button"
      onClick={onClick}
      className="flex flex-col items-center gap-1.5 shrink-0 group focus:outline-none cursor-pointer"
    >
      <div
        className={`w-16 h-16 rounded-full overflow-hidden p-1 transition-all duration-200 border-2 ${
          isSelected
            ? 'border-[#E23744] ring-2 ring-red-500/20 shadow-md scale-105'
            : 'border-slate-200 dark:border-slate-800 group-hover:border-slate-300 dark:group-hover:border-slate-700'
        }`}
      >
        <div className="w-full h-full rounded-full overflow-hidden bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
          {!imgError ? (
            <img
              src={category.imageUrl}
              alt={category.name}
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              loading="lazy"
            />
          ) : (
            <span className="text-xl">🍲</span>
          )}
        </div>
      </div>

      <span
        className={`text-xs font-semibold max-w-[70px] truncate text-center transition-colors ${
          isSelected
            ? 'text-[#E23744] font-bold'
            : 'text-slate-700 dark:text-slate-300 group-hover:text-slate-900 dark:group-hover:text-white'
        }`}
      >
        {category.name}
      </span>
    </button>
  );
};
