/**
 * Horizontal Category Navigation Strip
 * Displays cuisine categories with item count indicators and active filters.
 */

import React from 'react';
import { Category } from '../../types/restaurant';
import { CategoryCard } from './CategoryCard';

export interface CategoryStripProps {
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (categoryName: string) => void;
}

export const CategoryStrip: React.FC<CategoryStripProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
}) => {
  return (
    <section aria-label="Explore Cuisines" className="space-y-2.5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            What's on your mind?
          </h2>
          <p className="text-[11px] text-slate-400">Curated dishes & regional recipes</p>
        </div>

        {selectedCategory !== 'All' && (
          <button
            type="button"
            onClick={() => onSelectCategory('All')}
            className="text-[11px] font-bold text-[#E23744] hover:underline"
          >
            Show All
          </button>
        )}
      </div>

      <div className="flex gap-4 overflow-x-auto no-scrollbar -mx-4 px-4 py-1.5 scroll-smooth">
        <CategoryCard
          category={{
            id: 'all',
            name: 'All Foods',
            iconName: 'Utensils',
            imageUrl: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=200&auto=format&fit=crop&q=80',
          }}
          isSelected={selectedCategory === 'All'}
          onClick={() => onSelectCategory('All')}
        />

        {categories.map((cat) => (
          <CategoryCard
            key={cat.id}
            category={cat}
            isSelected={selectedCategory === cat.name}
            onClick={() =>
              onSelectCategory(selectedCategory === cat.name ? 'All' : cat.name)
            }
          />
        ))}
      </div>
    </section>
  );
};
