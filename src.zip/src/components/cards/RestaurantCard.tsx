/**
 * Restaurant Card Component
 * Strictly adheres to the zero-pill metadata discipline:
 * uses clean typographic separators (·) rather than clustered capsules.
 * Dynamically computes open/closed states, distance, and free delivery thresholds.
 */

import React, { useState } from 'react';
import { Heart, Clock, MapPin, Tag } from 'lucide-react';
import { Restaurant } from '../../types/restaurant';
import { RatingBadge } from '../ui/RatingBadge';
import { useFavorites } from '../../store/favoritesContext';
import { useAuth } from '../../store/authContext';
import { useApp } from '../../store/appContext';

export interface RestaurantCardProps {
  restaurant: Restaurant;
  onClick?: () => void;
  onFavoriteToggle?: (isFav: boolean) => void;
}

export const RestaurantCard: React.FC<RestaurantCardProps> = ({
  restaurant,
  onClick,
  onFavoriteToggle,
}) => {
  const { isRestaurantFavorite, toggleRestaurantFavorite } = useFavorites();
  const { triggerProtectedAction } = useAuth();
  const { showToast } = useApp();
  const [imgError, setImgError] = useState(false);

  const isFavorite = isRestaurantFavorite(restaurant.id);

  const handleFavClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    triggerProtectedAction(() => {
      const next = toggleRestaurantFavorite(restaurant);
      showToast(
        next
          ? `Added ${restaurant.name} to Favorites`
          : `Removed ${restaurant.name} from Favorites`,
        'info'
      );
      onFavoriteToggle?.(next);
    }, 'favorites');
  };

  return (
    <article
      onClick={onClick}
      className={`group relative bg-white dark:bg-slate-900 rounded-3xl p-3 border border-slate-200/80 dark:border-slate-800 transition-all duration-200 hover:shadow-md cursor-pointer select-none ${
        !restaurant.isOpen ? 'opacity-75' : ''
      }`}
    >
      {/* Cover Image Container */}
      <div className="relative w-full h-44 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800">
        {!imgError ? (
          <img
            src={restaurant.coverImageUrl}
            alt={restaurant.name}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-rose-50 to-amber-50 dark:from-slate-800 dark:to-slate-900 text-slate-400 p-4 text-center">
            <span className="text-3xl mb-1">🍽️</span>
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
              {restaurant.name}
            </span>
          </div>
        )}

        {/* Favorite Button (Minimum 44x44 hitbox) */}
        <button
          type="button"
          onClick={handleFavClick}
          className="absolute top-2 right-2 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full bg-white/90 dark:bg-slate-900/90 backdrop-blur-xs text-slate-700 dark:text-slate-200 shadow-sm active:scale-90 transition-transform cursor-pointer z-10"
          aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              isFavorite ? 'fill-[#E23744] text-[#E23744]' : 'text-slate-700 dark:text-slate-200'
            }`}
          />
        </button>

        {/* Veg Badge if Pure Veg */}
        {restaurant.isPureVeg && (
          <div className="absolute top-2 left-2 flex items-center gap-1 bg-emerald-700/90 text-white backdrop-blur-xs px-2 py-0.5 rounded-lg text-[10px] font-semibold z-10">
            <span className="w-1.5 h-1.5 rounded-full bg-white" />
            <span>PURE VEG</span>
          </div>
        )}

        {/* Closed Overlay if outside opening hours */}
        {!restaurant.isOpen && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-2xs flex flex-col items-center justify-center text-white p-3 text-center">
            <span className="text-xs font-black uppercase tracking-wider bg-rose-600 px-2.5 py-1 rounded-lg">
              Currently Closed
            </span>
            <span className="text-[11px] font-medium mt-1 text-white/90">
              {restaurant.openingHoursText}
            </span>
          </div>
        )}

        {/* Best Offer Strip Overlay on Bottom of Image */}
        {restaurant.offers.length > 0 && restaurant.isOpen && (
          <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/85 via-black/40 to-transparent px-3 py-2 flex items-center gap-1.5 text-white">
            <Tag className="w-3 h-3 text-amber-400 shrink-0" />
            <span className="text-[11px] font-semibold truncate">{restaurant.offers[0]}</span>
          </div>
        )}
      </div>

      {/* Restaurant Content Body */}
      <div className="pt-3 px-1 space-y-1.5">
        {/* Name and Rating */}
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate flex-1 group-hover:text-[#E23744] transition-colors">
            {restaurant.name}
          </h3>
          <RatingBadge rating={restaurant.rating} count={restaurant.ratingCount} size="sm" />
        </div>

        {/* Unboxed Cuisines (Zero-Pill Rule) */}
        <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 truncate">
          <span>{restaurant.cuisines.join(' · ')}</span>
        </div>

        {/* Delivery Time, Distance, and Pricing Breakdown */}
        <div className="flex items-center gap-2 pt-1 text-[11px] text-slate-600 dark:text-slate-300 font-medium">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-slate-400" />
            <span className="tabular-nums">
              {restaurant.deliveryTimeMin}–{restaurant.deliveryTimeMax} min
            </span>
          </div>

          <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>

          <div className="flex items-center gap-1">
            <MapPin className="w-3 h-3 text-slate-400" />
            <span className="tabular-nums">{restaurant.distanceKm} km</span>
          </div>

          <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>

          <div className="tabular-nums">
            {restaurant.deliveryFee === 0 ? (
              <span className="text-emerald-600 font-bold">Free Delivery</span>
            ) : (
              <span className="text-slate-500 dark:text-slate-400">₹{restaurant.deliveryFee} delivery</span>
            )}
          </div>

          <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>

          <div className="text-slate-500 dark:text-slate-400 tabular-nums">
            ₹{restaurant.priceForTwo} for two
          </div>
        </div>
      </div>
    </article>
  );
};
