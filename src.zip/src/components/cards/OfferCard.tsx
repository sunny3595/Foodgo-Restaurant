/**
 * Promotional Offer Banner Card
 * Shows discount, promo code, and expiration details.
 */

import React, { useState } from 'react';
import { Tag, Copy, Check } from 'lucide-react';
import { OfferBanner } from '../../types/restaurant';

export interface OfferCardProps {
  offer: OfferBanner;
  onApply?: (code: string) => void;
}

export const OfferCard: React.FC<OfferCardProps> = ({ offer, onApply }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(offer.code);
    setCopied(true);
    onApply?.(offer.code);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className={`relative shrink-0 w-72 rounded-3xl p-4 bg-gradient-to-r ${offer.bgGradient} text-white shadow-md overflow-hidden flex flex-col justify-between`}
    >
      {/* Background Decal Pattern */}
      <div className="absolute -right-4 -bottom-6 w-28 h-28 rounded-full bg-white/10 pointer-events-none" />

      <div className="space-y-1 relative z-10">
        <div className="inline-flex items-center gap-1 bg-black/20 backdrop-blur-xs px-2 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider">
          <Tag className="w-3 h-3" />
          <span>{offer.expiresInText}</span>
        </div>
        <h4 className="text-base font-extrabold tracking-tight mt-1">{offer.title}</h4>
        <p className="text-xs text-white/90 line-clamp-1">{offer.subtitle}</p>
      </div>

      <div className="pt-3 flex items-center justify-between relative z-10">
        <div className="flex items-center gap-1.5 bg-white/20 backdrop-blur-xs px-2.5 py-1 rounded-xl font-mono text-xs font-bold tracking-wider">
          <span>{offer.code}</span>
        </div>

        <button
          type="button"
          onClick={handleCopy}
          className="min-h-[36px] px-3 rounded-xl bg-white text-slate-900 text-xs font-bold flex items-center gap-1 shadow-sm active:scale-95 transition-all cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Apply</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
