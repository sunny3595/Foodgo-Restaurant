/**
 * Offline Mode Banner Component
 * Warns users when the device loses network connectivity and informs that cached data is shown.
 */

import React from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';
import { useApp } from '../../store/appContext';

export const OfflineBanner: React.FC = () => {
  const { isOnline, setIsOnline } = useApp();

  if (isOnline) return null;

  return (
    <div
      role="alert"
      className="sticky top-0 z-50 bg-amber-500 text-white px-4 py-2 text-xs font-semibold flex items-center justify-between shadow-md"
    >
      <div className="flex items-center gap-2">
        <WifiOff className="w-4 h-4 shrink-0 animate-pulse" />
        <span>You are offline. Showing cached restaurants.</span>
      </div>

      <button
        type="button"
        onClick={() => setIsOnline(navigator.onLine)}
        className="px-2 py-0.5 rounded-md bg-white/20 hover:bg-white/30 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
      >
        <RefreshCw className="w-3 h-3" />
        <span>Check</span>
      </button>
    </div>
  );
};
