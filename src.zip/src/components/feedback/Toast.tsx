/**
 * Toast Notifications Container
 */

import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { useApp } from '../../store/appContext';

export const ToastContainer: React.FC = () => {
  const { toasts, dismissToast } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 inset-x-0 z-50 pointer-events-none flex flex-col items-center gap-2 px-4">
      {toasts.map((toast) => {
        const icons = {
          success: <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />,
          error: <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />,
          warning: <AlertCircle className="w-4 h-4 text-amber-500 shrink-0" />,
          info: <Info className="w-4 h-4 text-blue-500 shrink-0" />,
        };

        return (
          <div
            key={toast.id}
            className="pointer-events-auto max-w-sm w-full bg-slate-900/95 dark:bg-white/95 text-white dark:text-slate-900 backdrop-blur-md px-4 py-2.5 rounded-2xl shadow-xl border border-slate-700 dark:border-slate-200 flex items-center justify-between gap-3 text-xs font-medium animate-in fade-in slide-in-from-top-2 duration-150"
          >
            <div className="flex items-center gap-2.5 truncate">
              {icons[toast.type]}
              <span className="truncate">{toast.message}</span>
            </div>

            <button
              type="button"
              onClick={() => dismissToast(toast.id)}
              className="text-slate-400 hover:text-white dark:hover:text-slate-900 p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
