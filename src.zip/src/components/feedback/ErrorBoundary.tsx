/**
 * Global React Error Boundary (Section 11)
 * Catches unhandled runtime render crashes and presents a friendly recovery UI
 * with state reset and reload options.
 */

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertOctagon, RotateCcw, Home } from 'lucide-react';
import { Button } from '../ui/Button';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // In production, send to error reporting telemetry
    console.error('Unhandled app error caught by ErrorBoundary:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  private handleClearStorage = () => {
    localStorage.clear();
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="min-h-screen w-full flex flex-col items-center justify-center p-6 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-center">
          <div className="w-16 h-16 rounded-3xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 flex items-center justify-center shadow-lg mb-4 ring-8 ring-rose-500/10">
            <AlertOctagon className="w-8 h-8" />
          </div>

          <h2 className="text-lg font-black tracking-tight text-slate-900 dark:text-slate-100">
            Something went unexpectedly wrong
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs leading-relaxed">
            We encountered a temporary interface issue. Your cart and saved account data are safe.
          </p>

          <div className="w-full max-w-xs space-y-2 mt-6">
            <Button
              size="lg"
              fullWidth
              onClick={this.handleReset}
              leftIcon={<RotateCcw className="w-4 h-4" />}
            >
              Reload Application
            </Button>

            <Button
              size="md"
              variant="outline"
              fullWidth
              onClick={this.handleClearStorage}
            >
              Reset Session Cache
            </Button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
