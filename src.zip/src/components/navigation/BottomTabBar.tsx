/**
 * Mobile Bottom Tab Bar
 * Thumb-zone navigation with 5 key destinations:
 * Home, Search, Orders, Favorites, Profile.
 * Strictly adheres to touch target dimensions and the 15% mobile sticky cap.
 */

import React from 'react';
import { Home, Search, ShoppingBag, Heart, User } from 'lucide-react';
import { MainTabType } from '../../types/navigation';
import { useApp } from '../../store/appContext';

export interface BottomTabBarProps {
  activeTab: MainTabType;
  onTabChange: (tab: MainTabType) => void;
}

export const BottomTabBar: React.FC<BottomTabBarProps> = ({ activeTab, onTabChange }) => {
  const { cartItemCount } = useApp();

  const tabs: Array<{ id: MainTabType; label: string; icon: React.ElementType; badge?: number }> = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'search', label: 'Search', icon: Search },
    { id: 'orders', label: 'Orders', icon: ShoppingBag, badge: cartItemCount },
    { id: 'favorites', label: 'Favorites', icon: Heart },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <nav
      className="fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800 pb-safe shadow-lg"
      aria-label="Main navigation"
    >
      <div className="grid grid-cols-5 items-center h-16 max-w-lg mx-auto px-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              className="min-h-[48px] flex flex-col items-center justify-center relative group focus:outline-none cursor-pointer"
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-150 ${
                    isActive
                      ? 'text-[#E23744] scale-110'
                      : 'text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300'
                  }`}
                />
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 min-w-[16px] h-4 px-1 rounded-full bg-[#E23744] text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white dark:ring-slate-900 tabular-nums">
                    {tab.badge}
                  </span>
                )}
              </div>

              <span
                className={`text-[10px] font-semibold tracking-tight mt-1 transition-colors ${
                  isActive
                    ? 'text-[#E23744]'
                    : 'text-slate-400 dark:text-slate-500 group-hover:text-slate-600'
                }`}
              >
                {tab.label}
              </span>

              {isActive && (
                <span className="w-1 h-1 rounded-full bg-[#E23744] mt-0.5" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
