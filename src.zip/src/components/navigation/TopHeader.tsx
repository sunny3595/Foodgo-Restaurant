/**
 * Mobile Top Header Component
 * Displays location selector, notification trigger, and profile/theme affordance.
 */

import React from 'react';
import { MapPin, ChevronDown, Bell, Moon, Sun } from 'lucide-react';
import { useLocation } from '../../store/locationContext';
import { useTheme } from '../../store/themeContext';
import { useApp } from '../../store/appContext';
import { useAuth } from '../../store/authContext';

export interface TopHeaderProps {
  onLocationClick: () => void;
  onNotificationClick?: () => void;
  onProfileClick?: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  onLocationClick,
  onNotificationClick,
  onProfileClick,
}) => {
  const { currentAddress } = useLocation();
  const { resolvedTheme, toggleTheme } = useTheme();
  const { unreadNotifications } = useApp();
  const { user, isGuest } = useAuth();

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/60 dark:border-slate-800 px-4 py-2.5 pt-safe flex items-center justify-between gap-3 shadow-xs">
      {/* Location Selector (Thumb Tap target) */}
      <button
        type="button"
        onClick={onLocationClick}
        className="flex items-center gap-2 text-left flex-1 min-w-0 group cursor-pointer focus:outline-none"
      >
        <div className="w-8 h-8 rounded-full bg-red-50 dark:bg-red-950/40 flex items-center justify-center text-[#E23744] shrink-0">
          <MapPin className="w-4 h-4 fill-[#E23744]/20" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1">
            <span className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider">
              {currentAddress.label}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-700 dark:group-hover:text-slate-200 transition-transform group-hover:translate-y-0.5" />
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
            {currentAddress.flatBuilding}, {currentAddress.city} - {currentAddress.postalCode}
          </p>
        </div>
      </button>

      {/* Action Buttons */}
      <div className="flex items-center gap-1 shrink-0">
        {/* Theme Toggle */}
        <button
          type="button"
          onClick={toggleTheme}
          className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-full text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Toggle dark mode"
        >
          {resolvedTheme === 'dark' ? (
            <Sun className="w-4 h-4 text-amber-400" />
          ) : (
            <Moon className="w-4 h-4" />
          )}
        </button>

        {/* Notifications */}
        <button
          type="button"
          onClick={onNotificationClick}
          className="relative min-h-[40px] min-w-[40px] flex items-center justify-center rounded-full text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadNotifications > 0 && (
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#E23744] ring-2 ring-white dark:ring-slate-900" />
          )}
        </button>

        {/* Profile Avatar Trigger */}
        <button
          type="button"
          onClick={onProfileClick}
          className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-full overflow-hidden border border-slate-200 dark:border-slate-700 ml-0.5"
          aria-label="User Profile"
        >
          {user ? (
            <div className="w-7 h-7 rounded-full bg-[#E23744] text-white flex items-center justify-center text-xs font-bold">
              {user.firstName[0]}
            </div>
          ) : isGuest ? (
            <div className="w-7 h-7 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center text-[10px] font-bold">
              G
            </div>
          ) : (
            <div className="w-7 h-7 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-500 flex items-center justify-center text-xs">
              ?
            </div>
          )}
        </button>
      </div>
    </header>
  );
};
