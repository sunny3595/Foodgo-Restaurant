/**
 * Real-time Google Maps Delivery Tracking Map
 * Powered by Google Maps Platform (@vis.gl/react-google-maps).
 * Features:
 * - Real Google Maps vector/satellite canvas
 * - Restaurant location AdvancedMarker
 * - Customer destination AdvancedMarker with pulsating doorstep beacon
 * - Animated Live Delivery Rider AdvancedMarker moving along the delivery path
 * - Real Google Maps Polyline route overlay
 * - Re-center camera on rider, custom zoom controls, and map view toggle
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Map,
  AdvancedMarker,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import {
  Plus,
  Minus,
  Navigation,
  MapPin,
  Store,
  Bike,
  Layers,
  Sparkles,
} from 'lucide-react';
import { Coordinates } from '../../types/location';

export interface DeliveryTrackingMapProps {
  restaurantCoords: Coordinates;
  customerCoords: Coordinates;
  riderCoords?: Coordinates;
  riderProgress: number; // 0 (at restaurant) to 1 (at customer)
  restaurantName: string;
  customerAddress: string;
}

// Inner Google Maps Controller for bounds, polyline, and camera controls
const InnerGoogleTrackingMap: React.FC<{
  restaurantCoords: Coordinates;
  customerCoords: Coordinates;
  currentRiderCoords: Coordinates;
  riderProgress: number;
  restaurantName: string;
  customerAddress: string;
}> = ({
  restaurantCoords,
  customerCoords,
  currentRiderCoords,
  riderProgress,
  restaurantName,
}) => {
  const map = useMap();
  const mapsLib = useMapsLibrary('maps');
  const polylineRef = useRef<google.maps.Polyline | null>(null);
  const traveledPolylineRef = useRef<google.maps.Polyline | null>(null);

  // Initialize camera bounds to fit both points
  useEffect(() => {
    if (!map) return;
    const bounds = new google.maps.LatLngBounds();
    bounds.extend({ lat: restaurantCoords.latitude, lng: restaurantCoords.longitude });
    bounds.extend({ lat: customerCoords.latitude, lng: customerCoords.longitude });
    bounds.extend({ lat: currentRiderCoords.latitude, lng: currentRiderCoords.longitude });

    map.fitBounds(bounds, { top: 60, bottom: 50, left: 40, right: 40 });
  }, [map, restaurantCoords, customerCoords]);

  // Draw and update Google Maps Polylines
  useEffect(() => {
    if (!map || !mapsLib) return;

    // Remove previous polylines
    if (polylineRef.current) polylineRef.current.setMap(null);
    if (traveledPolylineRef.current) traveledPolylineRef.current.setMap(null);

    // Full Route (dashed style)
    polylineRef.current = new mapsLib.Polyline({
      path: [
        { lat: restaurantCoords.latitude, lng: restaurantCoords.longitude },
        { lat: customerCoords.latitude, lng: customerCoords.longitude },
      ],
      geodesic: true,
      strokeColor: '#E23744',
      strokeOpacity: 0.6,
      strokeWeight: 4,
      map,
    });

    // Traveled Route (solid emerald line)
    traveledPolylineRef.current = new mapsLib.Polyline({
      path: [
        { lat: restaurantCoords.latitude, lng: restaurantCoords.longitude },
        { lat: currentRiderCoords.latitude, lng: currentRiderCoords.longitude },
      ],
      geodesic: true,
      strokeColor: '#10B981',
      strokeOpacity: 0.9,
      strokeWeight: 5,
      map,
    });

    return () => {
      if (polylineRef.current) polylineRef.current.setMap(null);
      if (traveledPolylineRef.current) traveledPolylineRef.current.setMap(null);
    };
  }, [map, mapsLib, restaurantCoords, customerCoords, currentRiderCoords]);

  const handleCenterOnRider = useCallback(() => {
    if (!map) return;
    map.panTo({
      lat: currentRiderCoords.latitude,
      lng: currentRiderCoords.longitude,
    });
    map.setZoom(16);
  }, [map, currentRiderCoords]);

  const handleFitRoute = useCallback(() => {
    if (!map) return;
    const bounds = new google.maps.LatLngBounds();
    bounds.extend({ lat: restaurantCoords.latitude, lng: restaurantCoords.longitude });
    bounds.extend({ lat: customerCoords.latitude, lng: customerCoords.longitude });
    map.fitBounds(bounds, { top: 60, bottom: 50, left: 40, right: 40 });
  }, [map, restaurantCoords, customerCoords]);

  return (
    <>
      {/* 1. Restaurant Marker */}
      <AdvancedMarker
        position={{
          lat: restaurantCoords.latitude,
          lng: restaurantCoords.longitude,
        }}
        title={restaurantName}
      >
        <div className="flex flex-col items-center">
          <div className="px-2 py-0.5 rounded-lg bg-white/95 dark:bg-slate-900/95 text-[10px] font-bold text-slate-800 dark:text-slate-200 shadow-lg border border-slate-200 dark:border-slate-800 mb-1 max-w-[130px] truncate text-center backdrop-blur-xs">
            {restaurantName}
          </div>
          <div className="w-8 h-8 rounded-full bg-[#E23744] text-white flex items-center justify-center shadow-xl ring-4 ring-red-500/20">
            <Store className="w-4 h-4" />
          </div>
        </div>
      </AdvancedMarker>

      {/* 2. Customer Destination Marker */}
      <AdvancedMarker
        position={{
          lat: customerCoords.latitude,
          lng: customerCoords.longitude,
        }}
        title="Delivery Destination"
      >
        <div className="flex flex-col items-center">
          <div className="px-2 py-0.5 rounded-lg bg-white/95 dark:bg-slate-900/95 text-[10px] font-bold text-slate-800 dark:text-slate-200 shadow-lg border border-slate-200 dark:border-slate-800 mb-1 max-w-[130px] truncate text-center backdrop-blur-xs">
            Your Delivery Doorstep
          </div>
          <div className="relative">
            <span className="absolute -inset-1.5 rounded-full bg-emerald-500/40 animate-ping" />
            <div className="relative w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-xl ring-4 ring-emerald-500/25">
              <MapPin className="w-4 h-4 fill-white/20" />
            </div>
          </div>
        </div>
      </AdvancedMarker>

      {/* 3. Live Animated Rider Marker */}
      <AdvancedMarker
        position={{
          lat: currentRiderCoords.latitude,
          lng: currentRiderCoords.longitude,
        }}
        title="Delivery Partner"
      >
        <div className="flex flex-col items-center transition-all duration-700 ease-out">
          <div className="px-2 py-0.5 rounded-full bg-slate-900 text-white text-[9px] font-black uppercase tracking-wider mb-1 shadow-lg flex items-center gap-1 border border-white/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>Rider • On the Way</span>
          </div>
          <div className="relative">
            <span className="absolute -inset-2 rounded-full bg-amber-400/50 animate-pulse" />
            <div className="relative w-9 h-9 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-2xl ring-4 ring-white dark:ring-slate-900">
              <Bike className="w-5 h-5 stroke-[2.5]" />
            </div>
          </div>
        </div>
      </AdvancedMarker>

      {/* Floating Map Re-center & Controls */}
      <div className="absolute right-3 top-3 z-20 flex flex-col gap-1.5">
        <button
          type="button"
          onClick={handleCenterOnRider}
          className="px-2.5 py-1.5 rounded-xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-md text-xs font-bold text-slate-800 dark:text-slate-200 shadow-md border border-slate-200 dark:border-slate-800 flex items-center gap-1.5 hover:bg-slate-50 cursor-pointer"
          title="Track Rider Location"
        >
          <Navigation className="w-3.5 h-3.5 text-[#E23744]" />
          <span>Follow Rider</span>
        </button>

        <button
          type="button"
          onClick={handleFitRoute}
          className="px-2.5 py-1 rounded-xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-md text-[11px] font-bold text-slate-600 dark:text-slate-300 shadow-md border border-slate-200 dark:border-slate-800 flex items-center gap-1 hover:bg-slate-50 cursor-pointer"
          title="Fit Whole Route"
        >
          <span>Fit Full Route</span>
        </button>
      </div>
    </>
  );
};

export const DeliveryTrackingMap: React.FC<DeliveryTrackingMapProps> = ({
  restaurantCoords,
  customerCoords,
  riderProgress,
  restaurantName,
  customerAddress,
}) => {
  const [mapTypeId, setMapTypeId] = useState<string>('roadmap');

  // Compute live interpolated rider coordinates
  const currentRiderLat =
    restaurantCoords.latitude +
    (customerCoords.latitude - restaurantCoords.latitude) * riderProgress;
  const currentRiderLng =
    restaurantCoords.longitude +
    (customerCoords.longitude - restaurantCoords.longitude) * riderProgress;

  const currentRiderCoords: Coordinates = {
    latitude: currentRiderLat,
    longitude: currentRiderLng,
  };

  const centerLat = (restaurantCoords.latitude + customerCoords.latitude) / 2;
  const centerLng = (restaurantCoords.longitude + customerCoords.longitude) / 2;

  return (
    <div className="relative w-full h-72 sm:h-80 bg-slate-100 dark:bg-slate-900 overflow-hidden select-none border-b border-slate-200 dark:border-slate-800">
      {/* Real Google Maps Platform Canvas */}
      <Map
        defaultCenter={{ lat: centerLat, lng: centerLng }}
        defaultZoom={14}
        mapId="foodgo_delivery_tracking_map"
        mapTypeId={mapTypeId}
        disableDefaultUI={true}
        gestureHandling="greedy"
        className="w-full h-full"
      >
        <InnerGoogleTrackingMap
          restaurantCoords={restaurantCoords}
          customerCoords={customerCoords}
          currentRiderCoords={currentRiderCoords}
          riderProgress={riderProgress}
          restaurantName={restaurantName}
          customerAddress={customerAddress}
        />
      </Map>

      {/* Top Left Live Status Pill */}
      <div className="absolute left-3 top-3 z-20 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border border-slate-200 dark:border-slate-800 shadow-sm text-[11px] font-bold text-slate-800 dark:text-slate-200">
        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
        <span>Live Google Maps GPS Active</span>
      </div>

      {/* Bottom Map Type Toggle & Controls */}
      <div className="absolute left-3 bottom-3 z-20 flex items-center gap-1.5">
        <button
          type="button"
          onClick={() =>
            setMapTypeId((prev) => (prev === 'roadmap' ? 'hybrid' : 'roadmap'))
          }
          className="px-2.5 py-1 rounded-xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-md text-[11px] font-bold text-slate-700 dark:text-slate-200 shadow-md border border-slate-200 dark:border-slate-800 flex items-center gap-1 hover:bg-slate-50 cursor-pointer"
        >
          <Layers className="w-3.5 h-3.5 text-[#E23744]" />
          <span>{mapTypeId === 'roadmap' ? 'Satellite' : 'Roadmap'}</span>
        </button>
      </div>
    </div>
  );
};
