/**
 * Interactive Map Address Pinpoint Picker Modal
 * Powered by Google Maps Platform (@vis.gl/react-google-maps).
 * Allows customers to interactively drag/tap to pinpoint their exact doorstep location,
 * search locations with Places Autocomplete, use GPS current location,
 * and dynamically reverse-geocode addresses.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  MapPin,
  Crosshair,
  Search,
  Plus,
  Minus,
  Navigation,
  Loader2,
  CheckCircle2,
  Building,
} from 'lucide-react';
import { Map, AdvancedMarker, useMap, useMapsLibrary } from '@vis.gl/react-google-maps';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Coordinates, Address } from '../../types/location';
import { useLocation } from '../../store/locationContext';
import { useApp } from '../../store/appContext';
import { reverseGeocodeCoords, ReverseGeocodeResult } from '../../services/map/geocodingService';

export interface AddressDetails {
  streetArea?: string;
  city?: string;
  postalCode?: string;
  flatBuilding?: string;
  landmark?: string;
  formattedAddress?: string;
}

export interface AddressPinpointMapModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCoords?: Coordinates;
  onConfirmLocation?: (
    coords: Coordinates,
    addressTitle?: string,
    details?: AddressDetails
  ) => void;
}

// Inner map controls & pin handler component
interface InnerMapProps {
  currentCoords: Coordinates;
  onCoordsChange: (coords: Coordinates) => void;
  isLocating: boolean;
  onLocateUser: () => void;
  onSelectSuggestionCoords: (
    coords: Coordinates,
    details?: {
      placeName?: string;
      formattedAddress?: string;
    }
  ) => void;
}

const InnerMapPinpoint: React.FC<InnerMapProps> = ({
  currentCoords,
  onCoordsChange,
  isLocating,
  onLocateUser,
  onSelectSuggestionCoords,
}) => {
  const map = useMap();
  const placesLib = useMapsLibrary('places');

  // Search autocomplete state
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState<google.maps.places.AutocompleteSuggestion[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const sessionTokenRef = useRef<google.maps.places.AutocompleteSessionToken | null>(null);

  // Pan map when currentCoords updates programmatically (e.g., GPS or suggestion)
  const panToCoords = useCallback(
    (lat: number, lng: number, zoomLevel?: number) => {
      if (!map) return;
      map.panTo({ lat, lng });
      if (zoomLevel) {
        map.setZoom(zoomLevel);
      }
    },
    [map]
  );

  // Map click handler - places pin directly where user tapped
  const handleMapClick = (e: any) => {
    const latLng = e?.detail?.latLng || e?.latLng;
    if (latLng) {
      const lat = typeof latLng.lat === 'function' ? latLng.lat() : latLng.lat;
      const lng = typeof latLng.lng === 'function' ? latLng.lng() : latLng.lng;
      onCoordsChange({ latitude: lat, longitude: lng });
    }
  };

  // Marker drag end handler
  const handleMarkerDragEnd = (e: any) => {
    const latLng = e?.latLng || e?.detail?.latLng;
    if (latLng) {
      const lat = typeof latLng.lat === 'function' ? latLng.lat() : latLng.lat;
      const lng = typeof latLng.lng === 'function' ? latLng.lng() : latLng.lng;
      onCoordsChange({ latitude: lat, longitude: lng });
    }
  };

  // Autocomplete suggestions search
  useEffect(() => {
    if (!placesLib || !searchQuery.trim()) {
      setSuggestions([]);
      setIsSearching(false);
      return;
    }

    if (!sessionTokenRef.current) {
      sessionTokenRef.current = new placesLib.AutocompleteSessionToken();
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const { suggestions: fetched } =
          await placesLib.AutocompleteSuggestion.fetchAutocompleteSuggestions({
            input: searchQuery,
            sessionToken: sessionTokenRef.current || undefined,
            region: 'in',
            locationBias: {
              center: { lat: currentCoords.latitude, lng: currentCoords.longitude },
              radius: 20000,
            },
          });
        setSuggestions(fetched || []);
        setShowDropdown(true);
      } catch (err) {
        console.warn('Place autocomplete error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery, placesLib, currentCoords]);

  // When a suggestion is clicked
  const handleSelectSuggestion = async (
    suggestion: google.maps.places.AutocompleteSuggestion
  ) => {
    setShowDropdown(false);
    const mainText = suggestion.placePrediction?.mainText?.toString() || '';
    const fullText = suggestion.placePrediction?.text?.toString() || '';
    setSearchQuery(fullText || mainText);

    try {
      const placePrediction = suggestion.placePrediction;
      if (!placePrediction) return;

      const place = placePrediction.toPlace();
      await place.fetchFields({
        fields: ['location', 'displayName', 'formattedAddress'],
      });

      if (place.location) {
        const lat = place.location.lat();
        const lng = place.location.lng();
        const newCoords = { latitude: lat, longitude: lng };
        onSelectSuggestionCoords(newCoords, {
          placeName: (place as any).displayName || mainText,
          formattedAddress: place.formattedAddress || fullText,
        });
        panToCoords(lat, lng, 17);
      }

      // Renew session token after selection
      if (placesLib) {
        sessionTokenRef.current = new placesLib.AutocompleteSessionToken();
      }
    } catch (err) {
      console.warn('Failed to retrieve place details:', err);
    }
  };

  const handleZoomIn = () => {
    if (map) {
      map.setZoom((map.getZoom() || 16) + 1);
    }
  };

  const handleZoomOut = () => {
    if (map) {
      map.setZoom((map.getZoom() || 16) - 1);
    }
  };

  return (
    <div className="relative w-full h-[320px] sm:h-[360px] rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-inner bg-slate-100 dark:bg-slate-900">
      {/* Top Search Input with Autocomplete Dropdown */}
      <div className="absolute top-3 inset-x-3 z-30">
        <div className="relative">
          <div className="flex items-center gap-2 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-3 py-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-lg">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              placeholder="Search area, landmark or apartment..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => {
                if (suggestions.length > 0) setShowDropdown(true);
              }}
              className="w-full text-xs font-medium text-slate-800 dark:text-slate-100 bg-transparent focus:outline-hidden placeholder:text-slate-400"
            />
            {isSearching && <Loader2 className="w-3.5 h-3.5 text-[#E23744] animate-spin shrink-0" />}
            {searchQuery && !isSearching && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSuggestions([]);
                  setShowDropdown(false);
                }}
                className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5"
              >
                &times;
              </button>
            )}
          </div>

          {/* Suggestions Dropdown */}
          {showDropdown && suggestions.length > 0 && (
            <div className="absolute left-0 right-0 mt-1.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden max-h-48 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 z-40">
              {suggestions.map((sug, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSelectSuggestion(sug)}
                  className="w-full text-left px-3.5 py-2.5 text-xs hover:bg-red-50/60 dark:hover:bg-red-950/30 flex items-start gap-2.5 transition-colors cursor-pointer"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#E23744] shrink-0 mt-0.5" />
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                      {sug.placePrediction?.mainText?.toString() || 'Location'}
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                      {sug.placePrediction?.secondaryText?.toString() || ''}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Actual Interactive Google Map */}
      <Map
        mapId="DEMO_MAP_ID"
        defaultCenter={{
          lat: currentCoords.latitude,
          lng: currentCoords.longitude,
        }}
        defaultZoom={16}
        gestureHandling="greedy"
        disableDefaultUI={true}
        onClick={handleMapClick}
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        className="w-full h-full"
      >
        {/* Draggable Delivery Pin Marker */}
        <AdvancedMarker
          position={{
            lat: currentCoords.latitude,
            lng: currentCoords.longitude,
          }}
          draggable={true}
          onDragEnd={handleMarkerDragEnd}
          title="Drag to adjust delivery pin"
        >
          <div className="flex flex-col items-center cursor-grab active:cursor-grabbing -translate-y-2 select-none group">
            <div className="px-2.5 py-1 rounded-xl bg-slate-900 text-white text-[10px] font-bold shadow-lg mb-1 whitespace-nowrap border border-white/20">
              Deliver Here
            </div>
            <div className="relative">
              <span className="absolute -inset-1 rounded-full bg-[#E23744]/40 animate-ping" />
              <div className="relative w-10 h-10 rounded-full bg-[#E23744] text-white flex items-center justify-center shadow-2xl ring-4 ring-white dark:ring-slate-900 transition-transform group-hover:scale-110">
                <MapPin className="w-5 h-5 fill-current" />
              </div>
            </div>
            <div className="w-2 h-2 rounded-full bg-slate-900/60 mt-0.5 shadow-sm" />
          </div>
        </AdvancedMarker>
      </Map>

      {/* Floating Map Controls (Right Side) */}
      <div className="absolute right-3 bottom-4 z-20 flex flex-col items-center gap-2">
        {/* GPS Locate Me Button */}
        <button
          type="button"
          onClick={onLocateUser}
          disabled={isLocating}
          title="Use my current GPS location"
          className="w-10 h-10 rounded-full bg-white dark:bg-slate-900 shadow-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:text-[#E23744] dark:hover:text-[#E23744] active:scale-95 transition-all cursor-pointer"
        >
          {isLocating ? (
            <Loader2 className="w-4 h-4 animate-spin text-[#E23744]" />
          ) : (
            <Crosshair className="w-4 h-4 text-[#E23744]" />
          )}
        </button>

        {/* Zoom Controls */}
        <div className="flex flex-col rounded-2xl bg-white dark:bg-slate-900 shadow-xl border border-slate-200 dark:border-slate-700 overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
          <button
            type="button"
            onClick={handleZoomIn}
            title="Zoom In"
            className="w-9 h-9 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleZoomOut}
            title="Zoom Out"
            className="w-9 h-9 flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Minus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tap/Drag Helper Pill */}
      <div className="absolute bottom-4 left-3 z-20 px-3 py-1.5 rounded-full bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border border-slate-200 dark:border-slate-800 text-[10px] font-bold text-slate-700 dark:text-slate-200 shadow-md flex items-center gap-1.5">
        <Navigation className="w-3.5 h-3.5 text-[#E23744]" />
        <span>Tap or drag pin to adjust</span>
      </div>
    </div>
  );
};

export const AddressPinpointMapModal: React.FC<AddressPinpointMapModalProps> = ({
  isOpen,
  onClose,
  initialCoords,
  onConfirmLocation,
}) => {
  const { currentAddress, setCurrentAddress, addAddress } = useLocation();
  const { showToast } = useApp();

  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

  // Local coordinates state
  const [coords, setCoords] = useState<Coordinates>(
    initialCoords || currentAddress.coordinates || { latitude: 13.6288, longitude: 79.4192 }
  );

  // Reverse Geocoded address details
  const [resolved, setResolved] = useState<{
    title: string;
    subtitle: string;
    details?: ReverseGeocodeResult;
    isLoading: boolean;
  }>({
    title: currentAddress.streetArea || 'Air Bypass Road, Near Alipiri Gate',
    subtitle: `${currentAddress.city || 'Tirupati'}, Andhra Pradesh - ${currentAddress.postalCode || '517501'}`,
    isLoading: false,
  });

  const [isLocating, setIsLocating] = useState(false);

  // Sync coords when initialCoords changes or modal opens
  useEffect(() => {
    if (isOpen) {
      const target = initialCoords || currentAddress.coordinates || { latitude: 13.6288, longitude: 79.4192 };
      setCoords(target);
    }
  }, [isOpen, initialCoords, currentAddress.coordinates]);

  // Debounced reverse geocoding on coordinates update
  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;
    setResolved((prev) => ({ ...prev, isLoading: true }));

    const timer = setTimeout(async () => {
      const res = await reverseGeocodeCoords(coords.latitude, coords.longitude, apiKey);
      if (!isMounted) return;

      if (res) {
        setResolved({
          title: res.streetArea || res.formattedAddress.split(',')[0],
          subtitle: `${res.city}, ${res.state} - ${res.postalCode}`,
          details: res,
          isLoading: false,
        });
      } else {
        // Fallback title with coordinates
        setResolved({
          title: 'Custom Pinned Location',
          subtitle: `Lat: ${coords.latitude.toFixed(4)}, Lng: ${coords.longitude.toFixed(4)}`,
          isLoading: false,
        });
      }
    }, 350);

    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [coords, apiKey, isOpen]);

  // Geolocation trigger
  const handleLocateUser = () => {
    if (!navigator.geolocation) {
      showToast('Geolocation is not supported by your browser', 'error');
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        const newCoords = {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
        };
        setCoords(newCoords);
        showToast('Located your current physical GPS position', 'success');
      },
      (err) => {
        setIsLocating(false);
        console.warn('Geolocation error:', err);
        showToast('Could not access current location. Please tap the map to pin.', 'info');
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleConfirmPin = () => {
    const calculatedFlatBuilding =
      resolved.details?.flatBuilding ||
      (resolved.title && resolved.title !== 'Custom Pinned Location'
        ? resolved.title
        : 'Doorstep Location');

    const calculatedStreetArea =
      resolved.details?.streetArea || resolved.title || 'Near Main Road';

    const addressDetails: AddressDetails = {
      streetArea: calculatedStreetArea,
      city: resolved.details?.city || 'Tirupati',
      postalCode: resolved.details?.postalCode || '517501',
      flatBuilding: calculatedFlatBuilding,
      landmark:
        resolved.details?.landmark ||
        (resolved.title ? `Near ${resolved.title.split(',')[0]}` : undefined),
      formattedAddress: resolved.details?.formattedAddress,
    };

    if (onConfirmLocation) {
      onConfirmLocation(coords, resolved.title, addressDetails);
      return;
    }

    // Default behavior if opened without custom onConfirmLocation callback
    const newAddr: Address = {
      id: `addr_pinned_${Date.now()}`,
      label: 'Home',
      receiverName: currentAddress.receiverName || 'Customer',
      phone: currentAddress.phone || '+91 98765 43210',
      flatBuilding: calculatedFlatBuilding,
      streetArea: calculatedStreetArea,
      landmark: addressDetails.landmark || 'Direct GPS Coordinate Pin',
      city: addressDetails.city || 'Tirupati',
      state: resolved.details?.state || 'Andhra Pradesh',
      postalCode: addressDetails.postalCode || '517501',
      isDefault: true,
      coordinates: coords,
    };

    addAddress(newAddr);
    setCurrentAddress(newAddr);
    showToast(`Delivery location set to ${resolved.title}`, 'success');
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Pin Delivery Location on Map"
      subtitle="Drag the pin or tap anywhere on the real interactive map to set your exact doorstep location"
    >
      <div className="space-y-3.5 -mt-2">
        {/* Interactive Google Map Container */}
        <InnerMapPinpoint
          currentCoords={coords}
          onCoordsChange={(newC) => setCoords(newC)}
          isLocating={isLocating}
          onLocateUser={handleLocateUser}
          onSelectSuggestionCoords={(newC, extra) => {
            setCoords(newC);
            if (extra?.placeName) {
              setResolved((prev) => ({
                ...prev,
                title: extra.placeName!,
                subtitle: extra.formattedAddress || prev.subtitle,
                details: {
                  formattedAddress: extra.formattedAddress || prev.title,
                  streetArea: extra.placeName!,
                  city: prev.details?.city || 'Tirupati',
                  state: prev.details?.state || 'Andhra Pradesh',
                  postalCode: prev.details?.postalCode || '517501',
                  flatBuilding: extra.placeName,
                  landmark: extra.placeName,
                },
                isLoading: false,
              }));
            }
          }}
        />

        {/* Selected / Reverse-Geocoded Location Card */}
        <div className="p-3.5 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-start gap-3 transition-colors">
          <div className="w-8 h-8 rounded-xl bg-red-100 dark:bg-red-950 text-[#E23744] flex items-center justify-center shrink-0 mt-0.5">
            {resolved.isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin text-[#E23744]" />
            ) : (
              <MapPin className="w-4 h-4" />
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                {resolved.title}
              </h4>
              {!resolved.isLoading && (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              )}
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
              {resolved.subtitle}
            </p>

            <div className="flex items-center gap-2 mt-1">
              <span className="text-[10px] font-mono font-medium text-slate-400 bg-slate-200/60 dark:bg-slate-800 px-1.5 py-0.5 rounded-md">
                {coords.latitude.toFixed(5)}, {coords.longitude.toFixed(5)}
              </span>
              {resolved.details?.city && (
                <span className="text-[10px] font-bold text-[#E23744] flex items-center gap-1">
                  <Building className="w-2.5 h-2.5" />
                  {resolved.details.city} &bull; PIN: {resolved.details.postalCode}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Action Button */}
        <Button size="lg" fullWidth onClick={handleConfirmPin}>
          Confirm Pin Location
        </Button>
      </div>
    </Modal>
  );
};
