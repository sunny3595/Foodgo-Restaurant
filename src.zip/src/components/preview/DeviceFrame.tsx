/**
 * Device Frame & Simulation Environment
 * Allows testing FoodGo Customer in realistic iPhone 16 Pro, Google Pixel 9, or Full Responsive layouts.
 */

import React, { useState } from 'react';
import { Smartphone, Monitor, Wifi, BatteryMedium, Signal, WifiOff, RotateCcw } from 'lucide-react';
import { useApp } from '../../store/appContext';
import { useTheme } from '../../store/themeContext';

export type DeviceMode = 'iphone' | 'pixel' | 'fluid';

export interface DeviceFrameProps {
  children: React.ReactNode;
  onResetFlow: () => void;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ children, onResetFlow }) => {
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('iphone');
  const { isOnline, setIsOnline } = useApp();
  const { resolvedTheme } = useTheme();
  const [currentTime] = useState(() => {
    const d = new Date();
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  });

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center justify-start p-0 sm:py-6 sm:px-4 font-sans antialiased select-none">
      {/* Simulation Controls Toolbar (Floating Desktop Bar) */}
      <aside aria-label="Device simulation toolbar" className="w-full max-w-4xl mb-4 hidden sm:flex items-center justify-between bg-slate-800/90 border border-slate-700/80 rounded-2xl px-4 py-2.5 backdrop-blur-md shadow-lg text-xs">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#E23744]" />
          <span className="font-bold text-white tracking-wide">FoodGo Customer Preview</span>
          <span className="text-slate-400">· Phase 1 Foundation</span>
        </div>

        {/* Device Switcher */}
        <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-slate-700">
          <button
            type="button"
            onClick={() => setDeviceMode('iphone')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
              deviceMode === 'iphone'
                ? 'bg-[#E23744] text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>iPhone 16 Pro</span>
          </button>

          <button
            type="button"
            onClick={() => setDeviceMode('pixel')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
              deviceMode === 'pixel'
                ? 'bg-[#E23744] text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Pixel 9</span>
          </button>

          <button
            type="button"
            onClick={() => setDeviceMode('fluid')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors flex items-center gap-1.5 cursor-pointer ${
              deviceMode === 'fluid'
                ? 'bg-[#E23744] text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Fluid View</span>
          </button>
        </div>

        {/* Quick Testing Toggles */}
        <div className="flex items-center gap-2">
          {/* Network Simulator Button */}
          <button
            type="button"
            onClick={() => setIsOnline(!isOnline)}
            className={`px-2.5 py-1 rounded-lg border flex items-center gap-1.5 font-medium transition-colors cursor-pointer ${
              isOnline
                ? 'bg-emerald-950/60 border-emerald-700/60 text-emerald-400'
                : 'bg-amber-950/60 border-amber-700/60 text-amber-400'
            }`}
            title="Toggle simulated network offline/online"
          >
            {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
            <span>{isOnline ? 'Online' : 'Offline'}</span>
          </button>

          {/* Reset App Flow to Splash */}
          <button
            type="button"
            onClick={onResetFlow}
            className="px-2.5 py-1 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 flex items-center gap-1.5 font-medium transition-colors cursor-pointer"
            title="Restart splash & onboarding flow"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restart Flow</span>
          </button>
        </div>
      </aside>

      {/* Frame Container */}
      <div
        className={`w-full transition-all duration-300 flex justify-center ${
          deviceMode === 'fluid'
            ? 'max-w-md'
            : deviceMode === 'iphone'
            ? 'max-w-[400px]'
            : 'max-w-[416px]'
        }`}
      >
        <div
          className={`w-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col relative transition-all duration-200 overflow-hidden ${
            resolvedTheme === 'dark' ? 'dark' : ''
          } ${
            deviceMode !== 'fluid'
              ? 'h-[852px] rounded-[52px] ring-12 ring-slate-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] border border-slate-700'
              : 'min-h-screen sm:min-h-[852px] sm:rounded-3xl sm:border sm:border-slate-800 shadow-2xl'
          }`}
        >
          {/* Native Device Status Bar */}
          {deviceMode !== 'fluid' && (
            <div className="h-11 px-7 pt-2 flex items-center justify-between text-xs font-semibold z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs select-none">
              <span>{currentTime}</span>

              {/* Dynamic Island / Notch Simulation */}
              {deviceMode === 'iphone' ? (
                <div className="w-24 h-5 bg-black rounded-full mx-auto self-center" />
              ) : (
                <div className="w-3.5 h-3.5 bg-black rounded-full mx-auto" />
              )}

              <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                <Signal className="w-3.5 h-3.5" />
                {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5 text-amber-500" />}
                <BatteryMedium className="w-4 h-4" />
              </div>
            </div>
          )}

          {/* Screen Content Viewport */}
          <div className="flex-1 flex flex-col overflow-y-auto no-scrollbar relative">
            {children}
          </div>

          {/* iOS Home Indicator Bar */}
          {deviceMode === 'iphone' && (
            <div className="h-5 flex items-center justify-center pointer-events-none bg-white/95 dark:bg-slate-900/95 z-50">
              <div className="w-32 h-1 bg-slate-300 dark:bg-slate-700 rounded-full" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
