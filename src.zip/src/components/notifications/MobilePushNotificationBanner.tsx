/**
 * Mobile Push Notification Banner (Flipkart / Amazon Style)
 * Renders an authentic OS-style push notification banner at the top of the mobile device view.
 * Displays:
 * - App Logo (FoodGo red emblem)
 * - App Title: FOODGO • now
 * - Title: e.g. "☀️ Good Morning Motivation!"
 * - Body Message
 * - Quick tap to open full notification modal or swipe up to dismiss
 */

import React, { useState, useEffect } from 'react';
import { UtensilsCrossed, X, Bell, ChevronRight, Sparkles, Sun, Tag, Bike } from 'lucide-react';
import { NotificationItem } from '../../types/profile';

export interface MobilePushNotificationBannerProps {
  onOpenNotifications?: () => void;
}

export const MobilePushNotificationBanner: React.FC<MobilePushNotificationBannerProps> = ({
  onOpenNotifications,
}) => {
  const [activeNotification, setActiveNotification] = useState<NotificationItem | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handlePushEvent = (e: Event) => {
      const customEvent = e as CustomEvent<NotificationItem>;
      if (customEvent.detail) {
        setActiveNotification(customEvent.detail);
        setIsVisible(true);

        // Auto dismiss after 7.5 seconds
        const timer = setTimeout(() => {
          setIsVisible(false);
        }, 7500);

        return () => clearTimeout(timer);
      }
    };

    window.addEventListener('foodgo-push-notification', handlePushEvent);
    return () => window.removeEventListener('foodgo-push-notification', handlePushEvent);
  }, []);

  if (!activeNotification || !isVisible) return null;

  const getTypeIcon = () => {
    switch (activeNotification.type) {
      case 'motivation':
        return <Sun className="w-3.5 h-3.5 text-amber-500 shrink-0" />;
      case 'promo':
        return <Tag className="w-3.5 h-3.5 text-[#E23744] shrink-0" />;
      case 'order':
        return <Bike className="w-3.5 h-3.5 text-emerald-500 shrink-0" />;
      default:
        return <Sparkles className="w-3.5 h-3.5 text-blue-500 shrink-0" />;
    }
  };

  const handleBannerClick = () => {
    setIsVisible(false);
    if (onOpenNotifications) {
      onOpenNotifications();
    }
  };

  return (
    <aside
      aria-label="Mobile push notification"
      className="absolute top-12 left-3 right-3 z-50 transition-all duration-300 transform animate-in slide-in-from-top-6 ease-out select-none"
    >
      <div
        onClick={handleBannerClick}
        className="w-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border border-slate-200/90 dark:border-slate-700/80 rounded-2xl p-3 shadow-[0_12px_32px_rgba(0,0,0,0.22)] cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/90 transition-all active:scale-[0.99]"
      >
        {/* Header row: App identity like Amazon/Flipkart */}
        <div className="flex items-center justify-between pb-1.5 border-b border-slate-100 dark:border-slate-800/80">
          <div className="flex items-center gap-1.5">
            <div className="w-4 h-4 rounded-md bg-[#E23744] flex items-center justify-center text-white shadow-xs">
              <UtensilsCrossed className="w-2.5 h-2.5" />
            </div>
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-800 dark:text-slate-200">
              FOODGO
            </span>
            <span className="text-[10px] text-slate-400">&bull;</span>
            <span className="text-[10px] font-medium text-slate-400">now</span>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsVisible(false);
              }}
              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              aria-label="Dismiss notification"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Content body */}
        <div className="pt-2 flex items-start gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/60 dark:border-amber-800/40 flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
            {getTypeIcon()}
          </div>

          <div className="min-w-0 flex-1">
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 tracking-tight leading-tight line-clamp-1">
              {activeNotification.title}
            </h4>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5 leading-snug line-clamp-2">
              {activeNotification.message}
            </p>
          </div>

          <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 self-center ml-0.5" />
        </div>

        {/* Tiny pill action footer */}
        <div className="mt-2 pt-1.5 flex items-center justify-between text-[10px] font-bold text-[#E23744]">
          <span className="flex items-center gap-1">
            <Bell className="w-2.5 h-2.5" />
            <span>Tap to view in FoodGo</span>
          </span>
          <span className="text-slate-400 font-normal">Swipe up to dismiss</span>
        </div>
      </div>
    </aside>
  );
};
