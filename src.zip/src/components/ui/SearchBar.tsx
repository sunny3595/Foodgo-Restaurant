/**
 * Mobile Search Bar Component
 * Clean touch-first search input with filter button, clear trigger, and voice affordance.
 */

import React from 'react';
import { Search, X, SlidersHorizontal, Mic } from 'lucide-react';

export interface SearchBarProps {
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  onFilterClick?: () => void;
  onVoiceClick?: () => void;
  onSubmit?: () => void;
  hasActiveFilters?: boolean;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  value,
  onChange,
  placeholder = 'Restaurant name or a dish...',
  onFilterClick,
  onVoiceClick,
  onSubmit,
  hasActiveFilters = false,
}) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && onSubmit) {
      onSubmit();
    }
  };

  return (
    <div className="flex items-center gap-2 w-full">
      <div className="relative flex-1 flex items-center">
        <Search className="absolute left-3.5 w-4 h-4 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full min-h-[46px] pl-10 pr-16 py-2.5 text-sm bg-slate-100 dark:bg-slate-900 border border-transparent focus:border-slate-300 dark:focus:border-slate-700 rounded-2xl text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:bg-white dark:focus:bg-slate-950 transition-all shadow-inner"
        />

        <div className="absolute right-2 flex items-center gap-1">
          {value ? (
            <button
              type="button"
              onClick={() => onChange('')}
              className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 transition-colors"
              aria-label="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : (
            onVoiceClick && (
              <button
                type="button"
                onClick={onVoiceClick}
                className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-[#E23744] transition-colors"
                aria-label="Voice search"
              >
                <Mic className="w-3.5 h-3.5" />
              </button>
            )
          )}
        </div>
      </div>

      {onFilterClick && (
        <button
          type="button"
          onClick={onFilterClick}
          className={`min-w-[46px] min-h-[46px] flex items-center justify-center rounded-2xl border transition-colors relative cursor-pointer ${
            hasActiveFilters
              ? 'bg-[#E23744] border-[#E23744] text-white'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
          }`}
          aria-label="Filter restaurants"
        >
          <SlidersHorizontal className="w-4 h-4" />
          {hasActiveFilters && (
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-white ring-2 ring-[#E23744]" />
          )}
        </button>
      )}
    </div>
  );
};
