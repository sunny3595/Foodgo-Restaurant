/**
 * Skeleton Loader Component
 * Smooth pulse placeholder for lists, restaurant cards, and text lines.
 */

import React from 'react';

export interface SkeletonProps {
  className?: string;
  variant?: 'rect' | 'circle' | 'text';
}

export const Skeleton: React.FC<SkeletonProps> = ({
  className = '',
  variant = 'rect',
}) => {
  const variantStyles = {
    rect: 'rounded-2xl',
    circle: 'rounded-full',
    text: 'rounded-md h-4',
  };

  return (
    <div
      className={`animate-pulse bg-slate-200 dark:bg-slate-800 ${variantStyles[variant]} ${className}`}
    />
  );
};

export const RestaurantCardSkeleton: React.FC = () => {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl p-3 border border-slate-100 dark:border-slate-800 space-y-3">
      <Skeleton className="w-full h-44 rounded-2xl" />
      <div className="space-y-2 px-1">
        <div className="flex justify-between items-center">
          <Skeleton variant="text" className="w-1/2 h-5" />
          <Skeleton variant="text" className="w-12 h-5" />
        </div>
        <Skeleton variant="text" className="w-3/4 h-3.5" />
        <div className="flex gap-2 pt-1">
          <Skeleton variant="text" className="w-20 h-4" />
          <Skeleton variant="text" className="w-24 h-4" />
        </div>
      </div>
    </div>
  );
};
