/**
 * Rating Badge Component
 * Accessible, clear presentation of scores and count with tabular figures.
 */

import React from 'react';
import { Star } from 'lucide-react';

export interface RatingBadgeProps {
  rating: number;
  count?: number;
  size?: 'sm' | 'md';
}

export const RatingBadge: React.FC<RatingBadgeProps> = ({
  rating,
  count,
  size = 'sm',
}) => {
  const isSm = size === 'sm';

  return (
    <div className="inline-flex items-center gap-1">
      <div
        className={`inline-flex items-center gap-1 font-semibold rounded-lg text-white bg-emerald-600 ${
          isSm ? 'px-1.5 py-0.5 text-[11px]' : 'px-2 py-1 text-xs'
        }`}
      >
        <span className="tabular-nums">{rating.toFixed(1)}</span>
        <Star className={isSm ? 'w-2.5 h-2.5 fill-current' : 'w-3 h-3 fill-current'} />
      </div>

      {count !== undefined && (
        <span className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
          ({count > 999 ? `${(count / 1000).toFixed(1)}k` : count})
        </span>
      )}
    </div>
  );
};
