/**
 * Error State Component
 */

export { ErrorState } from './EmptyState';
export type { ErrorStateProps } from './EmptyState';
