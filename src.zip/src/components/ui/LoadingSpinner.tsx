/**
 * Loading Spinner Component
 */

import React from 'react';
import { Loader2 } from 'lucide-react';

export const LoadingSpinner: React.FC<{ message?: string; size?: 'sm' | 'md' | 'lg' }> = ({
  message = 'Loading...',
  size = 'md',
}) => {
  const iconSizes = {
    sm: 'w-4 h-4',
    md: 'w-7 h-7',
    lg: 'w-10 h-10',
  };

  return (
    <div className="flex flex-col items-center justify-center py-10 gap-3 text-slate-500 dark:text-slate-400">
      <Loader2 className={`${iconSizes[size]} animate-spin text-[#E23744]`} />
      {message && <p className="text-xs font-medium">{message}</p>}
    </div>
  );
};
