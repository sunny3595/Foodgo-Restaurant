/**
 * Cart Restaurant Conflict Modal (Section 24)
 * Warns user when adding items from a different restaurant,
 * providing Discard & Add or Keep Current Cart options.
 */

import React from 'react';
import { AlertTriangle, ArrowRight, X } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { useCart } from '../../store/cartContext';

export const CartConflictModal: React.FC = () => {
  const { conflictModalOpen, restaurant, pendingRestaurant, resolveConflict } = useCart();

  if (!conflictModalOpen || !pendingRestaurant) return null;

  return (
    <Modal
      isOpen={conflictModalOpen}
      onClose={() => resolveConflict(false)}
      title="Replace cart items?"
      subtitle="Single restaurant order constraint"
    >
      <div className="flex flex-col items-center text-center p-2 space-y-4">
        {/* Warning Icon */}
        <div className="w-14 h-14 rounded-2xl bg-amber-50 dark:bg-amber-950/40 text-amber-500 flex items-center justify-center ring-8 ring-amber-500/10">
          <AlertTriangle className="w-7 h-7" />
        </div>

        {/* Description */}
        <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
          <p>
            Your cart already contains dishes from{' '}
            <span className="font-bold text-slate-900 dark:text-slate-100">
              {restaurant?.name || 'another kitchen'}
            </span>
            .
          </p>
          <p className="text-slate-500 dark:text-slate-400">
            Do you want to discard your current cart and start a fresh order from{' '}
            <span className="font-bold text-[#E23744]">{pendingRestaurant.name}</span>?
          </p>
        </div>

        {/* Buttons */}
        <div className="w-full space-y-2 pt-2">
          <Button
            size="lg"
            fullWidth
            onClick={() => resolveConflict(true)}
            rightIcon={<ArrowRight className="w-4 h-4" />}
          >
            Discard & Add New Items
          </Button>

          <Button
            size="md"
            variant="outline"
            fullWidth
            onClick={() => resolveConflict(false)}
          >
            Keep Current Cart
          </Button>
        </div>
      </div>
    </Modal>
  );
};
