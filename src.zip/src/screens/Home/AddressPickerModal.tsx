/**
 * Delivery Address Selector Modal
 * Allows switching between saved delivery addresses (Home, Work, Other)
 * or pinning an exact doorstep location on the interactive map.
 */

import React, { useState } from 'react';
import { Home, Briefcase, MapPin, Check, Plus, Navigation } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { AddressPinpointMapModal } from '../../components/map/AddressPinpointMapModal';
import { useLocation } from '../../store/locationContext';
import { useApp } from '../../store/appContext';

export interface AddressPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AddressPickerModal: React.FC<AddressPickerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { savedAddresses, currentAddress, selectAddress, addAddress } = useLocation();
  const { showToast } = useApp();
  const [isPinMapOpen, setIsPinMapOpen] = useState(false);

  const handleSelect = (id: string) => {
    selectAddress(id);
    onClose();
    showToast('Delivery address updated', 'success');
  };

  const getLabelIcon = (label: string) => {
    switch (label) {
      case 'Home':
        return <Home className="w-4 h-4" />;
      case 'Work':
        return <Briefcase className="w-4 h-4" />;
      default:
        return <MapPin className="w-4 h-4" />;
    }
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title="Select Delivery Address"
        subtitle="Choose where your food should be delivered"
      >
        <div className="space-y-3">
          {savedAddresses.map((addr) => {
            const isSelected = currentAddress.id === addr.id;

            return (
              <div
                key={addr.id}
                onClick={() => handleSelect(addr.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                  isSelected
                    ? 'border-[#E23744] bg-red-50/50 dark:bg-red-950/20 shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      isSelected
                        ? 'bg-[#E23744] text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {getLabelIcon(addr.label)}
                  </div>

                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                        {addr.label}
                      </span>
                      {addr.isDefault && (
                        <span className="text-[10px] text-slate-400 font-medium">· Default</span>
                      )}
                    </div>

                    <p className="text-xs font-medium text-slate-700 dark:text-slate-300">
                      {addr.flatBuilding}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {addr.streetArea}, {addr.city} - {addr.postalCode}
                    </p>
                  </div>
                </div>

                {isSelected && (
                  <div className="w-6 h-6 rounded-full bg-[#E23744] text-white flex items-center justify-center shrink-0 mt-1">
                    <Check className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            );
          })}

          <div className="pt-2 space-y-2">
            <Button
              size="md"
              fullWidth
              leftIcon={<Navigation className="w-4 h-4 text-white" />}
              onClick={() => {
                setIsPinMapOpen(true);
              }}
            >
              Pin on Interactive Map
            </Button>
          </div>
        </div>
      </Modal>

      {/* Interactive Map Pinpoint Modal */}
      <AddressPinpointMapModal
        isOpen={isPinMapOpen}
        onClose={() => {
          setIsPinMapOpen(false);
        }}
        initialCoords={currentAddress.coordinates}
        onConfirmLocation={(newCoords, addressSummary, details) => {
          const newAddr = {
            id: `addr_pinned_${Date.now()}`,
            label: (currentAddress.label || 'Home') as 'Home' | 'Work' | 'Other',
            receiverName: currentAddress.receiverName || 'Customer',
            phone: currentAddress.phone || '+91 98765 43210',
            flatBuilding:
              details?.flatBuilding ||
              (addressSummary ? `Near ${addressSummary.split(',')[0]}` : 'Doorstep Location'),
            streetArea: details?.streetArea || addressSummary || 'Pinned Location',
            landmark:
              details?.landmark ||
              (addressSummary ? `Near ${addressSummary.split(',')[0]}` : undefined),
            city: details?.city || 'Tirupati',
            state: 'Andhra Pradesh',
            postalCode: details?.postalCode || '517501',
            isDefault: true,
            coordinates: newCoords,
          };
          addAddress(newAddr);
          selectAddress(newAddr.id);
          setIsPinMapOpen(false);
          onClose();
          showToast(`Delivery location set to ${newAddr.streetArea}`, 'success');
        }}
      />
    </>
  );
};
