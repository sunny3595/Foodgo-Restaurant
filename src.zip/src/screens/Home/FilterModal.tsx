/**
 * Filter & Sort Modal
 * Multi-criteria filter options (Sort, Distance Radius, Rating, Pure Veg, Speed, Open Now).
 */

import React, { useState } from 'react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';

export interface FilterState {
  sortBy: 'recommended' | 'rating' | 'deliveryTime' | 'distance' | 'priceLow' | 'priceHigh';
  rating4Plus: boolean;
  pureVegOnly: boolean;
  freeDeliveryOnly: boolean;
  fastDeliveryOnly: boolean;
  openNowOnly: boolean;
  maxDistanceKm?: number;
}

export interface FilterModalProps {
  isOpen: boolean;
  onClose: () => void;
  filters: FilterState;
  onApply: (newFilters: FilterState) => void;
  matchingCount?: number;
}

export const FilterModal: React.FC<FilterModalProps> = ({
  isOpen,
  onClose,
  filters,
  onApply,
  matchingCount,
}) => {
  const [localFilters, setLocalFilters] = useState<FilterState>(filters);

  const handleApply = () => {
    onApply(localFilters);
    onClose();
  };

  const handleReset = () => {
    const resetState: FilterState = {
      sortBy: 'recommended',
      rating4Plus: false,
      pureVegOnly: false,
      freeDeliveryOnly: false,
      fastDeliveryOnly: false,
      openNowOnly: false,
      maxDistanceKm: undefined,
    };
    setLocalFilters(resetState);
    onApply(resetState);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Filter & Sort Restaurants"
      subtitle="Find exactly what you crave near your address"
    >
      <div className="space-y-5">
        {/* Sort Section */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            Sort by
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'recommended', label: 'Recommended' },
              { id: 'rating', label: 'Rating: High to Low' },
              { id: 'deliveryTime', label: 'Fastest Delivery' },
              { id: 'distance', label: 'Closest Distance' },
              { id: 'priceLow', label: 'Cost: Low to High' },
              { id: 'priceHigh', label: 'Cost: High to Low' },
            ].map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() =>
                  setLocalFilters({
                    ...localFilters,
                    sortBy: opt.id as FilterState['sortBy'],
                  })
                }
                className={`min-h-[44px] px-3 text-xs font-semibold rounded-2xl border transition-colors cursor-pointer text-left ${
                  localFilters.sortBy === opt.id
                    ? 'border-[#E23744] bg-red-50 dark:bg-red-950/40 text-[#E23744]'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Distance Radius */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            Delivery Radius
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: 'Any Distance', val: undefined },
              { label: '< 2 km', val: 2 },
              { label: '< 5 km', val: 5 },
            ].map((dist, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setLocalFilters({ ...localFilters, maxDistanceKm: dist.val })}
                className={`min-h-[40px] px-3 text-xs font-semibold rounded-xl border transition-colors cursor-pointer text-center ${
                  localFilters.maxDistanceKm === dist.val
                    ? 'border-[#E23744] bg-red-50 dark:bg-red-950/40 text-[#E23744]'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {dist.label}
              </button>
            ))}
          </div>
        </div>

        {/* Dietary & Speed Preferences */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            Preferences & Timing
          </label>
          <div className="space-y-2">
            <label className="flex items-center justify-between p-3 rounded-2xl border border-slate-200 dark:border-slate-800 cursor-pointer">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Pure Veg Only (Green Flagged)
              </span>
              <input
                type="checkbox"
                checked={localFilters.pureVegOnly}
                onChange={(e) =>
                  setLocalFilters({ ...localFilters, pureVegOnly: e.target.checked })
                }
                className="w-4 h-4 accent-emerald-600 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-2xl border border-slate-200 dark:border-slate-800 cursor-pointer">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Top Rated (4.0+ Stars)
              </span>
              <input
                type="checkbox"
                checked={localFilters.rating4Plus}
                onChange={(e) =>
                  setLocalFilters({ ...localFilters, rating4Plus: e.target.checked })
                }
                className="w-4 h-4 accent-[#E23744] rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-2xl border border-slate-200 dark:border-slate-800 cursor-pointer">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Fast Delivery (Under 25 min)
              </span>
              <input
                type="checkbox"
                checked={localFilters.fastDeliveryOnly}
                onChange={(e) =>
                  setLocalFilters({ ...localFilters, fastDeliveryOnly: e.target.checked })
                }
                className="w-4 h-4 accent-[#E23744] rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-2xl border border-slate-200 dark:border-slate-800 cursor-pointer">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Open Now Only
              </span>
              <input
                type="checkbox"
                checked={localFilters.openNowOnly}
                onChange={(e) =>
                  setLocalFilters({ ...localFilters, openNowOnly: e.target.checked })
                }
                className="w-4 h-4 accent-[#E23744] rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-2xl border border-slate-200 dark:border-slate-800 cursor-pointer">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Free Delivery
              </span>
              <input
                type="checkbox"
                checked={localFilters.freeDeliveryOnly}
                onChange={(e) =>
                  setLocalFilters({ ...localFilters, freeDeliveryOnly: e.target.checked })
                }
                className="w-4 h-4 accent-[#E23744] rounded"
              />
            </label>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 pt-2">
          <Button
            size="md"
            variant="outline"
            fullWidth
            onClick={handleReset}
          >
            Clear All
          </Button>

          <Button
            size="md"
            fullWidth
            onClick={handleApply}
          >
            {matchingCount !== undefined ? `Apply (${matchingCount})` : 'Apply Filters'}
          </Button>
        </div>
      </div>
    </Modal>
  );
};
