/**
 * Home Screen - Phase 3 Home & Discovery Engine
 * Master discovery view featuring:
 * - Dynamic Haversine distance & delivery ETA relative to active delivery address
 * - Interactive Promotional Banner Carousel with promo codes & category jumps
 * - "What's on your mind?" Cuisine category carousel
 * - "Lightning Fast Delivery" curated horizontal reel
 * - Multi-criteria filter drawer with distance radius, rating, open-now, and pure veg
 * - Full restaurant discovery feed adhering to zero-pill metadata discipline
 */

import React, { useEffect, useState, useMemo } from 'react';
import { Sparkles, Utensils, Zap, Clock, MapPin, X } from 'lucide-react';
import { TopHeader } from '../../components/navigation/TopHeader';
import { SearchBar } from '../../components/ui/SearchBar';
import { RestaurantCard } from '../../components/cards/RestaurantCard';
import { BannerCarousel } from '../../components/cards/BannerCarousel';
import { CategoryStrip } from '../../components/cards/CategoryStrip';
import { RestaurantCardSkeleton } from '../../components/ui/Skeleton';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorState } from '../../components/ui/ErrorState';
import { AddressPickerModal } from './AddressPickerModal';
import { FilterModal, FilterState } from './FilterModal';
import { NotificationsModal } from '../Profile/NotificationsModal';
import { MobilePushNotificationBanner } from '../../components/notifications/MobilePushNotificationBanner';
import { restaurantService } from '../../services/restaurantService';
import { bannerService } from '../../services/bannerService';
import { notificationService } from '../../services/notificationService';
import { mockRestaurantApi } from '../../services/api/mockApi';
import { Restaurant, Category, OfferBanner } from '../../types/restaurant';
import { useApp } from '../../store/appContext';
import { useAuth } from '../../store/authContext';
import { useLocation } from '../../store/locationContext';

export interface HomeScreenProps {
  onRestaurantClick?: (restaurantId: string) => void;
  onProfileClick?: () => void;
  onSearchFocus?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onRestaurantClick,
  onProfileClick,
}) => {
  const { showToast, isOnline } = useApp();
  const { triggerProtectedAction } = useAuth();
  const { currentAddress } = useLocation();

  const [categories, setCategories] = useState<Category[]>([]);
  const [offers, setOffers] = useState<OfferBanner[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  const [filters, setFilters] = useState<FilterState>({
    sortBy: 'recommended',
    rating4Plus: false,
    pureVegOnly: false,
    freeDeliveryOnly: false,
    fastDeliveryOnly: false,
    openNowOnly: false,
    maxDistanceKm: undefined,
  });

  // Load catalog data & subscribe to real-time customizable banners & broadcasts
  useEffect(() => {
    const fetchCatalog = async () => {
      try {
        const [cats, offs] = await Promise.all([
          mockRestaurantApi.getCategories(),
          bannerService.getBanners(),
        ]);
        setCategories(cats);
        setOffers(offs);
      } catch (err: unknown) {
        setError((err as Error).message || 'Failed to load offers and categories');
      } finally {
        setIsLoading(false);
      }
    };

    fetchCatalog();

    // Subscribe to live banner additions / edits from admin
    const unsubBanners = bannerService.subscribeBanners((liveBanners) => {
      if (liveBanners && liveBanners.length > 0) {
        setOffers(liveBanners);
      }
    });

    // Subscribe to real-time morning motivation & push broadcasts
    const unsubBroadcasts = notificationService.subscribeBroadcasts();

    return () => {
      unsubBanners();
      unsubBroadcasts();
    };
  }, [isOnline]);

  // Compute restaurants dynamically relative to user's selected address coordinates (Haversine math)
  const processedRestaurants = useMemo(() => {
    return restaurantService.getProcessedRestaurants(currentAddress.coordinates);
  }, [currentAddress.coordinates]);

  // Filter and sort the processed restaurants
  const filteredRestaurants = useMemo(() => {
    return restaurantService.filterAndSortRestaurants(processedRestaurants, {
      searchQuery,
      category: selectedCategory,
      pureVegOnly: filters.pureVegOnly,
      ratingMin: filters.rating4Plus ? 4.0 : undefined,
      maxDeliveryTime: filters.fastDeliveryOnly ? 25 : undefined,
      maxDistanceKm: filters.maxDistanceKm,
      openNowOnly: filters.openNowOnly,
      freeDeliveryOnly: filters.freeDeliveryOnly,
      sortBy: filters.sortBy,
    });
  }, [processedRestaurants, searchQuery, selectedCategory, filters]);

  // Fast Delivery Reel (< 25 min)
  const fastDeliveryKitchens = useMemo(() => {
    return processedRestaurants.filter((r) => r.isFastDelivery && r.isOpen);
  }, [processedRestaurants]);

  const hasActiveFilters =
    filters.pureVegOnly ||
    filters.rating4Plus ||
    filters.freeDeliveryOnly ||
    filters.fastDeliveryOnly ||
    filters.openNowOnly ||
    filters.maxDistanceKm !== undefined ||
    filters.sortBy !== 'recommended' ||
    selectedCategory !== 'All';

  const clearAllFilters = () => {
    setFilters({
      sortBy: 'recommended',
      rating4Plus: false,
      pureVegOnly: false,
      freeDeliveryOnly: false,
      fastDeliveryOnly: false,
      openNowOnly: false,
      maxDistanceKm: undefined,
    });
    setSelectedCategory('All');
    setSearchQuery('');
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-50 dark:bg-slate-950 pb-24 text-slate-900 dark:text-slate-100 relative">
      {/* Flipkart / Amazon Style Mobile Push Notification Banner */}
      <MobilePushNotificationBanner onOpenNotifications={() => setIsNotificationsOpen(true)} />

      {/* Sticky Top Bar with Address & Notifications */}
      <TopHeader
        onLocationClick={() => setIsAddressModalOpen(true)}
        onNotificationClick={() => setIsNotificationsOpen(true)}
        onProfileClick={onProfileClick}
      />

      {/* Main Discovery Feed */}
      <div className="space-y-5 px-4 pt-3">
        {/* Search Bar with filter drawer & voice trigger */}
        <SearchBar
          value={searchQuery}
          onChange={setSearchQuery}
          placeholder="Restaurant name, biryani, burger, dosa..."
          onFilterClick={() => setIsFilterModalOpen(true)}
          onVoiceClick={() => showToast('Voice search listening...', 'info')}
          hasActiveFilters={hasActiveFilters}
        />

        {/* Promotional Slidable Hero Banner Carousel */}
        {offers.length > 0 && !searchQuery && (
          <BannerCarousel
            banners={offers}
            onApplyCoupon={(code) => showToast(`Coupon ${code} applied to your cart!`, 'success')}
            onCategoryJump={(cat) => {
              setSelectedCategory(cat);
              showToast(`Showing popular ${cat} kitchens`, 'info');
            }}
          />
        )}

        {/* Cuisine Category Navigation Strip */}
        {!searchQuery && (
          <CategoryStrip
            categories={categories}
            selectedCategory={selectedCategory}
            onSelectCategory={(cat) => setSelectedCategory(cat)}
          />
        )}

        {/* Lightning Fast Delivery Reel (Under 25 mins) */}
        {!searchQuery && selectedCategory === 'All' && fastDeliveryKitchens.length > 0 && (
          <section aria-label="Fast Delivery" className="space-y-2.5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-500 fill-current" />
                  <span>Lightning Fast Delivery</span>
                </h2>
                <p className="text-[11px] text-slate-400">At your doorstep in under 25 mins</p>
              </div>

              <span className="text-[11px] font-bold text-[#E23744]">
                {fastDeliveryKitchens.length} Spots
              </span>
            </div>

            <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-4 px-4 py-1">
              {fastDeliveryKitchens.map((restaurant) => (
                <div key={restaurant.id} className="w-64 shrink-0">
                  <RestaurantCard
                    restaurant={restaurant}
                    onClick={() => {
                      onRestaurantClick?.(restaurant.id);
                      showToast(`Selected ${restaurant.name} (Menu in Phase 5)`, 'info');
                    }}
                    onFavoriteToggle={(isFav) => {
                      triggerProtectedAction(() => {
                        showToast(
                          isFav
                            ? `Saved ${restaurant.name} to Favorites`
                            : `Removed ${restaurant.name} from Favorites`,
                          'info'
                        );
                      }, 'favorites');
                    }}
                  />
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Interactive Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar -mx-4 px-4 py-1 text-xs">
          {hasActiveFilters && (
            <button
              type="button"
              onClick={clearAllFilters}
              className="min-h-[38px] px-3 rounded-xl font-bold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center gap-1 transition-colors shrink-0 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          )}

          <button
            type="button"
            onClick={() =>
              setFilters((prev) => ({ ...prev, pureVegOnly: !prev.pureVegOnly }))
            }
            className={`min-h-[38px] px-3.5 rounded-xl font-bold flex items-center gap-1.5 transition-colors shrink-0 border cursor-pointer ${
              filters.pureVegOnly
                ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Pure Veg</span>
          </button>

          <button
            type="button"
            onClick={() =>
              setFilters((prev) => ({ ...prev, rating4Plus: !prev.rating4Plus }))
            }
            className={`min-h-[38px] px-3.5 rounded-xl font-bold flex items-center gap-1 transition-colors shrink-0 border cursor-pointer ${
              filters.rating4Plus
                ? 'bg-amber-500 border-amber-500 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <span>★ 4.0+</span>
          </button>

          <button
            type="button"
            onClick={() =>
              setFilters((prev) => ({ ...prev, fastDeliveryOnly: !prev.fastDeliveryOnly }))
            }
            className={`min-h-[38px] px-3.5 rounded-xl font-bold flex items-center gap-1 transition-colors shrink-0 border cursor-pointer ${
              filters.fastDeliveryOnly
                ? 'bg-[#E23744] border-[#E23744] text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Fast Delivery</span>
          </button>

          <button
            type="button"
            onClick={() =>
              setFilters((prev) => ({
                ...prev,
                maxDistanceKm: prev.maxDistanceKm === 2 ? undefined : 2,
              }))
            }
            className={`min-h-[38px] px-3.5 rounded-xl font-bold flex items-center gap-1 transition-colors shrink-0 border cursor-pointer ${
              filters.maxDistanceKm === 2
                ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Within 2 km</span>
          </button>

          <button
            type="button"
            onClick={() =>
              setFilters((prev) => ({ ...prev, openNowOnly: !prev.openNowOnly }))
            }
            className={`min-h-[38px] px-3.5 rounded-xl font-bold flex items-center gap-1 transition-colors shrink-0 border cursor-pointer ${
              filters.openNowOnly
                ? 'bg-[#E23744] border-[#E23744] text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <span>Open Now</span>
          </button>

          <button
            type="button"
            onClick={() =>
              setFilters((prev) => ({
                ...prev,
                freeDeliveryOnly: !prev.freeDeliveryOnly,
              }))
            }
            className={`min-h-[38px] px-3.5 rounded-xl font-bold flex items-center gap-1 transition-colors shrink-0 border cursor-pointer ${
              filters.freeDeliveryOnly
                ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <span>Free Delivery</span>
          </button>
        </div>

        {/* Main Restaurant Discovery List */}
        <section aria-label="Available Restaurants" className="space-y-3 pt-1">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <span>Kitchens Delivering to {currentAddress.label}</span>
                <Sparkles className="w-4 h-4 text-amber-500 fill-current" />
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {isLoading
                  ? 'Calculating distances and delivery fees...'
                  : `${filteredRestaurants.length} restaurants ready near ${currentAddress.streetArea}`}
              </p>
            </div>
          </div>

          {/* Loading Skeleton */}
          {isLoading && (
            <div className="space-y-4">
              <RestaurantCardSkeleton />
              <RestaurantCardSkeleton />
            </div>
          )}

          {/* Error State */}
          {!isLoading && error && (
            <ErrorState message={error} onRetry={() => window.location.reload()} />
          )}

          {/* Empty State */}
          {!isLoading && !error && filteredRestaurants.length === 0 && (
            <EmptyState
              icon={<Utensils className="w-10 h-10 text-slate-400" />}
              title="No restaurants match these filters"
              description="Try adjusting your cuisine or delivery radius to see more places delivering to your area."
              actionLabel="Clear All Filters"
              onAction={clearAllFilters}
            />
          )}

          {/* Loaded Restaurant Cards */}
          {!isLoading && !error && filteredRestaurants.length > 0 && (
            <div className="space-y-4">
              {filteredRestaurants.map((restaurant) => (
                <RestaurantCard
                  key={restaurant.id}
                  restaurant={restaurant}
                  onClick={() => {
                    onRestaurantClick?.(restaurant.id);
                    showToast(`Selected ${restaurant.name} (Full Menu in Phase 5)`, 'info');
                  }}
                  onFavoriteToggle={(isFav) => {
                    triggerProtectedAction(() => {
                      showToast(
                        isFav
                          ? `Saved ${restaurant.name} to Favorites`
                          : `Removed ${restaurant.name} from Favorites`,
                        'info'
                      );
                    }, 'favorites');
                  }}
                />
              ))}
            </div>
          )}
        </section>
      </div>

      {/* Modals */}
      <AddressPickerModal
        isOpen={isAddressModalOpen}
        onClose={() => setIsAddressModalOpen(false)}
      />

      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
      />

      <FilterModal
        isOpen={isFilterModalOpen}
        onClose={() => setIsFilterModalOpen(false)}
        filters={filters}
        onApply={(newFilters) => setFilters(newFilters)}
        matchingCount={filteredRestaurants.length}
      />
    </div>
  );
};
