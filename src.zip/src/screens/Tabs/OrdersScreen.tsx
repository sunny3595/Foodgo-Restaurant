/**
 * Orders Screen (Tab 3)
 * Displays active and past food orders with real-time status badges,
 * item details, and direct tracking buttons.
 */

import React, { useState } from 'react';
import { ShoppingBag, Clock, ChevronRight, Bike, MapPin, CheckCircle2 } from 'lucide-react';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { useAuth } from '../../store/authContext';
import { useOrder } from '../../store/orderContext';
import { Order } from '../../types/order';

export interface OrdersScreenProps {
  onExplore: () => void;
  onTrackOrder?: (order: Order) => void;
}

export const OrdersScreen: React.FC<OrdersScreenProps> = ({
  onExplore,
  onTrackOrder,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'active' | 'past'>('active');
  const { isGuest, setGuestPromptOpen } = useAuth();
  const { orders, setActiveOrder } = useOrder();

  if (isGuest) {
    return (
      <div className="flex-1 flex flex-col p-4 pb-24 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 justify-center">
        <EmptyState
          icon={<ShoppingBag className="w-12 h-12 text-slate-400" />}
          title="Sign in to track orders"
          description="Your active orders, live GPS delivery updates, and past receipts will appear here once you sign in."
          actionLabel="Sign In to FoodGo"
          onAction={() => setGuestPromptOpen(true)}
        />
      </div>
    );
  }

  const activeOrders = orders.filter(
    (o) => o.status !== 'delivered' && o.status !== 'cancelled'
  );
  const pastOrders = orders.filter(
    (o) => o.status === 'delivered' || o.status === 'cancelled'
  );

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'placed':
        return (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 uppercase">
            Order Placed
          </span>
        );
      case 'confirmed':
        return (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 uppercase">
            Confirmed
          </span>
        );
      case 'preparing':
        return (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 uppercase animate-pulse">
            Kitchen Preparing
          </span>
        );
      case 'ready':
      case 'out_for_delivery':
        return (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 uppercase animate-pulse">
            Out for Delivery
          </span>
        );
      case 'delivered':
        return (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 uppercase">
            Delivered
          </span>
        );
      default:
        return (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500 uppercase">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 pb-28 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <div className="pt-safe mb-4">
        <h1 className="text-xl font-extrabold mb-3">My Food Orders</h1>

        {/* Sub tabs */}
        <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-2xl">
          <button
            type="button"
            onClick={() => setActiveSubTab('active')}
            className={`flex-1 min-h-[38px] text-xs font-bold rounded-xl transition-colors cursor-pointer ${
              activeSubTab === 'active'
                ? 'bg-white dark:bg-slate-800 text-[#E23744] shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Active Orders ({activeOrders.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveSubTab('past')}
            className={`flex-1 min-h-[38px] text-xs font-bold rounded-xl transition-colors cursor-pointer ${
              activeSubTab === 'past'
                ? 'bg-white dark:bg-slate-800 text-[#E23744] shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Past Orders ({pastOrders.length})
          </button>
        </div>
      </div>

      {activeSubTab === 'active' ? (
        activeOrders.length === 0 ? (
          <EmptyState
            icon={<ShoppingBag className="w-12 h-12 text-slate-400" />}
            title="No live orders right now"
            description="Your active orders and live GPS delivery tracking will appear here once you place an order."
            actionLabel="Find Food Nearby"
            onAction={onExplore}
          />
        ) : (
          <div className="space-y-4">
            {activeOrders.map((order) => (
              <div
                key={order.id}
                className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {order.restaurant.name}
                    </h3>
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-0.5">
                      <Clock className="w-3 h-3" />
                      <span>
                        Order {order.id} · {order.placedAt} · ₹{order.bill.totalPayable}
                      </span>
                    </div>
                  </div>

                  {getStatusBadge(order.status)}
                </div>

                {/* Items summary */}
                <div className="text-xs text-slate-600 dark:text-slate-400 border-t border-b border-slate-100 dark:border-slate-800 py-2 space-y-0.5">
                  {order.items.map((i) => (
                    <div key={i.id} className="truncate">
                      {i.quantity}x {i.food.name}
                      {i.customization.variation && ` (${i.customization.variation.name})`}
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500">
                    <Bike className="w-4 h-4 text-[#E23744]" />
                    <span>ETA: {order.estimatedDeliveryTimestamp}</span>
                  </div>

                  <Button
                    size="sm"
                    onClick={() => {
                      setActiveOrder(order);
                      onTrackOrder?.(order);
                    }}
                  >
                    Track Live Order
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )
      ) : pastOrders.length === 0 ? (
        <EmptyState
          icon={<Clock className="w-12 h-12 text-slate-400" />}
          title="No past orders"
          description="Your completed and delivered orders will show up here for easy reordering."
          actionLabel="Find Food Nearby"
          onAction={onExplore}
        />
      ) : (
        <div className="space-y-3">
          {pastOrders.map((order) => (
            <div
              key={order.id}
              className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    {order.restaurant.name}
                  </h3>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-0.5">
                    <Clock className="w-3 h-3" />
                    <span>Delivered · ₹{order.bill.totalPayable}</span>
                  </div>
                </div>
                {getStatusBadge(order.status)}
              </div>

              <div className="text-xs text-slate-600 dark:text-slate-400 border-t border-b border-slate-100 dark:border-slate-800 py-2">
                {order.items.map((i) => `${i.quantity}x ${i.food.name}`).join(', ')}
              </div>

              <div className="flex items-center justify-between pt-1">
                <Button size="sm" variant="outline">
                  Rate Order
                </Button>
                <Button size="sm" variant="primary" onClick={onExplore}>
                  Reorder
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
