/**
 * Profile Screen (Tab 5 - Phase 9)
 * Comprehensive user management, saved addresses, reviews, notifications,
 * settings, help & support, and secure session logout.
 */

import React, { useState, useEffect } from 'react';
import {
  User,
  MapPin,
  Clock,
  Star,
  Bell,
  Settings,
  HelpCircle,
  Info,
  LogOut,
  ChevronRight,
  ShieldCheck,
  Edit2,
  Sparkles,
  Camera,
  Sun,
} from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Modal } from '../../components/ui/Modal';
import { AddressManagementModal } from '../Profile/AddressManagementModal';
import { SettingsModal } from '../Profile/SettingsModal';
import { ReviewsModal } from '../Profile/ReviewsModal';
import { NotificationsModal } from '../Profile/NotificationsModal';
import { HelpSupportModal } from '../Profile/HelpSupportModal';
import { AboutAppModal } from '../Profile/AboutAppModal';
import { EditProfileModal } from '../Profile/EditProfileModal';
import { useAuth } from '../../store/authContext';
import { useLocation } from '../../store/locationContext';
import { useApp } from '../../store/appContext';
import { notificationService } from '../../services/notificationService';

export interface ProfileScreenProps {
  onLoginPrompt: () => void;
  onAddressClick?: () => void;
  onViewOrders?: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  onLoginPrompt,
  onAddressClick,
  onViewOrders,
}) => {
  const { user, isGuest, logout } = useAuth();
  const { currentAddress } = useLocation();
  const { showToast } = useApp();

  // Modals state
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isReviewsModalOpen, setIsReviewsModalOpen] = useState(false);
  const [isNotificationsModalOpen, setIsNotificationsModalOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isAboutModalOpen, setIsAboutModalOpen] = useState(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    setUnreadCount(notificationService.getUnreadCount());
  }, [isNotificationsModalOpen]);

  const handleLogoutConfirm = async () => {
    await logout();
    setIsLogoutModalOpen(false);
    showToast('Logged out successfully', 'info');
    onLoginPrompt();
  };

  return (
    <div className="flex-1 flex flex-col p-4 pb-28 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <div className="pt-safe mb-3">
        <h1 className="text-xl font-extrabold tracking-tight">My Profile & Account</h1>
      </div>

      {/* User Header Profile Card */}
      {isGuest ? (
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs mb-4 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center text-xl font-bold">
              👤
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Welcome, Foodie Guest!
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Sign in to save addresses, track live orders, and unlock member rewards.
              </p>
            </div>
          </div>

          <Button size="md" fullWidth onClick={onLoginPrompt}>
            Sign In / Register
          </Button>
        </div>
      ) : (
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#E23744] to-red-400 text-white flex items-center justify-center font-extrabold text-xl shadow-md">
                {user?.firstName?.[0] || 'N'}
              </div>
              <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-extrabold text-slate-900 dark:text-slate-100">
                  {user ? `${user.firstName} ${user.lastName}` : 'Nithin Ojili'}
                </h2>
                <span className="text-[10px] font-bold text-[#E23744] bg-red-50 dark:bg-red-950/40 px-1.5 py-0.2 rounded-md">
                  FoodGo Gold
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{user?.phone || '+91 98480 12345'}</p>
              <p className="text-[11px] text-slate-400">{user?.email || 'ojilinithinnithin@gmail.com'}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsEditProfileOpen(true)}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Edit Profile"
          >
            <Edit2 className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Account Settings Menu */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden shadow-xs">
        {/* Manage Addresses */}
        <button
          type="button"
          onClick={() => setIsAddressModalOpen(true)}
          className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-red-50 dark:bg-red-950/40 text-[#E23744] flex items-center justify-center">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                Manage Delivery Addresses
              </span>
              <span className="text-[10px] text-slate-400">
                Default: {currentAddress.label} ({currentAddress.streetArea})
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Reviews & Ratings */}
        <button
          type="button"
          onClick={() => setIsReviewsModalOpen(true)}
          className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-500 flex items-center justify-center">
              <Star className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                Reviews & Ratings
              </span>
              <span className="text-[10px] text-slate-400">
                Rate your past orders & see feedback
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Notifications */}
        <button
          type="button"
          onClick={() => setIsNotificationsModalOpen(true)}
          className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-600 flex items-center justify-center relative">
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-[#E23744]" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  Notifications
                </span>
                {unreadCount > 0 && (
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-[#E23744] text-white">
                    {unreadCount} new
                  </span>
                )}
              </div>
              <span className="text-[10px] text-slate-400">
                Order alerts, discounts, and vouchers
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* App Settings */}
        <button
          type="button"
          onClick={() => setIsSettingsModalOpen(true)}
          className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                Preferences & Theme
              </span>
              <span className="text-[10px] text-slate-400">
                Dark mode, language, and notifications
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Help & Support */}
        <button
          type="button"
          onClick={() => setIsHelpModalOpen(true)}
          className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 flex items-center justify-center">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                Help & 24/7 Support
              </span>
              <span className="text-[10px] text-slate-400">
                FAQs, helpline, and dispute resolution
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* About App */}
        <button
          type="button"
          onClick={() => setIsAboutModalOpen(true)}
          className="w-full p-3.5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center">
              <Info className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                About FoodGo
              </span>
              <span className="text-[10px] text-slate-400">
                Version 1.0.0 · Terms & Privacy
              </span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Logout (if authenticated) */}
        {!isGuest && (
          <button
            type="button"
            onClick={() => setIsLogoutModalOpen(true)}
            className="w-full p-3.5 flex items-center justify-between text-left hover:bg-red-50/30 dark:hover:bg-red-950/20 transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-red-50 dark:bg-red-950/40 text-rose-600 flex items-center justify-center">
                <LogOut className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-rose-600 block">
                  Sign Out
                </span>
                <span className="text-[10px] text-slate-400">
                  Securely end your current session
                </span>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        )}
      </div>

      {/* Sub-modals */}
      <AddressManagementModal
        isOpen={isAddressModalOpen}
        onClose={() => setIsAddressModalOpen(false)}
      />

      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
      />

      <ReviewsModal
        isOpen={isReviewsModalOpen}
        onClose={() => setIsReviewsModalOpen(false)}
      />

      <NotificationsModal
        isOpen={isNotificationsModalOpen}
        onClose={() => setIsNotificationsModalOpen(false)}
      />

      <HelpSupportModal
        isOpen={isHelpModalOpen}
        onClose={() => setIsHelpModalOpen(false)}
      />

      <AboutAppModal
        isOpen={isAboutModalOpen}
        onClose={() => setIsAboutModalOpen(false)}
      />

      <EditProfileModal
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
      />

      {/* Logout Confirmation Modal */}
      <Modal
        isOpen={isLogoutModalOpen}
        onClose={() => setIsLogoutModalOpen(false)}
        title="Sign Out from FoodGo?"
        subtitle="You can sign back in anytime with your phone number"
      >
        <div className="space-y-4 pt-1">
          <p className="text-xs text-slate-500">
            Are you sure you want to sign out? Your saved addresses, past order receipts, and favorites are stored securely.
          </p>

          <div className="flex gap-2">
            <Button
              size="md"
              variant="outline"
              fullWidth
              onClick={() => setIsLogoutModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              size="md"
              variant="danger"
              fullWidth
              onClick={handleLogoutConfirm}
            >
              Sign Out
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
