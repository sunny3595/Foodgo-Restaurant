/**
 * Search Screen (Tab 2) - Phase 4 Dedicated Search & Discovery Engine
 * Features:
 * - Real-time debounced query processing
 * - Live suggestions dropdown matching dishes, restaurants, and cuisines
 * - Persistent search history with individual delete and clear-all
 * - Segmented results tabs: All, Dishes, Restaurants
 * - Multi-criteria filter drawer synchronization
 * - Direct "Add to Cart" and restaurant menu navigation triggers
 */

import React, { useState, useMemo, useEffect } from 'react';
import {
  Clock,
  TrendingUp,
  X,
  Search,
  SlidersHorizontal,
  Utensils,
  Store,
  ChevronRight,
  ShoppingBag,
} from 'lucide-react';
import { SearchBar } from '../../components/ui/SearchBar';
import { RestaurantCard } from '../../components/cards/RestaurantCard';
import { FoodCard } from '../../components/cards/FoodCard';
import { FilterModal, FilterState } from '../Home/FilterModal';
import { FoodCustomizationModal } from '../Restaurant/FoodCustomizationModal';
import { EmptyState } from '../../components/ui/EmptyState';
import { useDebounce } from '../../hooks/useDebounce';
import { searchHistoryService } from '../../services/searchHistory';
import { restaurantService } from '../../services/restaurantService';
import { MOCK_FOOD_ITEMS } from '../../services/mock/mockFoodItems';
import { FoodItem, Restaurant } from '../../types/restaurant';
import { useApp } from '../../store/appContext';
import { useAuth } from '../../store/authContext';
import { useLocation } from '../../store/locationContext';
import { useCart } from '../../store/cartContext';

export interface SearchScreenProps {
  onRestaurantClick?: (restaurantId: string) => void;
  onViewCart?: () => void;
}

export const SearchScreen: React.FC<SearchScreenProps> = ({
  onRestaurantClick,
  onViewCart,
}) => {
  const { showToast } = useApp();
  const { triggerProtectedAction } = useAuth();
  const { currentAddress } = useLocation();
  const { addItem, totalItems, subtotal, getItemQuantity } = useCart();

  const [customizingFood, setCustomizingFood] = useState<FoodItem | null>(null);

  const [rawQuery, setRawQuery] = useState('');
  const debouncedQuery = useDebounce(rawQuery, 250);

  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'dishes' | 'restaurants'>('all');
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);

  const [filters, setFilters] = useState<FilterState>({
    sortBy: 'recommended',
    rating4Plus: false,
    pureVegOnly: false,
    freeDeliveryOnly: false,
    fastDeliveryOnly: false,
    openNowOnly: false,
    maxDistanceKm: undefined,
  });

  // Load search history
  useEffect(() => {
    setRecentSearches(searchHistoryService.getRecentSearches());
  }, []);

  // Update history when user submits or types a meaningful search
  useEffect(() => {
    if (debouncedQuery.trim().length >= 3) {
      const updated = searchHistoryService.addSearch(debouncedQuery.trim());
      setRecentSearches(updated);
    }
  }, [debouncedQuery]);

  // Compute restaurants relative to user's active address
  const processedRestaurants = useMemo(() => {
    return restaurantService.getProcessedRestaurants(currentAddress.coordinates);
  }, [currentAddress.coordinates]);

  const restaurantMap = useMemo(() => {
    const map = new Map<string, Restaurant>();
    processedRestaurants.forEach((r) => map.set(r.id, r));
    return map;
  }, [processedRestaurants]);

  // Filtered Restaurants matching query and filters
  const matchedRestaurants = useMemo(() => {
    return restaurantService.filterAndSortRestaurants(processedRestaurants, {
      searchQuery: debouncedQuery,
      pureVegOnly: filters.pureVegOnly,
      ratingMin: filters.rating4Plus ? 4.0 : undefined,
      maxDeliveryTime: filters.fastDeliveryOnly ? 25 : undefined,
      maxDistanceKm: filters.maxDistanceKm,
      openNowOnly: filters.openNowOnly,
      freeDeliveryOnly: filters.freeDeliveryOnly,
      sortBy: filters.sortBy,
    });
  }, [processedRestaurants, debouncedQuery, filters]);

  // Filtered Food Dishes matching query and filters
  const matchedDishes = useMemo(() => {
    if (!debouncedQuery.trim()) return [];

    const q = debouncedQuery.toLowerCase().trim();
    let list = MOCK_FOOD_ITEMS.filter((item) => {
      const rest = restaurantMap.get(item.restaurantId);
      const matchesName = item.name.toLowerCase().includes(q);
      const matchesDesc = item.description.toLowerCase().includes(q);
      const matchesCategory = item.category.toLowerCase().includes(q);
      const matchesRestaurant = rest?.name.toLowerCase().includes(q);
      return matchesName || matchesDesc || matchesCategory || matchesRestaurant;
    });

    if (filters.pureVegOnly) {
      list = list.filter((item) => item.isVeg);
    }
    if (filters.rating4Plus) {
      list = list.filter((item) => item.rating >= 4.0);
    }
    if (filters.fastDeliveryOnly) {
      list = list.filter((item) => {
        const rest = restaurantMap.get(item.restaurantId);
        return rest ? rest.isFastDelivery : false;
      });
    }

    return list;
  }, [debouncedQuery, filters, restaurantMap]);

  // Instant Suggestions (shown while typing)
  const suggestions = useMemo(() => {
    if (!rawQuery.trim() || rawQuery.trim().length < 2) return [];
    const q = rawQuery.toLowerCase().trim();

    const matches: Array<{ label: string; type: 'dish' | 'restaurant' | 'cuisine' }> = [];

    // Check restaurants
    processedRestaurants.forEach((r) => {
      if (r.name.toLowerCase().includes(q) && matches.length < 5) {
        matches.push({ label: r.name, type: 'restaurant' });
      }
    });

    // Check dishes
    MOCK_FOOD_ITEMS.forEach((f) => {
      if (f.name.toLowerCase().includes(q) && matches.length < 5) {
        matches.push({ label: f.name, type: 'dish' });
      }
    });

    return matches;
  }, [rawQuery, processedRestaurants]);

  const popularSearches = [
    'Biryani',
    'Masala Dosa',
    'Pizza',
    'Burger',
    'Chole Bhature',
    'Hakka Noodles',
    'Frankie',
    'Filter Coffee',
  ];

  const handleClearHistory = () => {
    const updated = searchHistoryService.clearAll();
    setRecentSearches(updated);
    showToast('Search history cleared', 'info');
  };

  const handleRemoveSingleHistory = (e: React.MouseEvent, item: string) => {
    e.stopPropagation();
    const updated = searchHistoryService.removeSearch(item);
    setRecentSearches(updated);
  };

  const handleAddDish = (food: FoodItem) => {
    const hasCustomization =
      (food.variations && food.variations.length > 0) ||
      (food.addons && food.addons.length > 0);

    const restaurant =
      restaurantMap.get(food.restaurantId) ||
      restaurantService.getRestaurantById(food.restaurantId, currentAddress.coordinates);

    if (hasCustomization) {
      setCustomizingFood(food);
    } else {
      if (restaurant) {
        addItem(food, { addons: [] }, restaurant, 1);
        showToast(`Added ${food.name} to cart`, 'success');
      }
    }
  };

  const totalResults = matchedRestaurants.length + matchedDishes.length;

  return (
    <div className="flex-1 flex flex-col p-4 pb-28 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Search Header */}
      <div className="pt-safe mb-3 space-y-2">
        <h1 className="text-xl font-extrabold tracking-tight">Search Food & Places</h1>

        <SearchBar
          value={rawQuery}
          onChange={setRawQuery}
          placeholder="Restaurant name, dish, or cuisine..."
          onFilterClick={() => setIsFilterModalOpen(true)}
          onVoiceClick={() => showToast('Voice search listening...', 'info')}
          hasActiveFilters={
            filters.pureVegOnly ||
            filters.rating4Plus ||
            filters.freeDeliveryOnly ||
            filters.fastDeliveryOnly ||
            filters.openNowOnly
          }
        />
      </div>

      {/* Live Auto-Suggestions Dropdown */}
      {suggestions.length > 0 && rawQuery.trim() !== debouncedQuery.trim() && (
        <div className="mb-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden">
          {suggestions.map((s, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => setRawQuery(s.label)}
              className="w-full px-4 py-2.5 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <Search className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                  {s.label}
                </span>
              </div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider">
                in {s.type}
              </span>
            </button>
          ))}
        </div>
      )}

      {/* View 1: When Search Bar is Empty */}
      {!debouncedQuery.trim() ? (
        <div className="space-y-6 pt-1">
          {/* Recent Searches Section */}
          {recentSearches.length > 0 && (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Recent Searches</span>
                </span>
                <button
                  type="button"
                  onClick={handleClearHistory}
                  className="text-xs font-semibold text-[#E23744] hover:underline cursor-pointer"
                >
                  Clear All
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {recentSearches.map((item) => (
                  <div
                    key={item}
                    onClick={() => setRawQuery(item)}
                    className="min-h-[38px] pl-3.5 pr-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-medium flex items-center gap-1.5 hover:border-slate-300 dark:hover:border-slate-700 transition-colors cursor-pointer group shadow-xs"
                  >
                    <span>{item}</span>
                    <button
                      type="button"
                      onClick={(e) => handleRemoveSingleHistory(e, item)}
                      className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-full"
                      aria-label={`Remove ${item}`}
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Popular Suggestions */}
          <div className="space-y-2.5">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-amber-500" />
              <span>Popular Cuisines & Dishes</span>
            </span>

            <div className="flex flex-wrap gap-2">
              {popularSearches.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setRawQuery(tag)}
                  className="min-h-[38px] px-3.5 rounded-xl bg-red-50/70 dark:bg-red-950/30 border border-red-100 dark:border-red-900/40 text-[#E23744] text-xs font-bold hover:bg-red-100 transition-colors cursor-pointer"
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* View 2: When Search Bar has an Active Query */
        <div className="space-y-4 pt-1">
          {/* Segmented Results Tabs */}
          <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-2xl">
            <button
              type="button"
              onClick={() => setActiveTab('all')}
              className={`flex-1 min-h-[38px] text-xs font-bold rounded-xl transition-colors cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-white dark:bg-slate-800 text-[#E23744] shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              All ({totalResults})
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('dishes')}
              className={`flex-1 min-h-[38px] text-xs font-bold rounded-xl transition-colors cursor-pointer ${
                activeTab === 'dishes'
                  ? 'bg-white dark:bg-slate-800 text-[#E23744] shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Dishes ({matchedDishes.length})
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('restaurants')}
              className={`flex-1 min-h-[38px] text-xs font-bold rounded-xl transition-colors cursor-pointer ${
                activeTab === 'restaurants'
                  ? 'bg-white dark:bg-slate-800 text-[#E23744] shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Restaurants ({matchedRestaurants.length})
            </button>
          </div>

          {/* Quick Filter Pill Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar -mx-4 px-4 py-0.5 text-xs">
            <button
              type="button"
              onClick={() =>
                setFilters((prev) => ({ ...prev, pureVegOnly: !prev.pureVegOnly }))
              }
              className={`min-h-[36px] px-3 rounded-xl font-bold flex items-center gap-1.5 transition-colors shrink-0 border cursor-pointer ${
                filters.pureVegOnly
                  ? 'bg-emerald-600 border-emerald-600 text-white'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Pure Veg</span>
            </button>

            <button
              type="button"
              onClick={() =>
                setFilters((prev) => ({ ...prev, rating4Plus: !prev.rating4Plus }))
              }
              className={`min-h-[36px] px-3 rounded-xl font-bold flex items-center gap-1 transition-colors shrink-0 border cursor-pointer ${
                filters.rating4Plus
                  ? 'bg-amber-500 border-amber-500 text-white'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              <span>★ 4.0+</span>
            </button>

            <button
              type="button"
              onClick={() =>
                setFilters((prev) => ({ ...prev, fastDeliveryOnly: !prev.fastDeliveryOnly }))
              }
              className={`min-h-[36px] px-3 rounded-xl font-bold flex items-center gap-1 transition-colors shrink-0 border cursor-pointer ${
                filters.fastDeliveryOnly
                  ? 'bg-[#E23744] border-[#E23744] text-white'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              <span>&lt; 25 mins</span>
            </button>

            <button
              type="button"
              onClick={() => setIsFilterModalOpen(true)}
              className="min-h-[36px] px-3 rounded-xl font-bold flex items-center gap-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 shrink-0 cursor-pointer"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>More Filters</span>
            </button>
          </div>

          {/* Results Display */}
          {totalResults === 0 ? (
            <EmptyState
              icon={<Search className="w-12 h-12 text-slate-400" />}
              title={`No results found for "${debouncedQuery}"`}
              description="We couldn't find any dishes or kitchens matching your search. Try checking your spelling or search for 'Biryani', 'Pizza', 'Dosa', or 'Burger'."
              actionLabel="Clear Search"
              onAction={() => setRawQuery('')}
            />
          ) : (
            <div className="space-y-6">
              {/* Dishes Section */}
              {(activeTab === 'all' || activeTab === 'dishes') && matchedDishes.length > 0 && (
                <section aria-label="Dishes" className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                      <Utensils className="w-3.5 h-3.5" />
                      <span>Matching Dishes ({matchedDishes.length})</span>
                    </span>
                  </div>

                  <div className="space-y-3">
                    {matchedDishes.map((food) => (
                      <FoodCard
                        key={food.id}
                        food={food}
                        restaurant={restaurantMap.get(food.restaurantId)}
                        onAdd={handleAddDish}
                        onClick={() => setCustomizingFood(food)}
                        quantityInCart={getItemQuantity(food.id)}
                      />
                    ))}
                  </div>
                </section>
              )}

              {/* Restaurants Section */}
              {(activeTab === 'all' || activeTab === 'restaurants') && matchedRestaurants.length > 0 && (
                <section aria-label="Restaurants" className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                      <Store className="w-3.5 h-3.5" />
                      <span>Matching Restaurants ({matchedRestaurants.length})</span>
                    </span>
                  </div>

                  <div className="space-y-4">
                    {matchedRestaurants.map((restaurant) => (
                      <RestaurantCard
                        key={restaurant.id}
                        restaurant={restaurant}
                        onClick={() => {
                          if (onRestaurantClick) {
                            onRestaurantClick(restaurant.id);
                          } else {
                            showToast(`Selected ${restaurant.name}`, 'info');
                          }
                        }}
                        onFavoriteToggle={(isFav) => {
                          triggerProtectedAction(() => {
                            showToast(
                              isFav
                                ? `Saved ${restaurant.name} to Favorites`
                                : `Removed ${restaurant.name} from Favorites`,
                              'info'
                            );
                          }, 'favorites');
                        }}
                      />
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}
        </div>
      )}

      {/* Floating Bottom Cart Bar (Appears when cart has items) */}
      {totalItems > 0 && (
        <aside
          aria-label="Current Cart Summary"
          className="fixed bottom-20 inset-x-4 z-40 max-w-md mx-auto"
        >
          <div
            onClick={onViewCart}
            className="p-3.5 bg-[#E23744] text-white rounded-2xl shadow-xl flex items-center justify-between cursor-pointer active:scale-[0.99] transition-transform"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
                <ShoppingBag className="w-4 h-4 text-white" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider">
                  {totalItems} {totalItems === 1 ? 'item' : 'items'} added
                </span>
                <p className="text-[11px] text-white/80 tabular-nums">
                  Subtotal: ₹{subtotal}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 font-bold text-xs bg-white text-[#E23744] px-3 py-1.5 rounded-xl shadow-xs">
              <span>View Cart</span>
            </div>
          </div>
        </aside>
      )}

      {/* Food Customization & Portion Selector Modal */}
      <FoodCustomizationModal
        food={customizingFood}
        restaurant={
          customizingFood
            ? restaurantMap.get(customizingFood.restaurantId) ||
              restaurantService.getRestaurantById(customizingFood.restaurantId, currentAddress.coordinates) ||
              null
            : null
        }
        isOpen={!!customizingFood}
        onClose={() => setCustomizingFood(null)}
      />

      {/* Filter Modal */}
      <FilterModal
        isOpen={isFilterModalOpen}
        onClose={() => setIsFilterModalOpen(false)}
        filters={filters}
        onApply={(newFilters) => setFilters(newFilters)}
        matchingCount={totalResults}
      />
    </div>
  );
};
