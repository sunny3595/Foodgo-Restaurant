/**
 * Favorites Screen (Tab 4)
 * Displays saved Restaurants and Food Items side by side.
 * Features:
 * - Side-by-side view toggle (Restaurants vs Dishes & Items)
 * - Instant reactive removal when clicking the Heart icon
 * - Quick "Add to Cart" directly from favorite dishes
 * - Tap to open restaurant details
 * - Guest authentication protection
 */

import React, { useState } from 'react';
import {
  Heart,
  Store,
  UtensilsCrossed,
  Plus,
  Trash2,
  Clock,
  Star,
  MapPin,
  ShoppingBag,
} from 'lucide-react';
import { RestaurantCard } from '../../components/cards/RestaurantCard';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { useFavorites } from '../../store/favoritesContext';
import { useAuth } from '../../store/authContext';
import { useCart } from '../../store/cartContext';
import { useApp } from '../../store/appContext';
import { Restaurant, FoodItem } from '../../types/restaurant';

export interface FavoritesScreenProps {
  onExplore: () => void;
  onRestaurantClick?: (restaurantId: string) => void;
}

export const FavoritesScreen: React.FC<FavoritesScreenProps> = ({
  onExplore,
  onRestaurantClick,
}) => {
  const {
    favoriteRestaurants,
    favoriteItems,
    removeRestaurantFavorite,
    removeItemFavorite,
  } = useFavorites();
  const { isGuest, setGuestPromptOpen } = useAuth();
  const { addItem } = useCart();
  const { showToast } = useApp();

  const [activeTab, setActiveTab] = useState<'restaurants' | 'items'>('restaurants');

  if (isGuest) {
    return (
      <div className="flex-1 flex flex-col p-4 pb-24 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 justify-center">
        <EmptyState
          icon={<Heart className="w-12 h-12 text-slate-400" />}
          title="Sign in to view favorites"
          description="Save and sync your favorite dining spots, dishes, and orders across all your mobile devices."
          actionLabel="Sign In to FoodGo"
          onAction={() => setGuestPromptOpen(true)}
        />
      </div>
    );
  }

  const handleQuickAddDish = (food: FoodItem, restaurant: Restaurant) => {
    addItem(food, { addons: [] }, restaurant, 1);
    showToast(`Added ${food.name} to cart!`, 'success');
  };

  const handleRemoveDish = (e: React.MouseEvent, foodId: string, foodName: string) => {
    e.stopPropagation();
    removeItemFavorite(foodId);
    showToast(`Removed ${foodName} from Favorites`, 'info');
  };

  return (
    <div className="flex-1 flex flex-col p-4 pb-28 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-h-screen">
      {/* Header */}
      <div className="pt-safe mb-3">
        <h1 className="text-xl font-extrabold tracking-tight">Saved Favorites</h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Your bookmarked kitchens and beloved dishes
        </p>
      </div>

      {/* Side-by-Side Dual Tabs Switcher */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/70 dark:bg-slate-900 rounded-2xl mb-4 border border-slate-200 dark:border-slate-800">
        <button
          type="button"
          onClick={() => setActiveTab('restaurants')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'restaurants'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Store className="w-4 h-4 text-[#E23744]" />
          <span>Restaurants</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-red-50 dark:bg-red-950/60 text-[#E23744] font-black">
            {favoriteRestaurants.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('items')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
            activeTab === 'items'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <UtensilsCrossed className="w-4 h-4 text-amber-500" />
          <span>Dishes & Items</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 font-black">
            {favoriteItems.length}
          </span>
        </button>
      </div>

      {/* 1. RESTAURANTS VIEW */}
      {activeTab === 'restaurants' && (
        <>
          {favoriteRestaurants.length > 0 ? (
            <div className="space-y-4">
              {favoriteRestaurants.map((restaurant) => (
                <div key={restaurant.id} className="relative group">
                  <RestaurantCard
                    restaurant={restaurant}
                    onClick={() => onRestaurantClick?.(restaurant.id)}
                    onFavoriteToggle={(isFav) => {
                      if (!isFav) {
                        removeRestaurantFavorite(restaurant.id);
                      }
                    }}
                  />
                </div>
              ))}
            </div>
          ) : (
            <EmptyState
              icon={<Store className="w-12 h-12 text-slate-400" />}
              title="No favorite restaurants yet"
              description="Tap the heart icon on any restaurant card to save it here for fast reordering."
              actionLabel="Explore Kitchens"
              onAction={onExplore}
            />
          )}
        </>
      )}

      {/* 2. DISHES & ITEMS VIEW */}
      {activeTab === 'items' && (
        <>
          {favoriteItems.length > 0 ? (
            <div className="space-y-3">
              {favoriteItems.map(({ food, restaurant }) => (
                <article
                  key={food.id}
                  onClick={() => onRestaurantClick?.(restaurant.id)}
                  className="p-3.5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 flex items-start justify-between gap-3.5 shadow-2xs hover:shadow-xs transition-shadow cursor-pointer select-none"
                >
                  {/* Left Info Column */}
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center gap-1.5">
                      {/* Veg / Non-Veg Indicator */}
                      <div
                        className={`w-3.5 h-3.5 border-2 flex items-center justify-center rounded-xs shrink-0 ${
                          food.isVeg ? 'border-emerald-600' : 'border-red-600'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full ${
                            food.isVeg ? 'bg-emerald-600' : 'bg-red-600'
                          }`}
                        />
                      </div>

                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider truncate">
                        {restaurant.name}
                      </span>
                    </div>

                    <h3 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 truncate">
                      {food.name}
                    </h3>

                    <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                      {food.description}
                    </p>

                    <div className="flex items-center gap-2 pt-1">
                      <span className="text-sm font-black text-slate-900 dark:text-slate-100 tabular-nums">
                        ₹{food.price}
                      </span>
                      {food.rating && (
                        <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-0.5">
                          <Star className="w-3 h-3 fill-emerald-600" />
                          <span>{food.rating.toFixed(1)}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Right Column: Dish Photo & CTA */}
                  <div className="relative shrink-0 flex flex-col items-center">
                    <div className="relative w-22 h-22 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800">
                      <img
                        src={food.imageUrl}
                        alt={food.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                      {/* Heart Button to remove from favorites */}
                      <button
                        type="button"
                        onClick={(e) => handleRemoveDish(e, food.id, food.name)}
                        className="absolute top-1 right-1 w-7 h-7 rounded-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs flex items-center justify-center text-[#E23744] shadow-sm active:scale-90 transition-transform cursor-pointer z-10"
                        title="Remove from favorites"
                      >
                        <Heart className="w-3.5 h-3.5 fill-[#E23744]" />
                      </button>
                    </div>

                    {/* Quick Add Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleQuickAddDish(food, restaurant);
                      }}
                      className="-mt-3 relative z-10 min-h-[30px] px-3 rounded-xl border bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-[#E23744] font-bold text-xs flex items-center justify-center gap-1 shadow-md hover:bg-red-50 dark:hover:bg-red-950/30 transition-all active:scale-95 cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      <span>ADD</span>
                    </button>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <EmptyState
              icon={<UtensilsCrossed className="w-12 h-12 text-slate-400" />}
              title="No favorite dishes yet"
              description="Tap the heart icon on any mouth-watering dish in a restaurant menu to bookmark it here."
              actionLabel="Explore Restaurants"
              onAction={onExplore}
            />
          )}
        </>
      )}
    </div>
  );
};
