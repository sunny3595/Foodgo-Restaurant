/**
 * Food Detail & Customization Modal (Section 21)
 * Displays dish details, portions, addons, special cooking instructions,
 * and dynamically calculates the total price with quantity controls.
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Minus, Plus, Flame, Clock, Check, X, ShieldCheck } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { FoodItem, FoodVariation, FoodAddon, Restaurant } from '../../types/restaurant';
import { useCart } from '../../store/cartContext';

export interface FoodCustomizationModalProps {
  food: FoodItem | null;
  restaurant: Restaurant | null;
  isOpen: boolean;
  onClose: () => void;
}

export const FoodCustomizationModal: React.FC<FoodCustomizationModalProps> = ({
  food,
  restaurant,
  isOpen,
  onClose,
}) => {
  const { addItem } = useCart();

  const [selectedVariation, setSelectedVariation] = useState<FoodVariation | undefined>(undefined);
  const [selectedAddons, setSelectedAddons] = useState<FoodAddon[]>([]);
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [quantity, setQuantity] = useState(1);

  // Reset local state when a new food item opens
  useEffect(() => {
    if (food) {
      const defaultVar = food.variations?.find((v) => v.isDefault) || food.variations?.[0];
      setSelectedVariation(defaultVar);
      setSelectedAddons([]);
      setSpecialInstructions('');
      setQuantity(1);
    }
  }, [food]);

  // Compute unit price dynamically
  const unitPrice = useMemo(() => {
    if (!food) return 0;
    const base = selectedVariation ? selectedVariation.price : food.price;
    const addonsSum = selectedAddons.reduce((sum, a) => sum + a.price, 0);
    return base + addonsSum;
  }, [food, selectedVariation, selectedAddons]);

  const totalPrice = unitPrice * quantity;

  const handleToggleAddon = (addon: FoodAddon) => {
    setSelectedAddons((prev) => {
      const exists = prev.some((a) => a.id === addon.id);
      if (exists) {
        return prev.filter((a) => a.id !== addon.id);
      } else {
        return [...prev, addon];
      }
    });
  };

  const handleAddToCart = () => {
    if (!food || !restaurant) return;

    addItem(
      food,
      {
        variation: selectedVariation,
        addons: selectedAddons,
        specialInstructions: specialInstructions.trim() || undefined,
      },
      restaurant,
      quantity
    );

    onClose();
  };

  if (!food || !restaurant) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} showCloseButton={true}>
      <div className="space-y-4 -mt-2">
        {/* Cover Photo & Badges */}
        <div className="relative w-full h-44 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800">
          <img
            src={food.imageUrl}
            alt={food.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />

          {/* Veg / Non-Veg Tag */}
          <div className="absolute top-2 left-2 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs px-2 py-1 rounded-lg flex items-center gap-1.5 shadow-sm text-xs font-bold">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                food.isVeg ? 'bg-emerald-600' : 'bg-red-600'
              }`}
            />
            <span className={food.isVeg ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-700 dark:text-red-400'}>
              {food.isVeg ? 'VEG' : 'NON-VEG'}
            </span>
          </div>

          {/* Bestseller Badge */}
          {food.isBestseller && (
            <div className="absolute top-2 right-2 bg-amber-500 text-white font-bold text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-md shadow-sm">
              ★ Bestseller
            </div>
          )}
        </div>

        {/* Title, Rating & Description */}
        <div className="space-y-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
              {food.name}
            </h3>
            <span className="text-base font-extrabold text-slate-900 dark:text-slate-100 tabular-nums">
              ₹{unitPrice}
            </span>
          </div>

          {/* Prep time & calories */}
          <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400 pt-0.5">
            {food.calories && (
              <span className="flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-500" />
                <span>{food.calories} kcal</span>
              </span>
            )}
            {food.prepTimeMinutes && (
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>{food.prepTimeMinutes} mins prep</span>
              </span>
            )}
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 pt-1 leading-relaxed">
            {food.description}
          </p>
        </div>

        {/* Portion / Size Variations (Radio Selector) */}
        {food.variations && food.variations.length > 0 && (
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                Select Portion / Size
              </span>
              <span className="text-[10px] font-semibold text-[#E23744] bg-red-50 dark:bg-red-950/40 px-2 py-0.5 rounded-md">
                REQUIRED
              </span>
            </div>

            <div className="space-y-1.5">
              {food.variations.map((v) => {
                const isSelected = selectedVariation?.id === v.id;
                return (
                  <label
                    key={v.id}
                    onClick={() => setSelectedVariation(v)}
                    className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#E23744] bg-red-50/50 dark:bg-red-950/30'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                          isSelected ? 'border-[#E23744]' : 'border-slate-300 dark:border-slate-600'
                        }`}
                      >
                        {isSelected && <span className="w-2 h-2 rounded-full bg-[#E23744]" />}
                      </div>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {v.name}
                      </span>
                    </div>

                    <span className="text-xs font-extrabold text-slate-900 dark:text-slate-100 tabular-nums">
                      ₹{v.price}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>
        )}

        {/* Add-ons Section (Checkbox Selector) */}
        {food.addons && food.addons.length > 0 && (
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                Customizable Add-ons
              </span>
              <span className="text-[10px] text-slate-400">Optional</span>
            </div>

            <div className="space-y-1.5">
              {food.addons.map((addon) => {
                const isChecked = selectedAddons.some((a) => a.id === addon.id);
                return (
                  <label
                    key={addon.id}
                    onClick={() => handleToggleAddon(addon)}
                    className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                      isChecked
                        ? 'border-[#E23744] bg-red-50/50 dark:bg-red-950/30'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-4 h-4 rounded-md border flex items-center justify-center ${
                          isChecked
                            ? 'bg-[#E23744] border-[#E23744] text-white'
                            : 'border-slate-300 dark:border-slate-600'
                        }`}
                      >
                        {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                      <span className="text-xs font-medium text-slate-800 dark:text-slate-200">
                        {addon.name}
                      </span>
                    </div>

                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 tabular-nums">
                      +₹{addon.price}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>
        )}

        {/* Special Instructions */}
        <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
          <label className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            Cooking Instructions (Optional)
          </label>
          <textarea
            value={specialInstructions}
            onChange={(e) => setSpecialInstructions(e.target.value)}
            rows={2}
            placeholder="e.g. Less spicy, extra onions, no mayonnaise..."
            className="w-full p-3 text-xs bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl placeholder-slate-400 focus:outline-none focus:border-[#E23744] resize-none"
          />
        </div>

        {/* Sticky Bottom Actions: Quantity Selector & Add Button */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center gap-3">
          {/* Quantity Controls */}
          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl shrink-0">
            <button
              type="button"
              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
              disabled={quantity <= 1}
              className="w-8 h-8 rounded-xl bg-white dark:bg-slate-900 flex items-center justify-center text-slate-700 dark:text-slate-200 disabled:opacity-40 cursor-pointer shadow-xs"
              aria-label="Decrease quantity"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>

            <span className="text-xs font-extrabold w-6 text-center tabular-nums">
              {quantity}
            </span>

            <button
              type="button"
              onClick={() => setQuantity((q) => q + 1)}
              className="w-8 h-8 rounded-xl bg-white dark:bg-slate-900 flex items-center justify-center text-slate-700 dark:text-slate-200 cursor-pointer shadow-xs"
              aria-label="Increase quantity"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Add to Cart Primary Button */}
          <Button
            size="lg"
            fullWidth
            onClick={handleAddToCart}
            className="flex-1 justify-between px-5 font-bold"
          >
            <span>Add Item</span>
            <span className="tabular-nums">₹{totalPrice}</span>
          </Button>
        </div>
      </div>
    </Modal>
  );
};
