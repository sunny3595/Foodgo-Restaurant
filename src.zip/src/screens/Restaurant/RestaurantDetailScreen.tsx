/**
 * Restaurant Detail & Menu Screen (Sections 19 & 20)
 * Features:
 * - Cover banner with Logo, Back button, Favorite toggle, and Share action
 * - Zero-pill unboxed metadata (Rating, Distance, Time, Fee, Min Order)
 * - In-menu search & Pure Veg toggle filter
 * - Sticky category navigation bar
 * - Menu items grouped by category with quantity counters & customisation triggers
 * - Floating Cart preview bar
 */

import React, { useState, useMemo } from 'react';
import {
  ArrowLeft,
  Heart,
  Share2,
  Clock,
  MapPin,
  Tag,
  Search,
  Plus,
  Minus,
  ShoppingBag,
  Sparkles,
  Info,
} from 'lucide-react';
import { Restaurant, FoodItem } from '../../types/restaurant';
import { RatingBadge } from '../../components/ui/RatingBadge';
import { FoodCustomizationModal } from './FoodCustomizationModal';
import { MOCK_FOOD_ITEMS } from '../../services/mock/mockFoodItems';
import { useCart } from '../../store/cartContext';
import { useAuth } from '../../store/authContext';
import { useApp } from '../../store/appContext';
import { useFavorites } from '../../store/favoritesContext';

export interface RestaurantDetailScreenProps {
  restaurant: Restaurant;
  onBack: () => void;
  onViewCart?: () => void;
}

export const RestaurantDetailScreen: React.FC<RestaurantDetailScreenProps> = ({
  restaurant,
  onBack,
  onViewCart,
}) => {
  const { showToast } = useApp();
  const { triggerProtectedAction } = useAuth();
  const { items, subtotal, totalItems, getItemQuantity, addItem } = useCart();

  const {
    isRestaurantFavorite,
    toggleRestaurantFavorite,
    isItemFavorite,
    toggleItemFavorite,
  } = useFavorites();

  const isFavorite = isRestaurantFavorite(restaurant.id);
  const [searchQuery, setSearchQuery] = useState('');
  const [vegOnly, setVegOnly] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [customizingFood, setCustomizingFood] = useState<FoodItem | null>(null);

  // Filter foods for this restaurant
  const restaurantFoods = useMemo(() => {
    return MOCK_FOOD_ITEMS.filter((f) => f.restaurantId === restaurant.id);
  }, [restaurant.id]);

  // Extract unique categories in this restaurant's menu
  const menuCategories = useMemo(() => {
    const cats = new Set<string>();
    restaurantFoods.forEach((f) => cats.add(f.category));
    return Array.from(cats);
  }, [restaurantFoods]);

  // Filter foods by search, veg-only, and active category
  const filteredFoods = useMemo(() => {
    return restaurantFoods.filter((f) => {
      const matchesSearch =
        !searchQuery.trim() ||
        f.name.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
        f.description.toLowerCase().includes(searchQuery.toLowerCase().trim());

      const matchesVeg = !vegOnly || f.isVeg;
      const matchesCat = activeCategory === 'All' || f.category === activeCategory;

      return matchesSearch && matchesVeg && matchesCat;
    });
  }, [restaurantFoods, searchQuery, vegOnly, activeCategory]);

  // Group filtered foods by category
  const groupedFoods = useMemo(() => {
    const groups: Record<string, FoodItem[]> = {};
    filteredFoods.forEach((food) => {
      if (!groups[food.category]) {
        groups[food.category] = [];
      }
      groups[food.category].push(food);
    });
    return groups;
  }, [filteredFoods]);

  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: restaurant.name,
          text: `Check out ${restaurant.name} on FoodGo!`,
          url,
        });
      } catch {}
    } else {
      navigator.clipboard?.writeText(url);
      showToast('Restaurant link copied to clipboard', 'info');
    }
  };

  const handleFavToggle = () => {
    triggerProtectedAction(() => {
      const next = toggleRestaurantFavorite(restaurant);
      showToast(
        next
          ? `Saved ${restaurant.name} to Favorites`
          : `Removed ${restaurant.name} from Favorites`,
        'info'
      );
    }, 'favorites');
  };

  const handleItemAdd = (food: FoodItem) => {
    // If food has variations or addons, open customization sheet
    if ((food.variations && food.variations.length > 0) || (food.addons && food.addons.length > 0)) {
      setCustomizingFood(food);
    } else {
      // Direct add
      addItem(food, { addons: [] }, restaurant, 1);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-h-screen pb-32">
      {/* Top Floating App Bar */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/60 dark:border-slate-800 px-3 py-2 pt-safe flex items-center justify-between shadow-xs">
        <button
          type="button"
          onClick={onBack}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="Back to restaurants"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate max-w-[200px]">
          {restaurant.name}
        </span>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={handleFavToggle}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Add to favorites"
          >
            <Heart
              className={`w-5 h-5 transition-colors ${
                isFavorite ? 'fill-[#E23744] text-[#E23744]' : 'text-slate-700 dark:text-slate-200'
              }`}
            />
          </button>

          <button
            type="button"
            onClick={handleShare}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Share restaurant"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Hero Cover Image & Header Info */}
      <div className="relative">
        <div className="w-full h-48 sm:h-56 bg-slate-200 dark:bg-slate-800 overflow-hidden">
          <img
            src={restaurant.coverImageUrl}
            alt={restaurant.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Floating Restaurant Info Card */}
        <div className="-mt-12 px-4 relative z-10">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 border border-slate-200/80 dark:border-slate-800 shadow-md space-y-2">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h1 className="text-lg font-black text-slate-900 dark:text-slate-100 tracking-tight">
                  {restaurant.name}
                </h1>
                {restaurant.tagline && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {restaurant.tagline}
                  </p>
                )}
              </div>
              <RatingBadge rating={restaurant.rating} count={restaurant.ratingCount} size="md" />
            </div>

            {/* Zero-Pill Unboxed Metadata */}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-slate-600 dark:text-slate-300 font-medium">
              <span>{restaurant.cuisines.join(' · ')}</span>

              <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>

              <div className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span className="tabular-nums">
                  {restaurant.deliveryTimeMin}–{restaurant.deliveryTimeMax} min
                </span>
              </div>

              <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>

              <div className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span className="tabular-nums">{restaurant.distanceKm} km</span>
              </div>

              <span aria-hidden="true" className="text-slate-300 dark:text-slate-700">·</span>

              <div className="tabular-nums">
                {restaurant.deliveryFee === 0 ? (
                  <span className="text-emerald-600 font-bold">Free Delivery</span>
                ) : (
                  `₹${restaurant.deliveryFee} delivery`
                )}
              </div>
            </div>

            {/* Address & Hours Status */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
              <span className="truncate max-w-[220px]">{restaurant.address}</span>
              <span className={restaurant.isOpen ? 'text-emerald-600 font-semibold' : 'text-rose-500 font-semibold'}>
                {restaurant.openingHoursText}
              </span>
            </div>

            {/* Offers Strip */}
            {restaurant.offers.length > 0 && (
              <div className="pt-2 flex items-center gap-2 overflow-x-auto no-scrollbar">
                {restaurant.offers.map((offer, idx) => (
                  <div
                    key={idx}
                    className="shrink-0 flex items-center gap-1.5 bg-red-50 dark:bg-red-950/30 border border-red-100 dark:border-red-900/40 text-[#E23744] px-2.5 py-1 rounded-xl text-[11px] font-bold"
                  >
                    <Tag className="w-3 h-3" />
                    <span>{offer}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Menu Search & Veg Filter Toolbar */}
      <div className="px-4 mt-4 space-y-3">
        <div className="flex items-center gap-2">
          {/* Search within Menu */}
          <div className="relative flex-1 flex items-center">
            <Search className="absolute left-3 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search in menu..."
              className="w-full min-h-[42px] pl-9 pr-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl placeholder-slate-400 focus:outline-none focus:border-[#E23744]"
            />
          </div>

          {/* Veg Only Switch */}
          <button
            type="button"
            onClick={() => setVegOnly(!vegOnly)}
            className={`min-h-[42px] px-3 rounded-2xl border text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
              vegOnly
                ? 'bg-emerald-600 border-emerald-600 text-white'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Veg Only</span>
          </button>
        </div>

        {/* Sticky Menu Category Bar */}
        {menuCategories.length > 1 && (
          <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-4 px-4 py-1 text-xs">
            <button
              type="button"
              onClick={() => setActiveCategory('All')}
              className={`min-h-[34px] px-3.5 rounded-xl font-bold transition-colors shrink-0 cursor-pointer ${
                activeCategory === 'All'
                  ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              All Items ({restaurantFoods.length})
            </button>

            {menuCategories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveCategory(cat)}
                className={`min-h-[34px] px-3.5 rounded-xl font-bold transition-colors shrink-0 cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-[#E23744] text-white shadow-xs'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Menu Categories & Items List */}
      <div className="px-4 mt-4 space-y-6">
        {Object.keys(groupedFoods).length === 0 ? (
          <div className="text-center py-12 space-y-2">
            <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
              No dishes found matching your criteria
            </p>
            <p className="text-xs text-slate-400">
              Try disabling the Veg Only filter or clearing the search query.
            </p>
          </div>
        ) : (
          Object.entries(groupedFoods).map(([categoryName, foods]) => (
            <section key={categoryName} className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200/60 dark:border-slate-800 pb-1.5">
                <h2 className="text-sm font-black text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                  {categoryName}
                </h2>
                <span className="text-xs font-semibold text-slate-400 tabular-nums">
                  {foods.length} {foods.length === 1 ? 'item' : 'items'}
                </span>
              </div>

              <div className="space-y-3">
                {foods.map((food) => {
                  const hasCustomization =
                    (food.variations && food.variations.length > 0) ||
                    (food.addons && food.addons.length > 0);
                  const qtyInCart = getItemQuantity(food.id);

                  return (
                    <article
                      key={food.id}
                      onClick={() => setCustomizingFood(food)}
                      className="p-3.5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 flex items-start justify-between gap-3.5 hover:shadow-xs transition-shadow cursor-pointer select-none"
                    >
                      {/* Left Info Column */}
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-3.5 h-3.5 border-2 flex items-center justify-center rounded-xs shrink-0 ${
                              food.isVeg ? 'border-emerald-600' : 'border-red-600'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                food.isVeg ? 'bg-emerald-600' : 'bg-red-600'
                              }`}
                            />
                          </div>

                          {food.isBestseller && (
                            <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                              ★ Bestseller
                            </span>
                          )}
                        </div>

                        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                          {food.name}
                        </h3>

                        <div className="flex items-center gap-2 text-xs font-extrabold text-slate-900 dark:text-slate-100 tabular-nums">
                          <span>₹{food.price}</span>
                          {food.rating && (
                            <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-0.5">
                              ★ {food.rating.toFixed(1)}
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                          {food.description}
                        </p>
                      </div>

                      {/* Right Photo & Action CTA */}
                      <div className="relative shrink-0 flex flex-col items-center">
                        <div className="relative w-24 h-24 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800">
                          <img
                            src={food.imageUrl}
                            alt={food.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                          {/* Dish Favorite Button */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              triggerProtectedAction(() => {
                                const next = toggleItemFavorite(food, restaurant);
                                showToast(
                                  next
                                    ? `Added ${food.name} to Favorites`
                                    : `Removed ${food.name} from Favorites`,
                                  'info'
                                );
                              }, 'favorites');
                            }}
                            className="absolute top-1 right-1 w-7 h-7 rounded-full bg-white/90 dark:bg-slate-900/90 backdrop-blur-xs flex items-center justify-center text-slate-700 dark:text-slate-200 shadow-sm active:scale-90 transition-transform cursor-pointer z-10"
                            aria-label={
                              isItemFavorite(food.id)
                                ? 'Remove from favorites'
                                : 'Add to favorites'
                            }
                          >
                            <Heart
                              className={`w-3.5 h-3.5 transition-colors ${
                                isItemFavorite(food.id)
                                  ? 'fill-[#E23744] text-[#E23744]'
                                  : 'text-slate-700 dark:text-slate-200'
                              }`}
                            />
                          </button>
                        </div>

                        <div className="-mt-3.5 relative z-10 flex flex-col items-center">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleItemAdd(food);
                            }}
                            className="min-h-[34px] min-w-[76px] px-3 rounded-xl border bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-[#E23744] font-bold text-xs flex items-center justify-center gap-1 shadow-md hover:bg-red-50 dark:hover:bg-red-950/30 transition-all active:scale-95 cursor-pointer"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>{qtyInCart > 0 ? `ADD (${qtyInCart})` : 'ADD'}</span>
                          </button>

                          {hasCustomization && (
                            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter mt-0.5">
                              Customisable
                            </span>
                          )}
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </section>
          ))
        )}
      </div>

      {/* Floating Bottom Cart Bar (Appears when cart has items) */}
      {totalItems > 0 && (
        <aside
          aria-label="Current Cart Summary"
          className="fixed bottom-4 inset-x-4 z-40 max-w-md mx-auto"
        >
          <div
            onClick={onViewCart}
            className="p-3.5 bg-[#E23744] text-white rounded-2xl shadow-xl flex items-center justify-between cursor-pointer active:scale-[0.99] transition-transform"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
                <ShoppingBag className="w-4 h-4 text-white" />
              </div>

              <div>
                <span className="text-xs font-bold uppercase tracking-wider">
                  {totalItems} {totalItems === 1 ? 'item' : 'items'} added
                </span>
                <p className="text-[11px] text-white/80 tabular-nums">
                  Subtotal: ₹{subtotal}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 font-bold text-xs bg-white text-[#E23744] px-3 py-1.5 rounded-xl shadow-xs">
              <span>View Cart</span>
            </div>
          </div>
        </aside>
      )}

      {/* Food Customization Modal */}
      <FoodCustomizationModal
        food={customizingFood}
        restaurant={restaurant}
        isOpen={!!customizingFood}
        onClose={() => setCustomizingFood(null)}
      />
    </div>
  );
};
