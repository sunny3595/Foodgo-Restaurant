/**
 * Coupon & Offers Selection Modal (Section 26)
 * Lists all promotional vouchers with min order requirements and instant 1-tap apply.
 */

import React, { useState } from 'react';
import { Tag, Sparkles, Check, ArrowRight } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { MOCK_OFFERS } from '../../services/mock/mockData';
import { useCart } from '../../store/cartContext';
import { useApp } from '../../store/appContext';

export interface CouponPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CouponPickerModal: React.FC<CouponPickerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { applyCoupon, appliedCoupon, bill } = useCart();
  const { showToast } = useApp();

  const [inputCode, setInputCode] = useState('');
  const [error, setError] = useState('');

  const handleManualApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCode.trim()) return;

    const res = applyCoupon(inputCode);
    if (res.success) {
      showToast(res.message, 'success');
      setError('');
      onClose();
    } else {
      setError(res.message);
    }
  };

  const handleApplyOffer = (code: string) => {
    const res = applyCoupon(code);
    if (res.success) {
      showToast(res.message, 'success');
      onClose();
    } else {
      showToast(res.message, 'error');
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Coupons & Offers"
      subtitle="Apply available coupon codes for exclusive discounts"
    >
      <div className="space-y-4">
        {/* Manual Code Input Form */}
        <form onSubmit={handleManualApply} className="space-y-2">
          <div className="flex gap-2">
            <div className="flex-1">
              <Input
                placeholder="ENTER COUPON CODE"
                value={inputCode}
                onChange={(e) => {
                  setInputCode(e.target.value.toUpperCase());
                  setError('');
                }}
                leftIcon={<Tag className="w-4 h-4" />}
                error={error}
              />
            </div>
            <Button type="submit" size="md" disabled={!inputCode.trim()}>
              Apply
            </Button>
          </div>
        </form>

        {/* Available Offers List */}
        <div className="space-y-2.5">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Available Vouchers ({MOCK_OFFERS.length})
          </span>

          <div className="space-y-2.5">
            {MOCK_OFFERS.map((offer) => {
              const isApplied = appliedCoupon?.id === offer.id;
              const meetsMin = !offer.minOrder || bill.itemTotal >= offer.minOrder;

              return (
                <div
                  key={offer.id}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    isApplied
                      ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/20'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 font-mono text-xs font-bold text-slate-800 dark:text-slate-200">
                        <Tag className="w-3 h-3 text-[#E23744]" />
                        <span>{offer.code}</span>
                      </div>

                      {offer.badge && (
                        <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-md">
                          {offer.badge}
                        </span>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => handleApplyOffer(offer.code)}
                      className={`text-xs font-extrabold px-3 py-1 rounded-xl transition-colors cursor-pointer ${
                        isApplied
                          ? 'bg-emerald-600 text-white'
                          : 'text-[#E23744] hover:bg-red-50 dark:hover:bg-red-950/40'
                      }`}
                    >
                      {isApplied ? 'Applied' : 'Apply'}
                    </button>
                  </div>

                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 mt-2">
                    {offer.title}
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    {offer.subtitle}
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span>
                      {offer.minOrder
                        ? `Min. order ₹${offer.minOrder}`
                        : 'No minimum order required'}
                    </span>
                    <span>{offer.expiresInText}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </Modal>
  );
};
