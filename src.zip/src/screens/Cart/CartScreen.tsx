/**
 * Cart & Checkout Screen (Phase 6 - Sections 23, 25, 26)
 * Complete itemized cart, portions/addons breakdown, rider instructions,
 * delivery partner tip selector, coupon discount engine, and strict bill calculations.
 */

import React, { useState } from 'react';
import {
  ArrowLeft,
  MapPin,
  Clock,
  Plus,
  Minus,
  Trash2,
  Tag,
  Check,
  ChevronRight,
  ShieldCheck,
  Sparkles,
  Info,
  Utensils,
  HeartHandshake,
  MessageSquare,
} from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { CouponPickerModal } from './CouponPickerModal';
import { AddressPickerModal } from '../Home/AddressPickerModal';
import { useCart } from '../../store/cartContext';
import { useLocation } from '../../store/locationContext';
import { useAuth } from '../../store/authContext';
import { useApp } from '../../store/appContext';

export interface CartScreenProps {
  onBack: () => void;
  onAddMoreItems?: () => void;
  onProceedToPayment: () => void;
}

export const CartScreen: React.FC<CartScreenProps> = ({
  onBack,
  onAddMoreItems,
  onProceedToPayment,
}) => {
  const { showToast, isOnline } = useApp();
  const { triggerProtectedAction } = useAuth();
  const { currentAddress } = useLocation();

  const {
    items,
    restaurant,
    appliedCoupon,
    tipAmount,
    deliveryNotes,
    selectedDeliveryTags,
    bill,
    totalItems,
    updateQuantity,
    removeItem,
    clearCart,
    removeCoupon,
    setTip,
    setDeliveryNotes,
    toggleDeliveryTag,
  } = useCart();

  const [isCouponModalOpen, setIsCouponModalOpen] = useState(false);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [customTipActive, setCustomTipActive] = useState(false);
  const [customTipInput, setCustomTipInput] = useState('');

  const deliveryInstructionTags = [
    'Avoid calling',
    'Leave at door',
    'Do not ring bell',
    'Directions to reach',
  ];

  const handleCheckoutClick = () => {
    if (!isOnline) {
      showToast('Please connect to the internet to place orders', 'error');
      return;
    }

    // Check if guest user (Rule 10)
    triggerProtectedAction(() => {
      onProceedToPayment();
    }, 'checkout');
  };

  const handleCustomTipSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(customTipInput, 10);
    if (!isNaN(val) && val > 0) {
      setTip(val);
      setCustomTipActive(false);
      showToast(`Tip of ₹${val} added for delivery partner`, 'success');
    }
  };

  if (items.length === 0 || !restaurant) {
    return (
      <div className="flex-1 flex flex-col p-4 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-h-screen">
        <header className="pt-safe flex items-center gap-3 pb-4">
          <button
            type="button"
            onClick={onBack}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-base font-extrabold">Your Food Cart</h1>
        </header>

        <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4">
          <div className="w-20 h-20 rounded-3xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-4xl">
            🛒
          </div>
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
              Your cart is currently empty
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xs">
              Explore mouth-watering dishes from top-rated kitchens in Tirupati and add them to your cart.
            </p>
          </div>
          <Button size="lg" onClick={onBack}>
            Browse Restaurants
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-h-screen pb-36">
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/60 dark:border-slate-800 px-3 py-2 pt-safe flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onBack}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div>
            <h1 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Order Checkout
            </h1>
            <p className="text-xs font-extrabold text-slate-900 dark:text-slate-100 truncate max-w-[180px]">
              {restaurant.name}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            clearCart();
            showToast('Cart cleared', 'info');
          }}
          className="text-xs font-bold text-rose-500 hover:underline px-2 py-1"
        >
          Clear
        </button>
      </header>

      <div className="p-4 space-y-4">
        {/* Delivery Address Card */}
        <div className="p-3.5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center justify-between gap-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-red-50 dark:bg-red-950/40 text-[#E23744] flex items-center justify-center shrink-0 mt-0.5">
              <MapPin className="w-4 h-4" />
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold text-slate-900 dark:text-slate-100">
                  Deliver to {currentAddress.label}
                </span>
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.2 rounded-md">
                  {restaurant.distanceKm} km away
                </span>
              </div>
              <p className="text-xs text-slate-500 truncate mt-0.5">
                {currentAddress.flatBuilding}, {currentAddress.streetArea}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsAddressModalOpen(true)}
            className="text-xs font-bold text-[#E23744] hover:underline shrink-0 cursor-pointer"
          >
            Change
          </button>
        </div>

        {/* Restaurant ETA Strip */}
        <div className="flex items-center justify-between px-3 py-2 bg-amber-50 dark:bg-amber-950/30 rounded-2xl border border-amber-200/60 dark:border-amber-900/40 text-amber-800 dark:text-amber-300 text-xs">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-600" />
            <span className="font-semibold">
              Estimated Delivery Time: {restaurant.deliveryTimeMin}–{restaurant.deliveryTimeMax} mins
            </span>
          </div>
        </div>

        {/* Itemized Cart Items List */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
          {items.map((item) => {
            const hasCustomization =
              item.customization.variation ||
              item.customization.addons.length > 0 ||
              item.customization.specialInstructions;

            return (
              <div key={item.id} className="p-4 space-y-2">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5 flex-1 min-w-0">
                    {/* Veg / Non-Veg Dot */}
                    <div
                      className={`w-3.5 h-3.5 border-2 flex items-center justify-center rounded-xs shrink-0 mt-0.5 ${
                        item.food.isVeg ? 'border-emerald-600' : 'border-red-600'
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          item.food.isVeg ? 'bg-emerald-600' : 'bg-red-600'
                        }`}
                      />
                    </div>

                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                        {item.food.name}
                      </h4>

                      {/* Portion / Size Tag */}
                      {item.customization.variation && (
                        <span className="text-[11px] font-semibold text-slate-500 block">
                          Size: {item.customization.variation.name}
                        </span>
                      )}

                      {/* Add-ons List */}
                      {item.customization.addons.length > 0 && (
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          + {item.customization.addons.map((a) => a.name).join(', ')}
                        </p>
                      )}

                      {/* Cooking Note */}
                      {item.customization.specialInstructions && (
                        <p className="text-[10px] italic text-amber-600 dark:text-amber-400 mt-0.5">
                          "{item.customization.specialInstructions}"
                        </p>
                      )}

                      {/* Unit Price */}
                      <span className="text-xs font-bold text-slate-900 dark:text-slate-100 tabular-nums block mt-1">
                        ₹{item.unitPrice * item.quantity}
                      </span>
                    </div>
                  </div>

                  {/* Quantity Stepper */}
                  <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl shrink-0">
                    <button
                      type="button"
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="w-7 h-7 rounded-lg bg-white dark:bg-slate-900 flex items-center justify-center text-slate-700 dark:text-slate-200 cursor-pointer shadow-xs"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-3 h-3" />
                    </button>

                    <span className="text-xs font-extrabold w-5 text-center tabular-nums">
                      {item.quantity}
                    </span>

                    <button
                      type="button"
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="w-7 h-7 rounded-lg bg-white dark:bg-slate-900 flex items-center justify-center text-slate-700 dark:text-slate-200 cursor-pointer shadow-xs"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Add More Items button */}
          <div className="p-3 bg-slate-50/50 dark:bg-slate-900/50 text-center">
            <button
              type="button"
              onClick={onAddMoreItems || onBack}
              className="text-xs font-bold text-[#E23744] hover:underline flex items-center justify-center gap-1 mx-auto cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add more dishes from {restaurant.name}</span>
            </button>
          </div>
        </div>

        {/* Delivery Instructions for Rider */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-2.5">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            <MessageSquare className="w-3.5 h-3.5 text-[#E23744]" />
            <span>Delivery Instructions for Rider</span>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {deliveryInstructionTags.map((tag) => {
              const isSelected = selectedDeliveryTags.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  onClick={() => toggleDeliveryTag(tag)}
                  className={`min-h-[32px] px-3 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-red-50 dark:bg-red-950/40 border-[#E23744] text-[#E23744]'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {tag}
                </button>
              );
            })}
          </div>

          <input
            type="text"
            value={deliveryNotes}
            onChange={(e) => setDeliveryNotes(e.target.value)}
            placeholder="Add note for delivery partner (e.g. Ring doorbell twice)"
            className="w-full min-h-[38px] px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl placeholder-slate-400 focus:outline-none focus:border-[#E23744]"
          />
        </div>

        {/* Tip Delivery Partner Section */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-2.5">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                <HeartHandshake className="w-3.5 h-3.5 text-rose-500" />
                <span>Tip your delivery partner</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                100% of the tip goes directly to your rider.
              </p>
            </div>

            {tipAmount > 0 && (
              <span className="text-xs font-extrabold text-emerald-600 tabular-nums">
                +₹{tipAmount}
              </span>
            )}
          </div>

          <div className="grid grid-cols-4 gap-2">
            {[20, 30, 50].map((amt) => {
              const isSelected = tipAmount === amt;
              return (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setTip(isSelected ? 0 : amt)}
                  className={`min-h-[38px] rounded-xl border text-xs font-bold transition-colors cursor-pointer ${
                    isSelected
                      ? 'border-[#E23744] bg-red-50 dark:bg-red-950/40 text-[#E23744]'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  ₹{amt}
                </button>
              );
            })}

            <button
              type="button"
              onClick={() => setCustomTipActive(!customTipActive)}
              className="min-h-[38px] rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
            >
              Other
            </button>
          </div>

          {customTipActive && (
            <form onSubmit={handleCustomTipSubmit} className="flex gap-2 pt-1">
              <input
                type="number"
                min={10}
                max={500}
                placeholder="Enter tip amount (₹)"
                value={customTipInput}
                onChange={(e) => setCustomTipInput(e.target.value)}
                className="flex-1 min-h-[38px] px-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
              <Button type="submit" size="sm">
                Add Tip
              </Button>
            </form>
          )}
        </div>

        {/* Coupons & Offers Strip */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800">
          {appliedCoupon ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center">
                  <Check className="w-4 h-4 stroke-[3]" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-emerald-600">
                      '{appliedCoupon.code}' Applied
                    </span>
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-700">
                      Saved ₹{bill.discountAmount}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">{appliedCoupon.title}</p>
                </div>
              </div>

              <button
                type="button"
                onClick={removeCoupon}
                className="text-xs font-bold text-rose-500 hover:underline cursor-pointer"
              >
                Remove
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setIsCouponModalOpen(true)}
              className="w-full flex items-center justify-between text-left cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-red-50 dark:bg-red-950/40 text-[#E23744] flex items-center justify-center">
                  <Tag className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    Apply Coupon Code
                  </span>
                  <p className="text-[11px] text-slate-400">Save up to ₹120 on your order</p>
                </div>
              </div>

              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
          )}
        </div>

        {/* Detailed Bill Breakdown (Section 25) */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-2.5">
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider block">
            Bill Details
          </span>

          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
            <div className="flex justify-between">
              <span>Item Total ({totalItems} items)</span>
              <span className="tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                ₹{bill.itemTotal}
              </span>
            </div>

            <div className="flex justify-between">
              <span>Delivery Fee ({restaurant.distanceKm} km)</span>
              <span className="tabular-nums font-semibold">
                {bill.deliveryFee === 0 ? (
                  <span className="text-emerald-600 font-bold">FREE</span>
                ) : (
                  `₹${bill.deliveryFee}`
                )}
              </span>
            </div>

            <div className="flex justify-between">
              <span>Restaurant Packaging Charges</span>
              <span className="tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                ₹{bill.packagingFee}
              </span>
            </div>

            <div className="flex justify-between">
              <span>Platform Fee</span>
              <span className="tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                ₹{bill.platformFee}
              </span>
            </div>

            <div className="flex justify-between">
              <span>Govt. Taxes & GST (5%)</span>
              <span className="tabular-nums font-semibold text-slate-900 dark:text-slate-100">
                ₹{bill.gstAmount}
              </span>
            </div>

            {bill.tipAmount > 0 && (
              <div className="flex justify-between text-emerald-600 font-semibold">
                <span>Delivery Partner Tip</span>
                <span className="tabular-nums">+₹{bill.tipAmount}</span>
              </div>
            )}

            {bill.discountAmount > 0 && (
              <div className="flex justify-between text-emerald-600 font-bold">
                <span>Coupon Discount ({appliedCoupon?.code})</span>
                <span className="tabular-nums">-₹{bill.discountAmount}</span>
              </div>
            )}

            {/* Total Payable */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex justify-between text-sm font-black text-slate-900 dark:text-slate-100">
              <span>To Pay</span>
              <span className="tabular-nums text-[#E23744] text-base">
                ₹{bill.totalPayable}
              </span>
            </div>
          </div>

          {/* Savings Highlight */}
          {bill.totalSavings > 0 && (
            <div className="mt-2 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Total Savings on this order</span>
              </div>
              <span className="tabular-nums">₹{bill.totalSavings}</span>
            </div>
          )}
        </div>

        {/* Cancellation Policy */}
        <div className="p-3 bg-slate-100/70 dark:bg-slate-900 rounded-2xl flex items-start gap-2 text-[11px] text-slate-500">
          <Info className="w-4 h-4 shrink-0 text-slate-400 mt-0.5" />
          <span>
            Orders cannot be cancelled once the restaurant accepts and begins food preparation.
          </span>
        </div>
      </div>

      {/* Sticky Bottom Bar for Checkout */}
      <footer className="fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800 p-4 pb-safe shadow-lg max-w-md mx-auto">
        <div className="flex items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Total to pay
            </span>
            <span className="text-lg font-black text-slate-900 dark:text-slate-100 tabular-nums">
              ₹{bill.totalPayable}
            </span>
          </div>

          <Button
            size="lg"
            onClick={handleCheckoutClick}
            disabled={!isOnline}
            className="flex-1 font-bold shadow-md"
          >
            <span>{isOnline ? 'Proceed to Pay' : 'Offline - Connect to Pay'}</span>
          </Button>
        </div>
      </footer>

      {/* Modals */}
      <CouponPickerModal
        isOpen={isCouponModalOpen}
        onClose={() => setIsCouponModalOpen(false)}
      />

      <AddressPickerModal
        isOpen={isAddressModalOpen}
        onClose={() => setIsAddressModalOpen(false)}
      />
    </div>
  );
};
