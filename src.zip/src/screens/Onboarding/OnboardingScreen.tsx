/**
 * Onboarding Carousel Screens
 * Highlights 4 key value propositions with pagination, Skip, Next, and Get Started.
 */

import React, { useState } from 'react';
import { Compass, Utensils, Navigation, ShieldCheck, ArrowRight } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { secureStorage } from '../../services/storage/secureStorage';

export interface OnboardingScreenProps {
  onComplete: () => void;
}

interface Slide {
  id: number;
  title: string;
  subtitle: string;
  icon: React.ElementType;
  color: string;
  bgGradient: string;
}

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ onComplete }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const slides: Slide[] = [
    {
      id: 1,
      title: 'Discover great food near you',
      subtitle:
        'Explore famous local kitchens, top rated biryanis, gourmet pizzas, and authentic regional cuisines with instant delivery.',
      icon: Compass,
      color: 'text-[#E23744]',
      bgGradient: 'from-rose-50 to-orange-50 dark:from-rose-950/20 dark:to-orange-950/20',
    },
    {
      id: 2,
      title: 'Order from your favorite spots',
      subtitle:
        'Hand-picked dining options, transparent price breakdowns, special kitchen discounts, and customized toppings made to order.',
      icon: Utensils,
      color: 'text-amber-500',
      bgGradient: 'from-amber-50 to-yellow-50 dark:from-amber-950/20 dark:to-yellow-950/20',
    },
    {
      id: 3,
      title: 'Track your delivery in real time',
      subtitle:
        'Watch your food as it prepares in the kitchen and follows your rider on live GPS route navigation right to your door.',
      icon: Navigation,
      color: 'text-blue-500',
      bgGradient: 'from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20',
    },
    {
      id: 4,
      title: 'Enjoy fast and secure delivery',
      subtitle:
        'Safe contactless handoffs, live updates, instant customer support, and multiple cashless payment options at your fingertips.',
      icon: ShieldCheck,
      color: 'text-emerald-500',
      bgGradient: 'from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20',
    },
  ];

  const handleFinish = async () => {
    await secureStorage.setOnboardingCompleted(true);
    onComplete();
  };

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      handleFinish();
    }
  };

  const currentSlide = slides[currentIndex];
  const Icon = currentSlide.icon;

  return (
    <div className="flex-1 flex flex-col justify-between p-6 bg-white dark:bg-slate-950 select-none min-h-[600px]">
      {/* Top Bar with Skip */}
      <div className="flex justify-end pt-safe">
        {currentIndex < slides.length - 1 ? (
          <button
            type="button"
            onClick={handleFinish}
            className="text-xs font-semibold text-slate-500 hover:text-slate-900 dark:hover:text-slate-200 px-3 py-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            Skip
          </button>
        ) : (
          <div className="h-8" />
        )}
      </div>

      {/* Main Slide Graphic & Text */}
      <div className="flex-1 flex flex-col items-center justify-center text-center my-6">
        {/* Animated Graphic Container */}
        <div
          className={`w-36 h-36 rounded-3xl bg-gradient-to-tr ${currentSlide.bgGradient} flex items-center justify-center mb-8 border border-slate-200/50 dark:border-slate-800 shadow-inner`}
        >
          <div className="w-20 h-20 rounded-2xl bg-white dark:bg-slate-900 shadow-md flex items-center justify-center">
            <Icon className={`w-10 h-10 ${currentSlide.color}`} />
          </div>
        </div>

        {/* Text Content */}
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 max-w-xs leading-snug">
          {currentSlide.title}
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-3 max-w-xs leading-relaxed">
          {currentSlide.subtitle}
        </p>
      </div>

      {/* Footer Controls: Dots & Action Button */}
      <div className="space-y-6 pb-safe">
        {/* Step Indicator Dots */}
        <div className="flex justify-center items-center gap-1.5">
          {slides.map((slide, index) => (
            <button
              key={slide.id}
              type="button"
              onClick={() => setCurrentIndex(index)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                index === currentIndex
                  ? 'w-6 bg-[#E23744]'
                  : 'w-1.5 bg-slate-200 dark:bg-slate-800'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>

        {/* Action Button */}
        <Button
          size="lg"
          fullWidth
          onClick={handleNext}
          rightIcon={<ArrowRight className="w-4 h-4" />}
        >
          {currentIndex === slides.length - 1 ? 'Get Started' : 'Next'}
        </Button>
      </div>
    </div>
  );
};
