/**
 * About FoodGo Application Modal
 */

import React from 'react';
import { Utensils, Heart, Shield, FileText } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';

export interface AboutAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutAppModal: React.FC<AboutAppModalProps> = ({ isOpen, onClose }) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="About FoodGo"
      subtitle="Fresh food delivery reimagined"
    >
      <div className="flex flex-col items-center text-center p-2 space-y-4 -mt-2">
        <div className="w-16 h-16 rounded-3xl bg-[#E23744] text-white flex items-center justify-center shadow-xl">
          <Utensils className="w-8 h-8" />
        </div>

        <div>
          <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
            FoodGo Customer App
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">Version 1.0.0 (Production Release)</p>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed max-w-xs">
          FoodGo delivers freshly prepared dishes from top-rated restaurants, sweet shops, and street joints straight to your doorstep with real-time GPS tracking.
        </p>

        <div className="w-full space-y-2 text-xs text-slate-600 dark:text-slate-400 border-t border-b border-slate-100 dark:border-slate-800 py-3">
          <div className="flex justify-between">
            <span>Terms of Service</span>
            <span className="font-semibold text-[#E23744]">Reviewed & Active</span>
          </div>
          <div className="flex justify-between">
            <span>Privacy & Data Policy</span>
            <span className="font-semibold text-emerald-600">256-Bit SSL Protected</span>
          </div>
          <div className="flex justify-between">
            <span>FSSAI Food Hygiene</span>
            <span className="font-semibold text-slate-800 dark:text-slate-200">100% Verified Kitchens</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          <span>Crafted with</span>
          <Heart className="w-3.5 h-3.5 text-rose-500 fill-current" />
          <span>for food lovers</span>
        </div>

        <Button size="md" fullWidth onClick={onClose}>
          Close
        </Button>
      </div>
    </Modal>
  );
};
