/**
 * Comprehensive Address Management Modal (Section 34)
 * Allows adding new addresses, editing existing addresses, deleting,
 * and setting defaults, with customizable City Name & Pincode,
 * interactive map pinpoint support, and Firestore database sync.
 */

import React, { useState } from 'react';
import { Home, Briefcase, MapPin, Trash2, Plus, Navigation, Edit2 } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { AddressPinpointMapModal } from '../../components/map/AddressPinpointMapModal';
import { Address, AddressLabel, Coordinates } from '../../types/location';
import { useLocation } from '../../store/locationContext';
import { useApp } from '../../store/appContext';

export interface AddressManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AddressManagementModal: React.FC<AddressManagementModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { savedAddresses, currentAddress, selectAddress, addAddress, updateAddress, deleteAddress } =
    useLocation();
  const { showToast } = useApp();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null);
  const [isPinMapOpen, setIsPinMapOpen] = useState(false);

  // Address Form State
  const [label, setLabel] = useState<AddressLabel>('Home');
  const [receiverName, setReceiverName] = useState(currentAddress.receiverName || '');
  const [phone, setPhone] = useState(currentAddress.phone || '');
  const [flatBuilding, setFlatBuilding] = useState('');
  const [streetArea, setStreetArea] = useState('');
  const [landmark, setLandmark] = useState('');
  const [city, setCity] = useState(currentAddress.city || 'Tirupati');
  const [postalCode, setPostalCode] = useState(currentAddress.postalCode || '517501');
  const [isDefault, setIsDefault] = useState(false);
  const [coordinates, setCoordinates] = useState<Coordinates>(currentAddress.coordinates);

  const resetForm = () => {
    setEditingAddressId(null);
    setLabel('Home');
    setReceiverName(currentAddress.receiverName || '');
    setPhone(currentAddress.phone || '');
    setFlatBuilding('');
    setStreetArea('');
    setLandmark('');
    setCity('Tirupati');
    setPostalCode('517501');
    setIsDefault(false);
    setCoordinates(currentAddress.coordinates);
    setIsFormOpen(false);
  };

  const handleStartAdd = () => {
    resetForm();
    setIsFormOpen(true);
  };

  const handleStartEdit = (addr: Address) => {
    setEditingAddressId(addr.id);
    setLabel(addr.label);
    setReceiverName(addr.receiverName);
    setPhone(addr.phone);
    setFlatBuilding(addr.flatBuilding);
    setStreetArea(addr.streetArea);
    setLandmark(addr.landmark || '');
    setCity(addr.city || 'Tirupati');
    setPostalCode(addr.postalCode || '517501');
    setIsDefault(addr.isDefault || currentAddress.id === addr.id);
    setCoordinates(addr.coordinates);
    setIsFormOpen(true);
  };

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !flatBuilding.trim() ||
      !streetArea.trim() ||
      !city.trim() ||
      !postalCode.trim() ||
      !receiverName.trim() ||
      !phone.trim()
    ) {
      showToast('Please fill all required address fields including City and Pincode', 'error');
      return;
    }

    if (editingAddressId) {
      // Update existing address
      const updatedAddr: Address = {
        id: editingAddressId,
        label,
        receiverName: receiverName.trim(),
        phone: phone.trim(),
        flatBuilding: flatBuilding.trim(),
        streetArea: streetArea.trim(),
        landmark: landmark.trim() || undefined,
        city: city.trim(),
        state: 'Andhra Pradesh',
        postalCode: postalCode.trim(),
        isDefault,
        coordinates,
      };

      updateAddress(updatedAddr);
      if (isDefault) {
        selectAddress(updatedAddr.id);
      }
      showToast('Address updated and synced to database', 'success');
    } else {
      // Create new address
      const newAddr: Address = {
        id: `addr_${Date.now()}`,
        label,
        receiverName: receiverName.trim(),
        phone: phone.trim(),
        flatBuilding: flatBuilding.trim(),
        streetArea: streetArea.trim(),
        landmark: landmark.trim() || undefined,
        city: city.trim(),
        state: 'Andhra Pradesh',
        postalCode: postalCode.trim(),
        isDefault,
        coordinates,
      };

      addAddress(newAddr);
      if (isDefault) {
        selectAddress(newAddr.id);
      }
      showToast('New address saved to database', 'success');
    }

    resetForm();
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (savedAddresses.length <= 1) {
      showToast('At least one delivery address must remain', 'error');
      return;
    }
    deleteAddress(id);
    showToast('Address removed', 'info');
  };

  const getLabelIcon = (tag: AddressLabel) => {
    switch (tag) {
      case 'Home':
        return <Home className="w-4 h-4" />;
      case 'Work':
        return <Briefcase className="w-4 h-4" />;
      default:
        return <MapPin className="w-4 h-4" />;
    }
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={() => {
          resetForm();
          onClose();
        }}
        title={
          isFormOpen
            ? editingAddressId
              ? 'Edit Delivery Address'
              : 'Add Delivery Address'
            : 'Manage Saved Addresses'
        }
        subtitle={
          isFormOpen
            ? 'Update complete doorstep address details including City and Pincode'
            : 'Select, modify, or add new delivery destinations'
        }
      >
        {isFormOpen ? (
          <form onSubmit={handleSaveAddress} className="space-y-3 -mt-2">
            {/* Tag Selector */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Address Tag
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Home', 'Work', 'Other'] as AddressLabel[]).map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => setLabel(tag)}
                    className={`min-h-[38px] rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                      label === tag
                        ? 'border-[#E23744] bg-red-50 dark:bg-red-950/40 text-[#E23744]'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {getLabelIcon(tag)}
                    <span>{tag}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <Input
                label="Receiver Name *"
                placeholder="Nithin"
                value={receiverName}
                onChange={(e) => setReceiverName(e.target.value)}
              />
              <Input
                label="Contact Phone *"
                placeholder="+91 98480..."
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>

            <Input
              label="Flat / House / Building Name *"
              placeholder="Flat 302, Sai Residency"
              value={flatBuilding}
              onChange={(e) => setFlatBuilding(e.target.value)}
            />

            <Input
              label="Area / Street / Sector *"
              placeholder="Air Bypass Road, Near Alipiri Gate"
              value={streetArea}
              onChange={(e) => setStreetArea(e.target.value)}
            />

            {/* City Name & Pincode Inputs */}
            <div className="grid grid-cols-2 gap-2">
              <Input
                label="City Name *"
                placeholder="Tirupati"
                value={city}
                onChange={(e) => setCity(e.target.value)}
              />
              <Input
                label="Pincode *"
                placeholder="517501"
                maxLength={6}
                value={postalCode}
                onChange={(e) => setPostalCode(e.target.value.replace(/\D/g, ''))}
              />
            </div>

            <Input
              label="Landmark (Optional)"
              placeholder="Opposite Indian Oil Petrol Pump"
              value={landmark}
              onChange={(e) => setLandmark(e.target.value)}
            />

            <div className="pt-1 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setIsPinMapOpen(true)}
                className="text-xs font-bold text-[#E23744] flex items-center gap-1 hover:underline cursor-pointer"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Adjust Pin on Map</span>
              </button>

              <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isDefault}
                  onChange={(e) => setIsDefault(e.target.checked)}
                  className="w-4 h-4 accent-[#E23744] rounded"
                />
                <span>Set as default</span>
              </label>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <Button
                type="button"
                variant="outline"
                size="md"
                fullWidth
                onClick={resetForm}
              >
                Cancel
              </Button>
              <Button type="submit" size="md" fullWidth>
                {editingAddressId ? 'Update Address' : 'Save Address'}
              </Button>
            </div>
          </form>
        ) : (
          <div className="space-y-3">
            <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1">
              {savedAddresses.map((addr) => {
                const isSelected = currentAddress.id === addr.id;

                return (
                  <div
                    key={addr.id}
                    className={`p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                      isSelected
                        ? 'border-[#E23744] bg-red-50/40 dark:bg-red-950/20'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                        {getLabelIcon(addr.label)}
                      </div>

                      <div className="space-y-0.5 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                            {addr.label}
                          </span>
                          {isSelected && (
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.2 rounded-md">
                              Active
                            </span>
                          )}
                        </div>

                        <p className="text-xs font-medium text-slate-700 dark:text-slate-300 truncate">
                          {addr.flatBuilding}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {addr.streetArea}
                        </p>
                        <p className="text-[10px] font-bold text-[#E23744] dark:text-red-400">
                          {addr.city} &bull; PIN: {addr.postalCode}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          Receiver: {addr.receiverName} ({addr.phone})
                        </p>
                      </div>
                    </div>

                    {/* Actions Column: Edit, Set Default, and Delete */}
                    <div className="flex items-center gap-1.5 shrink-0 self-center">
                      {/* Edit Button */}
                      <button
                        type="button"
                        onClick={() => handleStartEdit(addr)}
                        className="px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-1 text-[11px] font-bold transition-colors cursor-pointer"
                        title="Edit address details"
                      >
                        <Edit2 className="w-3 h-3 text-[#E23744]" />
                        <span>Edit</span>
                      </button>

                      {/* Set Default */}
                      {!isSelected && (
                        <button
                          type="button"
                          onClick={() => {
                            selectAddress(addr.id);
                            showToast(`Default address set to ${addr.label}`, 'success');
                          }}
                          className="px-2 py-1 rounded-lg text-xs font-bold text-[#E23744] hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors cursor-pointer"
                        >
                          Select
                        </button>
                      )}

                      {/* Delete */}
                      {savedAddresses.length > 1 && (
                        <button
                          type="button"
                          onClick={(e) => handleDelete(addr.id, e)}
                          className="p-1 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                          title="Delete address"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="space-y-2 pt-1">
              <Button
                size="md"
                fullWidth
                leftIcon={<Plus className="w-4 h-4" />}
                onClick={handleStartAdd}
              >
                Add New Address
              </Button>

              <Button
                size="md"
                variant="outline"
                fullWidth
                leftIcon={<Navigation className="w-4 h-4 text-[#E23744]" />}
                onClick={() => {
                  resetForm();
                  setIsPinMapOpen(true);
                }}
              >
                Pin Location on Map
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* Pin Map Modal */}
      <AddressPinpointMapModal
        isOpen={isPinMapOpen}
        onClose={() => setIsPinMapOpen(false)}
        initialCoords={coordinates}
        onConfirmLocation={(newCoords, addressSummary, details) => {
          setCoordinates(newCoords);
          if (details) {
            if (details.streetArea) setStreetArea(details.streetArea);
            if (details.city) setCity(details.city);
            if (details.postalCode) setPostalCode(details.postalCode);
            if (details.landmark) setLandmark(details.landmark);
            if (details.flatBuilding) {
              setFlatBuilding(details.flatBuilding);
            } else if (details.streetArea) {
              setFlatBuilding(`Near ${details.streetArea.split(',')[0]}`);
            }
          } else if (addressSummary) {
            setStreetArea(addressSummary);
            if (!flatBuilding) {
              setFlatBuilding(`Near ${addressSummary.split(',')[0]}`);
            }
          }
          setIsFormOpen(true);
          setIsPinMapOpen(false);
          showToast('Address fields filled from pinned location', 'success');
        }}
      />
    </>
  );
};
