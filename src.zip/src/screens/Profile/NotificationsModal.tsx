/**
 * Notifications Center Modal (Section 37)
 * Displays order tracking updates, vouchers, and announcements
 * grouped chronologically with mark-as-read and clear actions.
 */

import React, { useState, useEffect } from 'react';
import { Bell, CheckCheck, Trash2, Tag, Bike, Info, Sun } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { NotificationItem } from '../../types/profile';
import { notificationService } from '../../services/notificationService';
import { useApp } from '../../store/appContext';

export interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { showToast } = useApp();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  useEffect(() => {
    if (isOpen) {
      setNotifications(notificationService.getNotifications());
    }
  }, [isOpen]);

  const handleMarkAllRead = () => {
    const updated = notificationService.markAllAsRead();
    setNotifications(updated);
    showToast('All notifications marked as read', 'info');
  };

  const handleClearAll = () => {
    const updated = notificationService.clearAll();
    setNotifications(updated);
    showToast('Notifications cleared', 'info');
  };

  const handleItemClick = (id: string) => {
    const updated = notificationService.markAsRead(id);
    setNotifications(updated);
  };

  const getTypeIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'motivation':
        return <Sun className="w-4 h-4 text-amber-500" />;
      case 'order':
        return <Bike className="w-4 h-4 text-emerald-600" />;
      case 'promo':
        return <Tag className="w-4 h-4 text-[#E23744]" />;
      default:
        return <Info className="w-4 h-4 text-blue-600" />;
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Notifications"
      subtitle="Order alerts, seasonal offers, and platform updates"
    >
      <div className="space-y-3 -mt-2">
        {/* Actions Bar */}
        {notifications.length > 0 && (
          <div className="flex items-center justify-between text-xs pb-1 border-b border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={handleMarkAllRead}
              className="text-[#E23744] font-bold hover:underline flex items-center gap-1 cursor-pointer"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Mark all as read</span>
            </button>

            <button
              type="button"
              onClick={handleClearAll}
              className="text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
            >
              Clear all
            </button>
          </div>
        )}

        {/* List */}
        {notifications.length === 0 ? (
          <div className="text-center py-10 space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
              <Bell className="w-6 h-6" />
            </div>
            <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
              No notifications yet
            </p>
            <p className="text-[11px] text-slate-400">
              You're all caught up with your orders and updates.
            </p>
          </div>
        ) : (
          <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
            {notifications.map((n) => (
              <div
                key={n.id}
                onClick={() => handleItemClick(n.id)}
                className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                  !n.read
                    ? 'bg-red-50/40 dark:bg-red-950/20 border-red-200/80 dark:border-red-900/40'
                    : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'
                }`}
              >
                <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                  {getTypeIcon(n.type)}
                </div>

                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                      {n.title}
                    </h4>
                    <span className="text-[10px] text-slate-400 shrink-0">
                      {n.timestamp}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                    {n.message}
                  </p>
                </div>

                {!n.read && (
                  <span className="w-2 h-2 rounded-full bg-[#E23744] shrink-0 mt-1.5" />
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </Modal>
  );
};
