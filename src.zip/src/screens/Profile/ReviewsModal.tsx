/**
 * Customer Reviews & Ratings Modal (Section 36)
 * Allows rating past orders, writing detailed feedback on food quality
 * and delivery experience, and viewing all previous reviews.
 */

import React, { useState, useEffect } from 'react';
import { Star, MessageSquare, Plus, Check, ThumbsUp } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { UserReview } from '../../types/profile';
import { reviewService } from '../../services/reviewService';
import { useOrder } from '../../store/orderContext';
import { useApp } from '../../store/appContext';

export interface ReviewsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReviewsModal: React.FC<ReviewsModalProps> = ({ isOpen, onClose }) => {
  const { orders } = useOrder();
  const { showToast } = useApp();

  const [reviews, setReviews] = useState<UserReview[]>([]);
  const [isWriting, setIsWriting] = useState(false);

  // Form State
  const [overallRating, setOverallRating] = useState(5);
  const [foodRating, setFoodRating] = useState(5);
  const [deliveryRating, setDeliveryRating] = useState(5);
  const [comment, setComment] = useState('');
  const [selectedRestaurantName, setSelectedRestaurantName] = useState('Paradise Biryani Palace');

  useEffect(() => {
    if (isOpen) {
      setReviews(reviewService.getReviews());
    }
  }, [isOpen]);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) {
      showToast('Please enter your review feedback', 'error');
      return;
    }

    const created = reviewService.addReview({
      orderId: `#FG-${Math.floor(10000 + Math.random() * 90000)}`,
      restaurantId: 'rest_1',
      restaurantName: selectedRestaurantName,
      overallRating,
      foodRating,
      deliveryRating,
      comment: comment.trim(),
    });

    setReviews((prev) => [created, ...prev]);
    setIsWriting(false);
    setComment('');
    showToast('Thank you! Your review has been published.', 'success');
  };

  const renderStarSelector = (
    value: number,
    onChange: (val: number) => void
  ) => {
    return (
      <div className="flex gap-1.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="p-1 text-amber-400 hover:scale-110 transition-transform cursor-pointer"
          >
            <Star
              className={`w-6 h-6 ${
                star <= value ? 'fill-current text-amber-500' : 'text-slate-300 dark:text-slate-700'
              }`}
            />
          </button>
        ))}
      </div>
    );
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={isWriting ? 'Write a Food & Delivery Review' : 'Your Reviews & Ratings'}
      subtitle={
        isWriting
          ? 'Share your honest feedback to help kitchens and fellow foodies'
          : 'Reviews and feedback you have shared for restaurants'
      }
    >
      <div className="space-y-4 -mt-2">
        {isWriting ? (
          <form onSubmit={handleSubmitReview} className="space-y-3.5">
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block mb-1">
                Restaurant
              </label>
              <select
                value={selectedRestaurantName}
                onChange={(e) => setSelectedRestaurantName(e.target.value)}
                className="w-full min-h-[42px] px-3 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl"
              >
                <option value="Paradise Biryani Palace">Paradise Biryani Palace</option>
                <option value="Sangeetha Pure Vegetarian">Sangeetha Pure Vegetarian</option>
                <option value="Truffles American Bistro">Truffles American Bistro</option>
                <option value="Domino's Gourmet Pizza">Domino's Gourmet Pizza</option>
                <option value="Haldiram's Sweets & Chaat">Haldiram's Sweets & Chaat</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
                Overall Experience ({overallRating}/5)
              </label>
              {renderStarSelector(overallRating, setOverallRating)}
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="space-y-1">
                <span className="text-[11px] font-semibold text-slate-500">
                  Food Taste ({foodRating}★)
                </span>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setFoodRating(s)}
                      className={`w-7 h-7 rounded-lg text-xs font-bold ${
                        s <= foodRating ? 'bg-amber-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[11px] font-semibold text-slate-500">
                  Delivery Speed ({deliveryRating}★)
                </span>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setDeliveryRating(s)}
                      className={`w-7 h-7 rounded-lg text-xs font-bold ${
                        s <= deliveryRating ? 'bg-emerald-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-1 pt-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
                Detailed Review
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={3}
                placeholder="What did you love? How was the spice level, packing, and temperature?"
                className="w-full p-3 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl resize-none focus:outline-none focus:border-[#E23744]"
              />
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <Button
                type="button"
                variant="outline"
                size="md"
                fullWidth
                onClick={() => setIsWriting(false)}
              >
                Cancel
              </Button>
              <Button type="submit" size="md" fullWidth>
                Submit Review
              </Button>
            </div>
          </form>
        ) : (
          <div className="space-y-3">
            <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
              {reviews.map((rev) => (
                <div
                  key={rev.id}
                  className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 space-y-2"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                        {rev.restaurantName}
                      </h4>
                      <span className="text-[10px] text-slate-400">
                        Order {rev.orderId} · {rev.createdAt}
                      </span>
                    </div>

                    <div className="flex items-center gap-1 text-xs font-bold text-amber-500 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-lg">
                      <Star className="w-3 h-3 fill-current" />
                      <span>{rev.overallRating}.0</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    "{rev.comment}"
                  </p>

                  <div className="flex items-center gap-3 text-[10px] text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800">
                    <span>Food Taste: {rev.foodRating}★</span>
                    <span>Delivery: {rev.deliveryRating}★</span>
                  </div>
                </div>
              ))}
            </div>

            <Button
              size="md"
              fullWidth
              leftIcon={<Plus className="w-4 h-4" />}
              onClick={() => setIsWriting(true)}
            >
              Write New Review
            </Button>
          </div>
        )}
      </div>
    </Modal>
  );
};
