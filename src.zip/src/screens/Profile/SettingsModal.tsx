/**
 * App Settings & Preferences Modal (Section 35)
 * Theme toggle (Light/Dark/System), Notification preferences,
 * Language selector, and Cache clearing.
 */

import React, { useState } from 'react';
import { Sun, Moon, Monitor, Bell, Globe, Trash2, ShieldCheck, Check } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { useTheme } from '../../store/themeContext';
import { useApp } from '../../store/appContext';

export interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { theme, setTheme } = useTheme();
  const { showToast } = useApp();

  const [orderNotifs, setOrderNotifs] = useState(true);
  const [promoNotifs, setPromoNotifs] = useState(true);
  const [smsAlerts, setSmsAlerts] = useState(false);
  const [selectedLang, setSelectedLang] = useState('en');

  const languages = [
    { code: 'en', label: 'English', sub: 'Default' },
    { code: 'te', label: 'తెలుగు (Telugu)', sub: 'Local' },
    { code: 'hi', label: 'हिंदी (Hindi)', sub: 'National' },
    { code: 'ta', label: 'தமிழ் (Tamil)', sub: 'Regional' },
  ];

  const handleClearCache = () => {
    localStorage.removeItem('foodgo_recent_searches');
    showToast('Temporary search and image cache cleared', 'success');
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="App Settings & Preferences"
      subtitle="Customize appearance, notifications, and language"
    >
      <div className="space-y-4 -mt-2">
        {/* 1. Theme Selection */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
            Appearance & Theme
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'light', label: 'Light', icon: Sun },
              { id: 'dark', label: 'Dark', icon: Moon },
              { id: 'system', label: 'System', icon: Monitor },
            ].map((t) => {
              const Icon = t.icon;
              const isSelected = theme === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTheme(t.id as 'light' | 'dark' | 'system')}
                  className={`min-h-[42px] rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isSelected
                      ? 'border-[#E23744] bg-red-50 dark:bg-red-950/40 text-[#E23744] shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{t.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Notification Preferences */}
        <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
            Notification Preferences
          </label>

          <div className="space-y-2 text-xs">
            <label className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 cursor-pointer">
              <div>
                <span className="font-bold text-slate-800 dark:text-slate-200 block">
                  Order Status Updates
                </span>
                <span className="text-[10px] text-slate-400">
                  Kitchen confirmation, rider arrival & delivery alerts
                </span>
              </div>
              <input
                type="checkbox"
                checked={orderNotifs}
                onChange={(e) => setOrderNotifs(e.target.checked)}
                className="w-4 h-4 accent-[#E23744] rounded"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 cursor-pointer">
              <div>
                <span className="font-bold text-slate-800 dark:text-slate-200 block">
                  Promotions & Coupon Offers
                </span>
                <span className="text-[10px] text-slate-400">
                  Weekly discounts and festive cashback drops
                </span>
              </div>
              <input
                type="checkbox"
                checked={promoNotifs}
                onChange={(e) => setPromoNotifs(e.target.checked)}
                className="w-4 h-4 accent-[#E23744] rounded"
              />
            </label>

            <label className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 cursor-pointer">
              <div>
                <span className="font-bold text-slate-800 dark:text-slate-200 block">
                  SMS Order Receipts
                </span>
                <span className="text-[10px] text-slate-400">
                  Receive SMS summary for every placed order
                </span>
              </div>
              <input
                type="checkbox"
                checked={smsAlerts}
                onChange={(e) => setSmsAlerts(e.target.checked)}
                className="w-4 h-4 accent-[#E23744] rounded"
              />
            </label>
          </div>
        </div>

        {/* 3. Language Selector */}
        <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
            Language / భాష
          </label>
          <div className="grid grid-cols-2 gap-2">
            {languages.map((l) => {
              const isSelected = selectedLang === l.code;
              return (
                <button
                  key={l.code}
                  type="button"
                  onClick={() => {
                    setSelectedLang(l.code);
                    showToast(`Language set to ${l.label}`, 'info');
                  }}
                  className={`min-h-[42px] px-3 rounded-2xl border text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                    isSelected
                      ? 'border-[#E23744] bg-red-50 dark:bg-red-950/40 text-[#E23744]'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="text-left">
                    <span>{l.label}</span>
                    <span className="block text-[9px] text-slate-400 font-normal">
                      {l.sub}
                    </span>
                  </div>
                  {isSelected && <Check className="w-3.5 h-3.5" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Cache & Storage */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
              Clear App Cache
            </span>
            <span className="text-[10px] text-slate-400">
              Free up temporary memory & search terms
            </span>
          </div>
          <button
            type="button"
            onClick={handleClearCache}
            className="text-xs font-bold text-rose-500 hover:underline px-2 py-1 cursor-pointer"
          >
            Clear Cache
          </button>
        </div>
      </div>
    </Modal>
  );
};
