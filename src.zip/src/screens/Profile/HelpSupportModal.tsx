/**
 * Help & Customer Support Modal
 * FAQs, Contact channels, and issue resolution.
 */

import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Phone, Mail, MessageCircle } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { useApp } from '../../store/appContext';

export interface HelpSupportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HelpSupportModal: React.FC<HelpSupportModalProps> = ({ isOpen, onClose }) => {
  const { showToast } = useApp();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How can I track my active food order?',
      a: 'Navigate to the Orders tab and tap "Track Live Order" to see your delivery partner moving in real-time on our interactive map.',
    },
    {
      q: 'Can I cancel my order after placing it?',
      a: 'Orders can be cancelled free of charge before the restaurant begins cooking. Once food preparation starts, cancellation is disabled to prevent kitchen food waste.',
    },
    {
      q: 'What should I do if an item is missing or damaged?',
      a: 'Tap "Report an Issue" below or contact our 24/7 care team. We will issue an instant refund or replace the affected dish.',
    },
    {
      q: 'How do promo coupons work?',
      a: 'In the cart screen, tap "Apply Coupon Code" and select from available vouchers. The discount applies automatically to your bill subtotal.',
    },
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Help & Customer Care"
      subtitle="24/7 instant support for your orders and deliveries"
    >
      <div className="space-y-4 -mt-2">
        {/* Support Channels */}
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => showToast('Connecting to 24/7 Live Care Chat...', 'info')}
            className="p-3 rounded-2xl bg-red-50 dark:bg-red-950/30 border border-red-100 dark:border-red-900/40 text-left hover:bg-red-100/70 transition-colors cursor-pointer"
          >
            <MessageCircle className="w-5 h-5 text-[#E23744] mb-1.5" />
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">Live Chat</h4>
            <p className="text-[10px] text-slate-400">Response time ~ 1 min</p>
          </button>

          <a
            href="tel:18002004590"
            className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/40 text-left hover:bg-emerald-100/70 transition-colors cursor-pointer"
          >
            <Phone className="w-5 h-5 text-emerald-600 mb-1.5" />
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">Call Helpline</h4>
            <p className="text-[10px] text-slate-400">Toll-free 1800-200-4590</p>
          </a>
        </div>

        {/* FAQs */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
            Frequently Asked Questions
          </label>

          <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
            {faqs.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden"
                >
                  <button
                    type="button"
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full p-3 flex items-center justify-between text-left text-xs font-bold text-slate-800 dark:text-slate-200 cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-slate-400 shrink-0 ml-2" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400 shrink-0 ml-2" />
                    )}
                  </button>

                  {isOpen && (
                    <div className="px-3 pb-3 text-xs text-slate-500 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800 pt-2">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </Modal>
  );
};
