/**
 * Customer Profile Edit Modal
 * Allows updating First Name, Last Name, Phone Number, and Email,
 * syncing directly to Firestore and updating session state.
 */

import React, { useState, useEffect } from 'react';
import { User, Phone, Mail, Check, Camera } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useAuth } from '../../store/authContext';
import { useApp } from '../../store/appContext';
import { firestoreService } from '../../services/firebase/firestoreService';

export interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({ isOpen, onClose }) => {
  const { user, updateUser } = useAuth();
  const { showToast } = useApp();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (user) {
      setFirstName(user.firstName || '');
      setLastName(user.lastName || '');
      setPhone(user.phone || '');
      setEmail(user.email || '');
    }
  }, [user, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!firstName.trim()) {
      showToast('First name is required', 'error');
      return;
    }
    if (!phone.trim()) {
      showToast('Phone number is required', 'error');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      showToast('Please enter a valid email address', 'error');
      return;
    }

    if (!user) return;

    setIsSubmitting(true);
    const updatedUser = {
      ...user,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      phone: phone.trim(),
      email: email.trim(),
    };

    // Update in-memory auth state and localStorage
    updateUser(updatedUser);
    localStorage.setItem('foodgo_user_profile_custom', JSON.stringify(updatedUser));
    window.dispatchEvent(new Event('user-profile-updated'));

    try {
      // Sync to Cloud Firestore
      await firestoreService.saveUserProfile(updatedUser);
      showToast('Profile updated and synced to database', 'success');
      setIsSubmitting(false);
      onClose();
    } catch (err) {
      console.warn('Firestore database sync error:', err);
      showToast('Profile updated locally (database syncing in background)', 'info');
      setIsSubmitting(false);
      onClose();
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Edit Customer Profile"
      subtitle="Update your personal details stored in the database"
    >
      <form onSubmit={handleSubmit} className="space-y-3.5 -mt-2">
        {/* Avatar Display */}
        <div className="flex flex-col items-center justify-center py-2">
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#E23744] to-red-400 text-white flex items-center justify-center font-black text-2xl shadow-lg">
              {firstName?.[0] || 'U'}
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center shadow-md">
              <Camera className="w-3 h-3" />
            </div>
          </div>
          <span className="text-[10px] text-slate-400 mt-1 font-medium">Customer Avatar</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Input
            label="First Name *"
            placeholder="Nithin"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
          />

          <Input
            label="Last Name"
            placeholder="Ojili"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
          />
        </div>

        <Input
          label="Phone Number *"
          placeholder="+91 98480 12345"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          leftIcon={<Phone className="w-4 h-4 text-slate-400" />}
        />

        <Input
          label="Email Address *"
          type="email"
          placeholder="yourname@gmail.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          leftIcon={<Mail className="w-4 h-4 text-slate-400" />}
        />

        <div className="flex gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <Button
            type="button"
            variant="outline"
            size="md"
            fullWidth
            onClick={onClose}
            disabled={isSubmitting}
          >
            Cancel
          </Button>

          <Button
            type="submit"
            size="md"
            fullWidth
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Saving to Database...' : 'Save Profile'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
