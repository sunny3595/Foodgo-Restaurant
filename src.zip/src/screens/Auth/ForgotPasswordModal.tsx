/**
 * Forgot & Reset Password Modal
 * 3-step secure recovery flow:
 * 1. Email request -> 2. OTP Code input -> 3. Password reset
 */

import React, { useState } from 'react';
import { Mail, KeyRound, Lock, CheckCircle2, ArrowRight } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { mockAuthApi } from '../../services/api/mockApi';
import { validateEmail, validatePassword, evaluatePasswordStrength } from '../../utils/validation';
import { useApp } from '../../store/appContext';

export interface ForgotPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { showToast } = useApp();

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const pwdStrength = evaluatePasswordStrength(newPassword);

  const handleStep1Submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const emailCheck = validateEmail(email);
    if (!emailCheck.isValid) {
      setError(emailCheck.error!);
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const res = await mockAuthApi.forgotPassword(email);
      showToast(res.message, 'info');
      setCode(res.code); // Pre-fill test code for effortless testing
      setStep(2);
    } catch (err: unknown) {
      setError((err as Error).message || 'Failed to send reset code');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStep2Submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || code.length < 6) {
      setError('Please enter the 6-digit code sent to your email');
      return;
    }
    setError('');
    setStep(3);
  };

  const handleStep3Submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const pwdCheck = validatePassword(newPassword);
    if (!pwdCheck.isValid) {
      setError(pwdCheck.error!);
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      await mockAuthApi.resetPassword({
        email,
        code,
        newPassword,
      });
      showToast('Password reset successfully! Please sign in.', 'success');
      onSuccess();
      onClose();
      // Reset state
      setStep(1);
      setEmail('');
      setCode('');
      setNewPassword('');
    } catch (err: unknown) {
      setError((err as Error).message || 'Failed to reset password');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={step === 1 ? 'Reset Password' : step === 2 ? 'Verify Reset Code' : 'Create New Password'}
      subtitle={
        step === 1
          ? 'Enter your email to receive a 6-digit recovery code'
          : step === 2
          ? `Code sent to ${email}`
          : 'Choose a strong new password for your account'
      }
    >
      {/* Progress Steps Header */}
      <div className="flex items-center justify-between mb-4 px-2">
        {[1, 2, 3].map((s) => (
          <div key={s} className="flex items-center gap-1.5 flex-1">
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                step === s
                  ? 'bg-[#E23744] text-white'
                  : step > s
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
              }`}
            >
              {step > s ? <CheckCircle2 className="w-3.5 h-3.5" /> : s}
            </div>
            <div
              className={`h-1 flex-1 rounded-full ${
                step > s ? 'bg-emerald-600' : 'bg-slate-100 dark:bg-slate-800'
              }`}
            />
          </div>
        ))}
      </div>

      {step === 1 && (
        <form onSubmit={handleStep1Submit} className="space-y-4">
          <Input
            label="Email Address"
            type="email"
            placeholder="name@example.com"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              setError('');
            }}
            leftIcon={<Mail className="w-4 h-4" />}
            error={error}
            autoFocus
          />

          <Button type="submit" size="md" fullWidth isLoading={isLoading} rightIcon={<ArrowRight className="w-4 h-4" />}>
            Send Recovery Code
          </Button>
        </form>
      )}

      {step === 2 && (
        <form onSubmit={handleStep2Submit} className="space-y-4">
          <Input
            label="6-Digit Verification Code"
            type="text"
            maxLength={6}
            placeholder="849201"
            value={code}
            onChange={(e) => {
              setCode(e.target.value);
              setError('');
            }}
            leftIcon={<KeyRound className="w-4 h-4" />}
            error={error}
            helperText="Test code 849201 has been pre-filled for testing"
            autoFocus
          />

          <div className="flex items-center justify-between text-xs pt-1">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            >
              Change Email
            </button>
            <button
              type="button"
              onClick={() => showToast('New code sent to ' + email, 'info')}
              className="font-bold text-[#E23744] hover:underline"
            >
              Resend Code
            </button>
          </div>

          <Button type="submit" size="md" fullWidth rightIcon={<ArrowRight className="w-4 h-4" />}>
            Verify Code
          </Button>
        </form>
      )}

      {step === 3 && (
        <form onSubmit={handleStep3Submit} className="space-y-3">
          <Input
            label="New Password"
            type="password"
            placeholder="At least 8 characters"
            value={newPassword}
            onChange={(e) => {
              setNewPassword(e.target.value);
              setError('');
            }}
            leftIcon={<Lock className="w-4 h-4" />}
            autoFocus
          />

          {newPassword && (
            <div className="space-y-1 px-1">
              <div className="flex justify-between text-[11px] font-semibold text-slate-500">
                <span>Strength</span>
                <span className={pwdStrength.score >= 3 ? 'text-emerald-600' : 'text-amber-500'}>
                  {pwdStrength.label}
                </span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${pwdStrength.color}`}
                  style={{ width: `${(pwdStrength.score / 4) * 100}%` }}
                />
              </div>
            </div>
          )}

          <Input
            label="Confirm New Password"
            type="password"
            placeholder="Re-type new password"
            value={confirmPassword}
            onChange={(e) => {
              setConfirmPassword(e.target.value);
              setError('');
            }}
            leftIcon={<Lock className="w-4 h-4" />}
            error={error}
          />

          <div className="pt-2">
            <Button type="submit" size="md" fullWidth isLoading={isLoading}>
              Update Password & Sign In
            </Button>
          </div>
        </form>
      )}
    </Modal>
  );
};
