/**
 * FoodGo Customer - Login Screen
 * Features:
 * - Mobile Number authentication with instant 4-digit OTP verification
 * - Validates existing users against Firestore database and routes directly to homepage
 * - Automatically registers new mobile numbers in Firestore database and prompts for:
 *   1. Full Name
 *   2. Email Address
 *   3. Doorstep Delivery Address (with interactive map pin auto-fill)
 * - Guest mode with cart preservation guarantee
 * - Zero third-party social dependencies (Google, Apple, Facebook removed)
 */

import React, { useState } from 'react';
import {
  Phone,
  ArrowRight,
  ShieldCheck,
  UtensilsCrossed,
  Sparkles,
} from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { OtpModal } from './OtpModal';
import { CompleteProfileModal } from './CompleteProfileModal';
import { useAuth } from '../../store/authContext';
import { useLocation } from '../../store/locationContext';
import { useApp } from '../../store/appContext';
import { APP_CONFIG } from '../../config/appConfig';
import { validatePhone } from '../../utils/validation';

export interface LoginScreenProps {
  onLoginSuccess: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const { continueAsGuest } = useAuth();
  const { loadUserAddresses } = useLocation();
  const { showToast } = useApp();

  const [phoneNumber, setPhoneNumber] = useState('');
  const [error, setError] = useState('');
  const [isOtpOpen, setIsOtpOpen] = useState(false);

  // New user profile prompt state
  const [isCompleteProfileOpen, setIsCompleteProfileOpen] = useState(false);
  const [pendingNewUser, setPendingNewUser] = useState<{ id: string; phone: string } | null>(null);

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const phoneCheck = validatePhone(phoneNumber);
    if (!phoneCheck.isValid) {
      setError(phoneCheck.error || 'Please enter a valid 10-digit mobile number');
      return;
    }
    setError('');
    setIsOtpOpen(true);
  };

  const handleOtpSuccess = (result: { isNewUser: boolean; user: any; addresses?: any[] }) => {
    setIsOtpOpen(false);

    if (!result.isNewUser) {
      // Existing user validated in database -> directly go to homepage!
      if (result.addresses && result.addresses.length > 0) {
        loadUserAddresses(result.addresses);
      }
      onLoginSuccess();
    } else {
      // New user created in database -> ask for Name, Email, and Address
      setPendingNewUser({ id: result.user.id, phone: result.user.phone });
      setIsCompleteProfileOpen(true);
    }
  };

  const handleCompleteProfileSuccess = () => {
    setIsCompleteProfileOpen(false);
    setPendingNewUser(null);
    onLoginSuccess();
  };

  const handleGuest = () => {
    continueAsGuest();
    showToast('Browsing in Guest Mode. You can log in anytime before checkout.', 'info');
    onLoginSuccess();
  };

  return (
    <div className="flex-1 flex flex-col justify-between p-6 bg-white dark:bg-slate-950 select-none min-h-[600px]">
      {/* Brand Hero */}
      <div className="pt-safe flex flex-col items-center text-center">
        <div className="w-16 h-16 rounded-3xl bg-[#E23744] flex items-center justify-center text-white shadow-xl mb-4 ring-8 ring-red-500/10">
          <UtensilsCrossed className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
          Welcome to {APP_CONFIG.appName}
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs leading-relaxed">
          Log in with your mobile number to discover top kitchens, order food & track deliveries
        </p>
      </div>

      {/* Main Mobile Login Form */}
      <div className="my-auto py-6 max-w-sm mx-auto w-full">
        <form onSubmit={handlePhoneSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
              Mobile Number
            </label>
            <div className="flex gap-2">
              <div className="w-16 min-h-[46px] rounded-2xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-center text-xs font-bold text-slate-700 dark:text-slate-300 shrink-0 shadow-xs">
                +91
              </div>
              <div className="flex-1">
                <Input
                  type="tel"
                  maxLength={10}
                  placeholder="Enter 10-digit mobile number"
                  value={phoneNumber}
                  onChange={(e) => {
                    setPhoneNumber(e.target.value.replace(/\D/g, ''));
                    setError('');
                  }}
                  leftIcon={<Phone className="w-4 h-4 text-[#E23744]" />}
                  error={error}
                  autoFocus
                />
              </div>
            </div>
            <p className="text-[11px] text-slate-400 dark:text-slate-500 pl-1">
              We will send a 4-digit verification code to this number
            </p>
          </div>

          <Button
            type="submit"
            size="lg"
            fullWidth
            rightIcon={<ArrowRight className="w-4 h-4" />}
            className="shadow-md"
          >
            Continue with Mobile
          </Button>
        </form>

        {/* Divider */}
        <div className="relative my-6 text-center">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-200 dark:border-slate-800" />
          </div>
          <span className="relative bg-white dark:bg-slate-950 px-3 text-[11px] font-bold text-slate-400 uppercase tracking-widest">
            or
          </span>
        </div>

        {/* Continue as Guest Button */}
        <div>
          <Button
            type="button"
            variant="outline"
            size="lg"
            fullWidth
            onClick={handleGuest}
            leftIcon={<Sparkles className="w-4 h-4 text-amber-500" />}
          >
            Continue as Guest
          </Button>
        </div>
      </div>

      {/* Footer Info */}
      <div className="text-center pt-4 pb-safe border-t border-slate-100 dark:border-slate-800">
        <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <span>Secured with phone OTP verification & encrypted database sync</span>
        </div>
      </div>

      {/* OTP Verification Modal */}
      <OtpModal
        isOpen={isOtpOpen}
        onClose={() => setIsOtpOpen(false)}
        phone={`+91 ${phoneNumber}`}
        onSuccess={handleOtpSuccess}
      />

      {/* New User Profile & Doorstep Address Modal */}
      {pendingNewUser && (
        <CompleteProfileModal
          isOpen={isCompleteProfileOpen}
          userId={pendingNewUser.id}
          phone={pendingNewUser.phone}
          onSuccess={handleCompleteProfileSuccess}
        />
      )}
    </div>
  );
};
