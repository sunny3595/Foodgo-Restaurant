/**
 * User Registration Modal
 * Includes strict validation, password strength meter, referral verification, and terms agreement.
 */

import React, { useState } from 'react';
import { User, Mail, Phone, Lock, Tag, ShieldCheck } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useAuth } from '../../store/authContext';
import { useApp } from '../../store/appContext';
import {
  validateEmail,
  validatePhone,
  validatePassword,
  evaluatePasswordStrength,
  validateReferralCode,
} from '../../utils/validation';

export interface RegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const RegisterModal: React.FC<RegisterModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { register } = useAuth();
  const { showToast } = useApp();

  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    referralCode: '',
  });

  const [agreedToTerms, setAgreedToTerms] = useState(true);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [generalError, setGeneralError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const pwdStrength = evaluatePasswordStrength(form.password);

  const validateAll = (): boolean => {
    const errors: Record<string, string> = {};

    if (!form.firstName.trim()) {
      errors.firstName = 'First name is required';
    }

    const emailRes = validateEmail(form.email);
    if (!emailRes.isValid) {
      errors.email = emailRes.error!;
    }

    const phoneRes = validatePhone(form.phone);
    if (!phoneRes.isValid) {
      errors.phone = phoneRes.error!;
    }

    const pwdRes = validatePassword(form.password);
    if (!pwdRes.isValid) {
      errors.password = pwdRes.error!;
    }

    if (form.password !== form.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }

    const refRes = validateReferralCode(form.referralCode);
    if (!refRes.isValid) {
      errors.referralCode = refRes.error!;
    }

    if (!agreedToTerms) {
      setGeneralError('Please agree to the Terms of Service and Privacy Policy to proceed');
      return false;
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeneralError('');

    if (!validateAll()) {
      return;
    }

    setIsLoading(true);

    try {
      await register(form);
      showToast('Registration successful! Welcome to FoodGo.', 'success');
      onSuccess();
    } catch (err: unknown) {
      setGeneralError((err as Error).message || 'Registration failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Create FoodGo Account"
      subtitle="Sign up to order delicious food and track your delivery"
    >
      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          <Input
            label="First Name *"
            placeholder="John"
            value={form.firstName}
            onChange={(e) => {
              setForm({ ...form, firstName: e.target.value });
              setFieldErrors((prev) => ({ ...prev, firstName: '' }));
            }}
            error={fieldErrors.firstName}
            leftIcon={<User className="w-4 h-4" />}
            required
          />

          <Input
            label="Last Name"
            placeholder="Doe"
            value={form.lastName}
            onChange={(e) => setForm({ ...form, lastName: e.target.value })}
          />
        </div>

        <Input
          label="Email Address *"
          type="email"
          placeholder="name@example.com"
          value={form.email}
          onChange={(e) => {
            setForm({ ...form, email: e.target.value });
            setFieldErrors((prev) => ({ ...prev, email: '' }));
          }}
          error={fieldErrors.email}
          leftIcon={<Mail className="w-4 h-4" />}
          required
        />

        <Input
          label="Mobile Number (10 Digits) *"
          type="tel"
          maxLength={10}
          placeholder="9876543210"
          value={form.phone}
          onChange={(e) => {
            setForm({ ...form, phone: e.target.value.replace(/\D/g, '') });
            setFieldErrors((prev) => ({ ...prev, phone: '' }));
          }}
          error={fieldErrors.phone}
          leftIcon={<Phone className="w-4 h-4" />}
          required
        />

        {/* Password & Strength Indicator */}
        <div className="space-y-1">
          <Input
            label="Password (min 8 characters) *"
            type="password"
            placeholder="••••••••"
            value={form.password}
            onChange={(e) => {
              setForm({ ...form, password: e.target.value });
              setFieldErrors((prev) => ({ ...prev, password: '' }));
            }}
            error={fieldErrors.password}
            leftIcon={<Lock className="w-4 h-4" />}
            required
          />

          {form.password && (
            <div className="space-y-1 px-1 pt-0.5">
              <div className="flex justify-between text-[11px] font-semibold text-slate-500">
                <span>Strength</span>
                <span className={pwdStrength.score >= 3 ? 'text-emerald-600' : 'text-amber-500'}>
                  {pwdStrength.label}
                </span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${pwdStrength.color}`}
                  style={{ width: `${(pwdStrength.score / 4) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <Input
          label="Confirm Password *"
          type="password"
          placeholder="••••••••"
          value={form.confirmPassword}
          onChange={(e) => {
            setForm({ ...form, confirmPassword: e.target.value });
            setFieldErrors((prev) => ({ ...prev, confirmPassword: '' }));
          }}
          error={fieldErrors.confirmPassword}
          leftIcon={<Lock className="w-4 h-4" />}
          required
        />

        <Input
          label="Referral Code (Optional)"
          placeholder="e.g. FOODGO2026"
          value={form.referralCode}
          onChange={(e) => {
            setForm({ ...form, referralCode: e.target.value.toUpperCase() });
            setFieldErrors((prev) => ({ ...prev, referralCode: '' }));
          }}
          error={fieldErrors.referralCode}
          leftIcon={<Tag className="w-4 h-4" />}
        />

        {/* Terms Agreement Checkbox */}
        <label className="flex items-start gap-2 pt-1 text-xs text-slate-600 dark:text-slate-400 cursor-pointer">
          <input
            type="checkbox"
            checked={agreedToTerms}
            onChange={(e) => setAgreedToTerms(e.target.checked)}
            className="w-4 h-4 mt-0.5 accent-[#E23744] rounded"
          />
          <span>
            I agree to FoodGo's{' '}
            <span className="text-[#E23744] font-semibold">Terms of Service</span> and{' '}
            <span className="text-[#E23744] font-semibold">Privacy Policy</span>.
          </span>
        </label>

        {generalError && (
          <p className="text-xs font-semibold text-red-500 pt-1 text-center">{generalError}</p>
        )}

        <div className="pt-2">
          <Button type="submit" size="md" fullWidth isLoading={isLoading}>
            Create FoodGo Account
          </Button>
        </div>
      </form>
    </Modal>
  );
};
