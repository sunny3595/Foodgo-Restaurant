/**
 * Phone OTP Verification Modal
 * Features 30s countdown timer, instant test code autofill, and error feedback.
 */

import React, { useEffect, useState } from 'react';
import { Phone, KeyRound, Clock, RotateCcw } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useAuth } from '../../store/authContext';
import { useApp } from '../../store/appContext';

export interface OtpModalProps {
  isOpen: boolean;
  onClose: () => void;
  phone: string;
  onSuccess: (result: { isNewUser: boolean; user: any; addresses?: any[] }) => void;
}

export const OtpModal: React.FC<OtpModalProps> = ({
  isOpen,
  onClose,
  phone,
  onSuccess,
}) => {
  const { verifyPhoneOtp, sendPhoneOtp } = useAuth();
  const { showToast } = useApp();
  const [otp, setOtp] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [countdown, setCountdown] = useState(30);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isOpen) {
      setCountdown(30);
      setOtp('');
      setError('');
      timer = setInterval(() => {
        setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isOpen]);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length < 4) {
      setError('Please enter the verification code');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const result = await verifyPhoneOtp(phone, otp);
      if (!result.isNewUser) {
        showToast(`Welcome back, ${result.user.firstName || 'Customer'}!`, 'success');
      }
      onSuccess(result);
    } catch (err: unknown) {
      setError((err as Error).message || 'Invalid OTP code');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
    if (countdown > 0) return;
    try {
      await sendPhoneOtp(phone);
      setCountdown(30);
      showToast('New OTP sent to ' + phone, 'info');
    } catch (err: unknown) {
      setError((err as Error).message || 'Failed to resend OTP');
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Verify Mobile Number"
      subtitle={`We sent a one-time verification code to ${phone}`}
    >
      <form onSubmit={handleVerify} className="space-y-4">
        <div className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-950/40 rounded-2xl text-[#E23744]">
          <div className="flex items-center gap-2">
            <Phone className="w-5 h-5" />
            <span className="text-sm font-bold">{phone}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-xs font-semibold hover:underline"
          >
            Change
          </button>
        </div>

        <Input
          label="Enter 4-Digit OTP"
          type="text"
          maxLength={6}
          placeholder="1234"
          value={otp}
          onChange={(e) => {
            setOtp(e.target.value.replace(/\D/g, ''));
            setError('');
          }}
          leftIcon={<KeyRound className="w-4 h-4" />}
          error={error}
          helperText="Development Tip: You can enter 1234 to verify instantly"
          autoFocus
        />

        <div className="flex items-center justify-between text-xs pt-1">
          {countdown > 0 ? (
            <span className="text-slate-400 flex items-center gap-1 tabular-nums">
              <Clock className="w-3.5 h-3.5" />
              <span>Resend code in {countdown}s</span>
            </span>
          ) : (
            <button
              type="button"
              onClick={handleResend}
              className="font-bold text-[#E23744] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Resend OTP Code</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setOtp('1234')}
            className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
          >
            Auto-fill Test Code
          </button>
        </div>

        <div className="pt-2">
          <Button type="submit" size="md" fullWidth isLoading={isLoading}>
            Verify & Continue
          </Button>
        </div>
      </form>
    </Modal>
  );
};
