/**
 * Guest Login Prompt Modal (Rule 10)
 * Prompt shown when a guest attempts an authenticated action (Checkout, Favorites, Profile).
 * Ensures customer's cart and selections are strictly preserved upon sign-in.
 */

import React from 'react';
import { LogIn, ShoppingBag, ShieldCheck, Heart } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';

export interface GuestLoginPromptModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProceedToLogin: () => void;
  actionContext?: 'checkout' | 'favorites' | 'profile' | 'orders' | 'default';
}

export const GuestLoginPromptModal: React.FC<GuestLoginPromptModalProps> = ({
  isOpen,
  onClose,
  onProceedToLogin,
  actionContext = 'default',
}) => {
  const contextDetails = {
    checkout: {
      title: 'Sign in to complete checkout',
      subtitle: 'Your cart items and discounts are saved and will remain intact.',
      icon: ShoppingBag,
    },
    favorites: {
      title: 'Sign in to save favorites',
      subtitle: 'Bookmark your favorite dining spots across your devices.',
      icon: Heart,
    },
    profile: {
      title: 'Sign in to view your account',
      subtitle: 'Access your saved addresses, payment methods, and receipts.',
      icon: LogIn,
    },
    orders: {
      title: 'Sign in to track orders',
      subtitle: 'View live order status, GPS delivery tracking, and history.',
      icon: ShoppingBag,
    },
    default: {
      title: 'Please sign in to continue',
      subtitle: 'Log in with your mobile number. Your current selections are preserved.',
      icon: LogIn,
    },
  }[actionContext];

  const Icon = contextDetails.icon;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={contextDetails.title}
      subtitle={contextDetails.subtitle}
    >
      <div className="flex flex-col items-center text-center p-2 space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-red-50 dark:bg-red-950/40 flex items-center justify-center text-[#E23744] ring-8 ring-red-500/10">
          <Icon className="w-7 h-7" />
        </div>

        <div className="w-full bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-3 flex items-center gap-2.5 text-left border border-slate-100 dark:border-slate-800">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="text-[11px] text-slate-600 dark:text-slate-300">
            Cart preservation guarantee: Items already in your cart will NOT be emptied upon login.
          </span>
        </div>

        <div className="w-full space-y-2 pt-1">
          <Button
            size="lg"
            fullWidth
            onClick={() => {
              onClose();
              onProceedToLogin();
            }}
            leftIcon={<LogIn className="w-4 h-4" />}
          >
            Sign In / Register
          </Button>

          <Button
            size="md"
            variant="ghost"
            fullWidth
            onClick={onClose}
          >
            Continue Browsing
          </Button>
        </div>
      </div>
    </Modal>
  );
};
