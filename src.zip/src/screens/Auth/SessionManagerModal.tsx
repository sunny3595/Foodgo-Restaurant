/**
 * Active Sessions & Device Manager Modal
 * View all currently authenticated devices and revoke access remotely.
 */

import React, { useEffect, useState } from 'react';
import { Smartphone, Monitor, Shield, LogOut, CheckCircle2 } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { SessionDevice } from '../../types/auth';
import { mockAuthApi } from '../../services/api/mockApi';
import { useApp } from '../../store/appContext';

export interface SessionManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SessionManagerModal: React.FC<SessionManagerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { showToast } = useApp();
  const [sessions, setSessions] = useState<SessionDevice[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      loadSessions();
    }
  }, [isOpen]);

  const loadSessions = async () => {
    setIsLoading(true);
    try {
      const list = await mockAuthApi.getActiveSessions();
      setSessions(list);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRevoke = async (id: string, name: string) => {
    const updated = await mockAuthApi.revokeSession(id);
    setSessions(updated);
    showToast(`Session on ${name} revoked`, 'info');
  };

  const handleRevokeAllOthers = async () => {
    const updated = await mockAuthApi.revokeAllOtherSessions();
    setSessions(updated);
    showToast('Logged out of all other devices', 'success');
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Security & Active Sessions"
      subtitle="Manage devices signed into your FoodGo account"
    >
      <div className="space-y-4">
        {/* Security badge */}
        <div className="flex items-center gap-2 p-3 bg-emerald-50 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs">
          <Shield className="w-4 h-4 shrink-0" />
          <span>Automatic token rotation is active across all sessions.</span>
        </div>

        {/* Sessions list */}
        <div className="space-y-2.5">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Connected Devices ({sessions.length})
          </span>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            {sessions.map((sess) => (
              <div key={sess.id} className="p-3.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 shrink-0">
                    {sess.platform === 'web' ? (
                      <Monitor className="w-4 h-4" />
                    ) : (
                      <Smartphone className="w-4 h-4" />
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        {sess.deviceName}
                      </span>
                      {sess.isCurrent && (
                        <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 flex items-center gap-0.5">
                          <CheckCircle2 className="w-2.5 h-2.5" />
                          This Device
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {sess.location} · {sess.lastActive}
                    </p>
                  </div>
                </div>

                {!sess.isCurrent && (
                  <button
                    type="button"
                    onClick={() => handleRevoke(sess.id, sess.deviceName)}
                    className="text-xs font-semibold text-rose-500 hover:text-rose-700 px-2 py-1 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                  >
                    Revoke
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {sessions.filter((s) => !s.isCurrent).length > 0 && (
          <div className="pt-2">
            <Button
              size="md"
              variant="outline"
              fullWidth
              leftIcon={<LogOut className="w-4 h-4" />}
              onClick={handleRevokeAllOthers}
            >
              Sign Out of All Other Devices
            </Button>
          </div>
        )}
      </div>
    </Modal>
  );
};
