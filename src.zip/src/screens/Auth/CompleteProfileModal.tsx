/**
 * New User Profile Completion Modal
 * Prompts newly registered mobile numbers for:
 * 1. Name (First & Last)
 * 2. Email Address
 * 3. Doorstep Delivery Address (Flat/House, Area/Street, City, Pincode, Landmark)
 * Includes interactive Google Map pin adjustment support for instant doorstep pinpointing.
 */

import React, { useState } from 'react';
import { User as UserIcon, Mail, Phone, MapPin, Navigation, Sparkles, CheckCircle2 } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { AddressPinpointMapModal } from '../../components/map/AddressPinpointMapModal';
import { Address, Coordinates } from '../../types/location';
import { useAuth } from '../../store/authContext';
import { useLocation } from '../../store/locationContext';
import { useApp } from '../../store/appContext';
import { validateEmail } from '../../utils/validation';

export interface CompleteProfileModalProps {
  isOpen: boolean;
  onClose?: () => void;
  userId: string;
  phone: string;
  onSuccess: () => void;
}

export const CompleteProfileModal: React.FC<CompleteProfileModalProps> = ({
  isOpen,
  onClose,
  userId,
  phone,
  onSuccess,
}) => {
  const { completeNewProfile } = useAuth();
  const { addAddress, setCurrentAddress, currentAddress } = useLocation();
  const { showToast } = useApp();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');

  // Doorstep delivery address fields
  const [flatBuilding, setFlatBuilding] = useState('');
  const [streetArea, setStreetArea] = useState('');
  const [city, setCity] = useState(currentAddress.city || 'Tirupati');
  const [postalCode, setPostalCode] = useState(currentAddress.postalCode || '517501');
  const [landmark, setLandmark] = useState('');
  const [coordinates, setCoordinates] = useState<Coordinates>(
    currentAddress.coordinates || { latitude: 13.6288, longitude: 79.4192 }
  );

  const [isPinMapOpen, setIsPinMapOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim()) {
      setError('Please enter your first name');
      return;
    }
    const emailCheck = validateEmail(email);
    if (!emailCheck.isValid) {
      setError(emailCheck.error || 'Please enter a valid email address');
      return;
    }
    if (!flatBuilding.trim()) {
      setError('Please enter your flat, house, or building name');
      return;
    }
    if (!streetArea.trim()) {
      setError('Please enter your street, road, or area');
      return;
    }
    if (!city.trim() || !postalCode.trim() || postalCode.trim().length !== 6) {
      setError('Please enter a valid city and 6-digit pincode');
      return;
    }

    setError('');
    setIsLoading(true);

    try {
      const newAddress: Address = {
        id: `addr_home_${Date.now()}`,
        label: 'Home',
        receiverName: `${firstName.trim()} ${lastName.trim()}`.trim(),
        phone: phone.startsWith('+91') ? phone : `+91 ${phone}`,
        flatBuilding: flatBuilding.trim(),
        streetArea: streetArea.trim(),
        landmark: landmark.trim() || undefined,
        city: city.trim(),
        state: 'Andhra Pradesh',
        postalCode: postalCode.trim(),
        isDefault: true,
        coordinates,
      };

      await completeNewProfile(
        userId,
        {
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          email: email.trim(),
        },
        newAddress
      );

      // Set active delivery address in location state
      addAddress(newAddress);
      setCurrentAddress(newAddress);

      showToast(`Welcome to FoodGo, ${firstName.trim()}! Your account is ready.`, 'success');
      onSuccess();
    } catch (err: unknown) {
      console.error('Failed to complete profile:', err);
      setError((err as Error).message || 'Failed to save account details. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose || (() => {})}
        showCloseButton={false}
        title="Complete Your Profile"
        subtitle="Welcome to FoodGo! Please enter your name, email, and doorstep address to get started"
      >
        <form onSubmit={handleSubmit} className="space-y-3.5 -mt-2">
          {/* Welcome Banner */}
          <div className="p-3 bg-red-50 dark:bg-red-950/30 rounded-2xl border border-red-100 dark:border-red-900/40 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#E23744] text-white flex items-center justify-center shrink-0 shadow-sm">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <span>Verified Mobile: {phone}</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                New account created &bull; Complete profile to start ordering
              </p>
            </div>
          </div>

          {error && (
            <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 text-xs font-semibold text-rose-600 dark:text-rose-400">
              {error}
            </div>
          )}

          {/* Name Fields */}
          <div className="grid grid-cols-2 gap-2">
            <Input
              label="First Name *"
              placeholder="Rahul"
              value={firstName}
              onChange={(e) => {
                setFirstName(e.target.value);
                setError('');
              }}
              leftIcon={<UserIcon className="w-4 h-4" />}
              autoFocus
              required
            />
            <Input
              label="Last Name"
              placeholder="Sharma"
              value={lastName}
              onChange={(e) => {
                setLastName(e.target.value);
                setError('');
              }}
            />
          </div>

          {/* Email Address */}
          <Input
            label="Email Address *"
            type="email"
            placeholder="rahul@example.com"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              setError('');
            }}
            leftIcon={<Mail className="w-4 h-4" />}
            required
          />

          {/* Delivery Address Section */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-[#E23744]" />
                <span>Home Delivery Address</span>
              </span>

              <button
                type="button"
                onClick={() => setIsPinMapOpen(true)}
                className="text-xs font-bold text-[#E23744] flex items-center gap-1 hover:underline cursor-pointer"
              >
                <Navigation className="w-3 h-3" />
                <span>Adjust Pin on Map</span>
              </button>
            </div>

            <Input
              label="Flat / House / Building Name *"
              placeholder="Flat 302, Sai Residency"
              value={flatBuilding}
              onChange={(e) => {
                setFlatBuilding(e.target.value);
                setError('');
              }}
              required
            />

            <Input
              label="Area / Street / Sector *"
              placeholder="Air Bypass Road, Near Alipiri Gate"
              value={streetArea}
              onChange={(e) => {
                setStreetArea(e.target.value);
                setError('');
              }}
              required
            />

            <div className="grid grid-cols-2 gap-2">
              <Input
                label="City Name *"
                placeholder="Tirupati"
                value={city}
                onChange={(e) => {
                  setCity(e.target.value);
                  setError('');
                }}
                required
              />
              <Input
                label="Pincode *"
                placeholder="517501"
                maxLength={6}
                value={postalCode}
                onChange={(e) => {
                  setPostalCode(e.target.value.replace(/\D/g, ''));
                  setError('');
                }}
                required
              />
            </div>

            <Input
              label="Landmark (Optional)"
              placeholder="Opposite Indian Oil Petrol Pump"
              value={landmark}
              onChange={(e) => setLandmark(e.target.value)}
            />
          </div>

          <div className="pt-2">
            <Button type="submit" size="lg" fullWidth isLoading={isLoading}>
              Save Profile & Start Ordering
            </Button>
          </div>
        </form>
      </Modal>

      {/* Interactive Map Pinpoint Modal */}
      <AddressPinpointMapModal
        isOpen={isPinMapOpen}
        onClose={() => setIsPinMapOpen(false)}
        initialCoords={coordinates}
        onConfirmLocation={(newCoords, addressSummary, details) => {
          setCoordinates(newCoords);
          if (details) {
            if (details.streetArea) setStreetArea(details.streetArea);
            if (details.city) setCity(details.city);
            if (details.postalCode) setPostalCode(details.postalCode);
            if (details.landmark) setLandmark(details.landmark);
            if (details.flatBuilding) {
              setFlatBuilding(details.flatBuilding);
            } else if (details.streetArea) {
              setFlatBuilding(`Near ${details.streetArea.split(',')[0]}`);
            }
          } else if (addressSummary) {
            setStreetArea(addressSummary);
            if (!flatBuilding) {
              setFlatBuilding(`Near ${addressSummary.split(',')[0]}`);
            }
          }
          setIsPinMapOpen(false);
          showToast('Address details filled from pinned location', 'success');
        }}
      />
    </>
  );
};
