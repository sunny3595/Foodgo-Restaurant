/**
 * Location Permission Request Prompt
 * Prompts user for location permission with Allow, Don't Allow, and Manual options.
 */

import React, { useState } from 'react';
import { MapPin, Navigation, ShieldCheck } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { useLocation } from '../../store/locationContext';

export interface LocationPermissionModalProps {
  isOpen: boolean;
  onResolved: () => void;
}

export const LocationPermissionModal: React.FC<LocationPermissionModalProps> = ({
  isOpen,
  onResolved,
}) => {
  const { requestCurrentLocation, setPermission } = useLocation();
  const [isRequesting, setIsRequesting] = useState(false);

  const handleAllow = async () => {
    setIsRequesting(true);
    try {
      await requestCurrentLocation();
    } finally {
      setIsRequesting(false);
      onResolved();
    }
  };

  const handleDontAllow = () => {
    setPermission('denied');
    onResolved();
  };

  const handleManual = () => {
    onResolved();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleDontAllow} showCloseButton={false}>
      <div className="flex flex-col items-center text-center p-2">
        {/* Radar Icon */}
        <div className="w-16 h-16 rounded-full bg-red-50 dark:bg-red-950/40 flex items-center justify-center text-[#E23744] mb-4 ring-8 ring-red-500/10">
          <Navigation className="w-8 h-8 fill-current" />
        </div>

        <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
          Enable Device Location
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 max-w-xs leading-relaxed">
          Allow FoodGo to access your current location to show restaurants delivering to your exact
          address and accurate delivery times.
        </p>

        <div className="w-full bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-3 my-4 flex items-center gap-2.5 text-left border border-slate-100 dark:border-slate-800">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="text-[11px] text-slate-600 dark:text-slate-300">
            Your location is only used to calculate delivery distance and fees.
          </span>
        </div>

        {/* Buttons */}
        <div className="w-full space-y-2 pt-2">
          <Button
            size="md"
            fullWidth
            onClick={handleAllow}
            isLoading={isRequesting}
            leftIcon={<MapPin className="w-4 h-4" />}
          >
            Allow Location Access
          </Button>

          <Button
            size="md"
            variant="outline"
            fullWidth
            onClick={handleManual}
            disabled={isRequesting}
          >
            Select Location Manually
          </Button>

          <button
            type="button"
            onClick={handleDontAllow}
            className="text-xs font-semibold text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 pt-2 transition-colors"
          >
            Don't Allow
          </button>
        </div>
      </div>
    </Modal>
  );
};
