/**
 * Payment Selection & Simulation Screen (Section 27 & 28)
 * Supports UPI (Google Pay, PhonePe, Paytm, Custom ID), Credit/Debit Cards,
 * Net Banking, Wallets, and Cash on Delivery with mock 3D-Secure bank OTP verification.
 */

import React, { useState } from 'react';
import {
  ArrowLeft,
  ShieldCheck,
  CreditCard,
  Smartphone,
  Landmark,
  Wallet,
  Banknote,
  Check,
  Lock,
  HelpCircle,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Modal } from '../../components/ui/Modal';
import { PaymentMethodType, CardFormData } from '../../types/order';
import { useCart } from '../../store/cartContext';
import { useOrder } from '../../store/orderContext';
import { useLocation } from '../../store/locationContext';
import { useApp } from '../../store/appContext';

export interface PaymentScreenProps {
  onBack: () => void;
  onPaymentSuccess: () => void;
}

export const PaymentScreen: React.FC<PaymentScreenProps> = ({
  onBack,
  onPaymentSuccess,
}) => {
  const { items, restaurant, bill, deliveryNotes, selectedDeliveryTags, clearCart } = useCart();
  const { placeOrder } = useOrder();
  const { currentAddress } = useLocation();
  const { showToast } = useApp();

  const [selectedMethod, setSelectedMethod] = useState<PaymentMethodType>('upi_gpay');
  const [customUpiId, setCustomUpiId] = useState('');
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [selectedWallet, setSelectedWallet] = useState('Paytm');

  // Card Form State
  const [cardForm, setCardForm] = useState<CardFormData>({
    cardNumber: '',
    expiry: '',
    cvv: '',
    cardHolderName: '',
    saveCard: true,
  });

  // Processing & Simulation State
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState('');
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [bankOtp, setBankOtp] = useState('');

  // Detect card brand
  const detectCardBrand = (number: string): string => {
    const clean = number.replace(/\s/g, '');
    if (clean.startsWith('4')) return 'Visa';
    if (/^5[1-5]/.test(clean)) return 'MasterCard';
    if (/^(60|65|81|82)/.test(clean)) return 'RuPay';
    return 'Card';
  };

  const formatCardNumber = (val: string) => {
    const clean = val.replace(/\D/g, '').slice(0, 16);
    return clean.replace(/(\d{4})/g, '$1 ').trim();
  };

  const formatExpiry = (val: string) => {
    const clean = val.replace(/\D/g, '').slice(0, 4);
    if (clean.length >= 3) {
      return `${clean.slice(0, 2)}/${clean.slice(2)}`;
    }
    return clean;
  };

  const handlePayClick = () => {
    if (!restaurant) return;

    // Validate inputs
    if (selectedMethod === 'upi_custom' && !customUpiId.includes('@')) {
      showToast('Please enter a valid UPI ID (e.g. name@oksbi)', 'error');
      return;
    }

    if (selectedMethod === 'card_credit' || selectedMethod === 'card_debit') {
      const cleanNum = cardForm.cardNumber.replace(/\s/g, '');
      if (cleanNum.length < 16) {
        showToast('Please enter a valid 16-digit card number', 'error');
        return;
      }
      if (cardForm.expiry.length < 5) {
        showToast('Please enter expiry in MM/YY format', 'error');
        return;
      }
      if (cardForm.cvv.length < 3) {
        showToast('Please enter a valid 3-digit CVV', 'error');
        return;
      }

      // Open 3D Secure Bank OTP Simulator
      setShowOtpModal(true);
      return;
    }

    // Direct UPI / COD / Wallet flow
    processFinalOrder();
  };

  const processFinalOrder = async () => {
    if (!restaurant) return;

    setIsProcessing(true);
    setProcessingStatus('Securing payment with 256-bit bank encryption...');

    await new Promise((r) => setTimeout(r, 1200));

    if (selectedMethod !== 'cod') {
      setProcessingStatus('Verifying transaction with issuing bank...');
      await new Promise((r) => setTimeout(r, 1000));
    }

    setProcessingStatus('Confirming food order with kitchen...');
    await new Promise((r) => setTimeout(r, 800));

    try {
      await placeOrder({
        items,
        restaurant,
        deliveryAddress: currentAddress,
        bill,
        deliveryNotes,
        selectedDeliveryTags,
        payment: {
          method: selectedMethod,
          upiId: selectedMethod === 'upi_custom' ? customUpiId : undefined,
          card:
            selectedMethod === 'card_credit' || selectedMethod === 'card_debit'
              ? cardForm
              : undefined,
          bankName: selectedMethod === 'netbanking' ? selectedBank : undefined,
          walletName: selectedMethod === 'wallet' ? selectedWallet : undefined,
        },
      });

      clearCart();
      setIsProcessing(false);
      onPaymentSuccess();
    } catch {
      setIsProcessing(false);
      showToast('Payment processing failed. Please retry.', 'error');
    }
  };

  const handleOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (bankOtp.length < 4) {
      showToast('Please enter the 4-digit bank OTP', 'error');
      return;
    }
    setShowOtpModal(false);
    processFinalOrder();
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-h-screen pb-32">
      {/* Top App Bar */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/60 dark:border-slate-800 px-3 py-2 pt-safe flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onBack}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Payment Method
            </h1>
            <p className="text-xs font-extrabold text-slate-900 dark:text-slate-100">
              Total to Pay: ₹{bill.totalPayable}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-xl">
          <Lock className="w-3 h-3" />
          <span>256-bit Encrypted</span>
        </div>
      </header>

      {/* Main Options Container */}
      <div className="p-4 space-y-4">
        {/* 1. UPI Payment Section */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-3">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-[#E23744]" />
            <h2 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              UPI Instant Payments
            </h2>
          </div>

          <div className="space-y-2">
            {[
              { id: 'upi_gpay', name: 'Google Pay UPI', icon: '🇬', desc: 'Instant authorization' },
              { id: 'upi_phonepe', name: 'PhonePe UPI', icon: '🟣', desc: 'Direct UPI auto-debit' },
              { id: 'upi_paytm', name: 'Paytm UPI', icon: '🔵', desc: 'Fast checkout' },
              { id: 'upi_custom', name: 'Add New UPI ID', icon: '@', desc: 'e.g. mobile@upi' },
            ].map((opt) => {
              const isSelected = selectedMethod === opt.id;
              return (
                <div key={opt.id} className="space-y-2">
                  <label
                    onClick={() => setSelectedMethod(opt.id as PaymentMethodType)}
                    className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'border-[#E23744] bg-red-50/50 dark:bg-red-950/30'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-sm font-bold">
                        {opt.icon}
                      </div>
                      <div>
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                          {opt.name}
                        </span>
                        <p className="text-[10px] text-slate-400">{opt.desc}</p>
                      </div>
                    </div>

                    <div
                      className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                        isSelected ? 'border-[#E23744]' : 'border-slate-300 dark:border-slate-600'
                      }`}
                    >
                      {isSelected && <span className="w-2 h-2 rounded-full bg-[#E23744]" />}
                    </div>
                  </label>

                  {/* Custom UPI ID Input */}
                  {isSelected && opt.id === 'upi_custom' && (
                    <div className="pl-11 pr-2 pt-1 pb-2">
                      <Input
                        placeholder="Enter your VPA (e.g. name@oksbi)"
                        value={customUpiId}
                        onChange={(e) => setCustomUpiId(e.target.value)}
                        autoFocus
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* 2. Credit & Debit Cards Section */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-[#E23744]" />
              <h2 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                Credit & Debit Cards
              </h2>
            </div>
            <span className="text-[10px] text-slate-400">Visa, MasterCard, RuPay</span>
          </div>

          <label
            onClick={() => setSelectedMethod('card_credit')}
            className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
              selectedMethod === 'card_credit' || selectedMethod === 'card_debit'
                ? 'border-[#E23744] bg-red-50/50 dark:bg-red-950/30'
                : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                <CreditCard className="w-4 h-4 text-slate-600 dark:text-slate-300" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  Pay via Card
                </span>
                <p className="text-[10px] text-slate-400">
                  {cardForm.cardNumber ? detectCardBrand(cardForm.cardNumber) : 'Enter card details'}
                </p>
              </div>
            </div>

            <div
              className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                selectedMethod === 'card_credit' || selectedMethod === 'card_debit'
                  ? 'border-[#E23744]'
                  : 'border-slate-300 dark:border-slate-600'
              }`}
            >
              {(selectedMethod === 'card_credit' || selectedMethod === 'card_debit') && (
                <span className="w-2 h-2 rounded-full bg-[#E23744]" />
              )}
            </div>
          </label>

          {/* Expanded Card Form */}
          {(selectedMethod === 'card_credit' || selectedMethod === 'card_debit') && (
            <div className="space-y-3 pt-2">
              <Input
                label="Card Number"
                placeholder="4532 8920 1234 5678"
                maxLength={19}
                value={cardForm.cardNumber}
                onChange={(e) =>
                  setCardForm({
                    ...cardForm,
                    cardNumber: formatCardNumber(e.target.value),
                  })
                }
                leftIcon={<CreditCard className="w-4 h-4" />}
                rightIcon={
                  <span className="text-[10px] font-bold text-slate-500 uppercase px-1">
                    {detectCardBrand(cardForm.cardNumber)}
                  </span>
                }
              />

              <div className="grid grid-cols-2 gap-2">
                <Input
                  label="Valid Thru"
                  placeholder="MM/YY"
                  maxLength={5}
                  value={cardForm.expiry}
                  onChange={(e) =>
                    setCardForm({ ...cardForm, expiry: formatExpiry(e.target.value) })
                  }
                />

                <Input
                  label="CVV"
                  type="password"
                  placeholder="•••"
                  maxLength={4}
                  value={cardForm.cvv}
                  onChange={(e) =>
                    setCardForm({
                      ...cardForm,
                      cvv: e.target.value.replace(/\D/g, ''),
                    })
                  }
                  rightIcon={<HelpCircle className="w-3.5 h-3.5 text-slate-400" />}
                />
              </div>

              <Input
                label="Cardholder Name"
                placeholder="Nithin Ojili"
                value={cardForm.cardHolderName}
                onChange={(e) =>
                  setCardForm({ ...cardForm, cardHolderName: e.target.value })
                }
              />

              <label className="flex items-center gap-2 pt-1 text-xs text-slate-600 dark:text-slate-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={cardForm.saveCard}
                  onChange={(e) =>
                    setCardForm({ ...cardForm, saveCard: e.target.checked })
                  }
                  className="w-4 h-4 accent-[#E23744] rounded"
                />
                <span>Save card securely per RBI tokenization guidelines</span>
              </label>
            </div>
          )}
        </div>

        {/* 3. Net Banking Section */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-3">
          <div className="flex items-center gap-2">
            <Landmark className="w-4 h-4 text-[#E23744]" />
            <h2 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              Net Banking
            </h2>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {['HDFC Bank', 'ICICI Bank', 'SBI Bank', 'Axis Bank'].map((bank) => {
              const isSelected = selectedMethod === 'netbanking' && selectedBank === bank;
              return (
                <button
                  key={bank}
                  type="button"
                  onClick={() => {
                    setSelectedMethod('netbanking');
                    setSelectedBank(bank);
                  }}
                  className={`min-h-[42px] px-3 rounded-2xl border text-xs font-bold transition-all text-left flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'border-[#E23744] bg-red-50/50 dark:bg-red-950/30 text-[#E23744]'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <span>{bank}</span>
                  {isSelected && <Check className="w-3.5 h-3.5" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Cash on Delivery (COD) */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800">
          <label
            onClick={() => setSelectedMethod('cod')}
            className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
              selectedMethod === 'cod'
                ? 'border-[#E23744] bg-red-50/50 dark:bg-red-950/30'
                : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                <Banknote className="w-4 h-4 text-slate-600 dark:text-slate-300" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  Cash on Delivery
                </span>
                <p className="text-[10px] text-slate-400">Pay cash or scan QR at door</p>
              </div>
            </div>

            <div
              className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                selectedMethod === 'cod' ? 'border-[#E23744]' : 'border-slate-300 dark:border-slate-600'
              }`}
            >
              {selectedMethod === 'cod' && <span className="w-2 h-2 rounded-full bg-[#E23744]" />}
            </div>
          </label>
        </div>
      </div>

      {/* Sticky Bottom Bar */}
      <footer className="fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800 p-4 pb-safe shadow-lg max-w-md mx-auto">
        <div className="flex items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Total Amount
            </span>
            <span className="text-lg font-black text-slate-900 dark:text-slate-100 tabular-nums">
              ₹{bill.totalPayable}
            </span>
          </div>

          <Button
            size="lg"
            onClick={handlePayClick}
            className="flex-1 font-bold shadow-md"
            rightIcon={<ArrowRight className="w-4 h-4" />}
          >
            <span>{selectedMethod === 'cod' ? 'Place COD Order' : `Pay ₹${bill.totalPayable}`}</span>
          </Button>
        </div>
      </footer>

      {/* 3D-Secure Bank OTP Verification Modal */}
      <Modal
        isOpen={showOtpModal}
        onClose={() => setShowOtpModal(false)}
        title="Verified by Visa / RuPay Secure"
        subtitle="Authorizing payment of ₹"
      >
        <form onSubmit={handleOtpSubmit} className="space-y-4 -mt-2">
          <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-2xl flex items-center justify-between text-xs font-bold">
            <span>Merchant: FoodGo Delivery</span>
            <span className="text-[#E23744]">Amount: ₹{bill.totalPayable}</span>
          </div>

          <div className="space-y-1">
            <Input
              label="Enter 4-Digit Bank OTP"
              type="password"
              maxLength={4}
              placeholder="••••"
              value={bankOtp}
              onChange={(e) => setBankOtp(e.target.value.replace(/\D/g, ''))}
              autoFocus
            />

            <button
              type="button"
              onClick={() => setBankOtp('7829')}
              className="text-[11px] font-bold text-[#E23744] hover:underline pt-1"
            >
              Auto-fill Test Bank OTP (7829)
            </button>
          </div>

          <Button type="submit" size="md" fullWidth disabled={bankOtp.length < 4}>
            Authorize Payment
          </Button>
        </form>
      </Modal>

      {/* Payment Processing Overlay */}
      {isProcessing && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-white text-center">
          <div className="w-16 h-16 rounded-2xl bg-[#E23744] flex items-center justify-center animate-bounce shadow-xl mb-4">
            <Lock className="w-8 h-8 text-white" />
          </div>

          <h3 className="text-base font-extrabold tracking-tight">Processing Payment</h3>
          <p className="text-xs text-white/80 mt-1 max-w-xs">{processingStatus}</p>

          <div className="mt-6 flex items-center gap-2 text-[10px] text-white/60">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Do not press back or refresh the page</span>
          </div>
        </div>
      )}
    </div>
  );
};
