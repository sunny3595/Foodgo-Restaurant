/**
 * Splash Screen
 * Initializes app state, checks stored user session, verifies config, and transitions.
 */

import React, { useEffect, useState } from 'react';
import { UtensilsCrossed, Loader2 } from 'lucide-react';
import { APP_CONFIG } from '../../config/appConfig';
import { secureStorage } from '../../services/storage/secureStorage';

export interface SplashScreenProps {
  onFinish: (initialScreen: 'onboarding' | 'auth' | 'main') => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [initStep, setInitStep] = useState<string>('Initializing FoodGo...');

  useEffect(() => {
    let isMounted = true;

    const runStartupChecks = async () => {
      try {
        // Step 1: Remote config & maintenance check
        setInitStep('Loading configuration...');
        await new Promise((r) => setTimeout(r, 400));

        // Step 2: Check onboarding completion
        setInitStep('Checking session...');
        const hasOnboarded = await secureStorage.isOnboardingCompleted();
        const storedToken = await secureStorage.getAccessToken();

        await new Promise((r) => setTimeout(r, 500));

        if (!isMounted) return;

        if (!hasOnboarded) {
          onFinish('onboarding');
        } else if (!storedToken) {
          onFinish('auth');
        } else {
          onFinish('main');
        }
      } catch (err) {
        console.error('Splash initialization error:', err);
        if (isMounted) onFinish('onboarding');
      }
    };

    runStartupChecks();

    return () => {
      isMounted = false;
    };
  }, [onFinish]);

  return (
    <div className="flex-1 flex flex-col items-center justify-between p-8 bg-gradient-to-b from-[#E23744] to-[#C72330] text-white select-none min-h-[600px]">
      <div className="w-full" />

      {/* Brand Centerpiece */}
      <div className="flex flex-col items-center text-center space-y-4">
        <div className="relative">
          <div className="w-24 h-24 rounded-3xl bg-white shadow-2xl flex items-center justify-center text-[#E23744] ring-8 ring-white/20 animate-pulse">
            <UtensilsCrossed className="w-12 h-12 stroke-[2.2]" />
          </div>
        </div>

        <div className="space-y-1">
          <h1 className="text-3xl font-extrabold tracking-tight">{APP_CONFIG.appName}</h1>
          <p className="text-xs text-white/80 font-medium tracking-wide">
            {APP_CONFIG.tagline}
          </p>
        </div>
      </div>

      {/* Progress & Version Footer */}
      <div className="flex flex-col items-center space-y-2">
        <div className="flex items-center gap-2 text-xs text-white/90 font-medium">
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
          <span>{initStep}</span>
        </div>

        <span className="text-[10px] text-white/60 tracking-wider">
          v{APP_CONFIG.version} · {APP_CONFIG.localization.country}
        </span>
      </div>
    </div>
  );
};
