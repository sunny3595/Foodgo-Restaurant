/**
 * Live Order Tracking Screen (Phase 8 - Section 30)
 * Features:
 * - Real-time map with restaurant, destination, and animated delivery partner markers
 * - Driver GPS movement simulation
 * - 5-Step Order status progress stepper
 * - Delivery ETA countdown timer
 * - Assigned rider contact card (In-App Chat & Call dialer)
 * - Order details accordion & Cancellation policy guard
 */

import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Phone,
  MessageSquare,
  Bike,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  MapPin,
  Utensils,
  ShoppingBag,
} from 'lucide-react';
import { DeliveryTrackingMap } from '../../components/map/DeliveryTrackingMap';
import { RiderChatModal } from './RiderChatModal';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Order, OrderStatus } from '../../types/order';
import { useOrder } from '../../store/orderContext';
import { useApp } from '../../store/appContext';

export interface OrderTrackingScreenProps {
  order: Order;
  onBack: () => void;
}

export const OrderTrackingScreen: React.FC<OrderTrackingScreenProps> = ({
  order: initialOrder,
  onBack,
}) => {
  const { orders, cancelOrder } = useOrder();
  const { showToast } = useApp();

  // Find latest order state from context
  const order = orders.find((o) => o.id === initialOrder.id) || initialOrder;

  // Driver GPS progress simulation (0 = restaurant, 1 = customer)
  const [riderProgress, setRiderProgress] = useState(0.25);
  const [secondsRemaining, setSecondsRemaining] = useState(
    order.estimatedDeliveryMinutes * 60 || 1500
  );
  const [isOrderSummaryOpen, setIsOrderSummaryOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);

  // Countdown timer and simulated rider progression
  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsRemaining((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    const movementTimer = setInterval(() => {
      setRiderProgress((prev) => {
        if (prev >= 0.95) return 0.95;
        return prev + 0.015;
      });
    }, 3500);

    return () => {
      clearInterval(timer);
      clearInterval(movementTimer);
    };
  }, []);

  const formatCountdown = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  const steps: Array<{ key: OrderStatus; label: string }> = [
    { key: 'placed', label: 'Placed' },
    { key: 'confirmed', label: 'Confirmed' },
    { key: 'preparing', label: 'Preparing' },
    { key: 'out_for_delivery', label: 'On the Way' },
    { key: 'delivered', label: 'Delivered' },
  ];

  const getStepIndex = (status: OrderStatus): number => {
    switch (status) {
      case 'placed':
        return 0;
      case 'confirmed':
        return 1;
      case 'preparing':
        return 2;
      case 'ready':
      case 'out_for_delivery':
        return 3;
      case 'delivered':
        return 4;
      default:
        return 1;
    }
  };

  const currentStepIdx = getStepIndex(order.status);

  const handleCancelAttempt = () => {
    if (order.status === 'preparing' || order.status === 'out_for_delivery') {
      showToast(
        'Order cannot be cancelled as the kitchen has already started cooking.',
        'error'
      );
      return;
    }
    setIsCancelModalOpen(true);
  };

  const confirmCancellation = () => {
    const success = cancelOrder(order.id);
    if (success) {
      showToast('Order has been cancelled successfully', 'info');
      setIsCancelModalOpen(false);
      onBack();
    } else {
      showToast('Unable to cancel order at this stage', 'error');
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-h-screen pb-28">
      {/* Top Floating App Bar */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/60 dark:border-slate-800 px-3 py-2 pt-safe flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onBack}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Live Order Tracking
            </h1>
            <p className="text-xs font-extrabold text-slate-900 dark:text-slate-100">
              {order.restaurant.name} · {order.id}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleCancelAttempt}
          className="text-xs font-bold text-rose-500 hover:underline px-2 py-1 cursor-pointer"
        >
          Cancel
        </button>
      </header>

      {/* 1. Live Interactive Map View */}
      <div className="relative">
        <DeliveryTrackingMap
          restaurantCoords={order.restaurant.coordinates}
          customerCoords={order.deliveryAddress.coordinates}
          riderCoords={order.rider?.currentCoordinates || order.restaurant.coordinates}
          riderProgress={riderProgress}
          restaurantName={order.restaurant.name}
          customerAddress={order.deliveryAddress.streetArea}
        />
      </div>

      {/* 2. Order Tracking Status & Rider Card (Bottom Sheet Body) */}
      <div className="-mt-4 px-4 relative z-20 space-y-4">
        {/* Estimated Countdown Card */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-md flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-lg">
              <Clock className="w-6 h-6" />
            </div>

            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Estimated Arrival
              </span>
              <p className="text-lg font-black text-slate-900 dark:text-slate-100 tabular-nums">
                {formatCountdown(secondsRemaining)} mins
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 uppercase tracking-wider">
              {order.status === 'out_for_delivery' ? 'On The Way' : 'Kitchen Active'}
            </span>
            <p className="text-[11px] text-slate-400 mt-1 tabular-nums">
              By {order.estimatedDeliveryTimestamp}
            </p>
          </div>
        </div>

        {/* 5-Step Order Status Progress Bar (Section 30) */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-3">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
            Order Progress
          </span>

          <div className="relative flex items-center justify-between">
            {/* Horizontal connecting track */}
            <div className="absolute left-2 right-2 top-3 h-1 bg-slate-100 dark:bg-slate-800 -z-0">
              <div
                className="h-full bg-emerald-500 transition-all duration-500"
                style={{
                  width: `${(currentStepIdx / (steps.length - 1)) * 100}%`,
                }}
              />
            </div>

            {/* Stepper Nodes */}
            {steps.map((st, idx) => {
              const isPassed = idx <= currentStepIdx;
              const isCurrent = idx === currentStepIdx;

              return (
                <div key={st.key} className="flex flex-col items-center z-10">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                      isPassed
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-400'
                    } ${isCurrent ? 'ring-4 ring-emerald-500/20 scale-110' : ''}`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                  <span
                    className={`text-[9px] font-bold mt-1.5 uppercase tracking-tighter ${
                      isCurrent
                        ? 'text-emerald-600'
                        : isPassed
                        ? 'text-slate-800 dark:text-slate-200'
                        : 'text-slate-400'
                    }`}
                  >
                    {st.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Assigned Rider Interaction Card (Section 31) */}
        {order.rider && (
          <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-md">
                <Bike className="w-6 h-6" />
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                    {order.rider.name}
                  </h3>
                  <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-1 rounded-sm">
                    ★ {order.rider.rating}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 truncate mt-0.5">
                  {order.rider.vehicleModel} ({order.rider.vehicleNumber})
                </p>
                <p className="text-[10px] text-emerald-600 font-semibold mt-0.5">
                  Vaccinated & Sanitized Partner
                </p>
              </div>
            </div>

            {/* Action Buttons: Message & Call */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsChatOpen(true)}
                className="w-10 h-10 rounded-2xl bg-red-50 dark:bg-red-950/40 text-[#E23744] flex items-center justify-center hover:bg-red-100 transition-colors cursor-pointer"
                aria-label="Chat with Delivery Partner"
              >
                <MessageSquare className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setIsCallModalOpen(true)}
                className="w-10 h-10 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center hover:bg-emerald-100 transition-colors cursor-pointer"
                aria-label="Call Delivery Partner"
              >
                <Phone className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Collapsible Order Summary Accordion */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 overflow-hidden">
          <button
            type="button"
            onClick={() => setIsOrderSummaryOpen(!isOrderSummaryOpen)}
            className="w-full p-4 flex items-center justify-between text-left cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-[#E23744]" />
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100">
                Order Items ({order.items.reduce((s, i) => s + i.quantity, 0)} items)
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs font-bold">
              <span className="tabular-nums">₹{order.bill.totalPayable}</span>
              {isOrderSummaryOpen ? (
                <ChevronUp className="w-4 h-4 text-slate-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-slate-400" />
              )}
            </div>
          </button>

          {isOrderSummaryOpen && (
            <div className="px-4 pb-4 pt-1 border-t border-slate-100 dark:border-slate-800 space-y-2 text-xs">
              <div className="space-y-1.5 divide-y divide-slate-100 dark:divide-slate-800">
                {order.items.map((i) => (
                  <div key={i.id} className="pt-1.5 flex justify-between">
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {i.quantity}x {i.food.name}
                      </span>
                      {i.customization.variation && (
                        <span className="text-[10px] text-slate-400 block">
                          {i.customization.variation.name}
                        </span>
                      )}
                    </div>
                    <span className="font-bold tabular-nums">
                      ₹{i.unitPrice * i.quantity}
                    </span>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 space-y-1">
                <div className="flex justify-between">
                  <span>Paid via</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {order.paymentDetailsSummary}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Delivering to</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[200px]">
                    {order.deliveryAddress.streetArea}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* In-App Rider Chat Modal */}
      {order.rider && (
        <RiderChatModal
          rider={order.rider}
          orderId={order.id}
          isOpen={isChatOpen}
          onClose={() => setIsChatOpen(false)}
          onCallRider={() => {
            setIsChatOpen(false);
            setIsCallModalOpen(true);
          }}
        />
      )}

      {/* Call Dialer Simulation Sheet */}
      <Modal
        isOpen={isCallModalOpen}
        onClose={() => setIsCallModalOpen(false)}
        title="Contact Delivery Partner"
        subtitle="Call via masked phone routing"
      >
        <div className="flex flex-col items-center text-center p-3 space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center">
            <Phone className="w-7 h-7" />
          </div>

          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Call {order.rider?.name}
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Phone: {order.rider?.phone}
            </p>
            <p className="text-[11px] text-emerald-600 mt-1">
              Your personal phone number is masked for safety.
            </p>
          </div>

          <div className="w-full space-y-2">
            <a
              href={`tel:${order.rider?.phone}`}
              onClick={() => setIsCallModalOpen(false)}
              className="w-full min-h-[44px] px-4 rounded-2xl bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md hover:bg-emerald-700 transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span>Dial Partner's Number</span>
            </a>

            <Button
              size="md"
              variant="outline"
              fullWidth
              onClick={() => setIsCallModalOpen(false)}
            >
              Close
            </Button>
          </div>
        </div>
      </Modal>

      {/* Cancellation Confirmation Modal */}
      <Modal
        isOpen={isCancelModalOpen}
        onClose={() => setIsCancelModalOpen(false)}
        title="Cancel this order?"
        subtitle="Order Cancellation Policy"
      >
        <div className="flex flex-col items-center text-center p-2 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6" />
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300">
            Are you sure you want to cancel Order{' '}
            <span className="font-bold">{order.id}</span>? Once cancelled, refunds are
            processed back to your original payment method in 24-48 hours.
          </p>

          <div className="w-full space-y-2 pt-2">
            <Button size="md" fullWidth variant="danger" onClick={confirmCancellation}>
              Yes, Cancel Order
            </Button>
            <Button
              size="md"
              fullWidth
              variant="outline"
              onClick={() => setIsCancelModalOpen(false)}
            >
              Keep My Order
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
