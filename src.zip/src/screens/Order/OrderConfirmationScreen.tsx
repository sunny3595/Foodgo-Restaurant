/**
 * Order Confirmation Screen (Section 29)
 * Order placement confirmation with generated Order ID, delivery ETA,
 * item summary, address confirmation, and direct live tracking trigger.
 */

import React from 'react';
import {
  CheckCircle2,
  Clock,
  MapPin,
  ChevronRight,
  Sparkles,
  ShoppingBag,
  ArrowRight,
  ShieldCheck,
  Bike,
} from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { Order } from '../../types/order';

export interface OrderConfirmationScreenProps {
  order: Order;
  onTrackOrder: () => void;
  onGoHome: () => void;
}

export const OrderConfirmationScreen: React.FC<OrderConfirmationScreenProps> = ({
  order,
  onTrackOrder,
  onGoHome,
}) => {
  return (
    <div className="flex-1 flex flex-col p-4 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-h-screen pb-24">
      {/* Top Celebration Card */}
      <div className="pt-safe flex flex-col items-center text-center my-4 space-y-3">
        <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center ring-8 ring-emerald-500/10 shadow-lg">
          <CheckCircle2 className="w-9 h-9 stroke-[2.5]" />
        </div>

        <div>
          <span className="text-xs font-bold text-emerald-600 uppercase tracking-wider block">
            Payment Verified
          </span>
          <h1 className="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight mt-0.5">
            Order Placed Successfully!
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Order ID: <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{order.id}</span>
          </p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Estimated Arrival Banner */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Estimated Delivery
              </span>
              <p className="text-sm font-extrabold text-slate-900 dark:text-slate-100 tabular-nums">
                {order.estimatedDeliveryMinutes} mins · By {order.estimatedDeliveryTimestamp}
              </p>
            </div>
          </div>

          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 uppercase">
            Preparing
          </span>
        </div>

        {/* Assigned Rider Preview */}
        {order.rider && (
          <div className="p-3.5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200">
                <Bike className="w-5 h-5 text-[#E23744]" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Delivery Partner Assigned
                </span>
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  {order.rider.name} · {order.rider.vehicleModel}
                </p>
              </div>
            </div>

            <div className="text-[11px] font-bold text-emerald-600">
              ★ {order.rider.rating}
            </div>
          </div>
        )}

        {/* Delivery Address Summary */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-1">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider">
            <MapPin className="w-3.5 h-3.5 text-[#E23744]" />
            <span>Delivery Destination</span>
          </div>

          <p className="text-xs font-bold text-slate-900 dark:text-slate-100 pt-0.5">
            {order.deliveryAddress.receiverName} ({order.deliveryAddress.label})
          </p>
          <p className="text-xs text-slate-500">
            {order.deliveryAddress.flatBuilding}, {order.deliveryAddress.streetArea},{' '}
            {order.deliveryAddress.city}
          </p>
        </div>

        {/* Items Summary Card */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-[#E23744]" />
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                {order.restaurant.name}
              </span>
            </div>
            <span className="text-xs text-slate-400 tabular-nums">
              {order.items.reduce((s, i) => s + i.quantity, 0)} items
            </span>
          </div>

          <div className="space-y-2 text-xs divide-y divide-slate-100 dark:divide-slate-800">
            {order.items.map((item) => (
              <div key={item.id} className="pt-2 flex justify-between items-start">
                <div className="min-w-0 pr-2">
                  <span className="font-semibold text-slate-800 dark:text-slate-200 block truncate">
                    {item.quantity}x {item.food.name}
                  </span>
                  {item.customization.variation && (
                    <span className="text-[11px] text-slate-400 block">
                      {item.customization.variation.name}
                    </span>
                  )}
                  {item.customization.addons.length > 0 && (
                    <span className="text-[10px] text-slate-400 block">
                      + {item.customization.addons.map((a) => a.name).join(', ')}
                    </span>
                  )}
                </div>

                <span className="font-bold text-slate-900 dark:text-slate-100 tabular-nums shrink-0">
                  ₹{item.unitPrice * item.quantity}
                </span>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center text-xs font-bold">
            <span>Amount Paid</span>
            <span className="text-sm font-black text-[#E23744] tabular-nums">
              ₹{order.bill.totalPayable}
            </span>
          </div>

          <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1">
            <span>Payment Method</span>
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              {order.paymentDetailsSummary}
            </span>
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="space-y-2 pt-2">
          <Button
            size="lg"
            fullWidth
            onClick={onTrackOrder}
            rightIcon={<ArrowRight className="w-4 h-4" />}
          >
            Track Live Delivery on Map
          </Button>

          <Button
            size="md"
            variant="outline"
            fullWidth
            onClick={onGoHome}
          >
            Back to Home Feed
          </Button>
        </div>
      </div>
    </div>
  );
};
