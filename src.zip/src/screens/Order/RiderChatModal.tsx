/**
 * In-App Delivery Partner Chat Interface (Section 31)
 * Provides real-time chat with the assigned delivery partner,
 * quick message chips, and simulated driver replies.
 */

import React, { useState, useEffect, useRef } from 'react';
import { Send, Bike, Phone, X, CheckCheck } from 'lucide-react';
import { Modal } from '../../components/ui/Modal';
import { DeliveryRider } from '../../types/order';

export interface ChatMessage {
  id: string;
  sender: 'customer' | 'rider';
  text: string;
  timestamp: string;
}

export interface RiderChatModalProps {
  rider: DeliveryRider;
  orderId: string;
  isOpen: boolean;
  onClose: () => void;
  onCallRider: () => void;
}

export const RiderChatModal: React.FC<RiderChatModalProps> = ({
  rider,
  orderId,
  isOpen,
  onClose,
  onCallRider,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_1',
      sender: 'rider',
      text: `Hello! I have reached the kitchen and am safely packing your food for Order ${orderId}.`,
      timestamp: 'Just now',
    },
  ]);

  const [inputText, setInputText] = useState('');
  const [isRiderTyping, setIsRiderTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickMessages = [
    'Where are you?',
    'Please ring the doorbell',
    'Leave with building security',
    'Extra tissues please',
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isRiderTyping]);

  const handleSendMessage = (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed) return;

    const newMsg: ChatMessage = {
      id: `cust_${Date.now()}`,
      sender: 'customer',
      text: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputText('');

    // Simulate Rider Reply
    setIsRiderTyping(true);
    setTimeout(() => {
      let reply = 'Sure sir, got it!';
      const lower = trimmed.toLowerCase();
      if (lower.includes('where')) {
        reply = 'I am on the road near Air Bypass junction, arriving at your doorstep in 4-5 minutes!';
      } else if (lower.includes('ring') || lower.includes('bell')) {
        reply = 'Understood! I will ring the bell when I arrive.';
      } else if (lower.includes('security')) {
        reply = 'Noted! I will hand it over to the gate security with your name.';
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `rdr_${Date.now()}`,
          sender: 'rider',
          text: reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      setIsRiderTyping(false);
    }, 1800);
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} showCloseButton={false}>
      <div className="flex flex-col h-[460px] -mt-3">
        {/* Rider Top Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center font-bold">
                <Bike className="w-5 h-5" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" />
            </div>

            <div>
              <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <span>{rider.name}</span>
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-1 rounded-sm">
                  ★ {rider.rating}
                </span>
              </h3>
              <p className="text-[10px] text-slate-400">{rider.vehicleModel}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={onCallRider}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 cursor-pointer"
              aria-label="Call Rider"
            >
              <Phone className="w-4 h-4 text-[#E23744]" />
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-2 space-y-3">
          {messages.map((m) => {
            const isMe = m.sender === 'customer';
            return (
              <div
                key={m.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[78%] px-3.5 py-2 rounded-2xl text-xs leading-relaxed ${
                    isMe
                      ? 'bg-[#E23744] text-white rounded-br-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-bl-xs'
                  }`}
                >
                  <p>{m.text}</p>
                  <div
                    className={`flex items-center justify-end gap-1 mt-1 text-[9px] ${
                      isMe ? 'text-white/70' : 'text-slate-400'
                    }`}
                  >
                    <span>{m.timestamp}</span>
                    {isMe && <CheckCheck className="w-3 h-3 text-white/90" />}
                  </div>
                </div>
              </div>
            );
          })}

          {isRiderTyping && (
            <div className="flex items-center gap-1 text-[11px] text-slate-400 px-2">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" />
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce delay-100" />
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce delay-200" />
              <span className="ml-1 text-[10px] font-semibold">{rider.name} is typing...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Message Chips */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-2 border-t border-slate-100 dark:border-slate-800 shrink-0">
          {quickMessages.map((chip, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSendMessage(chip)}
              className="min-h-[30px] px-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] font-medium whitespace-nowrap hover:bg-slate-200 cursor-pointer shrink-0"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Chat Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage(inputText);
          }}
          className="flex items-center gap-2 pt-1 shrink-0"
        >
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type a message to your rider..."
            className="flex-1 min-h-[38px] px-3 text-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:border-[#E23744]"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="w-9 h-9 rounded-xl bg-[#E23744] text-white flex items-center justify-center disabled:opacity-40 cursor-pointer shadow-xs"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </Modal>
  );
};
