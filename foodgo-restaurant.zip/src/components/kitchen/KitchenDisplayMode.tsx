// ============================================================================
// FoodGo Restaurant - High-Visibility Kitchen Display System (KDS)
// Designed for chefs and kitchen line cooks (large buttons, touch friendly)
// ============================================================================

import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  ChefHat,
  Clock,
  Filter,
  Flame,
  Volume2,
} from 'lucide-react';
import { useOrderStore } from '../../store/useOrderStore';
import { useUIStore } from '../../store/useUIStore';
import { Order } from '../../types';
import { formatRemainingTime, formatTimeOnly } from '../../utils/formatters';
import { soundManager } from '../../utils/sound';

export const KitchenDisplayMode: React.FC = () => {
  const { orders, startPreparing, markReady, acceptOrder } = useOrderStore();
  const { toggleKitchenMode } = useUIStore();
  const [filterState, setFilterState] = useState<'ALL' | 'COOKING' | 'READY'>('ALL');

  // Kitchen focus: Accepted, Preparing, Ready
  const kitchenOrders = orders.filter((o) => {
    if (filterState === 'COOKING') return o.status === 'PREPARING' || o.status === 'ACCEPTED';
    if (filterState === 'READY') return o.status === 'READY_FOR_PICKUP';
    return ['NEW', 'ACCEPTED', 'PREPARING', 'READY_FOR_PICKUP'].includes(o.status);
  });

  return (
    <div className="min-h-full bg-slate-950 p-3 sm:p-5 pb-24 text-slate-100">
      {/* Kitchen Top Bar */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-3 rounded-2xl mb-4">
        <div className="flex items-center gap-2.5">
          <button
            onClick={toggleKitchenMode}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all active:scale-90"
            title="Exit Kitchen Mode"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-sm font-black text-white flex items-center gap-2">
              <Flame className="w-4 h-4 text-orange-500 fill-orange-500" />
              Kitchen Order Ticket Display (KDS)
            </h2>
            <p className="text-[10px] text-slate-400 font-mono">
              Live Cooking Queue · {kitchenOrders.length} Tickets
            </p>
          </div>
        </div>

        {/* Filter Buttons */}
        <div className="flex gap-1 bg-slate-800 p-1 rounded-xl">
          {(['ALL', 'COOKING', 'READY'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setFilterState(filter)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                filterState === filter
                  ? 'bg-orange-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Empty State */}
      {kitchenOrders.length === 0 ? (
        <div className="py-20 text-center flex flex-col items-center justify-center">
          <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 mb-3">
            <ChefHat className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-300">Kitchen Queue Is Clear!</h3>
          <p className="text-xs text-slate-500 mt-1">All current tickets have been cooked & dispatched.</p>
        </div>
      ) : (
        /* Large Ticket Cards Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {kitchenOrders.map((order) => {
            const remaining = formatRemainingTime(order.expectedReadyTime);
            const isUrgent = remaining.isOverdue || (remaining.minutes > 0 && remaining.minutes < 5);

            return (
              <div
                key={order.id}
                className={`rounded-3xl border-2 flex flex-col justify-between overflow-hidden transition-all shadow-xl ${
                  order.status === 'PREPARING'
                    ? isUrgent
                      ? 'bg-slate-900 border-rose-500/80 shadow-rose-500/10'
                      : 'bg-slate-900 border-orange-500/70 shadow-orange-500/10'
                    : order.status === 'READY_FOR_PICKUP'
                    ? 'bg-slate-900 border-emerald-500/70 shadow-emerald-500/10'
                    : 'bg-slate-900 border-amber-500/70'
                }`}
              >
                {/* Ticket Header */}
                <div
                  className={`p-3.5 flex items-center justify-between ${
                    order.status === 'PREPARING'
                      ? 'bg-orange-950/40 border-b border-orange-500/30'
                      : order.status === 'READY_FOR_PICKUP'
                      ? 'bg-emerald-950/40 border-b border-emerald-500/30'
                      : 'bg-amber-950/40 border-b border-amber-500/30'
                  }`}
                >
                  <div>
                    <span className="text-lg font-black text-white font-mono tracking-tight">
                      {order.orderNumber}
                    </span>
                    <div className="text-[10px] text-slate-400 font-medium">
                      Received {formatTimeOnly(order.createdAt)} · {order.deliveryType}
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`inline-block px-2.5 py-1 rounded-lg text-xs font-black uppercase font-mono tracking-wide ${
                        order.status === 'PREPARING'
                          ? 'bg-orange-500 text-slate-950'
                          : order.status === 'READY_FOR_PICKUP'
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-amber-500 text-slate-950'
                      }`}
                    >
                      {order.status === 'PREPARING'
                        ? 'COOKING'
                        : order.status === 'READY_FOR_PICKUP'
                        ? 'READY'
                        : order.status}
                    </span>
                    {order.status === 'PREPARING' && (
                      <div
                        className={`text-xs font-bold font-mono mt-1 flex items-center justify-end gap-1 ${
                          remaining.isOverdue ? 'text-rose-400 font-black animate-pulse' : 'text-orange-300'
                        }`}
                      >
                        <Clock className="w-3 h-3" />
                        {remaining.text}
                      </div>
                    )}
                  </div>
                </div>

                {/* Items & Special Instructions */}
                <div className="p-4 space-y-3 flex-1">
                  <div className="space-y-2">
                    {order.items.map((item) => (
                      <div
                        key={item.id}
                        className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/80 flex items-start gap-3"
                      >
                        <span className="w-8 h-8 rounded-lg bg-orange-500/20 text-orange-300 font-black text-sm flex items-center justify-center shrink-0">
                          {item.quantity}x
                        </span>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-black text-white leading-tight">
                            {item.name}
                          </h4>
                          {item.selectedVariation && (
                            <div className="text-[11px] text-slate-300 font-medium mt-0.5">
                              {item.selectedVariation.groupName}: {item.selectedVariation.optionName}
                            </div>
                          )}
                          {item.selectedAddons && item.selectedAddons.length > 0 && (
                            <div className="text-[11px] text-emerald-400 font-medium mt-0.5">
                              + {item.selectedAddons.map((a) => a.name).join(', ')}
                            </div>
                          )}
                          {item.specialInstructions && (
                            <div className="text-[11px] text-amber-300 bg-amber-950/40 border border-amber-500/20 rounded p-1 mt-1 font-semibold">
                              ⚠️ {item.specialInstructions}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {order.specialInstructions && (
                    <div className="p-2.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs font-medium">
                      <strong>Customer Order Note:</strong> &ldquo;{order.specialInstructions}&rdquo;
                    </div>
                  )}
                </div>

                {/* Large Kitchen Action Buttons */}
                <div className="p-3 bg-slate-950 border-t border-slate-800/80">
                  {order.status === 'NEW' && (
                    <button
                      onClick={() => {
                        soundManager.playSuccessChime();
                        acceptOrder(order.id, 20);
                        startPreparing(order.id);
                      }}
                      className="w-full py-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-lg shadow-amber-500/30"
                    >
                      <ChefHat className="w-5 h-5" />
                      ACCEPT & START COOKING (20m)
                    </button>
                  )}

                  {order.status === 'ACCEPTED' && (
                    <button
                      onClick={() => {
                        soundManager.playTap();
                        startPreparing(order.id);
                      }}
                      className="w-full py-4 rounded-2xl bg-orange-600 hover:bg-orange-500 text-white font-black text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-lg shadow-orange-600/30"
                    >
                      <ChefHat className="w-5 h-5" />
                      START PREPARING
                    </button>
                  )}

                  {order.status === 'PREPARING' && (
                    <button
                      onClick={() => {
                        soundManager.playSuccessChime();
                        markReady(order.id);
                      }}
                      className="w-full py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-lg shadow-emerald-600/30"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                      MARK PACKED & READY
                    </button>
                  )}

                  {order.status === 'READY_FOR_PICKUP' && (
                    <div className="py-2.5 px-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-center font-bold text-xs">
                      ✓ Ready on counter · Waiting for Rider {order.rider?.name || 'Assignment'}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
