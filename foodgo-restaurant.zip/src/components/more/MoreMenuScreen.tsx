// ============================================================================
// FoodGo Restaurant - More Hub (Settings, Stats, Settlements & Onboarding KYC)
// Directly implements user requirements:
// 1. "Stats" separate option displaying Revenue Analytics, Top Dishes,
//    Low Stock Inventory Alerts, and Customer Ratings & Reviews
// 2. "Merchant Onboarding KYC" under separate option
// 3. "Settlement & Bank Details" under separate option
// ============================================================================

import React, { useState } from 'react';
import {
  AlertCircle,
  BarChart3,
  Building,
  CheckCircle,
  ChevronRight,
  Clock,
  CreditCard,
  DollarSign,
  HelpCircle,
  KeyRound,
  Landmark,
  Lock,
  LogOut,
  MapPin,
  Phone,
  ShieldCheck,
  Smartphone,
  TrendingUp,
  UserCheck,
  Users,
  Volume2,
} from 'lucide-react';
import { APP_CONFIG } from '../../config/appConfig';
import { ROLE_PERMISSIONS, UserRole } from '../../types';
import { SecurityManagementModal } from '../auth/SecurityManagementModal';
import { useAuthStore } from '../../store/useAuthStore';
import { useOnboardingStore } from '../../store/useOnboardingStore';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { useUIStore } from '../../store/useUIStore';
import { formatCurrency, maskBankAccount } from '../../utils/formatters';
import { SettlementBankModal } from './SettlementBankModal';
import { StatsScreen } from './StatsScreen';

export const MoreMenuScreen: React.FC = () => {
  const {
    currentUser,
    switchRole,
    hasPermission,
    logout,
    activeDevices,
    isBiometricsEnabled,
  } = useAuthStore();

  const { profile } = useRestaurantStore();
  const {
    soundEnabled,
    toggleSound,
    moreSubView,
    setMoreSubView,
  } = useUIStore();

  const { data: onboardingData, setIsOpenModal: setIsOpenOnboarding } = useOnboardingStore();
  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState(false);
  const [isSettlementModalOpen, setIsSettlementModalOpen] = useState(false);

  const canViewFinance = hasPermission('finance.read');

  // If merchant tapped "Stats", render the full StatsScreen with Back button
  if (moreSubView === 'STATS') {
    return (
      <div className="p-4">
        <StatsScreen onBack={() => setMoreSubView('MENU')} />
      </div>
    );
  }

  return (
    <div className="p-4 pb-24 space-y-4 animate-in fade-in">
      {/* User Profile Card & Role Switcher */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-xl">
        <div className="flex items-center gap-3">
          <img
            src={currentUser?.avatarUrl}
            alt={currentUser?.name}
            className="w-12 h-12 rounded-full object-cover border-2 border-rose-500/50 shadow-md"
          />
          <div className="flex-1 min-w-0">
            <h3 className="text-sm font-bold text-white truncate">{currentUser?.name}</h3>
            <p className="text-[11px] text-slate-400 font-mono">{currentUser?.phone}</p>
            <span className="inline-block mt-1 px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-300 text-[10px] font-black uppercase tracking-wider">
              {currentUser?.role.replace(/_/g, ' ')}
            </span>
          </div>
        </div>

        {/* RBAC Role Switcher */}
        <div className="pt-2 border-t border-slate-800">
          <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1 mb-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            Switch Active Role (RBAC Simulator)
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            {(
              [
                'RESTAURANT_OWNER',
                'RESTAURANT_ADMIN',
                'RESTAURANT_MANAGER',
                'RESTAURANT_STAFF',
              ] as UserRole[]
            ).map((role) => {
              const isCurrent = currentUser?.role === role;
              return (
                <button
                  key={role}
                  onClick={() => switchRole(role)}
                  className={`p-2 rounded-xl text-[11px] font-bold text-left transition-all border ${
                    isCurrent
                      ? 'bg-rose-500 border-rose-400 text-white shadow-md shadow-rose-500/20'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="truncate">{role.replace('RESTAURANT_', '')}</div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* CORE DEDICATED OPTIONS AS REQUESTED BY USER */}
      <div className="space-y-2.5">
        <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-1">
          Business Intelligence &amp; Legal
        </h4>

        {/* 1. SEPARATE OPTION: Stats (Revenue Analytics, Top Dishes, Low Stock, Ratings) */}
        <button
          type="button"
          onClick={() => setMoreSubView('STATS')}
          className="w-full p-4 rounded-3xl bg-slate-900 hover:bg-slate-850 border border-purple-500/40 text-left transition-all active:scale-[0.99] flex items-center justify-between group shadow-xl"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform ring-2 ring-purple-500/20">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-white group-hover:text-purple-300">
                  Stats &amp; Analytics
                </span>
                <span className="text-[9px] font-bold text-purple-300 bg-purple-950/70 px-2 py-0.5 rounded border border-purple-500/30">
                  Interactive
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate mt-0.5">
                Revenue trends, top selling dishes, low stock alerts &amp; customer ratings
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-purple-400 shrink-0 opacity-70 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
        </button>

        {/* 2. SEPARATE OPTION: Settlement & Bank Details */}
        <button
          type="button"
          onClick={() => setIsSettlementModalOpen(true)}
          className="w-full p-4 rounded-3xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-left transition-all active:scale-[0.99] flex items-center justify-between group shadow-lg"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform ring-2 ring-emerald-500/20">
              <Landmark className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-white group-hover:text-emerald-300">
                  Settlement &amp; Bank Details
                </span>
                <span className="text-[9px] font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                  HDFC Verified
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate mt-0.5">
                Bank accounts, IFSC, daily auto-transfers &amp; payout ledger
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-500 shrink-0 group-hover:text-white group-hover:translate-x-0.5 transition-all" />
        </button>

        {/* 3. SEPARATE OPTION: Merchant Onboarding & KYC */}
        <button
          type="button"
          onClick={() => setIsOpenOnboarding(true)}
          className="w-full p-4 rounded-3xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-left transition-all active:scale-[0.99] flex items-center justify-between group shadow-lg"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-orange-500/20 text-orange-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform ring-2 ring-orange-500/20">
              <Building className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-white group-hover:text-orange-300">
                  Merchant Onboarding &amp; KYC
                </span>
                <span
                  className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border ${
                    onboardingData.verification.status === 'APPROVED'
                      ? 'text-emerald-400 bg-emerald-950/60 border-emerald-500/30'
                      : 'text-amber-400 bg-amber-950/60 border-amber-500/30'
                  }`}
                >
                  {onboardingData.verification.status.replace(/_/g, ' ')}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate mt-0.5">
                FSSAI food license, GST certificate, store verification &amp; legal docs
              </p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-slate-500 shrink-0 group-hover:text-white group-hover:translate-x-0.5 transition-all" />
        </button>
      </div>

      {/* Security, Passwords & Devices Card */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-lg">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <KeyRound className="w-4 h-4 text-rose-400" />
            Security &amp; Device Access
          </h4>
          <span className="text-[10px] font-mono text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
            {activeDevices.length} Connected
          </span>
        </div>

        <div className="text-xs text-slate-300 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Biometric Login:</span>
            <span className="font-bold text-white">
              {isBiometricsEnabled ? 'Enabled (Face ID / Fingerprint)' : 'Disabled'}
            </span>
          </div>

          <button
            type="button"
            onClick={() => setIsSecurityModalOpen(true)}
            className="w-full py-2.5 rounded-xl bg-slate-950 hover:bg-slate-850 border border-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <Smartphone className="w-3.5 h-3.5 text-rose-400" />
            <span>Manage Password, Devices &amp; Security</span>
          </button>
        </div>
      </div>

      {/* Restaurant Profile Information */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-2.5 shadow-lg">
        <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
          <Building className="w-4 h-4 text-rose-400" />
          Restaurant Profile &amp; Timings
        </h4>

        <div className="text-xs space-y-2 text-slate-300">
          <div className="flex items-start gap-2">
            <MapPin className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
            <span>{profile.address.street}, {profile.address.city}, {profile.address.state}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>{profile.phone}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>Open Daily: 11:00 AM – 11:30 PM (Extended Fri-Sun)</span>
          </div>
        </div>
      </div>

      {/* App Audio Preferences */}
      <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-lg">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <Volume2 className="w-4 h-4 text-orange-400" />
            <span className="font-bold">Order Audio Alarm &amp; Chimes</span>
          </div>
          <button
            onClick={toggleSound}
            className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ${
              soundEnabled ? 'bg-emerald-500' : 'bg-slate-700'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white transition duration-200 ${
                soundEnabled ? 'translate-x-4' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Sign Out Action Button */}
      <button
        type="button"
        onClick={logout}
        className="w-full py-3 rounded-2xl bg-rose-950/60 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 text-xs font-black flex items-center justify-center gap-2 transition-all active:scale-95"
      >
        <LogOut className="w-4 h-4" />
        <span>Sign Out of Terminal</span>
      </button>

      {/* App Footer Info */}
      <div className="text-center text-[11px] text-slate-500 pt-2 font-mono">
        <div>{APP_CONFIG.appName} v{APP_CONFIG.version} (Build #{APP_CONFIG.buildNumber})</div>
        <div className="text-[10px] mt-0.5">Enterprise Multi-Vendor Merchant Terminal</div>
      </div>

      {/* Security Management Modal Dialog */}
      <SecurityManagementModal
        isOpen={isSecurityModalOpen}
        onClose={() => setIsSecurityModalOpen(false)}
      />

      {/* Settlement & Bank Details Modal */}
      <SettlementBankModal
        isOpen={isSettlementModalOpen}
        onClose={() => setIsSettlementModalOpen(false)}
      />
    </div>
  );
};
