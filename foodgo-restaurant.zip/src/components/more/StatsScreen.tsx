// ============================================================================
// FoodGo Restaurant - Dedicated Stats & Analytics Screen (More Tab Option)
// Displays: Revenue Analytics, Top Selling Dishes, Low Stock Alerts, Customer Ratings
// ============================================================================

import React from 'react';
import { ArrowLeft, BarChart3, ChevronLeft, Sparkles, TrendingUp } from 'lucide-react';
import { CustomerRatingsWidget } from '../dashboard/CustomerRatingsWidget';
import { LowStockAlertsWidget } from '../dashboard/LowStockAlertsWidget';
import { RevenueChart } from '../dashboard/RevenueChart';
import { TopSellingItemsWidget } from '../dashboard/TopSellingItemsWidget';

interface StatsScreenProps {
  onBack: () => void;
}

export const StatsScreen: React.FC<StatsScreenProps> = ({ onBack }) => {
  return (
    <div className="space-y-4 animate-in fade-in pb-12">
      {/* Navigation Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-bold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to More Hub</span>
        </button>

        <div className="flex items-center gap-1.5 text-xs font-black text-white">
          <BarChart3 className="w-4 h-4 text-rose-500" />
          <span>Stats &amp; Analytics</span>
        </div>
      </div>

      {/* Screen Title & Subtitle */}
      <div className="bg-slate-900/60 p-3.5 rounded-3xl border border-slate-800 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-black text-white flex items-center gap-2">
            <span>Restaurant Intelligence &amp; Metrics</span>
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
              Live Real-Time
            </span>
          </h2>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Revenue trends, menu velocity, stock thresholds, and customer satisfaction
          </p>
        </div>
      </div>

      {/* 1. Revenue Analytics Chart */}
      <RevenueChart />

      {/* 2. Top Selling Dishes */}
      <TopSellingItemsWidget />

      {/* 3. Low Stock Inventory Alerts */}
      <LowStockAlertsWidget />

      {/* 4. Customer Ratings & Reviews */}
      <CustomerRatingsWidget />
    </div>
  );
};
