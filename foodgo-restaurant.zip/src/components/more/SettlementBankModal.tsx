// ============================================================================
// FoodGo Restaurant - Settlement & Bank Details Modal (More Tab Option)
// Displays bank accounts, IFSC, settlement cycle, payout history
// ============================================================================

import React, { useState } from 'react';
import {
  ArrowLeft,
  Building,
  CheckCircle2,
  Clock,
  CreditCard,
  DollarSign,
  Eye,
  EyeOff,
  Landmark,
  ShieldCheck,
  X,
} from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { formatCurrency, maskBankAccount } from '../../utils/formatters';

interface SettlementBankModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettlementBankModal: React.FC<SettlementBankModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { hasPermission } = useAuthStore();
  const [isMasked, setIsMasked] = useState(true);

  if (!isOpen) return null;

  const rawAccountNumber = '501002348914589';
  const displayAccount = isMasked ? maskBankAccount(rawAccountNumber) : rawAccountNumber;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-md max-h-[90vh] bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl p-5 overflow-y-auto space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Landmark className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Settlement &amp; Bank Details</h3>
              <p className="text-[11px] text-slate-400">Direct merchant settlement account</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Verification Status Badge */}
        <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-white">Verified by FoodGo Banking Ops</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-900/50 px-2 py-0.5 rounded border border-emerald-500/40">
            ACTIVE
          </span>
        </div>

        {/* Primary Bank Card */}
        <div className="p-4 rounded-3xl bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building className="w-4 h-4 text-slate-300" />
              <span className="text-xs font-black text-white">HDFC Bank Ltd</span>
            </div>
            <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
              Current A/C
            </span>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Account Number
            </span>
            <div className="flex items-center justify-between">
              <span className="text-sm font-black text-white font-mono tracking-wider">
                {displayAccount}
              </span>
              <button
                type="button"
                onClick={() => setIsMasked(!isMasked)}
                className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 font-semibold"
              >
                {isMasked ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span className="text-[10px]">{isMasked ? 'Reveal' : 'Mask'}</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-slate-800/80">
            <div>
              <span className="text-[10px] text-slate-400 block">IFSC Code</span>
              <span className="font-mono font-bold text-white text-[11px]">HDFC0001248</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Branch</span>
              <span className="font-medium text-slate-200 text-[11px] truncate block">
                Madhapur, Hyderabad
              </span>
            </div>
            <div className="col-span-2 pt-1">
              <span className="text-[10px] text-slate-400 block">Beneficiary Name</span>
              <span className="font-bold text-white text-xs">
                Royal Hyderabadi Biryani Hospitality LLP
              </span>
            </div>
          </div>
        </div>

        {/* Settlement Metrics & Schedule */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Next Settlement
            </span>
            <div className="text-lg font-black text-emerald-400 font-mono">
              {formatCurrency(14850)}
            </div>
            <span className="text-[10px] text-slate-400 block">Scheduled tomorrow 06:00 AM</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Payout Cadence
            </span>
            <div className="text-xs font-black text-white mt-1">Daily Automated NEFT/IMPS</div>
            <span className="text-[10px] text-emerald-400 font-semibold block">T+1 Settlement</span>
          </div>
        </div>

        {/* Historical Settlements List */}
        <div className="space-y-2 pt-1">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Recent Transferred Settlements
          </span>
          <div className="space-y-1.5 text-xs">
            {[
              { id: 'SETTL-8921', date: 'Yesterday, 6:00 AM', amount: 38240, status: 'CREDITED' },
              { id: 'SETTL-8919', date: '2 days ago', amount: 42100, status: 'CREDITED' },
              { id: 'SETTL-8914', date: '3 days ago', amount: 34950, status: 'CREDITED' },
            ].map((s) => (
              <div
                key={s.id}
                className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between text-xs font-mono"
              >
                <div>
                  <div className="font-bold text-white">{s.id}</div>
                  <div className="text-[10px] text-slate-400 font-sans">{s.date}</div>
                </div>
                <div className="text-right">
                  <div className="font-black text-emerald-400">{formatCurrency(s.amount)}</div>
                  <div className="text-[9px] text-emerald-500 font-bold">{s.status}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-bold transition-all"
        >
          Close
        </button>
      </div>
    </div>
  );
};
