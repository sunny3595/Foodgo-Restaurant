// ============================================================================
// FoodGo Restaurant - Menu & Inventory Management Screen
// ============================================================================

import React, { useState } from 'react';
import {
  AlertCircle,
  Check,
  CheckCircle2,
  Clock,
  Flame,
  Minus,
  Plus,
  PlusCircle,
  Search,
  SlidersHorizontal,
  XCircle,
} from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { useMenuStore } from '../../store/useMenuStore';
import { formatCurrency } from '../../utils/formatters';

export const MenuManagementScreen: React.FC = () => {
  const { categories, foodItems, selectedCategoryId, setSelectedCategory, toggleFoodAvailability, updateStock } =
    useMenuStore();
  const { hasPermission } = useAuthStore();
  const [searchQuery, setSearchQuery] = useState('');

  const canEditMenu = hasPermission('menu.update');

  const filteredItems = foodItems.filter((item) => {
    const matchesCategory = selectedCategoryId ? item.categoryId === selectedCategoryId : true;
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="p-4 pb-24 space-y-4">
      {/* Top Search & Actions */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search menu items..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-800/90 border border-slate-700 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-rose-500"
          />
        </div>
      </div>

      {/* Categories Horizontal Scroller */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all active:scale-95 ${
            selectedCategoryId === null
              ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
              : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
          }`}
        >
          All Items ({foodItems.length})
        </button>

        {categories.map((cat) => {
          const count = foodItems.filter((i) => i.categoryId === cat.id).length;
          const isSelected = selectedCategoryId === cat.id;

          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 active:scale-95 ${
                isSelected
                  ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
              }`}
            >
              <span>{cat.name}</span>
              <span className="text-[10px] opacity-75 font-mono">({count})</span>
            </button>
          );
        })}
      </div>

      {/* Food Items List */}
      <div className="space-y-3">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className={`p-3.5 rounded-2xl border transition-all ${
              item.isAvailable
                ? 'bg-slate-800/80 border-slate-700'
                : 'bg-slate-900/90 border-slate-800 opacity-60'
            }`}
          >
            <div className="flex gap-3">
              {/* Food Thumbnail */}
              <div className="relative w-20 h-20 rounded-xl overflow-hidden shrink-0 bg-slate-800">
                <img
                  src={item.imageUrl}
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
                <span
                  className={`absolute top-1 left-1 w-3.5 h-3.5 rounded-sm flex items-center justify-center border ${
                    item.isVegetarian
                      ? 'border-emerald-500 bg-emerald-950/80'
                      : 'border-rose-500 bg-rose-950/80'
                  }`}
                  title={item.isVegetarian ? 'Pure Vegetarian' : 'Non-Vegetarian'}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      item.isVegetarian ? 'bg-emerald-400' : 'bg-rose-400'
                    }`}
                  />
                </span>
              </div>

              {/* Item Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between">
                  <h4 className="text-xs font-bold text-white leading-tight">
                    {item.name}
                  </h4>
                  <span className="text-xs font-black font-mono text-emerald-400 shrink-0 ml-2">
                    {formatCurrency(item.price)}
                  </span>
                </div>

                <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                  {item.description}
                </p>

                {/* Badges / Modifiers preview */}
                <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1.5">
                  <span className="flex items-center gap-0.5">
                    <Clock className="w-3 h-3 text-orange-400" />
                    {item.preparationTimeMinutes}m
                  </span>
                  {item.variations && (
                    <span>• {item.variations[0].options.length} Sizes</span>
                  )}
                  {item.addonGroups && (
                    <span>• {item.addonGroups[0].addons.length} Add-ons</span>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Stock & Availability Control Bar */}
            <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex items-center justify-between">
              {/* Inventory Stock Count */}
              {item.trackInventory && (
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Stock:</span>
                  <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700 px-2 py-0.5 rounded-lg">
                    <button
                      onClick={() => updateStock(item.id, (item.currentStock || 0) - 1)}
                      disabled={!item.currentStock || item.currentStock <= 0}
                      className="text-slate-400 hover:text-white disabled:opacity-30"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-xs font-mono font-black text-white px-1">
                      {item.currentStock || 0}
                    </span>
                    <button
                      onClick={() => updateStock(item.id, (item.currentStock || 0) + 1)}
                      className="text-slate-400 hover:text-white"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              )}

              {/* Instant Available Toggle (86 Item) */}
              <div className="flex items-center gap-2 ml-auto">
                <span className="text-[10px] font-bold text-slate-400">
                  {item.isAvailable ? 'In Stock' : 'Sold Out'}
                </span>
                <button
                  type="button"
                  onClick={() => toggleFoodAvailability(item.id)}
                  className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    item.isAvailable ? 'bg-emerald-500' : 'bg-slate-700'
                  }`}
                  role="switch"
                  aria-checked={item.isAvailable}
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                      item.isAvailable ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
