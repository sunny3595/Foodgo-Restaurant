// ============================================================================
// FoodGo Restaurant - In-App Contact Sheet for Customer or Delivery Partner
// Directly implements Master Prompt Section 7: Contact customer, Contact driver
// ============================================================================

import React, { useState } from 'react';
import { Eye, EyeOff, MessageSquare, Phone, PhoneCall, Send, ShieldCheck, X } from 'lucide-react';
import { Order } from '../../types';
import { maskPhoneNumber } from '../../utils/formatters';

interface ContactModalProps {
  order: Order | null;
  target: 'CUSTOMER' | 'DRIVER';
  isOpen: boolean;
  onClose: () => void;
}

export const ContactModal: React.FC<ContactModalProps> = ({
  order,
  target,
  isOpen,
  onClose,
}) => {
  const [isMasked, setIsMasked] = useState(true);
  const [chatMessage, setChatMessage] = useState('');
  const [messages, setMessages] = useState<string[]>([
    target === 'CUSTOMER'
      ? 'Hello! Your Biryani is in the dum handi and will be ready in 15 mins.'
      : 'Hello rider, please enter via Gate 2 and collect from Counter 4.',
  ]);
  const [isCalling, setIsCalling] = useState(false);

  if (!isOpen || !order) return null;

  const isCustomer = target === 'CUSTOMER';
  const name = isCustomer ? order.customer.name : (order.rider?.name || 'Ramesh Kumar (Rider)');
  const rawPhone = isCustomer ? order.customer.phone : (order.rider?.phone || '+91 98480 22334');
  const displayPhone = isMasked ? maskPhoneNumber(rawPhone) : rawPhone;

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;
    setMessages((prev) => [...prev, chatMessage.trim()]);
    setChatMessage('');
  };

  const handleSimulateCall = () => {
    setIsCalling(true);
    setTimeout(() => {
      setIsCalling(false);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-black text-white">
              Contact {isCustomer ? 'Customer' : 'Delivery Partner'}
            </h3>
            <p className="text-[11px] text-slate-400">Order {order.orderNumber}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Contact Info Card */}
        <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-white text-sm">{name}</span>
            <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              <span>Verified Contact</span>
            </span>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div className="font-mono text-slate-300 font-bold">{displayPhone}</div>
            <button
              type="button"
              onClick={() => setIsMasked(!isMasked)}
              className="text-[10px] text-rose-400 hover:text-rose-300 flex items-center gap-1 font-semibold"
            >
              {isMasked ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              <span>{isMasked ? 'Reveal Phone' : 'Mask Number'}</span>
            </button>
          </div>

          {/* Call button */}
          <button
            type="button"
            onClick={handleSimulateCall}
            disabled={isCalling}
            className="w-full mt-2 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md shadow-emerald-600/20"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>{isCalling ? 'Connecting Encrypted Call...' : `Call ${name}`}</span>
          </button>
        </div>

        {/* In-App Direct Chat Simulation */}
        <div className="space-y-2">
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Direct FoodGo Terminal Chat
          </label>
          <div className="h-28 overflow-y-auto p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className="p-2 rounded-xl bg-slate-800 text-slate-200 text-xs max-w-[85%] self-end ml-auto"
              >
                {msg}
              </div>
            ))}
          </div>

          <form onSubmit={handleSendMessage} className="flex gap-2">
            <input
              type="text"
              value={chatMessage}
              onChange={(e) => setChatMessage(e.target.value)}
              placeholder="Type message to recipient..."
              className="flex-1 px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
            <button
              type="submit"
              className="p-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
