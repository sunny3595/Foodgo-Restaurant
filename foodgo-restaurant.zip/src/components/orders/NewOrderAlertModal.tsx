// ============================================================================
// FoodGo Restaurant - High-Priority New Order Modal & Action Flow
// ============================================================================

import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle,
  Clock,
  MapPin,
  Phone,
  Timer,
  Volume2,
  XCircle,
} from 'lucide-react';
import { useOrderStore } from '../../store/useOrderStore';
import { OrderRejectionReason } from '../../types';
import { formatCurrency, formatTimeOnly } from '../../utils/formatters';
import { soundManager } from '../../utils/sound';

export const NewOrderAlertModal: React.FC = () => {
  const { incomingNewOrder, setIncomingOrder, acceptOrder, rejectOrder } = useOrderStore();
  const [selectedPrepTime, setSelectedPrepTime] = useState<number>(20);
  const [isRejectModalOpen, setIsRejectModalOpen] = useState<boolean>(false);
  const [selectedRejectReason, setSelectedRejectReason] = useState<OrderRejectionReason>('RESTAURANT_BUSY');
  const [rejectNote, setRejectNote] = useState<string>('');
  const [secondsRemaining, setSecondsRemaining] = useState<number>(120);

  // Play audio alert on arrival and run countdown
  useEffect(() => {
    if (incomingNewOrder) {
      soundManager.playNewOrderAlert();
      setSecondsRemaining(120);
      const timer = setInterval(() => {
        setSecondsRemaining((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [incomingNewOrder]);

  if (!incomingNewOrder) return null;

  const handleAccept = () => {
    soundManager.playSuccessChime();
    acceptOrder(incomingNewOrder.id, selectedPrepTime);
  };

  const handleConfirmReject = () => {
    soundManager.playWarningTone();
    rejectOrder(incomingNewOrder.id, selectedRejectReason, rejectNote);
    setIsRejectModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 animate-in fade-in duration-200">
      <div className="w-full max-w-md max-h-[92vh] flex flex-col rounded-3xl bg-slate-900 border-2 border-amber-500/80 shadow-2xl shadow-amber-500/20 overflow-hidden">
        {/* Header Alert Strip */}
        <div className="bg-gradient-to-r from-amber-600 via-rose-600 to-amber-600 px-5 py-3 flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <span className="flex h-3 w-3 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75" />
              <span className="relative inline-flex rounded-full h-3 w-3 bg-white" />
            </span>
            <span className="text-xs font-black tracking-widest uppercase">
              NEW ORDER ARRIVED
            </span>
          </div>

          <div className="flex items-center gap-2 bg-black/30 backdrop-blur-sm px-2.5 py-1 rounded-full text-xs font-mono font-bold">
            <Timer className="w-3.5 h-3.5 text-amber-200 animate-spin" />
            <span>{Math.floor(secondsRemaining / 60)}:{(secondsRemaining % 60).toString().padStart(2, '0')}</span>
          </div>
        </div>

        {/* Order Content Scrollable Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {/* Order Number & Pricing Banner */}
          <div className="flex items-center justify-between bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700">
            <div>
              <span className="text-lg font-black text-white tracking-tight">
                {incomingNewOrder.orderNumber}
              </span>
              <div className="text-[11px] text-slate-400 font-medium flex items-center gap-2 mt-0.5">
                <span>{incomingNewOrder.deliveryType}</span>
                <span>•</span>
                <span>{formatTimeOnly(incomingNewOrder.createdAt)}</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-lg font-black text-emerald-400">
                {formatCurrency(incomingNewOrder.financials.customerTotal)}
              </span>
              <div className="text-[10px] text-emerald-400/90 font-bold uppercase tracking-wider">
                {incomingNewOrder.paymentStatus} ({incomingNewOrder.paymentMethod.replace('_', ' ')})
              </div>
            </div>
          </div>

          {/* Customer Summary */}
          <div className="flex items-start gap-3 bg-slate-800/50 p-3 rounded-xl border border-slate-700/60">
            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center text-white font-bold text-xs shrink-0">
              {incomingNewOrder.customer.name.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white truncate">
                  {incomingNewOrder.customer.name}
                </h4>
                <span className="text-[10px] text-slate-400 font-medium">
                  {incomingNewOrder.customer.totalPreviousOrders} previous orders
                </span>
              </div>
              <div className="flex items-center gap-1 text-[11px] text-slate-400 mt-0.5 truncate">
                <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                <span className="truncate">{incomingNewOrder.customer.deliveryAddress}</span>
              </div>
            </div>
          </div>

          {/* Items List */}
          <div>
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
              <span>Items ({incomingNewOrder.items.length})</span>
              <span>Price</span>
            </div>

            <div className="space-y-2">
              {incomingNewOrder.items.map((item) => (
                <div
                  key={item.id}
                  className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50 flex flex-col gap-1"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-2">
                      <span className="w-5 h-5 rounded bg-amber-500/20 text-amber-300 font-black text-xs flex items-center justify-center shrink-0">
                        {item.quantity}x
                      </span>
                      <div>
                        <span className="text-xs font-bold text-white leading-tight">
                          {item.name}
                        </span>
                        {item.selectedVariation && (
                          <div className="text-[10px] text-slate-400">
                            {item.selectedVariation.groupName}: {item.selectedVariation.optionName}
                          </div>
                        )}
                      </div>
                    </div>
                    <span className="text-xs font-bold text-slate-300 font-mono">
                      {formatCurrency(item.totalPrice)}
                    </span>
                  </div>

                  {item.selectedAddons && item.selectedAddons.length > 0 && (
                    <div className="pl-7 text-[10px] text-emerald-400/90 font-medium space-y-0.5">
                      {item.selectedAddons.map((addon) => (
                        <div key={addon.addonId} className="flex justify-between">
                          <span>+ {addon.name}</span>
                          <span>{formatCurrency(addon.price)}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {item.specialInstructions && (
                    <div className="pl-7 text-[10px] text-amber-300/90 font-medium italic mt-0.5">
                      Note: &ldquo;{item.specialInstructions}&rdquo;
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Prep Time Selection */}
          <div className="bg-slate-800/60 p-3.5 rounded-2xl border border-slate-700">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-white flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-orange-400" />
                Select Preparation Time
              </label>
              <span className="text-xs font-extrabold text-orange-400 font-mono">
                {selectedPrepTime} Minutes
              </span>
            </div>

            <div className="grid grid-cols-5 gap-1.5">
              {[15, 20, 25, 30, 45].map((time) => (
                <button
                  key={time}
                  type="button"
                  onClick={() => setSelectedPrepTime(time)}
                  className={`py-2 text-xs font-black rounded-xl border transition-all active:scale-95 ${
                    selectedPrepTime === time
                      ? 'bg-orange-500 border-orange-400 text-white shadow-md shadow-orange-500/30'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {time}m
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Action Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex gap-2.5">
          <button
            type="button"
            onClick={() => setIsRejectModalOpen(true)}
            className="flex-1 py-3.5 rounded-2xl bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all active:scale-95"
          >
            <XCircle className="w-4 h-4" />
            REJECT
          </button>

          <button
            type="button"
            onClick={handleAccept}
            className="flex-[2] py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30 text-xs font-black tracking-wide flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <CheckCircle className="w-4 h-4" />
            ACCEPT ORDER ({selectedPrepTime}m)
          </button>
        </div>

        {/* Rejection Sub-Modal */}
        {isRejectModalOpen && (
          <div className="absolute inset-0 z-50 bg-slate-950/95 backdrop-blur-md p-5 flex flex-col justify-between animate-in fade-in zoom-in-95">
            <div>
              <div className="flex items-center gap-2 text-rose-400 mb-2">
                <AlertTriangle className="w-5 h-5" />
                <h3 className="text-base font-bold text-white">Select Rejection Reason</h3>
              </div>
              <p className="text-xs text-slate-400 mb-4">
                The customer and support desk will receive this reason immediately.
              </p>

              <div className="space-y-2">
                {[
                  { id: 'RESTAURANT_BUSY', label: 'Kitchen at full capacity / Too busy' },
                  { id: 'ITEM_UNAVAILABLE', label: 'One or more items out of stock' },
                  { id: 'KITCHEN_CLOSED', label: 'Kitchen closing early / Maintenance' },
                  { id: 'DELIVERY_UNAVAILABLE', label: 'Delivery distance / Rider unavailable' },
                  { id: 'OTHER', label: 'Other operational issue' },
                ].map((reason) => (
                  <button
                    key={reason.id}
                    type="button"
                    onClick={() => setSelectedRejectReason(reason.id as OrderRejectionReason)}
                    className={`w-full p-3 rounded-xl border text-left text-xs font-semibold transition-all ${
                      selectedRejectReason === reason.id
                        ? 'bg-rose-950/80 border-rose-500 text-white'
                        : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    {reason.label}
                  </button>
                ))}
              </div>

              <div className="mt-3">
                <label className="text-[11px] font-bold text-slate-400 uppercase">Optional Note</label>
                <textarea
                  value={rejectNote}
                  onChange={(e) => setRejectNote(e.target.value)}
                  placeholder="Additional context for customer..."
                  className="w-full mt-1 p-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  rows={2}
                />
              </div>
            </div>

            <div className="flex gap-2 pt-3">
              <button
                type="button"
                onClick={() => setIsRejectModalOpen(false)}
                className="flex-1 py-3 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Back
              </button>
              <button
                type="button"
                onClick={handleConfirmReject}
                className="flex-1 py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black shadow-lg shadow-rose-600/30"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
