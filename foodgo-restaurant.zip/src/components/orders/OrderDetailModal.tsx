// ============================================================================
// FoodGo Restaurant - Complete Order Detail View & Actions Drawer
// Directly implements Master Prompt Section 7: Comprehensive Order Detail View
// ============================================================================

import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Bike,
  CheckCircle2,
  ChefHat,
  Clock,
  Eye,
  EyeOff,
  FileText,
  LifeBuoy,
  MapPin,
  MessageSquare,
  Navigation,
  Phone,
  Printer,
  Receipt,
  ShieldCheck,
  User,
  Utensils,
  X,
  XCircle,
} from 'lucide-react';
import { ORDER_STATUS_MAP } from '../../config/theme';
import { useAuthStore } from '../../store/useAuthStore';
import { useOrderStore } from '../../store/useOrderStore';
import { Order } from '../../types';
import {
  formatCurrency,
  formatRemainingTime,
  formatTimeOnly,
  maskPhoneNumber,
} from '../../utils/formatters';
import { CancelOrderModal } from './CancelOrderModal';
import { ContactModal } from './ContactModal';
import { HandoverVerificationModal } from './HandoverVerificationModal';
import { ReportIssueModal } from './ReportIssueModal';
import { ThermalReceiptModal } from './ThermalReceiptModal';

interface OrderDetailModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
}

export const OrderDetailModal: React.FC<OrderDetailModalProps> = ({
  order,
  isOpen,
  onClose,
}) => {
  const { startPreparing, markReady, acceptOrder, setIncomingOrder } = useOrderStore();
  const { hasPermission } = useAuthStore();

  const [isPhoneMasked, setIsPhoneMasked] = useState(true);
  const [isThermalReceiptOpen, setIsThermalReceiptOpen] = useState(false);
  const [thermalMode, setThermalMode] = useState<'KOT' | 'CUSTOMER_BILL'>('KOT');
  const [isHandoverOpen, setIsHandoverOpen] = useState(false);
  const [isCancelOpen, setIsCancelOpen] = useState(false);
  const [isReportIssueOpen, setIsReportIssueOpen] = useState(false);
  const [contactTarget, setContactTarget] = useState<'CUSTOMER' | 'DRIVER' | null>(null);

  if (!isOpen || !order) return null;

  const statusCfg = ORDER_STATUS_MAP[order.status];
  const remaining = formatRemainingTime(order.expectedReadyTime);
  const canManageFinances = hasPermission('finance.read');

  const customerPhone = isPhoneMasked
    ? maskPhoneNumber(order.customer.phone)
    : order.customer.phone;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-lg max-h-[92vh] bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl flex flex-col overflow-hidden shadow-2xl">
        {/* Top Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-black text-white font-mono">
                {order.orderNumber}
              </span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] font-black uppercase border ${statusCfg.bgColor} ${statusCfg.textColor} ${statusCfg.borderColor}`}
              >
                {statusCfg.label}
              </span>
              <span className="text-[10px] font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded uppercase">
                {order.deliveryType}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Placed at {formatTimeOnly(order.createdAt)} on{' '}
              {new Date(order.createdAt).toLocaleDateString()}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Active Prep Timer Banner (if Cooking) */}
          {order.status === 'PREPARING' && (
            <div className="p-3.5 rounded-2xl bg-orange-950/40 border border-orange-500/40 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <ChefHat className="w-4 h-4 text-orange-400 animate-bounce" />
                <div>
                  <span className="font-bold text-white block">Kitchen Prep Timer</span>
                  <span className="text-[10px] text-slate-400">
                    Target: {order.confirmedPrepTimeMinutes || 25} minutes total
                  </span>
                </div>
              </div>
              <span
                className={`font-mono font-black text-sm ${
                  remaining.isOverdue ? 'text-rose-400' : 'text-orange-300'
                }`}
              >
                {remaining.text}
              </span>
            </div>
          )}

          {/* Customer Information Card */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <User className="w-3.5 h-3.5 text-rose-400" />
                <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px]">
                  Customer Details
                </span>
              </div>
              <button
                type="button"
                onClick={() => setContactTarget('CUSTOMER')}
                className="text-[10px] font-bold text-rose-400 hover:text-rose-300 flex items-center gap-1"
              >
                <Phone className="w-3 h-3" />
                <span>Contact</span>
              </button>
            </div>

            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-sm">{order.customer.name}</span>
              <div className="flex items-center gap-1.5 font-mono text-[11px] text-slate-300">
                <span>{customerPhone}</span>
                <button
                  type="button"
                  onClick={() => setIsPhoneMasked(!isPhoneMasked)}
                  className="text-slate-400 hover:text-white"
                >
                  {isPhoneMasked ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                </button>
              </div>
            </div>

            <div className="flex items-start gap-1.5 text-slate-400 text-[11px] pt-1">
              <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
              <span>{order.customer.deliveryAddress}</span>
            </div>
          </div>

          {/* Driver Information Card (if assigned or ready for pickup) */}
          {order.rider && (
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <div className="flex items-center gap-2">
                  <Bike className="w-3.5 h-3.5 text-purple-400" />
                  <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px]">
                    Delivery Driver Partner
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setContactTarget('DRIVER')}
                  className="text-[10px] font-bold text-purple-400 hover:text-purple-300 flex items-center gap-1"
                >
                  <Phone className="w-3 h-3" />
                  <span>Call Rider</span>
                </button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">{order.rider.name}</div>
                  <div className="text-[10px] text-slate-400">
                    Vehicle: {order.rider.vehicleNumber} · TVS Apache
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] font-mono text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-500/30">
                    ETA 3 mins (En route)
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Ordered Food Items List */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
              <div className="flex items-center gap-2">
                <Utensils className="w-3.5 h-3.5 text-orange-400" />
                <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px]">
                  Dishes &amp; Cooking Instructions
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                {order.items.reduce((s, i) => s + i.quantity, 0)} Items Total
              </span>
            </div>

            <div className="space-y-2 pt-1">
              {order.items.map((item) => (
                <div
                  key={item.id}
                  className="p-2.5 rounded-xl bg-slate-900 border border-slate-800/80 space-y-1"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-black text-white text-xs">
                        {item.quantity}x {item.name}
                      </span>
                    </div>
                    <span className="font-mono font-bold text-white text-xs">
                      {formatCurrency(item.totalPrice)}
                    </span>
                  </div>

                  {item.selectedAddons && item.selectedAddons.length > 0 && (
                    <div className="text-[10px] text-slate-400 pl-2">
                      {item.selectedAddons.map((ad) => (
                        <div key={ad.addonId}>
                          + {ad.name} ({formatCurrency(ad.price)})
                        </div>
                      ))}
                    </div>
                  )}

                  {item.specialInstructions && (
                    <div className="text-[10px] font-bold text-rose-300 bg-rose-950/40 border border-rose-500/30 p-1.5 rounded-lg mt-1">
                      Chef Note: {item.specialInstructions}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Payment & Financial Breakdown Summary */}
          {canManageFinances && (
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px]">
                  Payment &amp; Settlement Summary
                </span>
                <span className="text-[10px] font-bold text-emerald-400 font-mono uppercase">
                  {order.paymentStatus} ({order.paymentMethod})
                </span>
              </div>

              <div className="space-y-1 text-slate-400 text-[11px]">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono text-slate-300">
                    {formatCurrency(order.financials.subtotal)}
                  </span>
                </div>
                {order.financials.discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount Voucher</span>
                    <span className="font-mono">
                      -{formatCurrency(order.financials.discountAmount)}
                    </span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Tax (5% GST)</span>
                  <span className="font-mono text-slate-300">
                    {formatCurrency(order.financials.taxAmount)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Platform Commission (15%)</span>
                  <span className="font-mono text-rose-400">
                    -{formatCurrency(order.financials.platformCommission)}
                  </span>
                </div>
                <div className="flex justify-between pt-1.5 border-t border-slate-800 font-bold text-white text-xs">
                  <span>Restaurant Net Settlement</span>
                  <span className="font-mono text-emerald-400">
                    {formatCurrency(order.financials.restaurantNetEarnings)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Status Timeline History */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
            <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px] block border-b border-slate-800/80 pb-2">
              Order Timeline Events
            </span>
            <div className="space-y-2 pt-1">
              {order.timeline.map((ev, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs">
                  <div className="w-2 h-2 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <span className="font-bold text-white">{ev.title}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {formatTimeOnly(ev.timestamp)}
                      </span>
                    </div>
                    {ev.description && (
                      <p className="text-[10px] text-slate-400">{ev.description}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Quick Action Toolbar */}
        <div className="p-3.5 bg-slate-950 border-t border-slate-800 space-y-2">
          {/* Secondary Actions Row: Print KOT, Print Bill, Report Issue, Cancel */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                setThermalMode('KOT');
                setIsThermalReceiptOpen(true);
              }}
              className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-bold flex items-center justify-center gap-1 transition-all"
            >
              <Printer className="w-3.5 h-3.5 text-orange-400" />
              <span>Print KOT</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setThermalMode('CUSTOMER_BILL');
                setIsThermalReceiptOpen(true);
              }}
              className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-bold flex items-center justify-center gap-1 transition-all"
            >
              <Receipt className="w-3.5 h-3.5 text-rose-400" />
              <span>Print Bill</span>
            </button>

            <button
              type="button"
              onClick={() => setIsReportIssueOpen(true)}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-white transition-all"
              title="Report Incident / Support"
            >
              <LifeBuoy className="w-4 h-4" />
            </button>

            {order.status !== 'CANCELLED' && order.status !== 'DELIVERED' && (
              <button
                type="button"
                onClick={() => setIsCancelOpen(true)}
                className="p-2 rounded-xl bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-300 hover:text-rose-200 transition-all"
                title="Cancel Order"
              >
                <XCircle className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Primary State Machine Flow Action Button */}
          {order.status === 'NEW' && (
            <button
              type="button"
              onClick={() => {
                onClose();
                setIncomingOrder(order);
              }}
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition-all shadow-md shadow-amber-500/20 active:scale-95"
            >
              Review &amp; Accept Order
            </button>
          )}

          {order.status === 'ACCEPTED' && (
            <button
              type="button"
              onClick={() => startPreparing(order.id)}
              className="w-full py-2.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md shadow-orange-600/20"
            >
              <ChefHat className="w-4 h-4" />
              <span>Start Cooking (Kitchen Timer)</span>
            </button>
          )}

          {order.status === 'PREPARING' && (
            <button
              type="button"
              onClick={() => markReady(order.id)}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md shadow-emerald-600/20"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Mark Packed &amp; Ready for Pickup</span>
            </button>
          )}

          {order.status === 'READY_FOR_PICKUP' && (
            <button
              type="button"
              onClick={() => setIsHandoverOpen(true)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-purple-600/25"
            >
              <Bike className="w-4 h-4" />
              <span>Verify Rider Handover (PIN / QR)</span>
            </button>
          )}
        </div>
      </div>

      {/* Sub-modals */}
      <ThermalReceiptModal
        order={order}
        isOpen={isThermalReceiptOpen}
        onClose={() => setIsThermalReceiptOpen(false)}
        defaultMode={thermalMode}
      />
      <HandoverVerificationModal
        order={order}
        isOpen={isHandoverOpen}
        onClose={() => setIsHandoverOpen(false)}
      />
      <CancelOrderModal
        order={order}
        isOpen={isCancelOpen}
        onClose={() => setIsCancelOpen(false)}
      />
      <ReportIssueModal
        order={order}
        isOpen={isReportIssueOpen}
        onClose={() => setIsReportIssueOpen(false)}
      />
      {contactTarget && (
        <ContactModal
          order={order}
          target={contactTarget}
          isOpen={true}
          onClose={() => setContactTarget(null)}
        />
      )}
    </div>
  );
};
