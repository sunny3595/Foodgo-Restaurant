// ============================================================================
// FoodGo Restaurant - Order Management Screen (Phase 5)
// Directly implements Master Prompt Section 7:
// Filters: All, Pending, Preparing, Ready, Delivered, Cancelled, Scheduled
// Search: Order ID, Customer Name, Phone number
// Actions: Accept, Start Prep, Mark Ready, Verify Handover (PIN/QR), Print Slip
// ============================================================================

import React, { useState } from 'react';
import {
  Bike,
  Calendar,
  CheckCircle2,
  ChefHat,
  ChevronRight,
  Clock,
  Eye,
  FileText,
  MapPin,
  Phone,
  Printer,
  Search,
  ShieldCheck,
  User,
  X,
  XCircle,
} from 'lucide-react';
import { ORDER_STATUS_MAP } from '../../config/theme';
import { useAuthStore } from '../../store/useAuthStore';
import { useOrderStore } from '../../store/useOrderStore';
import { Order, OrderStatus } from '../../types';
import {
  formatCurrency,
  formatRemainingTime,
  formatTimeOnly,
  maskPhoneNumber,
} from '../../utils/formatters';
import { HandoverVerificationModal } from './HandoverVerificationModal';
import { OrderDetailModal } from './OrderDetailModal';
import { ThermalReceiptModal } from './ThermalReceiptModal';

type FilterTabId = OrderStatus | 'ALL' | 'SCHEDULED';

export const OrderListScreen: React.FC = () => {
  const {
    orders,
    activeTab,
    setActiveTab,
    selectedOrderId,
    selectOrder,
    startPreparing,
    markReady,
    setIncomingOrder,
  } = useOrderStore();

  const [activeFilterTab, setActiveFilterTab] = useState<FilterTabId>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [printingOrder, setPrintingOrder] = useState<Order | null>(null);
  const [handoverOrder, setHandoverOrder] = useState<Order | null>(null);

  const tabs: { id: FilterTabId; label: string; count?: number }[] = [
    { id: 'ALL', label: 'All Orders', count: orders.length },
    { id: 'NEW', label: 'Pending', count: orders.filter((o) => o.status === 'NEW' && !o.isScheduled).length },
    { id: 'PREPARING', label: 'Preparing', count: orders.filter((o) => o.status === 'PREPARING' || o.status === 'ACCEPTED').length },
    { id: 'READY_FOR_PICKUP', label: 'Ready', count: orders.filter((o) => o.status === 'READY_FOR_PICKUP').length },
    { id: 'PICKED_UP', label: 'Out with Rider', count: orders.filter((o) => o.status === 'PICKED_UP' || o.status === 'RIDER_ASSIGNED').length },
    { id: 'DELIVERED', label: 'Delivered', count: orders.filter((o) => o.status === 'DELIVERED').length },
    { id: 'CANCELLED', label: 'Cancelled', count: orders.filter((o) => o.status === 'CANCELLED').length },
    { id: 'SCHEDULED', label: 'Scheduled', count: orders.filter((o) => o.isScheduled).length },
  ];

  const filteredOrders = orders.filter((order) => {
    // Tab Filter
    let matchesTab = true;
    if (activeFilterTab === 'ALL') {
      matchesTab = true;
    } else if (activeFilterTab === 'SCHEDULED') {
      matchesTab = !!order.isScheduled;
    } else if (activeFilterTab === 'NEW') {
      matchesTab = order.status === 'NEW' && !order.isScheduled;
    } else if (activeFilterTab === 'PREPARING') {
      matchesTab = order.status === 'PREPARING' || order.status === 'ACCEPTED';
    } else if (activeFilterTab === 'PICKED_UP') {
      matchesTab = order.status === 'PICKED_UP' || order.status === 'RIDER_ASSIGNED';
    } else {
      matchesTab = order.status === activeFilterTab;
    }

    // Search Filter: Order ID, Customer name, Phone number
    const query = searchQuery.trim().toLowerCase();
    const matchesSearch =
      !query ||
      order.orderNumber.toLowerCase().includes(query) ||
      order.customer.name.toLowerCase().includes(query) ||
      order.customer.phone.toLowerCase().includes(query) ||
      order.items.some((i) => i.name.toLowerCase().includes(query));

    return matchesTab && matchesSearch;
  });

  const selectedOrder = orders.find((o) => o.id === selectedOrderId) || null;

  return (
    <div className="p-4 pb-24 space-y-3.5">
      {/* Search Input Bar (Order ID, Customer name, Phone) */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by order #, customer, or phone number..."
          className="w-full pl-10 pr-9 py-2.5 rounded-2xl bg-slate-800/90 border border-slate-700 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-rose-500 shadow-inner"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3.5 top-3 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Section 7 Segmented Filter Tabs Strip */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {tabs.map((tab) => {
          const isActive = activeFilterTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveFilterTab(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 active:scale-95 ${
                isActive
                  ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-750 hover:text-slate-200'
              }`}
            >
              {tab.id === 'SCHEDULED' && <Calendar className="w-3 h-3 text-amber-300" />}
              <span>{tab.label}</span>
              {tab.count !== undefined && tab.count > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                    isActive ? 'bg-white text-rose-600' : 'bg-slate-700 text-slate-300'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Orders List Container */}
      {filteredOrders.length === 0 ? (
        <div className="py-16 text-center text-slate-500 flex flex-col items-center justify-center">
          <Clock className="w-10 h-10 mb-2 stroke-1 opacity-60 text-slate-600" />
          <p className="text-sm font-bold text-slate-400">No orders in this category</p>
          <p className="text-xs text-slate-500 mt-0.5">
            Incoming delivery orders will appear here in real-time.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredOrders.map((order) => {
            const statusConfig = ORDER_STATUS_MAP[order.status];
            const remaining = formatRemainingTime(order.expectedReadyTime);

            return (
              <div
                key={order.id}
                className="p-3.5 rounded-3xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all space-y-2.5 shadow-lg group"
              >
                {/* Order Top Card Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-white font-mono tracking-tight">
                        {order.orderNumber}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {formatTimeOnly(order.createdAt)}
                      </span>
                      {order.isScheduled && (
                        <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] font-black uppercase flex items-center gap-1">
                          <Calendar className="w-2.5 h-2.5" />
                          <span>Scheduled</span>
                        </span>
                      )}
                    </div>
                    <div className="text-xs font-bold text-slate-200 mt-0.5">
                      {order.customer.name}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {maskPhoneNumber(order.customer.phone)}
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded-md text-[10px] font-extrabold uppercase border ${statusConfig.bgColor} ${statusConfig.textColor} ${statusConfig.borderColor}`}
                    >
                      {statusConfig.shortLabel}
                    </span>

                    {order.status === 'PREPARING' && (
                      <div
                        className={`text-[10px] font-mono font-bold mt-1 ${
                          remaining.isOverdue ? 'text-rose-400' : 'text-orange-400'
                        }`}
                      >
                        {remaining.text}
                      </div>
                    )}

                    {order.status === 'READY_FOR_PICKUP' && (
                      <div className="text-[10px] font-mono font-bold text-purple-400 mt-1 flex items-center justify-end gap-1">
                        <KeyRound className="w-3 h-3" />
                        <span>PIN: 8492</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Items Summary Pill */}
                <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-1 text-xs">
                  {order.items.map((item) => (
                    <div key={item.id} className="flex justify-between items-center text-[11px]">
                      <span className="text-slate-300">
                        <strong className="text-white font-bold">{item.quantity}x</strong>{' '}
                        {item.name}
                      </span>
                      <span className="text-slate-400 font-mono font-medium">
                        {formatCurrency(item.totalPrice)}
                      </span>
                    </div>
                  ))}
                  {order.specialInstructions && (
                    <div className="text-[10px] text-amber-300/90 font-medium italic pt-0.5">
                      Note: &ldquo;{order.specialInstructions}&rdquo;
                    </div>
                  )}
                </div>

                {/* Card Action Row */}
                <div className="flex items-center justify-between gap-2 pt-1">
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setPrintingOrder(order)}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition-all flex items-center gap-1"
                      title="Print Slip / KOT"
                    >
                      <Printer className="w-3.5 h-3.5 text-orange-400" />
                      <span className="text-[10px]">Print</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => selectOrder(order.id)}
                      className="py-1.5 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold transition-all flex items-center gap-1"
                    >
                      <span>Details</span>
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Primary Direct Action */}
                  <div className="flex items-center gap-1.5">
                    {order.status === 'NEW' && (
                      <button
                        type="button"
                        onClick={() => setIncomingOrder(order)}
                        className="py-1.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition-all active:scale-95 shadow-md shadow-amber-500/20"
                      >
                        Accept
                      </button>
                    )}

                    {order.status === 'ACCEPTED' && (
                      <button
                        type="button"
                        onClick={() => startPreparing(order.id)}
                        className="py-1.5 px-3 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs flex items-center gap-1 transition-all active:scale-95 shadow-md shadow-orange-600/20"
                      >
                        <ChefHat className="w-3.5 h-3.5" />
                        <span>Start Prep</span>
                      </button>
                    )}

                    {order.status === 'PREPARING' && (
                      <button
                        type="button"
                        onClick={() => markReady(order.id)}
                        className="py-1.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 transition-all active:scale-95 shadow-md shadow-emerald-600/20"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Ready</span>
                      </button>
                    )}

                    {order.status === 'READY_FOR_PICKUP' && (
                      <button
                        type="button"
                        onClick={() => setHandoverOrder(order)}
                        className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs flex items-center gap-1 transition-all active:scale-95 shadow-md shadow-purple-600/25"
                      >
                        <Bike className="w-3.5 h-3.5" />
                        <span>Verify PIN</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Comprehensive Order Detail Modal */}
      <OrderDetailModal
        order={selectedOrder}
        isOpen={!!selectedOrder}
        onClose={() => selectOrder(null)}
      />

      {/* Thermal Receipt Print Modal */}
      <ThermalReceiptModal
        order={printingOrder}
        isOpen={!!printingOrder}
        onClose={() => setPrintingOrder(null)}
        defaultMode="KOT"
      />

      {/* Handover Verification Modal */}
      <HandoverVerificationModal
        order={handoverOrder}
        isOpen={!!handoverOrder}
        onClose={() => setHandoverOrder(null)}
      />
    </div>
  );
};

function KeyRound(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2 18v3c0 .6.4 1 1 1h4v-3h3v-3h2l1.4-1.4a6.5 6.5 0 1 0-4-4Z" />
      <circle cx="16.5" cy="7.5" r=".5" fill="currentColor" />
    </svg>
  );
}
