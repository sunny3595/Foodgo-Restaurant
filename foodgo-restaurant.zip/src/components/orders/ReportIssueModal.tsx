// ============================================================================
// FoodGo Restaurant - Report Incident & Support Ticket Modal
// Directly implements Master Prompt Section 7: Report issue
// ============================================================================

import React, { useState } from 'react';
import { AlertCircle, CheckCircle2, LifeBuoy, Send, X } from 'lucide-react';
import { Order } from '../../types';

interface ReportIssueModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
}

const ISSUE_CATEGORIES = [
  'Rider Delayed / Did Not Arrive',
  'Customer Address Unreachable / Out of Range',
  'Packaging Spill / Food Quality Concern',
  'Customer Requested Last-Minute Address Change',
  'Payment or Payout Discrepancy',
  'Other Operational Issue',
];

export const ReportIssueModal: React.FC<ReportIssueModalProps> = ({
  order,
  isOpen,
  onClose,
}) => {
  const [selectedIssue, setSelectedIssue] = useState<string>(ISSUE_CATEGORIES[0]);
  const [details, setDetails] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  if (!isOpen || !order) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center">
              <LifeBuoy className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Report Issue with Order</h3>
              <p className="text-[11px] text-slate-400">{order.orderNumber}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="p-6 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-center space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <h4 className="text-sm font-bold text-white">Ticket Submitted to FoodGo Priority Ops</h4>
            <p className="text-xs text-slate-400">
              An operations supervisor is reviewing this incident and will contact you.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                Issue Category
              </label>
              <select
                value={selectedIssue}
                onChange={(e) => setSelectedIssue(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white"
              >
                {ISSUE_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                Explain Details
              </label>
              <textarea
                required
                rows={3}
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Describe what occurred with driver or customer..."
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white text-xs font-black shadow-lg shadow-orange-600/30 transition-all"
              >
                Send Incident Report
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
