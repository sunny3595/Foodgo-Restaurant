// ============================================================================
// FoodGo Restaurant - Thermal 80mm Printable Receipt & Kitchen Ticket (KOT)
// Directly implements Master Prompt Section 7 & 78: Thermal Receipt Simulation
// ============================================================================

import React, { useState } from 'react';
import { ChefHat, FileText, Printer, Receipt, Sparkles, X } from 'lucide-react';
import { Order } from '../../types';
import { formatCurrency, formatTimeOnly } from '../../utils/formatters';

interface ThermalReceiptModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'KOT' | 'CUSTOMER_BILL';
}

export const ThermalReceiptModal: React.FC<ThermalReceiptModalProps> = ({
  order,
  isOpen,
  onClose,
  defaultMode = 'KOT',
}) => {
  const [ticketMode, setTicketMode] = useState<'KOT' | 'CUSTOMER_BILL'>(defaultMode);
  const [isPrinting, setIsPrinting] = useState(false);

  if (!isOpen || !order) return null;

  const handleSimulatePrint = () => {
    setIsPrinting(true);
    setTimeout(() => {
      setIsPrinting(false);
    }, 1200);
  };

  const isKOT = ticketMode === 'KOT';

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-sm max-h-[92vh] bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl flex flex-col overflow-hidden shadow-2xl">
        {/* Modal Top Bar */}
        <div className="p-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-950">
          <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setTicketMode('KOT')}
              className={`px-3 py-1 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 ${
                isKOT
                  ? 'bg-orange-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <ChefHat className="w-3.5 h-3.5" />
              <span>Kitchen (KOT)</span>
            </button>
            <button
              onClick={() => setTicketMode('CUSTOMER_BILL')}
              className={`px-3 py-1 rounded-lg text-xs font-black transition-all flex items-center gap-1.5 ${
                !isKOT
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Customer Bill</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Thermal Paper Slip Preview */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-950 flex justify-center">
          <div className="w-full max-w-[290px] bg-[#fffdfa] text-slate-900 font-mono text-[11px] p-4 shadow-2xl rounded-sm border-t-4 border-slate-800 space-y-3 leading-tight select-text">
            {/* Header */}
            <div className="text-center space-y-1 border-b border-dashed border-slate-400 pb-2.5">
              <div className="text-xs font-black tracking-widest uppercase">
                {isKOT ? '*** KITCHEN ORDER TICKET ***' : 'FOODGO RESTAURANT'}
              </div>
              {!isKOT && (
                <>
                  <div className="font-bold text-[10px]">Royal Hyderabad Dum Biryani</div>
                  <div className="text-[9px] text-slate-600">Madhapur, Silicon Valley, Hyd - 500081</div>
                  <div className="text-[9px] text-slate-600">GSTIN: 36AAAAA0000A1Z5 | FSSAI: 13622001000124</div>
                </>
              )}
            </div>

            {/* Order Meta */}
            <div className="space-y-0.5 border-b border-dashed border-slate-400 pb-2 text-[10px]">
              <div className="flex justify-between font-bold">
                <span>ORDER: {order.orderNumber}</span>
                <span className="uppercase">{order.deliveryType}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Time: {formatTimeOnly(order.createdAt)}</span>
                <span>Date: {new Date(order.createdAt).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Customer: <strong>{order.customer.name}</strong></span>
                <span>PIN: <strong>8492</strong></span>
              </div>
            </div>

            {/* Line Items */}
            <div className="space-y-1.5 border-b border-dashed border-slate-400 pb-2">
              <div className="flex justify-between font-bold text-[10px] uppercase border-b border-slate-300 pb-1">
                <span>Qty Item</span>
                {!isKOT && <span>Amount</span>}
              </div>

              {order.items.map((item) => (
                <div key={item.id} className="space-y-0.5">
                  <div className="flex justify-between font-bold text-[11px]">
                    <span>
                      {item.quantity}x {item.name}
                    </span>
                    {!isKOT && <span>{formatCurrency(item.totalPrice)}</span>}
                  </div>

                  {item.selectedAddons && item.selectedAddons.length > 0 && (
                    <div className="text-[9px] text-slate-600 pl-3">
                      {item.selectedAddons.map((addon) => (
                        <div key={addon.addonId}>+ {addon.name}</div>
                      ))}
                    </div>
                  )}

                  {item.specialInstructions && (
                    <div className="text-[9px] font-bold text-rose-700 bg-rose-50 p-1 rounded mt-0.5">
                      NOTE: {item.specialInstructions}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Bill Financials (Only shown on Customer Bill) */}
            {!isKOT && (
              <div className="space-y-1 text-[10px] border-b border-dashed border-slate-400 pb-2">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>{formatCurrency(order.financials.subtotal)}</span>
                </div>
                {order.financials.discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-bold">
                    <span>Discount Coupon:</span>
                    <span>-{formatCurrency(order.financials.discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Taxes (GST 5%):</span>
                  <span>{formatCurrency(order.financials.taxAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery Charge:</span>
                  <span>{formatCurrency(order.financials.deliveryFee)}</span>
                </div>
                <div className="flex justify-between font-black text-xs pt-1 border-t border-slate-300">
                  <span>TOTAL PAID:</span>
                  <span>{formatCurrency(order.financials.customerTotal)}</span>
                </div>
                <div className="text-[9px] text-slate-600 pt-0.5">
                  Method: {order.paymentMethod} ({order.paymentStatus})
                </div>
              </div>
            )}

            {/* Barcode & Footer Tear-off */}
            <div className="text-center pt-1 space-y-1">
              <div className="font-mono text-[9px] tracking-[4px] text-slate-600">
                ||||| | |||| |||||| || |
              </div>
              <div className="text-[8px] text-slate-500 uppercase">
                {isKOT ? 'KITCHEN COPY - KEEP WITH TRAY' : 'THANK YOU FOR ORDERING WITH FOODGO!'}
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Print Button */}
        <div className="p-3.5 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-bold transition-all"
          >
            Close
          </button>
          <button
            type="button"
            onClick={handleSimulatePrint}
            disabled={isPrinting}
            className="flex-1 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow-lg shadow-rose-500/25 transition-all"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{isPrinting ? 'Printing to 80mm POS...' : 'Print Thermal Ticket'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
