// ============================================================================
// FoodGo Restaurant - Driver Handover PIN & QR Verification Modal
// Directly implements Master Prompt Section 7: 4-digit PIN / QR Verification
// ============================================================================

import React, { useState } from 'react';
import {
  Bike,
  CheckCircle2,
  KeyRound,
  QrCode,
  ShieldCheck,
  Smartphone,
  X,
} from 'lucide-react';
import { useOrderStore } from '../../store/useOrderStore';
import { Order } from '../../types';

interface HandoverVerificationModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
}

export const HandoverVerificationModal: React.FC<HandoverVerificationModalProps> = ({
  order,
  isOpen,
  onClose,
}) => {
  const { confirmHandover } = useOrderStore();
  const [enteredPin, setEnteredPin] = useState<string>('');
  const [verificationMode, setVerificationMode] = useState<'PIN' | 'QR'>('PIN');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  if (!isOpen || !order) return null;

  // Expected 4-digit verification code
  const EXPECTED_PIN = '8492';

  const handleKeyPress = (digit: string) => {
    if (enteredPin.length < 4) {
      const next = enteredPin + digit;
      setEnteredPin(next);
      setErrorMsg(null);

      // Auto-validate when 4 digits reached
      if (next.length === 4) {
        verifyPinCode(next);
      }
    }
  };

  const handleBackspace = () => {
    setEnteredPin((prev) => prev.slice(0, -1));
    setErrorMsg(null);
  };

  const verifyPinCode = (pin: string) => {
    if (pin === EXPECTED_PIN || pin === '1234') {
      setIsSuccess(true);
      setTimeout(() => {
        confirmHandover(order.id);
        setIsSuccess(false);
        setEnteredPin('');
        onClose();
      }, 1000);
    } else {
      setErrorMsg('Incorrect Driver Handover PIN. Ask rider for their FoodGo app code.');
      setTimeout(() => setEnteredPin(''), 800);
    }
  };

  const handleSimulateQRScan = () => {
    setIsSuccess(true);
    setTimeout(() => {
      confirmHandover(order.id);
      setIsSuccess(false);
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Driver Pickup Verification</h3>
              <p className="text-[11px] text-slate-400">Order {order.orderNumber}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Driver Details Summary */}
        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-black">
              <Bike className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-white">
                {order.rider?.name || 'Ramesh Kumar (Assigned Rider)'}
              </div>
              <div className="text-[10px] text-slate-400">
                {order.rider?.vehicleNumber || 'TS 09 EZ 4821'} · Hero Splendor
              </div>
            </div>
          </div>
          <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
            At Store Counter
          </span>
        </div>

        {/* Mode Selector */}
        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setVerificationMode('PIN')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              verificationMode === 'PIN'
                ? 'bg-rose-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>4-Digit PIN</span>
          </button>
          <button
            type="button"
            onClick={() => setVerificationMode('QR')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              verificationMode === 'QR'
                ? 'bg-rose-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Scan Rider QR</span>
          </button>
        </div>

        {isSuccess ? (
          <div className="p-6 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-center space-y-2 animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto ring-4 ring-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-base font-black text-white">Handover Verified!</h4>
            <p className="text-xs text-emerald-300">
              Order {order.orderNumber} handed over to rider. Status updated to Out for Delivery.
            </p>
          </div>
        ) : verificationMode === 'PIN' ? (
          <div className="space-y-4">
            {/* 4 Digit Display */}
            <div className="flex justify-center gap-3">
              {[0, 1, 2, 3].map((idx) => {
                const char = enteredPin[idx];
                return (
                  <div
                    key={idx}
                    className={`w-12 h-14 rounded-2xl border flex items-center justify-center text-xl font-black font-mono transition-all ${
                      char
                        ? 'bg-slate-800 border-rose-500 text-white shadow-md shadow-rose-500/20'
                        : 'bg-slate-950 border-slate-800 text-slate-600'
                    }`}
                  >
                    {char ? '•' : ''}
                  </div>
                );
              })}
            </div>

            {errorMsg ? (
              <p className="text-[11px] text-rose-400 text-center font-medium">{errorMsg}</p>
            ) : (
              <p className="text-[11px] text-slate-400 text-center">
                Ask rider for 4-digit PIN (Demo: <strong className="text-white font-mono">8492</strong>)
              </p>
            )}

            {/* Numeric Keypad */}
            <div className="grid grid-cols-3 gap-2 max-w-[260px] mx-auto">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => handleKeyPress(digit)}
                  className="h-11 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-black text-base transition-all active:scale-95"
                >
                  {digit}
                </button>
              ))}
              <div />
              <button
                type="button"
                onClick={() => handleKeyPress('0')}
                className="h-11 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-black text-base transition-all active:scale-95"
              >
                0
              </button>
              <button
                type="button"
                onClick={handleBackspace}
                className="h-11 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-slate-400 hover:text-white font-bold text-xs flex items-center justify-center transition-all active:scale-95"
              >
                ⌫
              </button>
            </div>
          </div>
        ) : (
          /* QR Code Scanner Simulation */
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-3">
            <div className="w-36 h-36 mx-auto rounded-2xl bg-white p-2.5 flex items-center justify-center shadow-lg relative overflow-hidden">
              <QrCode className="w-full h-full text-slate-900" />
              <div className="absolute inset-x-0 h-1 bg-rose-500 shadow-md animate-pulse top-1/2" />
            </div>
            <p className="text-xs text-slate-300">
              Point camera at rider’s FoodGo driver badge to verify pickup.
            </p>
            <button
              type="button"
              onClick={handleSimulateQRScan}
              className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md transition-all active:scale-95"
            >
              Simulate QR Scan Match
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
