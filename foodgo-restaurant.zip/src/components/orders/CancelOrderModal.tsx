// ============================================================================
// FoodGo Restaurant - Order Cancellation, Lost Revenue & Refund Modal
// Directly implements Master Prompt Section 7: Cancellation reason, Refund, Lost revenue
// ============================================================================

import React, { useState } from 'react';
import { AlertCircle, AlertTriangle, DollarSign, X } from 'lucide-react';
import { useOrderStore } from '../../store/useOrderStore';
import { Order } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface CancelOrderModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
}

const CANCELLATION_REASONS = [
  'Item(s) Out of Stock (86)',
  'Kitchen Overload / Rush Hour Delay',
  'Customer Requested Cancellation',
  'Delivery Address Outside Operating Radius',
  'Safety / Emergency Power Interruption',
  'Customer Contact Unreachable',
];

export const CancelOrderModal: React.FC<CancelOrderModalProps> = ({
  order,
  isOpen,
  onClose,
}) => {
  const { cancelOrder } = useOrderStore();
  const [selectedReason, setSelectedReason] = useState<string>(CANCELLATION_REASONS[0]);
  const [customNote, setCustomNote] = useState<string>('');
  const [refundStatus, setRefundStatus] = useState<'FULL_REFUND' | 'NO_REFUND'>('FULL_REFUND');
  const [isConfirmed, setIsConfirmed] = useState<boolean>(false);

  if (!isOpen || !order) return null;

  const lostRevenue = order.financials.restaurantNetEarnings;

  const handleExecuteCancel = () => {
    const finalReason = customNote.trim()
      ? `${selectedReason}: ${customNote.trim()}`
      : selectedReason;

    cancelOrder(order.id, finalReason);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-md bg-slate-900 border border-rose-500/40 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Cancel Order {order.orderNumber}</h3>
              <p className="text-[11px] text-slate-400">Specify reason and initiate refund</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Lost Revenue Impact Metric Box */}
        <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/30 flex items-center justify-between text-xs">
          <div className="space-y-0.5">
            <span className="text-[10px] uppercase font-bold text-rose-300 tracking-wider">
              Lost Merchant Revenue Impact
            </span>
            <div className="text-lg font-black text-rose-400 font-mono">
              -{formatCurrency(lostRevenue)}
            </div>
          </div>
          <div className="text-right text-[10px] text-slate-400">
            <div>Customer Total: {formatCurrency(order.financials.customerTotal)}</div>
            <div className="text-emerald-400 font-semibold">100% Refundable to Customer</div>
          </div>
        </div>

        {/* Reason Selector */}
        <div className="space-y-3 text-xs">
          <div>
            <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
              Select Cancellation Reason
            </label>
            <select
              value={selectedReason}
              onChange={(e) => setSelectedReason(e.target.value)}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-rose-500"
            >
              {CANCELLATION_REASONS.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
              Additional Notes for Customer &amp; Dispatch
            </label>
            <textarea
              rows={2}
              value={customNote}
              onChange={(e) => setCustomNote(e.target.value)}
              placeholder="e.g. Mutton Handi freshly sold out, customer notified by phone."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
              Customer Payment &amp; Refund Status
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setRefundStatus('FULL_REFUND')}
                className={`p-2.5 rounded-xl border text-left text-xs font-bold transition-all ${
                  refundStatus === 'FULL_REFUND'
                    ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                <div>Instant Full Refund</div>
                <span className="text-[10px] text-slate-400 font-normal">Auto-credited via UPI</span>
              </button>

              <button
                type="button"
                onClick={() => setRefundStatus('NO_REFUND')}
                className={`p-2.5 rounded-xl border text-left text-xs font-bold transition-all ${
                  refundStatus === 'NO_REFUND'
                    ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                <div>Food Prepared (Claim)</div>
                <span className="text-[10px] text-slate-400 font-normal">Customer no-show</span>
              </button>
            </div>
          </div>
        </div>

        {/* Confirmation Buttons */}
        <div className="flex gap-2 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
          >
            Go Back
          </button>
          <button
            type="button"
            onClick={handleExecuteCancel}
            className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black shadow-lg shadow-rose-600/30 transition-all active:scale-95"
          >
            Confirm Cancellation
          </button>
        </div>
      </div>
    </div>
  );
};
