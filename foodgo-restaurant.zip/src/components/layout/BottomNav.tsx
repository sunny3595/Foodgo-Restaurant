// ============================================================================
// FoodGo Restaurant - Mobile Bottom Navigation Bar
// ============================================================================

import React from 'react';
import { ChefHat, Home, MoreHorizontal, ShoppingBag, UtensilsCrossed } from 'lucide-react';
import { useOrderStore } from '../../store/useOrderStore';
import { NavTab, useUIStore } from '../../store/useUIStore';

export const BottomNav: React.FC = () => {
  const { activeNavTab, setActiveNavTab, isKitchenMode } = useUIStore();
  const { orders } = useOrderStore();

  const activeOrdersCount = orders.filter(
    (o) => o.status === 'NEW' || o.status === 'ACCEPTED' || o.status === 'PREPARING'
  ).length;

  const preparingCount = orders.filter((o) => o.status === 'PREPARING').length;

  const navItems: { id: NavTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'orders', label: 'Orders', icon: ShoppingBag, badge: activeOrdersCount },
    { id: 'kitchen', label: 'Kitchen', icon: ChefHat, badge: preparingCount },
    { id: 'menu', label: 'Menu', icon: UtensilsCrossed },
    { id: 'more', label: 'More', icon: MoreHorizontal },
  ];

  return (
    <nav className="sticky bottom-0 z-40 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 px-2 py-1.5 pb-safe shadow-lg">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeNavTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveNavTab(item.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all duration-200 active:scale-90 ${
                isActive
                  ? 'text-rose-500 font-bold'
                  : 'text-slate-400 hover:text-slate-200 font-medium'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1 -right-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-black text-white px-1 shadow-md shadow-rose-500/30">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight">{item.label}</span>
              {isActive && (
                <span className="absolute -bottom-1 w-5 h-0.5 rounded-full bg-rose-500" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
