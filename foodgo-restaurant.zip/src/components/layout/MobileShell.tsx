// ============================================================================
// FoodGo Restaurant - High-Fidelity Mobile Shell & Device Container
// Supports iPhone 16 Pro, Google Pixel 9, and Full Viewport modes
// ============================================================================

import React, { useEffect, useState } from 'react';
import {
  BatteryCharging,
  BellRing,
  ChefHat,
  LogOut,
  Monitor,
  Radio,
  Smartphone,
  Sparkles,
  Store,
  UserCheck,
  Wifi,
} from 'lucide-react';
import { AuthFlowContainer } from '../auth/AuthFlowContainer';
import { HomeDashboard } from '../dashboard/HomeDashboard';
import { KitchenDisplayMode } from '../kitchen/KitchenDisplayMode';
import { MenuManagementScreen } from '../menu/MenuManagementScreen';
import { MoreMenuScreen } from '../more/MoreMenuScreen';
import { OnboardingWizardModal } from '../onboarding/OnboardingWizardModal';
import { NewOrderAlertModal } from '../orders/NewOrderAlertModal';
import { OrderListScreen } from '../orders/OrderListScreen';
import { AppHeader } from './AppHeader';
import { BottomNav } from './BottomNav';
import { useAuthStore } from '../../store/useAuthStore';
import { useOnboardingStore } from '../../store/useOnboardingStore';
import { useOrderStore } from '../../store/useOrderStore';
import { useUIStore } from '../../store/useUIStore';

export const MobileShell: React.FC = () => {
  const { deviceFrame, setDeviceFrame, activeNavTab, isKitchenMode } = useUIStore();
  const { simulateIncomingOrder } = useOrderStore();
  const { currentUser, isAuthenticated, logout, quickDemoLogin } = useAuthStore();
  const { setIsOpenModal: setIsOpenOnboarding } = useOnboardingStore();

  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start p-0 md:py-6 md:px-4 font-sans antialiased selection:bg-rose-500 selection:text-white">
      {/* Top Device & Diagnostic Switcher Toolbar */}
      <aside aria-label="Device Preview Toolbar" className="w-full max-w-5xl mb-4 px-4 py-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 backdrop-blur-md hidden md:flex items-center justify-between text-xs shadow-xl">
        <div className="flex items-center gap-2">
          <span className="font-extrabold text-white flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            FoodGo Restaurant
          </span>
          <span className="text-slate-500">|</span>
          <span className="text-[11px] text-slate-400 font-medium">Phase 5: Order Management</span>
        </div>

        {/* Device Frame Selector */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setDeviceFrame('IPHONE')}
            className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
              deviceFrame === 'IPHONE'
                ? 'bg-rose-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>iPhone 16 Pro</span>
          </button>

          <button
            onClick={() => setDeviceFrame('PIXEL')}
            className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
              deviceFrame === 'PIXEL'
                ? 'bg-rose-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Pixel 9</span>
          </button>

          <button
            onClick={() => setDeviceFrame('FULL_RESPONSIVE')}
            className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1.5 transition-all ${
              deviceFrame === 'FULL_RESPONSIVE'
                ? 'bg-rose-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Responsive Web</span>
          </button>
        </div>

        {/* Auth Diagnostic & Order Simulator Triggers */}
        <div className="flex items-center gap-2">
          {isAuthenticated ? (
            <button
              onClick={logout}
              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold flex items-center gap-1.5 transition-all"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-400" />
              <span>Test Sign Out</span>
            </button>
          ) : (
            <button
              onClick={() => quickDemoLogin('RESTAURANT_OWNER')}
              className="px-2.5 py-1.5 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 font-bold flex items-center gap-1.5 transition-all"
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Quick Login as Owner</span>
            </button>
          )}

          <button
            onClick={() => setIsOpenOnboarding(true)}
            className="px-2.5 py-1.5 rounded-xl bg-rose-950/80 hover:bg-rose-900 border border-rose-500/40 text-rose-300 font-bold flex items-center gap-1.5 transition-all"
          >
            <Store className="w-3.5 h-3.5" />
            <span>Store Onboarding</span>
          </button>

          <button
            onClick={() => simulateIncomingOrder()}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-400 hover:to-rose-400 text-slate-950 font-black flex items-center gap-1.5 shadow-md shadow-amber-500/20 active:scale-95 transition-all"
          >
            <BellRing className="w-3.5 h-3.5" />
            <span>Simulate Order</span>
          </button>
        </div>
      </aside>

      {/* Main Container / Mobile Device Enclosure */}
      <div
        className={`w-full transition-all duration-300 relative flex flex-col bg-slate-900 overflow-hidden ${
          deviceFrame === 'FULL_RESPONSIVE'
            ? 'max-w-2xl min-h-screen md:min-h-[880px] md:rounded-3xl md:border md:border-slate-800 md:shadow-2xl'
            : deviceFrame === 'IPHONE'
            ? 'max-w-[412px] h-[870px] rounded-[52px] border-[10px] border-slate-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] ring-1 ring-slate-700/50'
            : 'max-w-[420px] h-[860px] rounded-[44px] border-[8px] border-slate-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] ring-1 ring-slate-700/50'
        }`}
      >
        {/* Device Status Bar */}
        <div className="w-full pt-3 px-6 pb-2 flex items-center justify-between text-xs text-white bg-slate-900 select-none z-40 shrink-0">
          <span className="font-semibold text-xs font-mono">{currentTime || '09:41'}</span>

          {/* Device Notch / Dynamic Island */}
          {deviceFrame === 'IPHONE' ? (
            <div className="w-24 h-5 bg-black rounded-full flex items-center justify-center gap-1 shadow-inner">
              <span className="w-2 h-2 rounded-full bg-slate-900/90" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80 animate-pulse" />
            </div>
          ) : deviceFrame === 'PIXEL' ? (
            <div className="w-3.5 h-3.5 bg-black rounded-full" />
          ) : null}

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-black tracking-wider">5G</span>
            <Wifi className="w-3.5 h-3.5" />
            <BatteryCharging className="w-4 h-4 text-emerald-400" />
          </div>
        </div>

        {/* Unauthenticated View: Auth Flow Master Container */}
        {!isAuthenticated ? (
          <main className="flex-1 overflow-y-auto relative bg-slate-950">
            <AuthFlowContainer />
          </main>
        ) : (
          /* Authenticated Merchant Dashboard */
          <>
            <AppHeader />

            {/* Scrollable Viewport Content */}
            <main className="flex-1 overflow-y-auto relative bg-slate-950">
              {isKitchenMode || activeNavTab === 'kitchen' ? (
                <KitchenDisplayMode />
              ) : activeNavTab === 'home' ? (
                <HomeDashboard />
              ) : activeNavTab === 'orders' ? (
                <OrderListScreen />
              ) : activeNavTab === 'menu' ? (
                <MenuManagementScreen />
              ) : (
                <MoreMenuScreen />
              )}
            </main>

            <BottomNav />

            {/* High Priority Incoming New Order Alert Modal Overlay */}
            <NewOrderAlertModal />

            {/* Merchant Onboarding & Verification Wizard */}
            <OnboardingWizardModal />
          </>
        )}

        {/* Home Indicator Bar for iOS frame */}
        {deviceFrame === 'IPHONE' && (
          <div className="w-full pb-1 pt-0.5 bg-slate-900 flex justify-center shrink-0">
            <div className="w-32 h-1 bg-slate-700 rounded-full" />
          </div>
        )}
      </div>
    </div>
  );
};

