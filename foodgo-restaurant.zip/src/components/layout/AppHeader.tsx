// ============================================================================
// FoodGo Restaurant - Top Navigation Header & Status Controller
// ============================================================================

import React, { useState } from 'react';
import {
  Bell,
  ChefHat,
  ChevronDown,
  Clock,
  Pause,
  Play,
  Volume2,
  VolumeX,
  Wifi,
} from 'lucide-react';
import { RESTAURANT_STATUS_CONFIG } from '../../config/theme';
import { useAuthStore } from '../../store/useAuthStore';
import { useOrderStore } from '../../store/useOrderStore';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { useUIStore } from '../../store/useUIStore';
import { PauseReason, RestaurantAvailabilityStatus } from '../../types';

export const AppHeader: React.FC = () => {
  const { profile, status, setStatus, pauseOrders, resumeOrders, pausedUntil } = useRestaurantStore();
  const { soundEnabled, toggleSound, isKitchenMode, toggleKitchenMode } = useUIStore();
  const { orders, setIncomingOrder } = useOrderStore();
  const { currentUser } = useAuthStore();

  const [isStatusDropdownOpen, setIsStatusDropdownOpen] = useState(false);
  const [isPauseModalOpen, setIsPauseModalOpen] = useState(false);
  const [selectedPauseReason, setSelectedPauseReason] = useState<PauseReason>('TOO_BUSY');
  const [pauseMinutes, setPauseMinutes] = useState(30);

  const pendingOrders = orders.filter((o) => o.status === 'NEW');
  const preparingOrders = orders.filter((o) => o.status === 'PREPARING');
  const currentStatusConfig = RESTAURANT_STATUS_CONFIG[status];

  const handleStatusChange = (newStatus: RestaurantAvailabilityStatus) => {
    if (newStatus === 'PAUSED') {
      setIsStatusDropdownOpen(false);
      setIsPauseModalOpen(true);
      return;
    }
    setStatus(newStatus);
    setIsStatusDropdownOpen(false);
  };

  const handleConfirmPause = () => {
    pauseOrders(selectedPauseReason, pauseMinutes);
    setIsPauseModalOpen(false);
  };

  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-3">
      <div className="flex items-center justify-between gap-2">
        {/* Restaurant Status Dropdown */}
        <div className="relative">
          <button
            onClick={() => setIsStatusDropdownOpen(!isStatusDropdownOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-left transition-all active:scale-95"
            aria-label="Change restaurant availability status"
          >
            <span className="relative flex h-2.5 w-2.5">
              <span
                className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  status === 'OPEN'
                    ? 'bg-emerald-400'
                    : status === 'BUSY'
                    ? 'bg-amber-400'
                    : 'bg-violet-400'
                }`}
              />
              <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${currentStatusConfig.dotColor}`} />
            </span>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-white tracking-tight flex items-center gap-1">
                {profile.name.length > 20 ? `${profile.name.slice(0, 18)}...` : profile.name}
              </span>
              <span className="text-[10px] text-slate-400 flex items-center gap-1 font-medium">
                {currentStatusConfig.label}
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </span>
            </div>
          </button>

          {/* Status Dropdown Menu */}
          {isStatusDropdownOpen && (
            <div className="absolute left-0 mt-2 w-56 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl p-1 z-50 animate-in fade-in zoom-in-95 duration-100">
              <div className="px-3 py-2 border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Store Availability
              </div>

              {(['OPEN', 'BUSY', 'PAUSED', 'CLOSED'] as RestaurantAvailabilityStatus[]).map((s) => {
                const config = RESTAURANT_STATUS_CONFIG[s];
                const isActive = status === s;
                return (
                  <button
                    key={s}
                    onClick={() => handleStatusChange(s)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
                      isActive ? 'bg-slate-800 text-white' : 'text-slate-300 hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full ${config.dotColor}`} />
                      <span>{config.label}</span>
                    </div>
                    {isActive && <span className="text-[10px] text-emerald-400 font-bold">Active</span>}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Quick Action Controls */}
        <div className="flex items-center gap-1.5">
          {/* Real-time Connection Indicator */}
          <div
            title="Real-time WebSocket Online"
            className="flex items-center gap-1 px-2 py-1 rounded-md bg-emerald-950/40 border border-emerald-500/20 text-emerald-400 text-[10px] font-medium"
          >
            <Wifi className="w-3 h-3 animate-pulse" />
            <span className="hidden sm:inline">LIVE</span>
          </div>

          {/* Kitchen Mode Switcher */}
          <button
            onClick={toggleKitchenMode}
            title={isKitchenMode ? 'Exit Kitchen Display Mode' : 'Enter Kitchen Display Mode'}
            className={`p-2 rounded-lg border transition-all active:scale-95 flex items-center gap-1 text-xs font-semibold ${
              isKitchenMode
                ? 'bg-orange-500 text-white border-orange-400 shadow-lg shadow-orange-500/20'
                : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border-slate-700'
            }`}
          >
            <ChefHat className="w-4 h-4" />
            {preparingOrders.length > 0 && (
              <span className="text-[10px] bg-white text-slate-900 font-bold px-1 rounded-full">
                {preparingOrders.length}
              </span>
            )}
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            title={soundEnabled ? 'Mute Alert Sound' : 'Enable Alert Sound'}
            className={`p-2 rounded-lg border transition-all active:scale-95 ${
              soundEnabled
                ? 'bg-slate-800 hover:bg-slate-750 text-slate-200 border-slate-700'
                : 'bg-rose-950/40 text-rose-400 border-rose-500/30'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Incoming Order Notification Bell */}
          <button
            onClick={() => {
              if (pendingOrders.length > 0) {
                setIncomingOrder(pendingOrders[0]);
              }
            }}
            title={`${pendingOrders.length} Pending Orders`}
            className={`relative p-2 rounded-lg border transition-all active:scale-95 ${
              pendingOrders.length > 0
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
          >
            <Bell className="w-4 h-4" />
            {pendingOrders.length > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-amber-500 text-[9px] font-black text-slate-950 ring-2 ring-slate-900">
                {pendingOrders.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Paused Banner if restaurant is paused */}
      {status === 'PAUSED' && (
        <div className="mt-2 flex items-center justify-between px-3 py-1.5 bg-violet-950/80 border border-violet-500/40 rounded-lg text-xs text-violet-200 animate-in fade-in slide-in-from-top-1">
          <div className="flex items-center gap-1.5 font-medium">
            <Pause className="w-3.5 h-3.5 text-violet-400 shrink-0" />
            <span>Orders paused {pausedUntil ? `until ${new Date(pausedUntil).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : ''}</span>
          </div>
          <button
            onClick={resumeOrders}
            className="px-2 py-0.5 rounded bg-violet-600 hover:bg-violet-500 text-white font-bold text-[10px] flex items-center gap-1 transition-all"
          >
            <Play className="w-2.5 h-2.5 fill-current" />
            Resume
          </button>
        </div>
      )}

      {/* Pause Orders Scheduling Modal */}
      {isPauseModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-5 shadow-2xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-violet-400" />
              Pause Incoming Orders
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Customers will see your store as temporarily busy. Current active orders will still be processed.
            </p>

            <div className="mt-4 space-y-3">
              <div>
                <label className="text-[11px] font-bold uppercase text-slate-400">Reason</label>
                <div className="grid grid-cols-2 gap-1.5 mt-1">
                  {[
                    { id: 'TOO_BUSY', label: 'Too Busy' },
                    { id: 'KITCHEN_MAINTENANCE', label: 'Kitchen Break' },
                    { id: 'OUT_OF_INGREDIENTS', label: 'Stock Shortage' },
                    { id: 'STAFF_SHORTAGE', label: 'Staff Shift' },
                  ].map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => setSelectedPauseReason(r.id as PauseReason)}
                      className={`px-3 py-2 text-xs font-semibold rounded-lg border text-left transition-all ${
                        selectedPauseReason === r.id
                          ? 'bg-violet-950/60 border-violet-500 text-violet-200'
                          : 'bg-slate-800 border-slate-700 text-slate-400'
                      }`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-400">Duration</label>
                <div className="flex gap-2 mt-1">
                  {[15, 30, 60, 120].map((mins) => (
                    <button
                      key={mins}
                      type="button"
                      onClick={() => setPauseMinutes(mins)}
                      className={`flex-1 py-1.5 text-xs font-bold rounded-lg border transition-all ${
                        pauseMinutes === mins
                          ? 'bg-violet-600 border-violet-500 text-white'
                          : 'bg-slate-800 border-slate-700 text-slate-300'
                      }`}
                    >
                      {mins}m
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 flex gap-2">
              <button
                type="button"
                onClick={() => setIsPauseModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition-all"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmPause}
                className="flex-1 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold shadow-lg shadow-violet-600/30 transition-all"
              >
                Confirm Pause
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
