// ============================================================================
// FoodGo Restaurant - Phone OTP Verification Screen
// ============================================================================

import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, KeyRound, ShieldAlert, Sparkles } from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { maskPhoneNumber } from '../../utils/formatters';

export const OtpVerificationScreen: React.FC = () => {
  const {
    tempPhoneForOtp,
    demoOtpHint,
    verifyPhoneOtp,
    requestPhoneOtp,
    setAuthScreen,
    isLoading,
    error,
  } = useAuthStore();

  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [countdown, setCountdown] = useState<number>(30);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    // Focus first input on mount
    inputRefs.current[0]?.focus();

    const interval = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleDigitChange = (index: number, value: string) => {
    if (value.length > 1) {
      // Handle paste of full 6-digit code
      const clean = value.replace(/\D/g, '').slice(0, 6);
      if (clean) {
        const nextDigits = [...otpDigits];
        for (let i = 0; i < clean.length; i++) {
          nextDigits[i] = clean[i];
        }
        setOtpDigits(nextDigits);
        inputRefs.current[Math.min(clean.length, 5)]?.focus();
        if (clean.length === 6) {
          verifyPhoneOtp(clean);
        }
        return;
      }
    }

    const digit = value.slice(-1);
    const nextDigits = [...otpDigits];
    nextDigits[index] = digit;
    setOtpDigits(nextDigits);

    // Auto-advance to next input
    if (digit && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    // Auto-submit if all 6 digits entered
    if (digit && index === 5) {
      const fullOtp = nextDigits.join('');
      if (fullOtp.length === 6) {
        verifyPhoneOtp(fullOtp);
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleResend = () => {
    if (countdown > 0) return;
    setCountdown(30);
    if (tempPhoneForOtp) {
      requestPhoneOtp(tempPhoneForOtp);
    }
  };

  const handleUseDemoCode = () => {
    const demo = demoOtpHint || '458921';
    const split = demo.split('');
    setOtpDigits(split);
    verifyPhoneOtp(demo);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => setAuthScreen('LOGIN')}
          className="p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h3 className="text-base font-black text-white">Enter Verification Code</h3>
          <p className="text-xs text-slate-400">
            Sent to <span className="font-mono text-white font-bold">{maskPhoneNumber(tempPhoneForOtp || '+91 98765 43210')}</span>
          </p>
        </div>
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/40 text-rose-300 text-xs font-medium">
          {error}
        </div>
      )}

      {/* 6 Digit Inputs */}
      <div className="flex justify-between gap-1.5 py-2">
        {otpDigits.map((digit, index) => (
          <input
            key={index}
            ref={(el) => {
              inputRefs.current[index] = el;
            }}
            type="text"
            inputMode="numeric"
            maxLength={6}
            value={digit}
            onChange={(e) => handleDigitChange(index, e.target.value)}
            onKeyDown={(e) => handleKeyDown(index, e)}
            className="w-12 h-14 text-center text-lg font-black font-mono rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 transition-all"
          />
        ))}
      </div>

      {/* Auto-fill demo helper badge */}
      <button
        type="button"
        onClick={handleUseDemoCode}
        className="w-full p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-amber-500/20 transition-all"
      >
        <Sparkles className="w-3.5 h-3.5" />
        <span>One-Click Auto-Fill Demo OTP ({demoOtpHint || '458921'})</span>
      </button>

      {/* Submit Button */}
      <button
        type="button"
        disabled={isLoading || otpDigits.join('').length !== 6}
        onClick={() => verifyPhoneOtp(otpDigits.join(''))}
        className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-500 to-orange-500 hover:from-rose-600 hover:to-orange-600 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-500/25 active:scale-95 transition-all disabled:opacity-50"
      >
        {isLoading ? 'Verifying OTP Code...' : 'Verify & Launch Terminal'}
        <ArrowRight className="w-4 h-4" />
      </button>

      {/* Resend Timer */}
      <div className="text-center pt-2">
        <span className="text-xs text-slate-400">Didn&apos;t receive code? </span>
        {countdown > 0 ? (
          <span className="text-xs font-mono font-bold text-slate-400">
            Resend in {countdown}s
          </span>
        ) : (
          <button
            type="button"
            onClick={handleResend}
            className="text-xs font-bold text-rose-400 hover:text-rose-300"
          >
            Resend OTP via SMS
          </button>
        )}
      </div>
    </div>
  );
};
