// ============================================================================
// FoodGo Restaurant - Login Screen (Email/Password, Phone OTP, Biometrics)
// ============================================================================

import React, { useState } from 'react';
import {
  ArrowRight,
  Fingerprint,
  KeyRound,
  Lock,
  Mail,
  Phone,
  ScanFace,
  ShieldCheck,
  Smartphone,
  User,
} from 'lucide-react';
import { APP_CONFIG } from '../../config/appConfig';
import { useAuthStore } from '../../store/useAuthStore';
import { UserRole } from '../../types';

export const LoginScreen: React.FC = () => {
  const {
    loginWithPassword,
    requestPhoneOtp,
    biometricLogin,
    quickDemoLogin,
    setAuthScreen,
    isLoading,
    error,
    clearError,
    isBiometricsEnabled,
  } = useAuthStore();

  const [authMode, setAuthMode] = useState<'PASSWORD' | 'OTP'>('PASSWORD');
  const [email, setEmail] = useState('vikram.owner@royalhyderabad.com');
  const [password, setPassword] = useState('Secret@1234');
  const [phone, setPhone] = useState('+91 98765 43210');

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await loginWithPassword(email, password);
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await requestPhoneOtp(phone);
  };

  return (
    <div className="space-y-4">
      {/* Tab Switcher: Password vs OTP */}
      <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800">
        <button
          type="button"
          onClick={() => {
            setAuthMode('PASSWORD');
            clearError();
          }}
          className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            authMode === 'PASSWORD'
              ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Mail className="w-3.5 h-3.5" />
          <span>Email & Password</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setAuthMode('OTP');
            clearError();
          }}
          className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            authMode === 'OTP'
              ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Phone OTP</span>
        </button>
      </div>

      {/* Error alert */}
      {error && (
        <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/40 text-rose-300 text-xs font-medium animate-in fade-in">
          {error}
        </div>
      )}

      {/* Form: Password Login */}
      {authMode === 'PASSWORD' ? (
        <form onSubmit={handlePasswordSubmit} className="space-y-3.5">
          <div>
            <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
              Work Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@restaurant.com"
                className="w-full pl-10 pr-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500 transition-colors"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                Password
              </label>
              <button
                type="button"
                onClick={() => setAuthScreen('FORGOT_PASSWORD')}
                className="text-[11px] text-rose-400 hover:text-rose-300 font-semibold"
              >
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500 transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-500 to-orange-500 hover:from-rose-600 hover:to-orange-600 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-500/25 active:scale-95 transition-all disabled:opacity-50"
          >
            {isLoading ? 'Verifying Credentials...' : 'Sign In to Terminal'}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      ) : (
        /* Form: Phone OTP Login */
        <form onSubmit={handleOtpSubmit} className="space-y-3.5">
          <div>
            <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
              Registered Mobile Number
            </label>
            <div className="relative">
              <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full pl-10 pr-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500 transition-colors"
              />
            </div>
            <p className="text-[10px] text-slate-500 mt-1">
              We will send a 6-digit authentication code via SMS (Demo code: 458921).
            </p>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-500 to-orange-500 hover:from-rose-600 hover:to-orange-600 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-500/25 active:scale-95 transition-all disabled:opacity-50"
          >
            {isLoading ? 'Sending SMS OTP...' : 'Send Verification OTP'}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      )}

      {/* Biometric Unlock Option */}
      {isBiometricsEnabled && (
        <button
          type="button"
          onClick={() => biometricLogin()}
          disabled={isLoading}
          className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-300 text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95"
        >
          <ScanFace className="w-4 h-4 text-rose-400" />
          <span>Unlock with Face ID / Biometrics</span>
        </button>
      )}

      {/* Social Login Options */}
      <div className="relative my-4">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-slate-800" />
        </div>
        <div className="relative flex justify-center text-[10px] uppercase">
          <span className="bg-slate-950 px-2 text-slate-500 font-bold">Or continue with</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => quickDemoLogin('RESTAURANT_OWNER')}
          className="py-2.5 px-3 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-600 text-slate-200 text-xs font-bold flex items-center justify-center gap-2 transition-all"
        >
          <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
            <path
              fill="#EA4335"
              d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.4 9 5 12 5z"
            />
            <path
              fill="#4285F4"
              d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.9z"
            />
            <path
              fill="#FBBC05"
              d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3 0-.8.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 12.4 0 15.3s.7 5.6 1.9 8l3.7-2.9z"
            />
            <path
              fill="#34A853"
              d="M12 23.5c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.4-6.4-5.2L1.9 16.5C3.7 20.2 7.5 23.5 12 23.5z"
            />
          </svg>
          <span>Google</span>
        </button>

        <button
          type="button"
          onClick={() => quickDemoLogin('RESTAURANT_MANAGER')}
          className="py-2.5 px-3 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-600 text-slate-200 text-xs font-bold flex items-center justify-center gap-2 transition-all"
        >
          <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
            <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.89c.66-.82 1.11-1.96.99-3.1-.96.04-2.11.64-2.8 1.45-.6.7-1.13 1.84-.99 2.95 1.07.08 2.15-.54 2.8-1.3" />
          </svg>
          <span>Apple</span>
        </button>
      </div>

      {/* One-Click Quick Testing Roles Bar */}
      <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5">
        <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-wider">
          <span className="flex items-center gap-1 text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            Quick Demo Login
          </span>
          <span>Instant Bypass</span>
        </div>
        <div className="grid grid-cols-3 gap-1">
          {(['RESTAURANT_OWNER', 'RESTAURANT_MANAGER', 'RESTAURANT_STAFF'] as UserRole[]).map(
            (role) => (
              <button
                key={role}
                type="button"
                onClick={() => quickDemoLogin(role)}
                className="py-1.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-slate-300 hover:text-white transition-all text-center"
              >
                {role.replace('RESTAURANT_', '')}
              </button>
            )
          )}
        </div>
      </div>

      {/* Switch to Register */}
      <div className="text-center pt-2">
        <span className="text-xs text-slate-400">New restaurant merchant? </span>
        <button
          type="button"
          onClick={() => setAuthScreen('REGISTER')}
          className="text-xs font-bold text-rose-400 hover:text-rose-300"
        >
          Register Store
        </button>
      </div>
    </div>
  );
};
