// ============================================================================
// FoodGo Restaurant - Security & Device Management Hub
// Passwords, Device Sessions, Biometrics, and Account Deletion
// ============================================================================

import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  KeyRound,
  Lock,
  LogOut,
  ScanFace,
  Shield,
  Smartphone,
  Trash2,
  X,
} from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const SecurityManagementModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const {
    activeDevices,
    revokeDevice,
    logoutAllDevices,
    changePassword,
    deleteAccount,
    isBiometricsEnabled,
    toggleBiometrics,
    isLoading,
    error,
    clearError,
  } = useAuthStore();

  const [activeTab, setActiveTab] = useState<'PASSWORD' | 'DEVICES' | 'DANGER'>('PASSWORD');

  // Change Password state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  // Delete Account state
  const [deleteConfirmationPass, setDeleteConfirmationPass] = useState('');
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);

  if (!isOpen) return null;

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    const ok = await changePassword({
      currentPassword,
      newPassword,
      confirmPassword,
    });
    if (ok) {
      setPasswordSuccess(true);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPasswordSuccess(false), 3000);
    }
  };

  const handleDeleteAccountSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await deleteAccount(deleteConfirmationPass);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-lg max-h-[90vh] bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl p-5 overflow-y-auto space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Security &amp; Device Access</h3>
              <p className="text-[11px] text-slate-400">Manage credentials and connected terminals</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800">
          {[
            { id: 'PASSWORD', label: 'Password' },
            { id: 'DEVICES', label: `Devices (${activeDevices.length})` },
            { id: 'DANGER', label: 'Danger Zone' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                clearError();
              }}
              className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === tab.id
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/40 text-rose-300 text-xs font-medium">
            {error}
          </div>
        )}

        {/* Tab 1: Change Password & Biometrics */}
        {activeTab === 'PASSWORD' && (
          <div className="space-y-4">
            {/* Biometric Toggle Card */}
            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <ScanFace className="w-5 h-5 text-rose-400" />
                <div>
                  <h4 className="text-xs font-bold text-white">Biometric Quick Login</h4>
                  <p className="text-[10px] text-slate-400">Unlock terminal via Face ID or Fingerprint</p>
                </div>
              </div>
              <button
                type="button"
                onClick={toggleBiometrics}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ${
                  isBiometricsEnabled ? 'bg-emerald-500' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white transition duration-200 ${
                    isBiometricsEnabled ? 'translate-x-4' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Change Password Form */}
            <form onSubmit={handlePasswordSubmit} className="space-y-3">
              <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-rose-400" />
                Change Account Password
              </h4>

              {passwordSuccess && (
                <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Password updated successfully!</span>
                </div>
              )}

              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Verify your existing password"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  New Password (Min 8 Characters)
                </label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new strong password"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat new password"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-600/30 transition-all active:scale-95 disabled:opacity-50"
              >
                {isLoading ? 'Updating Password...' : 'Save New Password'}
              </button>
            </form>
          </div>
        )}

        {/* Tab 2: Connected Devices & Sessions */}
        {activeTab === 'DEVICES' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-white">Active Device Sessions</h4>
                <p className="text-[10px] text-slate-400">Terminals with valid auth refresh tokens</p>
              </div>
              <button
                type="button"
                onClick={logoutAllDevices}
                className="text-[10px] font-bold text-rose-400 hover:text-rose-300 bg-rose-950/60 px-2.5 py-1 rounded-lg border border-rose-500/30"
              >
                Sign Out Other Devices
              </button>
            </div>

            <div className="space-y-2">
              {activeDevices.map((device) => (
                <div
                  key={device.id}
                  className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700 flex items-start justify-between gap-3 text-xs"
                >
                  <div className="flex items-start gap-2.5">
                    <Smartphone className="w-5 h-5 text-slate-400 mt-0.5 shrink-0" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{device.deviceName}</span>
                        {device.isCurrentDevice && (
                          <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-black uppercase">
                            This Device
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {device.browserOrOs} · IP: {device.ipAddress}
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        {device.location} · Active {device.lastActiveAt}
                      </div>
                    </div>
                  </div>

                  {!device.isCurrentDevice && (
                    <button
                      type="button"
                      onClick={() => revokeDevice(device.id)}
                      className="px-2 py-1 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 border border-rose-500/30 text-rose-300 text-[10px] font-bold shrink-0 transition-all"
                    >
                      Revoke
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Danger Zone & Account Deletion */}
        {activeTab === 'DANGER' && (
          <div className="p-4 rounded-2xl bg-rose-950/30 border border-rose-500/40 space-y-3">
            <div className="flex items-center gap-2 text-rose-400">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h4 className="text-xs font-black uppercase tracking-wider">
                Permanent Account Deletion
              </h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Deleting your merchant account will permanently revoke store access, cancel all pending payout transfers, and deactivate your restaurant listing on FoodGo. This action is irreversible.
            </p>

            {!isConfirmDeleteOpen ? (
              <button
                type="button"
                onClick={() => setIsConfirmDeleteOpen(true)}
                className="w-full py-2.5 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete Merchant Account...</span>
              </button>
            ) : (
              <form onSubmit={handleDeleteAccountSubmit} className="space-y-2 pt-2 border-t border-rose-500/30">
                <label className="text-[10px] font-bold text-rose-300 uppercase block">
                  Confirm Password to Delete Account:
                </label>
                <input
                  type="password"
                  required
                  value={deleteConfirmationPass}
                  onChange={(e) => setDeleteConfirmationPass(e.target.value)}
                  placeholder="Enter current password"
                  className="w-full px-3 py-2 bg-slate-950 border border-rose-500/60 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none"
                />
                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsConfirmDeleteOpen(false)}
                    className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black shadow-lg shadow-rose-600/40"
                  >
                    Confirm Permanent Deletion
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
