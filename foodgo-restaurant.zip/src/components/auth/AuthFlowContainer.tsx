// ============================================================================
// FoodGo Restaurant - Auth Flow Master Container
// Hosts Login, Register, Phone OTP, and Forgot Password views in mobile frame
// ============================================================================

import React from 'react';
import { ChefHat, ShieldCheck, Utensils } from 'lucide-react';
import { APP_CONFIG } from '../../config/appConfig';
import { useAuthStore } from '../../store/useAuthStore';
import { ForgotPasswordScreen } from './ForgotPasswordScreen';
import { LoginScreen } from './LoginScreen';
import { OtpVerificationScreen } from './OtpVerificationScreen';
import { RegisterScreen } from './RegisterScreen';

export const AuthFlowContainer: React.FC = () => {
  const { authScreen } = useAuthStore();

  return (
    <div className="min-h-full flex flex-col justify-between p-4 sm:p-6 bg-slate-950 text-slate-100">
      <div>
        {/* Brand Header */}
        <div className="text-center py-4 space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-rose-500 via-orange-500 to-amber-500 shadow-xl shadow-rose-500/25 ring-4 ring-rose-500/20">
            <Utensils className="w-7 h-7 text-white" />
          </div>

          <div>
            <h1 className="text-xl font-black text-white tracking-tight flex items-center justify-center gap-1.5">
              <span>{APP_CONFIG.appName}</span>
            </h1>
            <p className="text-[11px] text-slate-400 font-medium">
              Restaurant Partner &amp; Kitchen Management Portal
            </p>
          </div>
        </div>

        {/* Dynamic Auth Sub-Screen */}
        <div className="mt-2 bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-2xl backdrop-blur-md">
          {authScreen === 'LOGIN' && <LoginScreen />}
          {authScreen === 'REGISTER' && <RegisterScreen />}
          {authScreen === 'OTP_VERIFY' && <OtpVerificationScreen />}
          {authScreen === 'FORGOT_PASSWORD' && <ForgotPasswordScreen />}
        </div>
      </div>

      {/* Security & Support Footer */}
      <footer className="pt-6 pb-2 text-center space-y-1">
        <div className="flex items-center justify-center gap-1 text-[11px] text-slate-500 font-medium">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>256-Bit Hardware Encrypted Merchant Session</span>
        </div>
        <div className="text-[10px] text-slate-600">
          Need help? Contact {APP_CONFIG.supportEmail}
        </div>
      </footer>
    </div>
  );
};
