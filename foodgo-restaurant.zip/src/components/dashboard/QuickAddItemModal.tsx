// ============================================================================
// FoodGo Restaurant - Quick Add Item Modal (Master Prompt Section 6)
// ============================================================================

import React, { useState } from 'react';
import { Check, Plus, Utensils, X } from 'lucide-react';
import { useDashboardStore } from '../../store/useDashboardStore';
import { useMenuStore } from '../../store/useMenuStore';

export const QuickAddItemModal: React.FC = () => {
  const { isQuickAddItemOpen, setIsQuickAddItemOpen } = useDashboardStore();
  const { addFoodItem, categories } = useMenuStore();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('340');
  const [categoryId, setCategoryId] = useState(categories[0]?.id || 'cat_biryani');
  const [isVeg, setIsVeg] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isQuickAddItemOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    addFoodItem({
      name,
      description,
      price: parseFloat(price) || 0,
      categoryId,
      isVegetarian: isVeg,
      isAvailable: true,
      spicinessLevel: 2,
      imageUrl: isVeg
        ? 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=400&q=80'
        : 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=400&q=80',
      preparationTimeMinutes: 20,
    });

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setIsQuickAddItemOpen(false);
      setName('');
      setDescription('');
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <Utensils className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Quick Add Menu Dish</h3>
              <p className="text-[11px] text-slate-400">Instantly publish a new item</p>
            </div>
          </div>
          <button
            onClick={() => setIsQuickAddItemOpen(false)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-5 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <Check className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-white">Item Added to Menu!</h4>
            <p className="text-xs text-slate-400">Available immediately for customer orders.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                Dish Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Nizami Zafrani Kebab"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Price (₹)
                </label>
                <input
                  type="number"
                  required
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Category
                </label>
                <select
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full px-2 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                Short Description
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Succulent minced mutton cooked on slow charcoal flame..."
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="quickVeg"
                checked={isVeg}
                onChange={(e) => setIsVeg(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-500 bg-slate-950 border-slate-700"
              />
              <label htmlFor="quickVeg" className="text-xs text-slate-300 cursor-pointer">
                This is a Pure Vegetarian preparation
              </label>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsQuickAddItemOpen(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-black shadow-lg shadow-rose-500/25 transition-all"
              >
                Publish Dish
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
