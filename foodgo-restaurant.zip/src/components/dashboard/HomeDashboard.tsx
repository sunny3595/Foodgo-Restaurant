// ============================================================================
// FoodGo Restaurant - Complete Operational Home Dashboard (Phase 4)
// Directly implements Master Prompt Section 6:
// - Metrics: Sales, Orders, AOV, Pending, Preparing, Ready, Completed, Cancelled
// - Revenue Chart: Hourly, Daily, Weekly, Monthly
// - Top Selling Dishes, Low Stock Alerts, Customer Ratings Summary
// - Quick Actions: Toggle Online/Offline, Pause Orders, Kitchen Display, Add Item,
//   Create Promotion, Emergency Store Closing
// ============================================================================

import React, { useMemo } from 'react';
import {
  AlertCircle,
  AlertOctagon,
  ArrowRight,
  BarChart3,
  Bike,
  CheckCircle2,
  ChefHat,
  ChevronRight,
  Clock,
  DollarSign,
  Package,
  PauseCircle,
  Percent,
  Play,
  PlusCircle,
  Power,
  RotateCcw,
  ShoppingBag,
  Sparkles,
  Star,
  Tag,
  TrendingDown,
  TrendingUp,
  XCircle,
} from 'lucide-react';
import { ORDER_STATUS_MAP } from '../../config/theme';
import { dashboardService } from '../../services/dashboardService';
import { useAuthStore } from '../../store/useAuthStore';
import { useDashboardStore } from '../../store/useDashboardStore';
import { useOrderStore } from '../../store/useOrderStore';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { useUIStore } from '../../store/useUIStore';
import { formatCurrency, formatRemainingTime, formatTimeOnly } from '../../utils/formatters';
import { OnboardingBanner } from '../onboarding/OnboardingBanner';
import { EmergencyCloseModal } from './EmergencyCloseModal';
import { PauseStoreModal } from './PauseStoreModal';
import { QuickAddItemModal } from './QuickAddItemModal';
import { QuickCreatePromotionModal } from './QuickCreatePromotionModal';

export const HomeDashboard: React.FC = () => {
  const {
    orders,
    setActiveTab,
    selectOrder,
    setIncomingOrder,
    startPreparing,
    markReady,
    confirmHandover,
  } = useOrderStore();

  const { isOnline, toggleOnline, profile } = useRestaurantStore();
  const { setActiveNavTab, toggleKitchenMode, openStats } = useUIStore();
  const { currentUser } = useAuthStore();

  const {
    pauseConfig,
    resumeStore,
    emergencyConfig,
    setIsPauseModalOpen,
    setIsEmergencyModalOpen,
    setIsQuickAddItemOpen,
    setIsQuickPromotionOpen,
  } = useDashboardStore();

  // Metrics computation from live order state
  const metrics = useMemo(() => {
    return dashboardService.calculateMetrics(orders);
  }, [orders]);

  const newOrders = orders.filter((o) => o.status === 'NEW');
  const preparingOrders = orders.filter((o) => o.status === 'PREPARING');
  const readyOrders = orders.filter((o) => o.status === 'READY_FOR_PICKUP');
  const pickedUpOrders = orders.filter(
    (o) => o.status === 'PICKED_UP' || o.status === 'RIDER_ASSIGNED'
  );

  return (
    <div className="space-y-4 p-4 pb-24">
      {/* Merchant Onboarding & Verification Status Banner */}
      <OnboardingBanner />

      {/* Emergency Shutdown Alert Banner (if active) */}
      {emergencyConfig.isEmergencyClosed && (
        <div className="p-3.5 rounded-2xl bg-rose-950/80 border-2 border-rose-500 shadow-xl flex items-center justify-between text-xs animate-pulse">
          <div className="flex items-center gap-2.5">
            <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <span className="font-black text-rose-200 uppercase tracking-wider block">
                Emergency Store Shutdown Active
              </span>
              <span className="text-[11px] text-rose-300">
                Reason: {emergencyConfig.reason}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setIsEmergencyModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-[10px] shrink-0"
          >
            Manage Closure
          </button>
        </div>
      )}

      {/* Temporary Pause Alert Banner (if active) */}
      {pauseConfig.isPaused && !emergencyConfig.isEmergencyClosed && (
        <div className="p-3.5 rounded-2xl bg-amber-950/80 border-2 border-amber-500 shadow-xl flex items-center justify-between text-xs">
          <div className="flex items-center gap-2.5">
            <Clock className="w-5 h-5 text-amber-400 shrink-0 animate-spin" />
            <div>
              <span className="font-black text-amber-200 uppercase tracking-wider block">
                Orders Paused: {pauseConfig.durationLabel}
              </span>
              <span className="text-[11px] text-amber-300">
                {pauseConfig.reason} · Auto-resumes at{' '}
                {new Date(pauseConfig.pausedUntil || Date.now()).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={resumeStore}
            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-[10px] flex items-center gap-1 shrink-0 shadow-sm"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>Resume</span>
          </button>
        </div>
      )}

      {/* Store Master Control Bar: Online/Offline Toggle & Status */}
      <div className="p-3.5 rounded-3xl bg-slate-900 border border-slate-800 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={toggleOnline}
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
              isOnline && !emergencyConfig.isEmergencyClosed ? 'bg-emerald-500' : 'bg-slate-700'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                isOnline && !emergencyConfig.isEmergencyClosed ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black text-white">
                {emergencyConfig.isEmergencyClosed
                  ? 'EMERGENCY CLOSED'
                  : pauseConfig.isPaused
                  ? 'STORE PAUSED'
                  : isOnline
                  ? 'STORE IS ONLINE'
                  : 'STORE IS OFFLINE'}
              </span>
              <span
                className={`w-2 h-2 rounded-full ${
                  isOnline && !emergencyConfig.isEmergencyClosed && !pauseConfig.isPaused
                    ? 'bg-emerald-500 animate-pulse'
                    : 'bg-rose-500'
                }`}
              />
            </div>
            <p className="text-[10px] text-slate-400">
              {isOnline
                ? 'Accepting live marketplace delivery orders'
                : 'Hidden from customer search'}
            </p>
          </div>
        </div>

        {/* Action button: Pause or Emergency */}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setIsPauseModalOpen(true)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-xs font-bold transition-all border border-slate-700 flex items-center gap-1"
            title="Pause Orders"
          >
            <PauseCircle className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Pause</span>
          </button>

          <button
            type="button"
            onClick={() => setIsEmergencyModalOpen(true)}
            className="p-2 rounded-xl bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-300 hover:text-rose-200 text-xs font-bold transition-all"
            title="Emergency Close"
          >
            <AlertOctagon className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Master Prompt Section 6 Quick Actions Strip */}
      <div className="grid grid-cols-5 gap-1.5">
        <button
          type="button"
          onClick={toggleKitchenMode}
          className="p-2 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-center transition-all active:scale-95 group shadow-sm"
        >
          <div className="w-7 h-7 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center mx-auto mb-1 group-hover:scale-110 transition-transform">
            <ChefHat className="w-3.5 h-3.5" />
          </div>
          <span className="text-[10px] font-black text-slate-200 block truncate">Kitchen POS</span>
        </button>

        <button
          type="button"
          onClick={() => setIsQuickAddItemOpen(true)}
          className="p-2 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-center transition-all active:scale-95 group shadow-sm"
        >
          <div className="w-7 h-7 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto mb-1 group-hover:scale-110 transition-transform">
            <PlusCircle className="w-3.5 h-3.5" />
          </div>
          <span className="text-[10px] font-black text-slate-200 block truncate">Add Item</span>
        </button>

        <button
          type="button"
          onClick={() => setIsQuickPromotionOpen(true)}
          className="p-2 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-center transition-all active:scale-95 group shadow-sm"
        >
          <div className="w-7 h-7 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-1 group-hover:scale-110 transition-transform">
            <Percent className="w-3.5 h-3.5" />
          </div>
          <span className="text-[10px] font-black text-slate-200 block truncate">Promotion</span>
        </button>

        <button
          type="button"
          onClick={openStats}
          className="p-2 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-purple-500/30 text-center transition-all active:scale-95 group shadow-sm"
        >
          <div className="w-7 h-7 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center mx-auto mb-1 group-hover:scale-110 transition-transform">
            <BarChart3 className="w-3.5 h-3.5" />
          </div>
          <span className="text-[10px] font-black text-purple-300 block truncate">Stats</span>
        </button>

        <button
          type="button"
          onClick={() => setIsPauseModalOpen(true)}
          className="p-2 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 text-center transition-all active:scale-95 group shadow-sm"
        >
          <div className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-1 group-hover:scale-110 transition-transform">
            <Clock className="w-3.5 h-3.5" />
          </div>
          <span className="text-[10px] font-black text-slate-200 block truncate">Pause Store</span>
        </button>
      </div>

      {/* High-Priority Pending Order Incoming Alert */}
      {newOrders.length > 0 && (
        <div className="p-4 rounded-3xl bg-gradient-to-r from-amber-500/25 via-orange-500/25 to-amber-500/25 border-2 border-amber-500/70 shadow-xl shadow-amber-500/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl bg-amber-500 flex items-center justify-center text-slate-950 font-black text-sm animate-bounce shadow-md">
              {newOrders.length}
            </span>
            <div>
              <h3 className="text-sm font-black text-white">
                {newOrders.length === 1
                  ? 'New Order Awaiting Acceptance'
                  : `${newOrders.length} New Orders Awaiting Acceptance`}
              </h3>
              <p className="text-[11px] text-amber-300 font-medium">
                Tap to confirm prep time &amp; notify kitchen
              </p>
            </div>
          </div>
          <button
            onClick={() => setIncomingOrder(newOrders[0])}
            className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition-all active:scale-95 shadow-md shadow-amber-500/30"
          >
            Review Now
          </button>
        </div>
      )}

      {/* Primary KPI Metrics Summary Grid (Section 6 Requirement) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {/* Metric 1: Today's Sales */}
        <div className="p-3.5 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Today&apos;s Sales
            </span>
            <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <DollarSign className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-lg font-black text-white font-mono">
              {formatCurrency(metrics.todaySales)}
            </span>
            <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-bold mt-0.5">
              <TrendingUp className="w-2.5 h-2.5" />
              <span>+{metrics.salesGrowthPercent}%</span>
            </div>
          </div>
        </div>

        {/* Metric 2: Orders Count */}
        <div className="p-3.5 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Orders Count
            </span>
            <div className="w-6 h-6 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center">
              <ShoppingBag className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-lg font-black text-white font-mono">
              {metrics.ordersCount}
            </span>
            <div className="flex items-center gap-1 text-[10px] text-sky-400 font-bold mt-0.5">
              <TrendingUp className="w-2.5 h-2.5" />
              <span>+{metrics.ordersGrowthPercent}%</span>
            </div>
          </div>
        </div>

        {/* Metric 3: Average Order Value */}
        <div className="p-3.5 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Avg Order Value
            </span>
            <div className="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-lg font-black text-white font-mono">
              {formatCurrency(metrics.averageOrderValue)}
            </span>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Per customer ticket
            </div>
          </div>
        </div>

        {/* Metric 4: Completed Orders */}
        <div className="p-3.5 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Completed
            </span>
            <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2">
            <span className="text-lg font-black text-emerald-400 font-mono">
              {metrics.completedOrdersCount}
            </span>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {metrics.cancelledOrdersCount} cancelled
            </div>
          </div>
        </div>
      </div>

      {/* Operational Pipeline Counters (Pending, Preparing, Ready, Driver) */}
      <div className="bg-slate-900 p-3.5 rounded-3xl border border-slate-800 shadow-xl space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black text-slate-300 uppercase tracking-wider">
            Live Kitchen &amp; Rider Funnel
          </span>
          <button
            onClick={() => setActiveNavTab('orders')}
            className="text-[11px] font-bold text-rose-400 hover:text-rose-300 flex items-center gap-0.5"
          >
            <span>Order Queue</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-4 gap-1.5">
          {[
            {
              label: 'Pending',
              count: metrics.pendingOrdersCount,
              color: 'text-amber-400',
              tab: 'NEW',
            },
            {
              label: 'Preparing',
              count: metrics.preparingOrdersCount,
              color: 'text-orange-400',
              tab: 'PREPARING',
            },
            {
              label: 'Ready',
              count: metrics.readyOrdersCount,
              color: 'text-emerald-400',
              tab: 'READY_FOR_PICKUP',
            },
            {
              label: 'With Rider',
              count: pickedUpOrders.length,
              color: 'text-purple-400',
              tab: 'PICKED_UP',
            },
          ].map((item) => (
            <button
              key={item.label}
              onClick={() => {
                setActiveTab(item.tab as any);
                setActiveNavTab('orders');
              }}
              className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col items-center hover:border-slate-700 transition-all active:scale-95"
            >
              <span className={`text-lg font-black font-mono ${item.color}`}>
                {item.count}
              </span>
              <span className="text-[10px] text-slate-400 font-semibold mt-0.5">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Quick shortcut to Stats in More tab */}
      <button
        type="button"
        onClick={openStats}
        className="w-full p-3 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-800 flex items-center justify-between text-xs group transition-all"
      >
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
            <BarChart3 className="w-3.5 h-3.5" />
          </div>
          <div className="text-left">
            <span className="font-bold text-white block">View Stats &amp; Revenue Analytics</span>
            <span className="text-[10px] text-slate-400">Charts, top selling dishes, low stock alerts &amp; reviews</span>
          </div>
        </div>
        <div className="flex items-center gap-1 text-[11px] font-bold text-rose-400 group-hover:text-rose-300">
          <span>Open Stats</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </div>
      </button>

      {/* Live Orders Feed */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-black text-slate-200 uppercase tracking-wider">
            Urgent Orders Feed
          </h3>
          <span className="text-[10px] font-mono text-slate-400">
            {orders.filter((o) => o.status !== 'DELIVERED' && o.status !== 'CANCELLED').length} active
          </span>
        </div>

        <div className="space-y-2.5">
          {orders
            .filter((o) => o.status !== 'DELIVERED' && o.status !== 'CANCELLED')
            .map((order) => {
              const statusCfg = ORDER_STATUS_MAP[order.status];
              const remaining = formatRemainingTime(order.expectedReadyTime);

              return (
                <div
                  key={order.id}
                  className="p-3.5 rounded-3xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all space-y-2 shadow-lg"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-white font-mono">
                          {order.orderNumber}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {formatTimeOnly(order.createdAt)}
                        </span>
                      </div>
                      <div className="text-xs font-bold text-slate-300 mt-0.5">
                        {order.customer.name}
                      </div>
                    </div>

                    <div className="text-right">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase border ${statusCfg.bgColor} ${statusCfg.textColor} ${statusCfg.borderColor}`}
                      >
                        {statusCfg.shortLabel}
                      </span>
                      {order.status === 'PREPARING' && (
                        <div
                          className={`text-[10px] font-mono font-bold mt-1 ${
                            remaining.isOverdue ? 'text-rose-400' : 'text-orange-300'
                          }`}
                        >
                          {remaining.text}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Items summary */}
                  <div className="text-[11px] text-slate-300 bg-slate-950/80 p-2.5 rounded-2xl border border-slate-800/80 space-y-1">
                    {order.items.map((item) => (
                      <div key={item.id} className="flex justify-between">
                        <span>
                          <strong className="text-white">{item.quantity}x</strong> {item.name}
                        </span>
                        <span className="text-slate-400 font-mono">
                          {formatCurrency(item.totalPrice)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Direct Action Buttons */}
                  <div className="flex gap-2 pt-1">
                    {order.status === 'NEW' && (
                      <button
                        onClick={() => setIncomingOrder(order)}
                        className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs transition-all active:scale-95 shadow-md shadow-amber-500/20"
                      >
                        Review &amp; Accept
                      </button>
                    )}

                    {order.status === 'ACCEPTED' && (
                      <button
                        onClick={() => startPreparing(order.id)}
                        className="w-full py-2.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95"
                      >
                        <ChefHat className="w-3.5 h-3.5" />
                        Start Cooking
                      </button>
                    )}

                    {order.status === 'PREPARING' && (
                      <button
                        onClick={() => markReady(order.id)}
                        className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Mark Packed &amp; Ready
                      </button>
                    )}

                    {order.status === 'READY_FOR_PICKUP' && (
                      <button
                        onClick={() => confirmHandover(order.id)}
                        className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-95"
                      >
                        <Bike className="w-3.5 h-3.5" />
                        Hand Over to Rider
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
        </div>
      </div>

      {/* Quick Action Modals */}
      <PauseStoreModal />
      <EmergencyCloseModal />
      <QuickAddItemModal />
      <QuickCreatePromotionModal />
    </div>
  );
};
