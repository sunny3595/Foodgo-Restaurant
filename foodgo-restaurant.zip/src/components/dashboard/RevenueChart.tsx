// ============================================================================
// FoodGo Restaurant - Interactive Revenue & Sales Chart
// Supports Hourly, Daily, Weekly, and Monthly Timeframes
// ============================================================================

import React, { useMemo, useState } from 'react';
import {
  BarChart3,
  Calendar,
  ChevronRight,
  Clock,
  DollarSign,
  ShoppingBag,
  TrendingUp,
} from 'lucide-react';
import { dashboardService } from '../../services/dashboardService';
import { useDashboardStore } from '../../store/useDashboardStore';
import { useOrderStore } from '../../store/useOrderStore';
import { RevenueTimeframe } from '../../types/dashboard';
import { formatCurrency } from '../../utils/formatters';

const TIMEFRAMES: { id: RevenueTimeframe; label: string }[] = [
  { id: 'HOURLY', label: 'Hourly' },
  { id: 'DAILY', label: 'Daily' },
  { id: 'WEEKLY', label: 'Weekly' },
  { id: 'MONTHLY', label: 'Monthly' },
];

export const RevenueChart: React.FC = () => {
  const { timeframe, setTimeframe } = useDashboardStore();
  const { orders } = useOrderStore();
  const [selectedPointIdx, setSelectedPointIdx] = useState<number | null>(null);

  const series = useMemo(() => {
    return dashboardService.getRevenueSeries(timeframe, orders);
  }, [timeframe, orders]);

  const maxRevenue = useMemo(() => {
    return Math.max(...series.map((s) => s.revenue), 100);
  }, [series]);

  const totalPeriodRevenue = useMemo(() => {
    return series.reduce((sum, s) => sum + s.revenue, 0);
  }, [series]);

  const totalPeriodOrders = useMemo(() => {
    return series.reduce((sum, s) => sum + s.orders, 0);
  }, [series]);

  const activePoint = selectedPointIdx !== null ? series[selectedPointIdx] : series[series.length - 1];

  return (
    <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3.5 shadow-xl">
      {/* Header & Timeframe Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-300">
              Revenue Analytics
            </h3>
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
              +14.8% vs Prev
            </span>
          </div>
          <div className="text-xl font-black text-white font-mono mt-1">
            {formatCurrency(totalPeriodRevenue)}
            <span className="text-xs font-normal text-slate-400 font-sans ml-2">
              ({totalPeriodOrders} Orders)
            </span>
          </div>
        </div>

        {/* Timeframe pill tabs */}
        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf.id}
              onClick={() => {
                setTimeframe(tf.id);
                setSelectedPointIdx(null);
              }}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-black transition-all ${
                timeframe === tf.id
                  ? 'bg-rose-500 text-white shadow-sm shadow-rose-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tf.label}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Point Inspection Tooltip */}
      {activePoint && (
        <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <span className="font-bold text-white font-mono">{activePoint.label}</span>
          </div>
          <div className="flex items-center gap-3 font-mono">
            <span className="text-emerald-400 font-bold">{formatCurrency(activePoint.revenue)}</span>
            <span className="text-slate-400 text-[11px]">{activePoint.orders} Orders</span>
          </div>
        </div>
      )}

      {/* Visual Chart Bars Container */}
      <div className="pt-2">
        <div className="h-32 flex items-end gap-1.5 sm:gap-2 px-1">
          {series.map((pt, idx) => {
            const heightPercent = Math.max(12, Math.round((pt.revenue / maxRevenue) * 100));
            const isSelected = selectedPointIdx === idx || (selectedPointIdx === null && idx === series.length - 1);

            return (
              <div
                key={pt.label}
                onClick={() => setSelectedPointIdx(idx)}
                className="flex-1 h-full flex flex-col justify-end items-center group cursor-pointer"
              >
                <div
                  style={{ height: `${heightPercent}%` }}
                  className={`w-full rounded-t-lg transition-all duration-300 relative ${
                    isSelected
                      ? 'bg-gradient-to-t from-rose-600 via-rose-500 to-orange-400 shadow-lg shadow-rose-500/30'
                      : 'bg-slate-800 group-hover:bg-slate-700'
                  }`}
                >
                  {/* Top indicator dot on selected */}
                  {isSelected && (
                    <div className="w-1.5 h-1.5 rounded-full bg-white mx-auto mt-1 shadow-sm" />
                  )}
                </div>
                <span
                  className={`text-[9px] mt-2 block font-mono truncate max-w-full text-center ${
                    isSelected ? 'font-black text-rose-300' : 'text-slate-500'
                  }`}
                >
                  {pt.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
