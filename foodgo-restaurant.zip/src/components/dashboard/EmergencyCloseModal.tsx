// ============================================================================
// FoodGo Restaurant - Emergency Store Closing Modal (Master Prompt Section 6)
// ============================================================================

import React, { useState } from 'react';
import { AlertOctagon, AlertTriangle, ShieldAlert, X } from 'lucide-react';
import { useDashboardStore } from '../../store/useDashboardStore';
import { useRestaurantStore } from '../../store/useRestaurantStore';

const EMERGENCY_REASONS = [
  'Severe Weather / Local Flooding',
  'Kitchen Equipment / Gas Safety Issue',
  'Commercial Power Outage',
  'Critical Staff / Medical Emergency',
  'Inventory Supply Failure',
];

export const EmergencyCloseModal: React.FC = () => {
  const { isEmergencyModalOpen, setIsEmergencyModalOpen, triggerEmergencyClose, emergencyConfig, reopenFromEmergency } =
    useDashboardStore();
  const { toggleOnline } = useRestaurantStore();

  const [selectedReason, setSelectedReason] = useState<string>(EMERGENCY_REASONS[0]);
  const [confirmedSafety, setConfirmedSafety] = useState<boolean>(false);

  if (!isEmergencyModalOpen) return null;

  const handleExecuteEmergencyClose = () => {
    if (!confirmedSafety) return;
    triggerEmergencyClose(selectedReason);
    toggleOnline(); // Immediately sets store to offline
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-md bg-slate-900 border border-rose-500/50 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-rose-950/60 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-500 flex items-center justify-center ring-2 ring-rose-500/30">
              <AlertOctagon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-rose-400 uppercase tracking-wider">
                Emergency Store Closing
              </h3>
              <p className="text-[11px] text-slate-400">Immediate shutdown of food terminal</p>
            </div>
          </div>
          <button
            onClick={() => setIsEmergencyModalOpen(false)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {emergencyConfig.isEmergencyClosed ? (
          <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-center space-y-3">
            <AlertTriangle className="w-10 h-10 text-rose-400 mx-auto animate-bounce" />
            <h4 className="text-sm font-black text-white">Store is in Emergency Shutdown</h4>
            <p className="text-xs text-rose-300">
              Reason: <strong>{emergencyConfig.reason}</strong>
            </p>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Customers cannot place new orders. Deliveries in transit will complete normally.
            </p>

            <button
              type="button"
              onClick={() => {
                reopenFromEmergency();
                toggleOnline();
                setIsEmergencyModalOpen(false);
              }}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all"
            >
              Reopen Store &amp; Resume Normal Operations
            </button>
          </div>
        ) : (
          <div className="space-y-3.5">
            <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-500/30 text-rose-300 text-xs">
              <strong>Warning:</strong> This will instantly delist your store from the FoodGo consumer app, reject new incoming carts, and notify dispatch.
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                Emergency Incident Category
              </label>
              <select
                value={selectedReason}
                onChange={(e) => setSelectedReason(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white"
              >
                {EMERGENCY_REASONS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="confirmEmergency"
                checked={confirmedSafety}
                onChange={(e) => setConfirmedSafety(e.target.checked)}
                className="w-4 h-4 rounded text-rose-500 bg-slate-950 border-slate-700"
              />
              <label htmlFor="confirmEmergency" className="text-xs text-slate-300 cursor-pointer">
                I authorize emergency closing for kitchen personnel safety.
              </label>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEmergencyModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!confirmedSafety}
                onClick={handleExecuteEmergencyClose}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black shadow-lg shadow-rose-600/30 transition-all disabled:opacity-40"
              >
                Execute Emergency Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
