// ============================================================================
// FoodGo Restaurant - Customer Ratings & Feedback Summary
// ============================================================================

import React from 'react';
import { Heart, MessageSquare, Sparkles, Star, ThumbsUp } from 'lucide-react';
import { useDashboardStore } from '../../store/useDashboardStore';

export const CustomerRatingsWidget: React.FC = () => {
  const { ratingSummary } = useDashboardStore();

  return (
    <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3.5 shadow-xl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-300">
            Customer Ratings &amp; Reviews
          </h3>
        </div>
        <span className="text-[10px] font-bold text-slate-400">
          {ratingSummary.totalReviews} Total Reviews
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-center">
        {/* Rating Score Hero */}
        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 text-center space-y-1">
          <div className="text-3xl font-black text-white font-mono flex items-center justify-center gap-1">
            <span>{ratingSummary.averageRating}</span>
            <Star className="w-5 h-5 text-amber-400 fill-amber-400 inline mb-1" />
          </div>
          <div className="text-[10px] text-emerald-400 font-bold">
            {ratingSummary.satisfactionRate}% Positive Sentiment
          </div>
          <div className="text-[9px] text-slate-500 uppercase tracking-wider">Top 5% in Hyderabad</div>
        </div>

        {/* Stars Breakdown Bars */}
        <div className="sm:col-span-2 space-y-1.5 text-xs font-mono">
          {ratingSummary.breakdown.map((row) => (
            <div key={row.stars} className="flex items-center gap-2">
              <span className="text-[10px] text-slate-400 w-4 text-right">{row.stars}★</span>
              <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
                <div
                  style={{ width: `${row.percentage}%` }}
                  className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-400"
                />
              </div>
              <span className="text-[10px] text-slate-400 w-8 text-right">{row.percentage}%</span>
            </div>
          ))}
        </div>
      </div>

      {/* Top Compliment Tags */}
      <div className="pt-1">
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
          What Customers Love Most
        </span>
        <div className="flex flex-wrap gap-1.5">
          {ratingSummary.topCompliments.map((comp) => (
            <span
              key={comp.tag}
              className="px-2.5 py-1 rounded-xl bg-slate-950 text-slate-300 text-[10px] font-medium border border-slate-800 flex items-center gap-1"
            >
              <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
              <span>{comp.tag}</span>
              <strong className="text-white font-mono ml-0.5">({comp.count})</strong>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};
