// ============================================================================
// FoodGo Restaurant - Quick Create Promotion Modal (Master Prompt Section 6)
// ============================================================================

import React, { useState } from 'react';
import { Check, Percent, Tag, X } from 'lucide-react';
import { useDashboardStore } from '../../store/useDashboardStore';

export const QuickCreatePromotionModal: React.FC = () => {
  const { isQuickPromotionOpen, setIsQuickPromotionOpen } = useDashboardStore();

  const [promoCode, setPromoCode] = useState('BIRYANIFEST25');
  const [discountPercent, setDiscountPercent] = useState('25');
  const [minOrder, setMinOrder] = useState('399');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isQuickPromotionOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setIsQuickPromotionOpen(false);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center">
              <Percent className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Create Flash Promotion</h3>
              <p className="text-[11px] text-slate-400">Boost customer order volume</p>
            </div>
          </div>
          <button
            onClick={() => setIsQuickPromotionOpen(false)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-5 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-center space-y-2">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <Check className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-white">Coupon {promoCode} Activated!</h4>
            <p className="text-xs text-slate-400">
              Live on FoodGo app banner for all nearby customers.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                Coupon Code
              </label>
              <div className="relative">
                <Tag className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                  placeholder="e.g. TASTY20"
                  className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono uppercase focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Discount (%)
                </label>
                <input
                  type="number"
                  min="5"
                  max="70"
                  required
                  value={discountPercent}
                  onChange={(e) => setDiscountPercent(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono focus:outline-none"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-300 uppercase block mb-1">
                  Min Order (₹)
                </label>
                <input
                  type="number"
                  min="99"
                  required
                  value={minOrder}
                  onChange={(e) => setMinOrder(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono focus:outline-none"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsQuickPromotionOpen(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white text-xs font-black shadow-lg shadow-orange-500/25 transition-all"
              >
                Launch Coupon
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
