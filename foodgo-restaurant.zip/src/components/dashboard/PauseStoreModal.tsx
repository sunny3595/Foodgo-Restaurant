// ============================================================================
// FoodGo Restaurant - Pause Incoming Orders Modal
// Options: 15m, 30m, 1h, or custom duration (Master Prompt Section 6)
// ============================================================================

import React, { useState } from 'react';
import { AlertCircle, Clock, PauseCircle, Play, X } from 'lucide-react';
import { useDashboardStore } from '../../store/useDashboardStore';

const DURATION_PRESETS = [
  { minutes: 15, label: '15 Minutes (Rush Peak)' },
  { minutes: 30, label: '30 Minutes (Kitchen Buffer)' },
  { minutes: 60, label: '1 Hour (Shift Change / Restock)' },
  { minutes: 120, label: '2 Hours (Deep Cleaning)' },
];

const REASONS = [
  'Kitchen at Peak Capacity',
  'Staff Break / Shift Change',
  'Packaging Restock',
  'Equipment Cleaning & Sanitization',
];

export const PauseStoreModal: React.FC = () => {
  const { isPauseModalOpen, setIsPauseModalOpen, pauseStore, pauseConfig, resumeStore } =
    useDashboardStore();

  const [selectedMinutes, setSelectedMinutes] = useState<number>(30);
  const [selectedReason, setSelectedReason] = useState<string>(REASONS[0]);
  const [isCustom, setIsCustom] = useState<boolean>(false);
  const [customMinutes, setCustomMinutes] = useState<number>(45);

  if (!isPauseModalOpen) return null;

  const handleApplyPause = () => {
    const mins = isCustom ? customMinutes : selectedMinutes;
    const label = `${mins} Minutes`;
    pauseStore(mins, label, selectedReason);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <PauseCircle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">Pause Incoming Orders</h3>
              <p className="text-[11px] text-slate-400">Temporarily stop accepting new orders</p>
            </div>
          </div>
          <button
            onClick={() => setIsPauseModalOpen(false)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* If already paused */}
        {pauseConfig.isPaused ? (
          <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-center space-y-2">
            <Clock className="w-8 h-8 text-amber-400 mx-auto animate-pulse" />
            <h4 className="text-sm font-black text-white">Store is Currently Paused</h4>
            <p className="text-xs text-amber-200">
              Reason: <strong>{pauseConfig.reason}</strong>
            </p>
            <p className="text-[11px] text-slate-400">
              Auto-resuming at {new Date(pauseConfig.pausedUntil || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.
            </p>

            <button
              type="button"
              onClick={() => {
                resumeStore();
                setIsPauseModalOpen(false);
              }}
              className="w-full mt-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Resume Accepting Orders Now</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3.5">
            {/* Presets */}
            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                Select Pause Duration
              </label>
              <div className="space-y-1.5">
                {DURATION_PRESETS.map((preset) => (
                  <button
                    key={preset.minutes}
                    type="button"
                    onClick={() => {
                      setSelectedMinutes(preset.minutes);
                      setIsCustom(false);
                    }}
                    className={`w-full p-2.5 rounded-xl text-xs font-semibold border text-left flex items-center justify-between transition-all ${
                      !isCustom && selectedMinutes === preset.minutes
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span>{preset.label}</span>
                    <Clock className="w-3.5 h-3.5" />
                  </button>
                ))}

                {/* Custom duration button */}
                <button
                  type="button"
                  onClick={() => setIsCustom(true)}
                  className={`w-full p-2.5 rounded-xl text-xs font-semibold border text-left flex items-center justify-between transition-all ${
                    isCustom
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <span>Custom Duration</span>
                  <span className="font-mono">{customMinutes} Mins</span>
                </button>
              </div>

              {isCustom && (
                <div className="mt-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2">
                  <input
                    type="range"
                    min="5"
                    max="180"
                    step="5"
                    value={customMinutes}
                    onChange={(e) => setCustomMinutes(parseInt(e.target.value))}
                    className="flex-1 accent-amber-500"
                  />
                  <span className="font-mono text-xs font-bold text-amber-400 w-16 text-right">
                    {customMinutes} mins
                  </span>
                </div>
              )}
            </div>

            {/* Reason */}
            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1">
                Reason for Pause
              </label>
              <select
                value={selectedReason}
                onChange={(e) => setSelectedReason(e.target.value)}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white"
              >
                {REASONS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            {/* Action buttons */}
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsPauseModalOpen(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleApplyPause}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow-lg shadow-amber-500/25 transition-all"
              >
                Pause Kitchen Terminal
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
