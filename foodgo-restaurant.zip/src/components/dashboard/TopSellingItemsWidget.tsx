// ============================================================================
// FoodGo Restaurant - Top Selling Items Widget
// ============================================================================

import React from 'react';
import { Award, ChevronRight, Flame, Sparkles, TrendingUp } from 'lucide-react';
import { useDashboardStore } from '../../store/useDashboardStore';
import { useUIStore } from '../../store/useUIStore';
import { formatCurrency } from '../../utils/formatters';

export const TopSellingItemsWidget: React.FC = () => {
  const { topSellers } = useDashboardStore();
  const { setActiveNavTab } = useUIStore();

  return (
    <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-xl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-orange-500" />
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-300">
            Top Selling Dishes
          </h3>
        </div>
        <button
          type="button"
          onClick={() => setActiveNavTab('menu')}
          className="text-[10px] font-bold text-rose-400 hover:text-rose-300 flex items-center gap-0.5"
        >
          <span>View Menu</span>
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>

      <div className="space-y-2.5">
        {topSellers.map((item, index) => (
          <div
            key={item.id}
            className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between gap-3 text-xs hover:border-slate-700 transition-all"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              {/* Rank number badge */}
              <div
                className={`w-5 h-5 rounded-lg flex items-center justify-center font-black text-[10px] shrink-0 ${
                  index === 0
                    ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                    : index === 1
                    ? 'bg-slate-300 text-slate-950'
                    : index === 2
                    ? 'bg-amber-700 text-white'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                #{index + 1}
              </div>

              {/* Item Thumbnail */}
              <img
                src={item.imageUrl}
                alt={item.name}
                className="w-10 h-10 rounded-xl object-cover border border-slate-800 shrink-0"
              />

              <div className="min-w-0">
                <h4 className="font-bold text-white truncate text-xs">{item.name}</h4>
                <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                  <span>{item.category}</span>
                  <span>•</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                    <TrendingUp className="w-2.5 h-2.5" />
                    +{item.growthPercent}%
                  </span>
                </div>
              </div>
            </div>

            {/* Units sold & Revenue */}
            <div className="text-right shrink-0">
              <div className="font-mono font-bold text-white text-xs">
                {formatCurrency(item.revenue)}
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                {item.quantitySold} sold
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
