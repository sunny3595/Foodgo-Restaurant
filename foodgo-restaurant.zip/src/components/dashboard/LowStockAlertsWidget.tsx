// ============================================================================
// FoodGo Restaurant - Low Stock & Inventory Alerts Widget
// ============================================================================

import React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Package,
  Plus,
  RefreshCw,
  Slash,
} from 'lucide-react';
import { useDashboardStore } from '../../store/useDashboardStore';

export const LowStockAlertsWidget: React.FC = () => {
  const { lowStockItems, restockItem, markSoldOut } = useDashboardStore();

  const criticalCount = lowStockItems.filter((i) => i.currentStock <= i.minimumThreshold).length;

  return (
    <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-xl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-300">
            Low Stock Inventory Alerts
          </h3>
        </div>
        <span className="text-[10px] font-bold text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-500/30">
          {criticalCount} Critical Items
        </span>
      </div>

      <div className="space-y-2">
        {lowStockItems.map((item) => (
          <div
            key={item.id}
            className={`p-3 rounded-2xl border flex items-center justify-between gap-3 text-xs transition-all ${
              item.isSoldOut
                ? 'bg-rose-950/30 border-rose-500/40 text-rose-300'
                : 'bg-slate-950/80 border-slate-800 text-slate-300'
            }`}
          >
            <div className="flex items-start gap-2.5 min-w-0">
              <Package
                className={`w-4 h-4 mt-0.5 shrink-0 ${
                  item.isSoldOut ? 'text-rose-400' : 'text-amber-400'
                }`}
              />
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h4 className="font-bold text-white truncate text-xs">{item.name}</h4>
                  {item.isSoldOut && (
                    <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 text-[9px] font-black uppercase">
                      Sold Out (86)
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  In stock: <strong className="text-white font-mono">{item.currentStock}</strong>{' '}
                  {item.unit} (Min target: {item.minimumThreshold})
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-1.5 shrink-0">
              {!item.isSoldOut && (
                <button
                  type="button"
                  onClick={() => markSoldOut(item.id)}
                  title="Mark 86 / Sold out"
                  className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 text-[10px] font-bold border border-slate-700 transition-all"
                >
                  86 Item
                </button>
              )}

              <button
                type="button"
                onClick={() => restockItem(item.id, 10)}
                className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-black flex items-center gap-1 shadow-sm transition-all active:scale-95"
              >
                <Plus className="w-3 h-3" />
                <span>Restock (+10)</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
