// ============================================================================
// FoodGo Restaurant - Onboarding Status Banner
// Displays verification state & shortcut to 6-Step Onboarding Wizard
// ============================================================================

import React from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clock,
  ShieldAlert,
  Sparkles,
  Store,
} from 'lucide-react';
import { useOnboardingStore } from '../../store/useOnboardingStore';

export const OnboardingBanner: React.FC = () => {
  const { data, setIsOpenModal } = useOnboardingStore();

  const status = data.verification.status;

  // When merchant KYC & store is approved, remove the banner from homepage
  if (status === 'APPROVED') {
    return null;
  }

  return (
    <div
      className={`p-3.5 rounded-2xl border flex items-center justify-between ${
        status === 'PENDING_VERIFICATION'
          ? 'bg-amber-950/40 border-amber-500/40 text-amber-200'
          : status === 'REQUIRES_CHANGES'
          ? 'bg-rose-950/40 border-rose-500/40 text-rose-200'
          : 'bg-gradient-to-r from-rose-950/60 to-orange-950/60 border-rose-500/40'
      }`}
    >
      <div className="flex items-center gap-2.5">
        <div
          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
            status === 'PENDING_VERIFICATION'
              ? 'bg-amber-500/20 text-amber-300'
              : status === 'REQUIRES_CHANGES'
              ? 'bg-rose-500/20 text-rose-400'
              : 'bg-rose-500/20 text-rose-400'
          }`}
        >
          {status === 'PENDING_VERIFICATION' ? (
            <Clock className="w-4 h-4 animate-spin" />
          ) : status === 'REQUIRES_CHANGES' ? (
            <AlertTriangle className="w-4 h-4" />
          ) : (
            <Store className="w-4 h-4" />
          )}
        </div>

        <div>
          <div className="text-xs font-black text-white flex items-center gap-1.5">
            <span>
              {status === 'PENDING_VERIFICATION'
                ? 'Store Verification in Progress'
                : status === 'REQUIRES_CHANGES'
                ? 'Verification Update Required'
                : 'Complete Store Onboarding'}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              (Step {data.step} of 6)
            </span>
          </div>
          <p className="text-[10px] text-slate-300 mt-0.5">
            {status === 'PENDING_VERIFICATION'
              ? 'FSSAI compliance & bank verification undergoing audit.'
              : status === 'REQUIRES_CHANGES'
              ? 'Action needed on legal documentation.'
              : 'Add your kitchen address, menu, and legal KYC to start accepting orders.'}
          </p>
        </div>
      </div>

      <button
        type="button"
        onClick={() => setIsOpenModal(true)}
        className="px-3 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-black text-xs flex items-center gap-1 shadow-md shadow-rose-500/25 shrink-0 transition-all active:scale-95 ml-2"
      >
        <span>{status === 'PENDING_VERIFICATION' ? 'Review' : 'Resume'}</span>
        <ArrowRight className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};
