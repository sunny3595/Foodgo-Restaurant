// ============================================================================
// FoodGo Restaurant - 6-Step Merchant Onboarding & Verification Wizard
// Directly implements Master Prompt Section 5:
// Step 1: Account -> Step 2: Restaurant -> Step 3: Location ->
// Step 4: Business Info -> Step 5: Legal/Docs -> Step 6: Verification
// ============================================================================

import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  ArrowRight,
  Building,
  CheckCircle2,
  Clock,
  Compass,
  FileCheck,
  FileText,
  FileUp,
  Image,
  Lock,
  Mail,
  MapPin,
  Navigation,
  Phone,
  ShieldAlert,
  ShieldCheck,
  Store,
  Trash2,
  User,
  UtensilsCrossed,
  X,
  XCircle,
} from 'lucide-react';
import { useOnboardingStore } from '../../store/useOnboardingStore';
import { useRestaurantStore } from '../../store/useRestaurantStore';
import { OnboardingVerificationStatus, RestaurantType } from '../../types/onboarding';
import { formatCurrency } from '../../utils/formatters';

const STEP_LABELS = [
  'Account',
  'Restaurant',
  'Location',
  'Business',
  'Legal & KYC',
  'Verification',
];

const AVAILABLE_CUISINES = [
  'Biryani',
  'Hyderabadi',
  'North Indian',
  'Mughlai',
  'Tandoor',
  'South Indian',
  'Chinese & Pan-Asian',
  'Pizza & Italian',
  'Burgers & Fast Food',
  'Desserts & Bakery',
  'Healthy & Salads',
];

export const OnboardingWizardModal: React.FC = () => {
  const {
    data,
    isOpenModal,
    setIsOpenModal,
    setStep,
    nextStep,
    prevStep,
    updateAccount,
    updateRestaurant,
    updateLocation,
    updateBusiness,
    updateLegal,
    uploadDocument,
    submitForVerification,
    setVerificationStatus,
    resetOnboarding,
    isLoading,
    error,
  } = useOnboardingStore();

  const { updateProfile } = useRestaurantStore();

  const [newDocType, setNewDocType] = useState<'FSSAI_LICENSE' | 'GST_CERTIFICATE' | 'PAN_CARD'>('FSSAI_LICENSE');
  const [docNameInput, setDocNameInput] = useState('');

  if (!isOpenModal) return null;

  const currentStep = data.step;

  const handleToggleCuisine = (cuisine: string) => {
    const current = data.business.cuisines || [];
    if (current.includes(cuisine)) {
      updateBusiness({ cuisines: current.filter((c) => c !== cuisine) });
    } else {
      updateBusiness({ cuisines: [...current, cuisine] });
    }
  };

  const handleAddSampleDoc = async () => {
    const name = docNameInput.trim() || `${newDocType.toLowerCase()}_verified_2026.pdf`;
    await uploadDocument(newDocType, name, 1.5);
    setDocNameInput('');
  };

  const handleApproveAndSync = () => {
    setVerificationStatus('APPROVED', 'Application approved by FoodGo Compliance Team.');
    updateProfile({
      name: data.restaurant.name || 'Royal Hyderabad Dum Biryani',
      description: data.restaurant.description,
      deliveryRadiusKm: data.business.deliveryRadiusKm,
      minimumOrderAmount: data.business.minimumOrderAmount,
      averagePrepTimeMinutes: data.business.averagePrepTimeMinutes,
      cuisine: data.business.cuisines,
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-xl max-h-[92vh] bg-slate-900 border border-slate-700 rounded-t-3xl sm:rounded-3xl flex flex-col overflow-hidden shadow-2xl">
        {/* Top Header & Close */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Merchant Onboarding
              </h3>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Step {currentStep} of 6: <strong className="text-slate-200">{STEP_LABELS[currentStep - 1]}</strong>
            </p>
          </div>
          <button
            onClick={() => setIsOpenModal(false)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stepper Progress Bar */}
        <div className="px-4 py-2 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between gap-1 overflow-x-auto no-scrollbar">
          {STEP_LABELS.map((label, idx) => {
            const stepNum = idx + 1;
            const isCompleted = stepNum < currentStep;
            const isCurrent = stepNum === currentStep;

            return (
              <button
                key={label}
                type="button"
                onClick={() => setStep(stepNum)}
                className={`flex items-center gap-1 py-1 px-2 rounded-lg text-[10px] font-bold whitespace-nowrap transition-all ${
                  isCurrent
                    ? 'bg-rose-500 text-white shadow-sm'
                    : isCompleted
                    ? 'text-emerald-400 bg-emerald-950/40 border border-emerald-500/30'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                {isCompleted ? (
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                ) : (
                  <span>{stepNum}.</span>
                )}
                <span>{label}</span>
              </button>
            );
          })}
        </div>

        {/* Scrollable Step Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/40 text-rose-300 text-xs font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* STEP 1: Account */}
          {currentStep === 1 && (
            <div className="space-y-3.5">
              <div>
                <h4 className="text-sm font-black text-white">Step 1 — Owner Account Details</h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Enter your credentials to manage your store ownership and access.
                </p>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={data.account.name}
                    onChange={(e) => updateAccount({ name: e.target.value })}
                    placeholder="Vikramaditya Rao"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                  Business Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    value={data.account.email}
                    onChange={(e) => updateAccount({ email: e.target.value })}
                    placeholder="owner@royalhyderabad.com"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                  Mobile Number
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    value={data.account.phone}
                    onChange={(e) => updateAccount({ phone: e.target.value })}
                    placeholder="+91 98765 43210"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Restaurant Profile */}
          {currentStep === 2 && (
            <div className="space-y-3.5">
              <div>
                <h4 className="text-sm font-black text-white">Step 2 — Restaurant Information</h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Set up your brand identity, restaurant format, and customer-facing imagery.
                </p>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                  Restaurant / Kitchen Brand Name
                </label>
                <input
                  type="text"
                  value={data.restaurant.name}
                  onChange={(e) => updateRestaurant({ name: e.target.value })}
                  placeholder="e.g. Royal Hyderabad Dum Biryani"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                  Restaurant Type
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'CLOUD_KITCHEN', label: 'Cloud Kitchen / Dark Kitchen' },
                    { id: 'DINE_IN_RESTAURANT', label: 'Dine-In Restaurant' },
                    { id: 'FAST_FOOD_QSR', label: 'Fast Food / QSR' },
                    { id: 'CAFE_AND_BAKERY', label: 'Cafe & Bakery' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => updateRestaurant({ type: t.id as RestaurantType })}
                      className={`p-2.5 rounded-xl border text-left text-xs font-semibold transition-all ${
                        data.restaurant.type === t.id
                          ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                  Description
                </label>
                <textarea
                  value={data.restaurant.description}
                  onChange={(e) => updateRestaurant({ description: e.target.value })}
                  rows={2}
                  placeholder="Describe your kitchen specials, culinary heritage, and ingredients..."
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              {/* Logo & Cover Image Preview */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                    Store Logo
                  </label>
                  <div className="flex items-center gap-2">
                    <img
                      src={data.restaurant.logoUrl}
                      alt="Logo"
                      className="w-12 h-12 rounded-xl object-cover border border-slate-700 shrink-0"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        updateRestaurant({
                          logoUrl:
                            'https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=200&q=80',
                        })
                      }
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 text-[10px] font-bold text-slate-300 hover:text-white"
                    >
                      Change Logo
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                    Cover Banner
                  </label>
                  <div className="flex items-center gap-2">
                    <img
                      src={data.restaurant.coverImageUrl}
                      alt="Cover"
                      className="w-16 h-12 rounded-xl object-cover border border-slate-700 shrink-0"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        updateRestaurant({
                          coverImageUrl:
                            'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
                        })
                      }
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 text-[10px] font-bold text-slate-300 hover:text-white"
                    >
                      Change Banner
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Location */}
          {currentStep === 3 && (
            <div className="space-y-3.5">
              <div>
                <h4 className="text-sm font-black text-white">Step 3 — Kitchen Location & Pin</h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Precise GPS coordinates ensure riders and customers locate your kitchen easily.
                </p>
              </div>

              <div>
                <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                  Street Address & Building
                </label>
                <input
                  type="text"
                  value={data.location.address}
                  onChange={(e) => updateLocation({ address: e.target.value })}
                  placeholder="e.g. Plot 42, Silicon Valley Avenue"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                    City
                  </label>
                  <input
                    type="text"
                    value={data.location.city}
                    onChange={(e) => updateLocation({ city: e.target.value })}
                    placeholder="Hyderabad"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                    Postal Code
                  </label>
                  <input
                    type="text"
                    value={data.location.postalCode}
                    onChange={(e) => updateLocation({ postalCode: e.target.value })}
                    placeholder="500081"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Simulated Map Coordinates & Pin Widget */}
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-300 flex items-center gap-1.5">
                    <Navigation className="w-3.5 h-3.5 text-rose-500" />
                    GPS Coordinates (Google Places Pin)
                  </span>
                  <span className="font-mono text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                    High Accuracy
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-slate-500 block">Latitude</span>
                    <span className="text-white font-bold">{data.location.latitude.toFixed(4)}</span>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-slate-500 block">Longitude</span>
                    <span className="text-white font-bold">{data.location.longitude.toFixed(4)}</span>
                  </div>
                </div>

                <div className="w-full h-24 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#ff4b2b_1px,transparent_1px)] [background-size:12px_12px]" />
                  <div className="flex items-center gap-2 text-xs font-bold text-white z-10 bg-slate-950/80 px-3 py-1.5 rounded-full border border-slate-700 shadow-lg">
                    <MapPin className="w-4 h-4 text-rose-500 animate-bounce" />
                    <span>{data.location.address || 'Silicon Valley, Madhapur, Hyderabad'}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: Business Information */}
          {currentStep === 4 && (
            <div className="space-y-3.5">
              <div>
                <h4 className="text-sm font-black text-white">Step 4 — Business Operations</h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Configure cuisines, operating hours, delivery radius, and prep times.
                </p>
              </div>

              {/* Cuisine Multi-select */}
              <div>
                <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1.5">
                  Select Cuisines Served
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {AVAILABLE_CUISINES.map((cuisine) => {
                    const isSelected = data.business.cuisines.includes(cuisine);
                    return (
                      <button
                        key={cuisine}
                        type="button"
                        onClick={() => handleToggleCuisine(cuisine)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                          isSelected
                            ? 'bg-rose-500 text-white shadow-sm'
                            : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                        }`}
                      >
                        {cuisine}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Operating Hours */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                    Opening Time
                  </label>
                  <input
                    type="time"
                    value={data.business.openTime}
                    onChange={(e) => updateBusiness({ openTime: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                    Closing Time
                  </label>
                  <input
                    type="time"
                    value={data.business.closeTime}
                    onChange={(e) => updateBusiness({ closeTime: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Delivery Radius & Prep Time */}
              <div className="space-y-3 pt-1">
                <div>
                  <div className="flex justify-between items-center text-xs mb-1">
                    <span className="font-bold text-slate-300">Delivery Radius</span>
                    <span className="font-mono font-bold text-rose-400">
                      {data.business.deliveryRadiusKm} km
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    step="0.5"
                    value={data.business.deliveryRadiusKm}
                    onChange={(e) =>
                      updateBusiness({ deliveryRadiusKm: parseFloat(e.target.value) })
                    }
                    className="w-full accent-rose-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                      Min Order Amount
                    </label>
                    <input
                      type="number"
                      value={data.business.minimumOrderAmount}
                      onChange={(e) =>
                        updateBusiness({ minimumOrderAmount: parseInt(e.target.value) || 0 })
                      }
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-mono text-white focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                      Avg Prep Time (Mins)
                    </label>
                    <input
                      type="number"
                      value={data.business.averagePrepTimeMinutes}
                      onChange={(e) =>
                        updateBusiness({ averagePrepTimeMinutes: parseInt(e.target.value) || 15 })
                      }
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl font-mono text-white focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: Legal & KYC Documents */}
          {currentStep === 5 && (
            <div className="space-y-3.5">
              <div>
                <h4 className="text-sm font-black text-white">Step 5 — Legal, Tax &amp; Banking KYC</h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Required for food delivery compliance, GST invoices, and weekly bank settlements.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                    GSTIN / Tax ID
                  </label>
                  <input
                    type="text"
                    value={data.legal.taxId}
                    onChange={(e) => updateLegal({ taxId: e.target.value })}
                    placeholder="36AAAAA0000A1Z5"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono uppercase focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-bold uppercase text-slate-300 block mb-1">
                    Business Reg / CIN
                  </label>
                  <input
                    type="text"
                    value={data.legal.businessRegistrationNumber}
                    onChange={(e) => updateLegal({ businessRegistrationNumber: e.target.value })}
                    placeholder="U55101TG2022PTC160124"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white font-mono uppercase focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Bank Details */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px] block">
                  Payout Settlement Bank Account
                </span>

                <div>
                  <label className="text-[10px] text-slate-400 block mb-0.5">Account Beneficiary</label>
                  <input
                    type="text"
                    value={data.legal.bankHolderName}
                    onChange={(e) => updateLegal({ bankHolderName: e.target.value })}
                    placeholder="Royal Hyderabad Kitchens Pvt Ltd"
                    className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-0.5">Account Number</label>
                    <input
                      type="text"
                      value={data.legal.accountNumber}
                      onChange={(e) => updateLegal({ accountNumber: e.target.value })}
                      placeholder="501002348914589"
                      className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-0.5">IFSC / Routing</label>
                    <input
                      type="text"
                      value={data.legal.ifscOrRoutingCode}
                      onChange={(e) => updateLegal({ ifscOrRoutingCode: e.target.value })}
                      placeholder="HDFC0001248"
                      className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono uppercase"
                    />
                  </div>
                </div>
              </div>

              {/* Uploaded Documents List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-300 uppercase text-[11px]">
                    Compliance Documents ({data.legal.documents.length})
                  </span>
                </div>

                <div className="space-y-1.5">
                  {Array.from(
                    new Map((data.legal.documents || []).map((doc) => [doc.id, doc])).values()
                  ).map((doc, idx) => (
                    <div
                      key={doc.id || `doc_${idx}`}
                      className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <FileCheck className="w-4 h-4 text-emerald-400" />
                        <div>
                          <div className="font-bold text-white">{doc.name}</div>
                          <div className="text-[10px] text-slate-400">
                            {doc.type} · {doc.fileSizeMb} MB
                          </div>
                        </div>
                      </div>
                      <span className="text-[10px] font-black uppercase text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                        {doc.verificationStatus}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Upload Action */}
                <div className="p-3 rounded-xl bg-slate-950/80 border border-dashed border-slate-700 flex flex-col gap-2">
                  <div className="flex gap-2">
                    <select
                      value={newDocType}
                      onChange={(e) => setNewDocType(e.target.value as any)}
                      className="px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white"
                    >
                      <option value="FSSAI_LICENSE">FSSAI Food License</option>
                      <option value="GST_CERTIFICATE">GST Certificate</option>
                      <option value="PAN_CARD">Company PAN Card</option>
                    </select>

                    <input
                      type="text"
                      value={docNameInput}
                      onChange={(e) => setDocNameInput(e.target.value)}
                      placeholder="e.g. fssai_license_2026.pdf"
                      className="flex-1 px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleAddSampleDoc}
                    className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                  >
                    <FileUp className="w-3.5 h-3.5 text-rose-400" />
                    <span>Upload &amp; Attach Document</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 6: Verification Status */}
          {currentStep === 6 && (
            <div className="space-y-4 text-center py-2">
              {data.verification.status === 'APPROVED' ? (
                <div className="p-5 rounded-3xl bg-emerald-950/40 border border-emerald-500/40 space-y-3">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto ring-4 ring-emerald-500/20">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-white">
                      Restaurant Approved &amp; Active!
                    </h4>
                    <p className="text-xs text-emerald-300 mt-1">
                      {data.verification.reviewerNotes || 'All merchant documents verified.'}
                    </p>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    You can now accept orders, edit menus, receive payouts, and manage staff.
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsOpenModal(false)}
                    className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg shadow-emerald-600/30 transition-all active:scale-95"
                  >
                    Launch Restaurant POS Terminal
                  </button>
                </div>
              ) : data.verification.status === 'PENDING_VERIFICATION' ? (
                <div className="p-5 rounded-3xl bg-amber-950/40 border border-amber-500/40 space-y-3">
                  <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center mx-auto ring-4 ring-amber-500/20 animate-pulse">
                    <Clock className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-white">Application Under Review</h4>
                    <p className="text-xs text-amber-300 mt-1">
                      Submitted on {new Date(data.verification.submittedAt || Date.now()).toLocaleDateString()}. Typical verification time is 2-4 hours.
                    </p>
                  </div>
                  <p className="text-xs text-slate-400">
                    Our compliance team is auditing your FSSAI food license, GST details, and bank account for daily settlements.
                  </p>
                </div>
              ) : (
                <div className="p-5 rounded-3xl bg-rose-950/40 border border-rose-500/40 space-y-3">
                  <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto ring-4 ring-rose-500/20">
                    <XCircle className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-base font-black text-white">Verification Requires Changes</h4>
                    <p className="text-xs text-rose-300 mt-1">
                      {data.verification.reviewerNotes || 'Please upload a clearer copy of your FSSAI license.'}
                    </p>
                  </div>
                </div>
              )}

              {/* Admin Simulation Controller (Allows Testing All States) */}
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-left">
                <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <span className="flex items-center gap-1.5 text-white">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Admin Review Simulator
                  </span>
                  <span>Test Transitions</span>
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={handleApproveAndSync}
                    className="py-2 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-black text-center transition-all shadow-md shadow-emerald-600/20"
                  >
                    Simulate Approval
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setVerificationStatus(
                        'REQUIRES_CHANGES',
                        'FSSAI document registration address does not match kitchen location pin.'
                      )
                    }
                    className="py-2 px-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-[11px] font-black text-center transition-all shadow-md shadow-amber-600/20"
                  >
                    Request Changes
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setVerificationStatus(
                        'REJECTED',
                        'Incomplete registration documents.'
                      )
                    }
                    className="py-2 px-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-black text-center transition-all shadow-md shadow-rose-600/20"
                  >
                    Reject
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Navigation Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3">
          {currentStep > 1 && currentStep < 6 ? (
            <button
              type="button"
              onClick={prevStep}
              className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          ) : (
            <div />
          )}

          {currentStep < 5 && (
            <button
              type="button"
              onClick={nextStep}
              className="py-2.5 px-5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white text-xs font-black flex items-center gap-1.5 transition-all shadow-md shadow-rose-500/25 ml-auto"
            >
              <span>Next Step</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          {currentStep === 5 && (
            <button
              type="button"
              onClick={submitForVerification}
              disabled={isLoading}
              className="py-3 px-6 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black flex items-center gap-2 transition-all shadow-lg shadow-emerald-600/30 ml-auto"
            >
              <FileCheck className="w-4 h-4" />
              <span>{isLoading ? 'Submitting Application...' : 'Submit for Verification'}</span>
            </button>
          )}

          {currentStep === 6 && (
            <button
              type="button"
              onClick={() => setIsOpenModal(false)}
              className="py-2.5 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all ml-auto"
            >
              Close Wizard
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
