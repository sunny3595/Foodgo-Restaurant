// ============================================================================
// FoodGo Restaurant - Configurable App & Brand Configuration
// ============================================================================

export interface SupportedCurrency {
  code: string;
  symbol: string;
  name: string;
  rateAgainstUSD: number;
}

export interface SupportedLanguage {
  code: string;
  name: string;
  nativeName: string;
}

export interface AppConfig {
  appName: string;
  tagline: string;
  version: string;
  buildNumber: string;
  primaryColor: string;
  accentColor: string;
  supportEmail: string;
  supportPhone: string;
  apiUrl: string;
  socketUrl: string;
  defaultCurrency: SupportedCurrency;
  availableCurrencies: SupportedCurrency[];
  defaultLanguage: string;
  availableLanguages: SupportedLanguage[];
  features: {
    kitchenDisplayMode: boolean;
    audioAlerts: boolean;
    biometricAuth: boolean;
    inventoryTracking: boolean;
    riderLiveMap: boolean;
    ticketPrinting: boolean;
  };
}

export const APP_CONFIG: AppConfig = {
  appName: 'FoodGo Restaurant',
  tagline: 'Merchant & Kitchen Terminal',
  version: '1.0.0',
  buildNumber: '100',
  primaryColor: '#FF4B2B', // Energetic food delivery brand primary
  accentColor: '#10B981',  // Emerald for online / accept / profit
  supportEmail: 'restaurant-support@foodgo.delivery',
  supportPhone: '+91 (800) 456-7890',
  apiUrl: '/api/v1',
  socketUrl: 'wss://realtime.foodgo.delivery/socket.io',
  defaultCurrency: {
    code: 'INR',
    symbol: '₹',
    name: 'Indian Rupee',
    rateAgainstUSD: 86.5,
  },
  availableCurrencies: [
    { code: 'INR', symbol: '₹', name: 'Indian Rupee', rateAgainstUSD: 86.5 },
    { code: 'USD', symbol: '$', name: 'US Dollar', rateAgainstUSD: 1.0 },
    { code: 'EUR', symbol: '€', name: 'Euro', rateAgainstUSD: 0.92 },
    { code: 'GBP', symbol: '£', name: 'British Pound', rateAgainstUSD: 0.78 },
    { code: 'AED', symbol: 'AED ', name: 'UAE Dirham', rateAgainstUSD: 3.67 },
  ],
  defaultLanguage: 'en',
  availableLanguages: [
    { code: 'en', name: 'English', nativeName: 'English' },
    { code: 'te', name: 'Telugu', nativeName: 'తెలుగు' },
    { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
    { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்' },
    { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ' },
    { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം' },
  ],
  features: {
    kitchenDisplayMode: true,
    audioAlerts: true,
    biometricAuth: true,
    inventoryTracking: true,
    riderLiveMap: true,
    ticketPrinting: true,
  },
};
