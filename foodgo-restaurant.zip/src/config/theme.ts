// ============================================================================
// FoodGo Restaurant - Theme & Semantic Design Tokens
// ============================================================================

import { OrderStatus, RestaurantAvailabilityStatus } from '../types';

export const THEME = {
  colors: {
    primary: {
      50: '#fff1ee',
      100: '#ffe4dd',
      200: '#ffccbe',
      500: '#ff4b2b', // Brand Primary
      600: '#ea3817',
      700: '#c5280b',
    },
    surface: {
      base: '#020617', // Slate 950
      card: '#0f172a', // Slate 900
      elevated: '#1e293b', // Slate 800
      border: '#334155', // Slate 700
      muted: '#64748b', // Slate 500
    },
    status: {
      open: '#10b981', // Emerald 500
      busy: '#f59e0b', // Amber 500
      paused: '#8b5cf6', // Violet 500
      closed: '#ef4444', // Red 500
    },
  },
  radius: {
    sm: '0.375rem',
    md: '0.5rem',
    lg: '0.75rem',
    xl: '1rem',
    full: '9999px',
  },
};

export interface OrderStatusConfig {
  label: string;
  shortLabel: string;
  textColor: string;
  bgColor: string;
  borderColor: string;
  accentColor: string;
  iconName: string;
}

export const ORDER_STATUS_MAP: Record<OrderStatus, OrderStatusConfig> = {
  NEW: {
    label: 'New Order',
    shortLabel: 'New',
    textColor: 'text-amber-300',
    bgColor: 'bg-amber-950/50',
    borderColor: 'border-amber-500/40',
    accentColor: '#f59e0b',
    iconName: 'Bell',
  },
  ACCEPTED: {
    label: 'Order Accepted',
    shortLabel: 'Accepted',
    textColor: 'text-sky-300',
    bgColor: 'bg-sky-950/50',
    borderColor: 'border-sky-500/40',
    accentColor: '#0ea5e9',
    iconName: 'CheckCircle',
  },
  PREPARING: {
    label: 'In Kitchen / Preparing',
    shortLabel: 'Preparing',
    textColor: 'text-orange-300',
    bgColor: 'bg-orange-950/50',
    borderColor: 'border-orange-500/40',
    accentColor: '#f97316',
    iconName: 'ChefHat',
  },
  READY_FOR_PICKUP: {
    label: 'Ready for Handover',
    shortLabel: 'Ready',
    textColor: 'text-emerald-300',
    bgColor: 'bg-emerald-950/50',
    borderColor: 'border-emerald-500/40',
    accentColor: '#10b981',
    iconName: 'PackageCheck',
  },
  RIDER_ASSIGNED: {
    label: 'Rider Heading In',
    shortLabel: 'Rider En Route',
    textColor: 'text-indigo-300',
    bgColor: 'bg-indigo-950/50',
    borderColor: 'border-indigo-500/40',
    accentColor: '#6366f1',
    iconName: 'Bike',
  },
  PICKED_UP: {
    label: 'Handed Over to Rider',
    shortLabel: 'Out for Delivery',
    textColor: 'text-purple-300',
    bgColor: 'bg-purple-950/50',
    borderColor: 'border-purple-500/40',
    accentColor: '#a855f7',
    iconName: 'Truck',
  },
  DELIVERED: {
    label: 'Delivered to Customer',
    shortLabel: 'Completed',
    textColor: 'text-emerald-400',
    bgColor: 'bg-emerald-950/30',
    borderColor: 'border-emerald-500/30',
    accentColor: '#059669',
    iconName: 'CheckCheck',
  },
  CANCELLED: {
    label: 'Order Cancelled',
    shortLabel: 'Cancelled',
    textColor: 'text-rose-400',
    bgColor: 'bg-rose-950/40',
    borderColor: 'border-rose-500/30',
    accentColor: '#f43f5e',
    iconName: 'XCircle',
  },
};

export const RESTAURANT_STATUS_CONFIG: Record<
  RestaurantAvailabilityStatus,
  { label: string; dotColor: string; badgeClass: string; description: string }
> = {
  OPEN: {
    label: 'Online & Accepting',
    dotColor: 'bg-emerald-500 shadow-emerald-500/50',
    badgeClass: 'text-emerald-400 bg-emerald-950/60 border-emerald-500/30',
    description: 'Customers can place orders. Kitchen is operating normally.',
  },
  BUSY: {
    label: 'Busy / Rush Hour',
    dotColor: 'bg-amber-500 shadow-amber-500/50',
    badgeClass: 'text-amber-400 bg-amber-950/60 border-amber-500/30',
    description: 'Orders accepted with extended estimated preparation times.',
  },
  PAUSED: {
    label: 'Orders Paused',
    dotColor: 'bg-violet-500 shadow-violet-500/50',
    badgeClass: 'text-violet-400 bg-violet-950/60 border-violet-500/30',
    description: 'Temporarily not accepting orders. Auto-reopens on timer.',
  },
  TEMPORARILY_UNAVAILABLE: {
    label: 'Unavailable',
    dotColor: 'bg-slate-400',
    badgeClass: 'text-slate-400 bg-slate-900 border-slate-700',
    description: 'Store is temporarily unavailable to customers.',
  },
  CLOSED: {
    label: 'Closed',
    dotColor: 'bg-rose-500 shadow-rose-500/50',
    badgeClass: 'text-rose-400 bg-rose-950/60 border-rose-500/30',
    description: 'Kitchen is closed outside business operating hours.',
  },
};
