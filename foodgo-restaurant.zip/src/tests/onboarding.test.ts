// ============================================================================
// FoodGo Restaurant - Phase 3 Onboarding Unit Tests
// Tests 6-step onboarding validations, documents, and verification lifecycle
// ============================================================================

import { onboardingService } from '../services/onboardingService';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`  ✓ PASS: ${testName}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${testName}`);
    failed++;
  }
}

async function runOnboardingTests() {
  console.log('--- RUNNING PHASE 3 ONBOARDING TESTS ---\n');

  // Test Suite 1: Initial State & Step Tracking
  console.log('Test Suite 1: Initial Onboarding State');
  const initial = onboardingService.getOnboardingData();
  assert(initial.account.name.length > 0, 'Initial owner account name populated');
  assert(initial.restaurant.name.length > 0, 'Initial restaurant name populated');
  assert(initial.location.latitude > 0, 'Initial location GPS coordinates set');
  assert(initial.business.cuisines.length > 0, 'Initial business cuisines selected');

  // Test Suite 2: Step Data Mutation
  console.log('\nTest Suite 2: Step Updates & Document Upload');
  const updated = onboardingService.saveStepData({
    restaurant: {
      ...initial.restaurant,
      name: 'Nawabi Charcoal Biryani House',
    },
  });
  assert(
    updated.restaurant.name === 'Nawabi Charcoal Biryani House',
    'Restaurant name updated successfully in draft'
  );

  const newDoc = await onboardingService.uploadDocument(
    'FSSAI_LICENSE',
    'fssai_renewed_2026.pdf',
    2.1
  );
  assert(newDoc.name === 'fssai_renewed_2026.pdf', 'Uploaded document name recorded');
  assert(newDoc.type === 'FSSAI_LICENSE', 'Document type tagged as FSSAI_LICENSE');
  assert(newDoc.verificationStatus === 'PENDING', 'Document initially tagged PENDING');

  // Test Suite 3: Verification Lifecycle Transitions
  console.log('\nTest Suite 3: Verification Transitions & State Machine');
  const submitted = await onboardingService.submitForVerification();
  assert(
    submitted.verification.status === 'PENDING_VERIFICATION',
    'Submitting transitions state to PENDING_VERIFICATION'
  );
  assert(submitted.step === 6, 'Submitting advances flow to step 6');

  const changesReq = onboardingService.setVerificationStatus(
    'REQUIRES_CHANGES',
    'Bank branch address mismatch'
  );
  assert(
    changesReq.verification.status === 'REQUIRES_CHANGES',
    'Compliance review can request changes'
  );

  const approved = onboardingService.setVerificationStatus(
    'APPROVED',
    'All KYC and food licenses verified'
  );
  assert(approved.verification.status === 'APPROVED', 'Compliance review can approve merchant');

  console.log(`\n--- RESULTS: ${passed} passed, ${failed} failed ---\n`);

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runOnboardingTests();
