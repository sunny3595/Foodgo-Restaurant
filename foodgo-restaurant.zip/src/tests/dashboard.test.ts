// ============================================================================
// FoodGo Restaurant - Phase 4 Restaurant Dashboard Unit Tests
// Tests metric calculations, revenue timeframes, inventory alerts, and store pause
// ============================================================================

import { dashboardService } from '../services/dashboardService';
import { INITIAL_ORDERS } from '../services/mockData';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`  ✓ PASS: ${testName}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${testName}`);
    failed++;
  }
}

function runDashboardTests() {
  console.log('--- RUNNING PHASE 4 RESTAURANT DASHBOARD TESTS ---\n');

  // Test Suite 1: Metrics Aggregation
  console.log('Test Suite 1: KPI & Metrics Aggregation');
  const metrics = dashboardService.calculateMetrics(INITIAL_ORDERS);
  assert(metrics.todaySales > 0, 'Today sales calculated from completed & active orders');
  assert(metrics.ordersCount === INITIAL_ORDERS.length, 'Orders count matches total order queue');
  assert(metrics.averageOrderValue > 0, 'Average Order Value (AOV) calculated correctly');
  assert(metrics.pendingOrdersCount >= 0, 'Pending orders counter computed');
  assert(metrics.preparingOrdersCount >= 0, 'Preparing orders counter computed');
  assert(metrics.readyOrdersCount >= 0, 'Ready orders counter computed');

  // Test Suite 2: Revenue Chart Series
  console.log('\nTest Suite 2: Multi-Timeframe Revenue Chart Series');
  const hourly = dashboardService.getRevenueSeries('HOURLY', INITIAL_ORDERS);
  assert(hourly.length === 12, 'Hourly timeframe produces 12 data intervals (11:00-22:00)');
  assert(hourly[0].revenue > 0, 'Hourly data points contain non-zero revenue values');

  const daily = dashboardService.getRevenueSeries('DAILY', INITIAL_ORDERS);
  assert(daily.length === 7, 'Daily timeframe produces 7 daily data points (Mon-Sun)');

  const weekly = dashboardService.getRevenueSeries('WEEKLY', INITIAL_ORDERS);
  assert(weekly.length === 4, 'Weekly timeframe produces 4 weekly data points');

  const monthly = dashboardService.getRevenueSeries('MONTHLY', INITIAL_ORDERS);
  assert(monthly.length === 6, 'Monthly timeframe produces 6 monthly trend points');

  // Test Suite 3: Top Selling Dishes
  console.log('\nTest Suite 3: Top Selling Items');
  const topSellers = dashboardService.getTopSellingItems();
  assert(topSellers.length >= 3, 'Top sellers list returns top ranked items');
  assert(topSellers[0].quantitySold >= topSellers[2].quantitySold, 'Items sorted by sales velocity');

  // Test Suite 4: Low Stock Inventory & 86 Item
  console.log('\nTest Suite 4: Low Stock Inventory Alerts');
  const alerts = dashboardService.getLowStockAlerts();
  assert(alerts.length >= 2, 'Low stock alerts populated');

  const target = alerts[0];
  const initialQty = target.currentStock;
  const restocked = dashboardService.restockItem(target.id, 10);
  const updatedItem = restocked.find((i) => i.id === target.id);
  assert(
    updatedItem?.currentStock === initialQty + 10,
    'Restocking increases item inventory count by 10'
  );

  const markedSoldOut = dashboardService.markSoldOut(target.id);
  const soldOutItem = markedSoldOut.find((i) => i.id === target.id);
  assert(soldOutItem?.isSoldOut === true, '86 Item sets isSoldOut flag to true');
  assert(soldOutItem?.currentStock === 0, '86 Item zeroes current stock');

  // Test Suite 5: Customer Ratings
  console.log('\nTest Suite 5: Customer Ratings & Compliments');
  const ratings = dashboardService.getRatingSummary();
  assert(ratings.averageRating >= 4.0, 'Average customer rating meets high standard');
  assert(ratings.breakdown.length === 5, 'Star breakdown includes 1 to 5 star ratings');
  assert(ratings.topCompliments.length > 0, 'Customer compliment tags available');

  console.log(`\n--- RESULTS: ${passed} passed, ${failed} failed ---\n`);

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runDashboardTests();
