// ============================================================================
// FoodGo Restaurant - Phase 2 Authentication Unit Tests
// Tests login, registration, OTP, password changes, sessions, and device revocation
// ============================================================================

import { authService, INITIAL_DEVICES } from '../services/authService';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`  ✓ PASS: ${testName}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${testName}`);
    failed++;
  }
}

async function runTests() {
  console.log('--- RUNNING PHASE 2 AUTHENTICATION TESTS ---\n');

  // Test Suite 1: Password Login & Role Resolution
  console.log('Test Suite 1: Email & Password Authentication');
  try {
    const res = await authService.loginWithPassword('vikram.owner@royalhyderabad.com', 'Secret@1234');
    assert(Boolean(res.tokens.accessToken), 'Valid login issues access token');
    assert(Boolean(res.tokens.refreshToken), 'Valid login issues refresh token');
    assert(res.user.role === 'RESTAURANT_OWNER', 'Owner email resolves RESTAURANT_OWNER role');
  } catch {
    assert(false, 'Valid login should succeed');
  }

  try {
    const mgrRes = await authService.loginWithPassword('priya.manager@royalhyderabad.com', 'Secret@1234');
    assert(mgrRes.user.role === 'RESTAURANT_MANAGER', 'Manager email resolves RESTAURANT_MANAGER role');
  } catch {
    assert(false, 'Manager login should succeed');
  }

  try {
    await authService.loginWithPassword('', 'Secret@1234');
    assert(false, 'Empty email should throw validation error');
  } catch (err: unknown) {
    assert(true, 'Empty email rejected with validation error');
  }

  try {
    await authService.loginWithPassword('user@domain.com', '123');
    assert(false, 'Short password (<6 chars) should be rejected');
  } catch (err: unknown) {
    assert(true, 'Short password rejected with validation error');
  }

  // Test Suite 2: Phone OTP Authentication
  console.log('\nTest Suite 2: Phone Number & SMS OTP Flow');
  try {
    const otpReq = await authService.requestPhoneOtp('+91 98765 43210');
    assert(otpReq.success, 'OTP request succeeds for valid 10+ digit phone');
    assert(otpReq.demoOtp === '458921', 'Demo OTP generated is 458921');

    const verifyRes = await authService.verifyPhoneOtp('+91 98765 43210', '458921');
    assert(Boolean(verifyRes.tokens.accessToken), 'Correct OTP successfully authenticates user');
  } catch {
    assert(false, 'Phone OTP flow failed');
  }

  try {
    await authService.verifyPhoneOtp('+91 98765 43210', '000000');
    assert(false, 'Incorrect OTP should fail verification');
  } catch {
    assert(true, 'Incorrect OTP rejected successfully');
  }

  // Test Suite 3: Registration
  console.log('\nTest Suite 3: Merchant Registration');
  try {
    const regRes = await authService.register({
      name: 'Chef Anand Varma',
      email: 'anand@kitchen.com',
      phone: '+91 91234 56789',
      password: 'StrongPassword@99',
      role: 'RESTAURANT_OWNER',
      restaurantName: 'Anand Tandoor Express',
    });
    assert(regRes.user.name === 'Chef Anand Varma', 'Registered user name matches payload');
    assert(regRes.user.role === 'RESTAURANT_OWNER', 'Registered user role assigned correctly');
  } catch {
    assert(false, 'Registration should succeed with valid data');
  }

  try {
    await authService.register({
      name: '',
      email: 'invalid',
      phone: '',
      password: '123',
      role: 'RESTAURANT_OWNER',
    });
    assert(false, 'Invalid registration payload should throw');
  } catch {
    assert(true, 'Invalid registration payload rejected');
  }

  // Test Suite 4: Password Management & Recovery
  console.log('\nTest Suite 4: Password Reset & Change');
  try {
    const resetReq = await authService.requestPasswordReset('vikram@royalhyderabad.com');
    assert(resetReq.success, 'Password reset instruction dispatched');

    const changed = await authService.changePassword({
      currentPassword: 'Secret@1234',
      newPassword: 'BrandNewSecurePassword@2026',
      confirmPassword: 'BrandNewSecurePassword@2026',
    });
    assert(changed, 'Password successfully changed when confirmation matches');
  } catch {
    assert(false, 'Password change flow failed');
  }

  try {
    await authService.changePassword({
      currentPassword: 'Secret@1234',
      newPassword: 'BrandNewSecurePassword@2026',
      confirmPassword: 'MismatchPassword',
    });
    assert(false, 'Mismatched passwords should throw error');
  } catch {
    assert(true, 'Mismatched passwords rejected');
  }

  // Test Suite 5: Device Management & Sessions
  console.log('\nTest Suite 5: Device Management & Revocation');
  const devices = authService.getActiveDevices();
  assert(devices.length >= 2, 'Initial active devices list populated');

  const targetDeviceId = devices.find((d) => !d.isCurrentDevice)?.id || 'dev_mac_03';
  const remaining = authService.revokeDevice(targetDeviceId);
  assert(
    !remaining.some((d) => d.id === targetDeviceId),
    `Device ${targetDeviceId} revoked from active sessions`
  );

  console.log(`\n--- RESULTS: ${passed} passed, ${failed} failed ---\n`);

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runTests();
