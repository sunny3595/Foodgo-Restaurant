// ============================================================================
// FoodGo Restaurant - Phase 5 Order Management Unit Tests
// Tests full order lifecycle, prep times, handover verification, and cancellations
// ============================================================================

import { useOrderStore } from '../store/useOrderStore';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`  ✓ PASS: ${testName}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${testName}`);
    failed++;
  }
}

function runOrderManagementTests() {
  console.log('--- RUNNING PHASE 5 ORDER MANAGEMENT TESTS ---\n');

  const store = useOrderStore.getState();

  // Test Suite 1: Order Acceptance & Prep Time
  console.log('Test Suite 1: Order Acceptance & Prep Time Computation');
  const targetNewOrder = store.orders.find((o) => o.status === 'NEW' && !o.isScheduled);
  assert(!!targetNewOrder, 'Target new order exists for test');

  if (targetNewOrder) {
    const acceptRes = store.acceptOrder(targetNewOrder.id, 25);
    assert(acceptRes.success === true, 'Accept order succeeds with 25 minutes prep time');

    const updated = useOrderStore.getState().orders.find((o) => o.id === targetNewOrder.id);
    assert(updated?.status === 'ACCEPTED', 'Order status transitioned to ACCEPTED');
    assert(updated?.confirmedPrepTimeMinutes === 25, 'Confirmed prep time set to 25 minutes');
    assert(!!updated?.expectedReadyTime, 'Expected ready timestamp calculated');

    // Test Suite 2: Kitchen Cooking Pipeline
    console.log('\nTest Suite 2: Kitchen Cooking & Ready Pipeline');
    const startPrepRes = store.startPreparing(targetNewOrder.id);
    assert(startPrepRes.success === true, 'Order transition to PREPARING succeeds');

    const prepOrder = useOrderStore.getState().orders.find((o) => o.id === targetNewOrder.id);
    assert(prepOrder?.status === 'PREPARING', 'Order status confirmed PREPARING');

    const markReadyRes = store.markReady(targetNewOrder.id);
    assert(markReadyRes.success === true, 'Marking order READY_FOR_PICKUP succeeds');

    const readyOrder = useOrderStore.getState().orders.find((o) => o.id === targetNewOrder.id);
    assert(readyOrder?.status === 'READY_FOR_PICKUP', 'Order status confirmed READY_FOR_PICKUP');

    // Test Suite 3: Driver Handover Verification
    console.log('\nTest Suite 3: Driver Handover Confirmation');
    const handoverRes = store.confirmHandover(targetNewOrder.id);
    assert(handoverRes.success === true, 'Handover confirmation transitions order to PICKED_UP');

    const pickedUpOrder = useOrderStore.getState().orders.find((o) => o.id === targetNewOrder.id);
    assert(pickedUpOrder?.status === 'PICKED_UP', 'Order status confirmed PICKED_UP');
  }

  // Test Suite 4: Order Cancellation & Lost Revenue
  console.log('\nTest Suite 4: Order Cancellation with Reason');
  const orderToCancel = useOrderStore.getState().orders.find((o) => o.status === 'NEW');
  if (orderToCancel) {
    const cancelRes = store.cancelOrder(orderToCancel.id, 'Item(s) Out of Stock (86)');
    assert(cancelRes.success === true, 'Cancellation executed successfully');

    const cancelledOrder = useOrderStore.getState().orders.find((o) => o.id === orderToCancel.id);
    assert(cancelledOrder?.status === 'CANCELLED', 'Order status updated to CANCELLED');
    assert(
      cancelledOrder?.rejectionNote === 'Item(s) Out of Stock (86)',
      'Cancellation reason recorded on order'
    );
  }

  // Test Suite 5: Scheduled Orders & Search
  console.log('\nTest Suite 5: Scheduled Orders & Multi-Attribute Search');
  const allOrders = useOrderStore.getState().orders;
  const scheduledOrders = allOrders.filter((o) => o.isScheduled);
  assert(scheduledOrders.length >= 1, 'Scheduled orders identified correctly in store');
  assert(!!scheduledOrders[0].scheduledFor, 'Scheduled order contains scheduledFor ISO timestamp');

  // Search verification
  const searchById = allOrders.filter((o) => o.orderNumber.includes('1024'));
  assert(searchById.length > 0, 'Search by order number matches order');

  const searchByPhone = allOrders.filter((o) => o.customer.phone.includes('99887'));
  assert(searchByPhone.length > 0, 'Search by customer phone number matches order');

  console.log(`\n--- RESULTS: ${passed} passed, ${failed} failed ---\n`);

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runOrderManagementTests();
