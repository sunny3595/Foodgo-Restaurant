// ============================================================================
// FoodGo Restaurant - Phase 1 Architecture Unit Tests
// Tests state machine transitions, RBAC permissions, and formatters
// ============================================================================

import { ROLE_PERMISSIONS, UserRole, Permission, OrderStatus } from '../types';
import { canTransitionOrder, hasPermission } from '../utils/validators';
import { formatCurrency, maskBankAccount, maskPhoneNumber } from '../utils/formatters';

let passed = 0;
let failed = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    console.log(`  ✓ PASS: ${testName}`);
    passed++;
  } else {
    console.error(`  ✗ FAIL: ${testName}`);
    failed++;
  }
}

console.log('--- RUNNING PHASE 1 ARCHITECTURE TESTS ---\n');

// 1. RBAC Tests
console.log('Test Suite 1: Role-Based Access Control (RBAC)');
assert(hasPermission('RESTAURANT_OWNER', 'finance.read'), 'Owner has financial read permission');
assert(hasPermission('RESTAURANT_OWNER', 'staff.manage'), 'Owner has staff management permission');
assert(hasPermission('RESTAURANT_STAFF', 'kitchen.view'), 'Staff has kitchen view permission');
assert(!hasPermission('RESTAURANT_STAFF', 'finance.payout'), 'Staff CANNOT access financial payouts');
assert(!hasPermission('RESTAURANT_STAFF', 'settings.update'), 'Staff CANNOT access settings update');

// 2. Order Finite State Machine Tests
console.log('\nTest Suite 2: Order State Machine Transitions');
assert(canTransitionOrder('NEW', 'ACCEPTED').allowed, 'Valid: NEW -> ACCEPTED');
assert(canTransitionOrder('ACCEPTED', 'PREPARING').allowed, 'Valid: ACCEPTED -> PREPARING');
assert(canTransitionOrder('PREPARING', 'READY_FOR_PICKUP').allowed, 'Valid: PREPARING -> READY_FOR_PICKUP');
assert(canTransitionOrder('READY_FOR_PICKUP', 'PICKED_UP').allowed, 'Valid: READY_FOR_PICKUP -> PICKED_UP');
assert(canTransitionOrder('PICKED_UP', 'DELIVERED').allowed, 'Valid: PICKED_UP -> DELIVERED');

// Negative State Machine Tests (Illegal state jumps)
assert(!canTransitionOrder('NEW', 'DELIVERED').allowed, 'BLOCKED: Illegal transition NEW -> DELIVERED');
assert(!canTransitionOrder('NEW', 'READY_FOR_PICKUP').allowed, 'BLOCKED: Illegal transition NEW -> READY_FOR_PICKUP');
assert(!canTransitionOrder('DELIVERED', 'PREPARING').allowed, 'BLOCKED: Terminal state DELIVERED -> PREPARING');

// 3. Formatting & Security Masking Tests
console.log('\nTest Suite 3: Formatting & Privacy Masking');
assert(formatCurrency(500, 'INR', '₹').includes('500'), 'Currency formatting includes amount');
assert(maskBankAccount('501004589211248') === '•••• •••• 1248', 'Bank account is masked with only last 4 digits visible');
assert(maskPhoneNumber('+91 98765 43210').includes('••••'), 'Customer phone number is masked for privacy');

console.log(`\n--- RESULTS: ${passed} passed, ${failed} failed ---\n`);

if (failed > 0) {
  process.exit(1);
} else {
  process.exit(0);
}
