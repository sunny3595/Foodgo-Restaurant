/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { MobileShell } from './components/layout/MobileShell';
import { realtimeService } from './services/realtimeService';
import { useRestaurantStore } from './store/useRestaurantStore';

export default function App() {
  const { profile } = useRestaurantStore();

  useEffect(() => {
    // Connect realtime socket on app startup
    realtimeService.connect(profile.id);
    return () => {
      realtimeService.disconnect();
    };
  }, [profile.id]);

  return <MobileShell />;
}

