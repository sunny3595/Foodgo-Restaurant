// ============================================================================
// FoodGo Restaurant - Utility Formatters
// ============================================================================

import { APP_CONFIG } from '../config/appConfig';

/**
 * Format currency amount with symbol and optional precision
 */
export function formatCurrency(
  amount: number,
  currencyCode = APP_CONFIG.defaultCurrency.code,
  currencySymbol = APP_CONFIG.defaultCurrency.symbol
): string {
  const formatted = new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(amount);

  return `${currencySymbol}${formatted}`;
}

/**
 * Format timestamp to 12-hour local time (e.g. "02:45 PM")
 */
export function formatTimeOnly(isoString: string): string {
  try {
    const d = new Date(isoString);
    return d.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    return isoString;
  }
}

/**
 * Format relative elapsed time (e.g. "4m ago", "Just now")
 */
export function formatTimeAgo(isoString: string): string {
  try {
    const now = Date.now();
    const past = new Date(isoString).getTime();
    const diffSeconds = Math.max(0, Math.floor((now - past) / 1000));

    if (diffSeconds < 60) return 'Just now';
    const diffMinutes = Math.floor(diffSeconds / 60);
    if (diffMinutes < 60) return `${diffMinutes}m ago`;
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${Math.floor(diffHours / 24)}d ago`;
  } catch {
    return 'Recent';
  }
}

/**
 * Format minutes remaining until target timestamp (e.g. "14 mins remaining")
 */
export function formatRemainingTime(targetIsoString?: string): {
  text: string;
  isOverdue: boolean;
  minutes: number;
} {
  if (!targetIsoString) {
    return { text: 'Time not set', isOverdue: false, minutes: 0 };
  }

  const now = Date.now();
  const target = new Date(targetIsoString).getTime();
  const diffMinutes = Math.round((target - now) / 60000);

  if (diffMinutes <= 0) {
    return {
      text: `${Math.abs(diffMinutes)}m overdue`,
      isOverdue: true,
      minutes: diffMinutes,
    };
  }

  return {
    text: `${diffMinutes}m left`,
    isOverdue: false,
    minutes: diffMinutes,
  };
}

/**
 * Mask sensitive bank account number: "XXXX XXXX 4589"
 */
export function maskBankAccount(accountNumber: string): string {
  if (!accountNumber) return '•••• •••• ••••';
  const clean = accountNumber.replace(/\s+/g, '');
  const lastFour = clean.slice(-4);
  return `•••• •••• ${lastFour}`;
}

/**
 * Mask customer phone number: "+91 98765 •••••"
 */
export function maskPhoneNumber(phone: string): string {
  if (!phone) return '••••••••••';
  if (phone.length < 8) return phone;
  const visiblePrefix = phone.slice(0, 7);
  return `${visiblePrefix} ••••`;
}
