// ============================================================================
// FoodGo Restaurant - Web Audio API Sound Synthesizer
// Zero external assets dependency. Produces instant alert tones.
// ============================================================================

class SoundManager {
  private ctx: AudioContext | null = null;
  private isSoundEnabled = true;

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setSoundEnabled(enabled: boolean) {
    this.isSoundEnabled = enabled;
  }

  public getSoundEnabled(): boolean {
    return this.isSoundEnabled;
  }

  /**
   * High-priority urgent double chime for incoming new orders
   * Replicates standard restaurant POS kitchen alert tones
   */
  public playNewOrderAlert() {
    if (!this.isSoundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Tone 1
    this.playTone(ctx, 880, now, 0.18, 0.25);
    // Tone 2 (higher fifth)
    this.playTone(ctx, 1318.51, now + 0.15, 0.28, 0.3);
    // Secondary chime echo
    this.playTone(ctx, 880, now + 0.45, 0.18, 0.25);
    this.playTone(ctx, 1318.51, now + 0.6, 0.35, 0.35);
  }

  /**
   * Smooth affirmative chime for order accepted / ready
   */
  public playSuccessChime() {
    if (!this.isSoundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    this.playTone(ctx, 523.25, now, 0.12, 0.15); // C5
    this.playTone(ctx, 659.25, now + 0.1, 0.12, 0.15); // E5
    this.playTone(ctx, 783.99, now + 0.2, 0.25, 0.2); // G5
  }

  /**
   * Low rejection or cancel tone
   */
  public playWarningTone() {
    if (!this.isSoundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    this.playTone(ctx, 330, now, 0.2, 0.2, 'sawtooth');
    this.playTone(ctx, 220, now + 0.18, 0.3, 0.25, 'sawtooth');
  }

  /**
   * Subtle click/tap sound for kitchen buttons
   */
  public playTap() {
    if (!this.isSoundEnabled) return;
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    this.playTone(ctx, 1200, now, 0.04, 0.05, 'triangle');
  }

  private playTone(
    ctx: AudioContext,
    freq: number,
    startTime: number,
    duration: number,
    volume: number,
    type: OscillatorType = 'sine'
  ) {
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, startTime);

      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(volume, startTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + duration);
    } catch {
      // Audio playback safely ignores any browser policy restrictions
    }
  }
}

export const soundManager = new SoundManager();
