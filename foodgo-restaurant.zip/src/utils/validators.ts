// ============================================================================
// FoodGo Restaurant - Business Logic & State Transition Validators
// ============================================================================

import { OrderStatus, Permission, ROLE_PERMISSIONS, UserRole } from '../types';

/**
 * Valid order status progression mapping
 * Enforces strict finite-state machine transitions
 */
export const VALID_ORDER_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  NEW: ['ACCEPTED', 'CANCELLED'],
  ACCEPTED: ['PREPARING', 'CANCELLED'],
  PREPARING: ['READY_FOR_PICKUP', 'CANCELLED'],
  READY_FOR_PICKUP: ['RIDER_ASSIGNED', 'PICKED_UP', 'CANCELLED'],
  RIDER_ASSIGNED: ['PICKED_UP', 'CANCELLED'],
  PICKED_UP: ['DELIVERED', 'CANCELLED'],
  DELIVERED: [], // Terminal state
  CANCELLED: [], // Terminal state
};

/**
 * Validates whether an order can transition from current to target status
 */
export function canTransitionOrder(
  currentStatus: OrderStatus,
  targetStatus: OrderStatus
): { allowed: boolean; reason?: string } {
  if (currentStatus === targetStatus) {
    return { allowed: false, reason: `Order is already in state ${currentStatus}` };
  }

  const allowedNext = VALID_ORDER_TRANSITIONS[currentStatus] || [];
  if (!allowedNext.includes(targetStatus)) {
    return {
      allowed: false,
      reason: `Illegal state transition from ${currentStatus} to ${targetStatus}. Valid transitions are: ${allowedNext.join(', ') || 'None (terminal)'}`,
    };
  }

  return { allowed: true };
}

/**
 * Role-Based Access Control Validator
 */
export function hasPermission(role: UserRole, permission: Permission): boolean {
  const permissions = ROLE_PERMISSIONS[role] || [];
  return permissions.includes(permission);
}

/**
 * Validate phone number format (E.164 or national format)
 */
export function isValidPhone(phone: string): boolean {
  const clean = phone.replace(/[\s\-\(\)\+]/g, '');
  return clean.length >= 10 && clean.length <= 15;
}

/**
 * Validate email address
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}
