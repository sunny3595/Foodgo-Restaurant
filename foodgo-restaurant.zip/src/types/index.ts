// ============================================================================
// FoodGo Restaurant Mobile Application - Core Type System
// ============================================================================

export type UserRole =
  | 'RESTAURANT_OWNER'
  | 'RESTAURANT_ADMIN'
  | 'RESTAURANT_MANAGER'
  | 'RESTAURANT_STAFF';

export type Permission =
  | 'orders.read'
  | 'orders.update'
  | 'orders.cancel'
  | 'menu.read'
  | 'menu.update'
  | 'analytics.read'
  | 'finance.read'
  | 'finance.payout'
  | 'settings.update'
  | 'staff.manage'
  | 'kitchen.view';

export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  RESTAURANT_OWNER: [
    'orders.read',
    'orders.update',
    'orders.cancel',
    'menu.read',
    'menu.update',
    'analytics.read',
    'finance.read',
    'finance.payout',
    'settings.update',
    'staff.manage',
    'kitchen.view',
  ],
  RESTAURANT_ADMIN: [
    'orders.read',
    'orders.update',
    'orders.cancel',
    'menu.read',
    'menu.update',
    'analytics.read',
    'finance.read',
    'settings.update',
    'kitchen.view',
  ],
  RESTAURANT_MANAGER: [
    'orders.read',
    'orders.update',
    'orders.cancel',
    'menu.read',
    'menu.update',
    'analytics.read',
    'kitchen.view',
  ],
  RESTAURANT_STAFF: [
    'orders.read',
    'orders.update',
    'menu.read',
    'kitchen.view',
  ],
};

export type RestaurantAvailabilityStatus =
  | 'OPEN'
  | 'CLOSED'
  | 'TEMPORARILY_UNAVAILABLE'
  | 'BUSY'
  | 'PAUSED';

export type PauseReason =
  | 'TOO_BUSY'
  | 'KITCHEN_MAINTENANCE'
  | 'OUT_OF_INGREDIENTS'
  | 'STAFF_SHORTAGE'
  | 'CUSTOM';

export type OrderStatus =
  | 'NEW'
  | 'ACCEPTED'
  | 'PREPARING'
  | 'READY_FOR_PICKUP'
  | 'RIDER_ASSIGNED'
  | 'PICKED_UP'
  | 'DELIVERED'
  | 'CANCELLED';

export type OrderRejectionReason =
  | 'RESTAURANT_BUSY'
  | 'ITEM_UNAVAILABLE'
  | 'KITCHEN_CLOSED'
  | 'DELIVERY_UNAVAILABLE'
  | 'OUT_OF_STOCK'
  | 'OTHER';

export type DeliveryType = 'DELIVERY' | 'PICKUP';

export type PaymentMethod = 'ONLINE_UPI' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'CASH_ON_DELIVERY' | 'WALLET';
export type PaymentStatus = 'PENDING' | 'PAID' | 'REFUNDED' | 'FAILED';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatarUrl?: string;
  restaurantId: string;
  createdAt: string;
}

export interface BusinessDayHours {
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';
  isOpen: boolean;
  openTime: string; // e.g. "11:00"
  closeTime: string; // e.g. "23:00"
  breakStart?: string;
  breakEnd?: string;
}

export interface RestaurantProfile {
  id: string;
  name: string;
  slug: string;
  description: string;
  cuisine: string[];
  logoUrl: string;
  coverImageUrl: string;
  phone: string;
  email: string;
  status: RestaurantAvailabilityStatus;
  pauseReason?: PauseReason;
  pausedUntil?: string; // ISO string
  rating: number;
  totalReviews: number;
  deliveryRadiusKm: number;
  minimumOrderAmount: number;
  averagePrepTimeMinutes: number;
  deliveryFee: number;
  isDeliveryEnabled: boolean;
  isPickupEnabled: boolean;
  currency: string;
  currencySymbol: string;
  address: {
    street: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
    latitude: number;
    longitude: number;
  };
  businessHours: BusinessDayHours[];
  taxSettings: {
    taxRatePercent: number; // e.g. 5% GST
    taxName: string; // e.g. "GST"
  };
}

export interface FoodVariationOption {
  id: string;
  name: string;
  price: number;
  isDefault?: boolean;
}

export interface FoodVariation {
  id: string;
  name: string; // e.g. "Size" or "Portion"
  options: FoodVariationOption[];
}

export interface FoodAddon {
  id: string;
  name: string;
  price: number;
  isAvailable: boolean;
}

export interface FoodAddonGroup {
  id: string;
  name: string; // e.g. "Extra Toppings"
  isRequired: boolean;
  minSelections: number;
  maxSelections: number;
  addons: FoodAddon[];
}

export interface FoodItem {
  id: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  discountPrice?: number;
  imageUrl: string;
  isVegetarian: boolean;
  isAvailable: boolean;
  isFeatured?: boolean;
  preparationTimeMinutes: number;
  spicinessLevel: 0 | 1 | 2 | 3; // 0=None, 1=Mild, 2=Medium, 3=Hot
  currentStock?: number;
  lowStockThreshold?: number;
  trackInventory?: boolean;
  variations?: FoodVariation[];
  addonGroups?: FoodAddonGroup[];
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  displayOrder: number;
  imageUrl?: string;
  isActive: boolean;
}

export interface OrderItem {
  id: string;
  foodId: string;
  name: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  selectedVariation?: {
    groupName: string;
    optionName: string;
    price: number;
  };
  selectedAddons?: {
    addonId: string;
    name: string;
    price: number;
  }[];
  specialInstructions?: string;
}

export interface CustomerInfo {
  id: string;
  name: string;
  phone: string;
  deliveryAddress: string;
  totalPreviousOrders: number;
  avatarUrl?: string;
}

export interface RiderInfo {
  id: string;
  name: string;
  phone: string;
  avatarUrl?: string;
  vehicleNumber: string;
  vehicleType: 'BIKE' | 'SCOOTER' | 'BICYCLE';
  currentStatus: 'ASSIGNED' | 'HEADING_TO_RESTAURANT' | 'ARRIVED_AT_RESTAURANT' | 'PICKED_UP' | 'OUT_FOR_DELIVERY';
  rating: number;
}

export interface OrderTimelineEvent {
  status: OrderStatus;
  timestamp: string;
  title: string;
  description?: string;
}

export interface FinancialBreakdown {
  subtotal: number;
  discountAmount: number;
  taxAmount: number;
  deliveryFee: number;
  platformCommission: number; // Commission deducted by platform
  platformCommissionRate: number; // e.g. 0.15 (15%)
  restaurantNetEarnings: number; // subtotal - discount + tax - commission
  customerTotal: number;
}

export interface Order {
  id: string;
  orderNumber: string; // e.g. "#FG-1024"
  restaurantId: string;
  status: OrderStatus;
  deliveryType: DeliveryType;
  customer: CustomerInfo;
  rider?: RiderInfo;
  items: OrderItem[];
  financials: FinancialBreakdown;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  specialInstructions?: string;
  createdAt: string;
  isScheduled?: boolean;
  scheduledFor?: string; // ISO timestamp
  confirmedPrepTimeMinutes?: number;
  expectedReadyTime?: string;
  rejectionReason?: OrderRejectionReason;
  rejectionNote?: string;
  timeline: OrderTimelineEvent[];
}

export type RealtimeEventType =
  | 'order.created'
  | 'order.updated'
  | 'order.accepted'
  | 'order.rejected'
  | 'order.preparing'
  | 'order.ready'
  | 'rider.assigned'
  | 'rider.arrived'
  | 'order.picked_up'
  | 'order.delivered'
  | 'order.cancelled'
  | 'restaurant.status_changed';

export interface RealtimeEvent<T = unknown> {
  id: string;
  type: RealtimeEventType;
  restaurantId: string;
  timestamp: string;
  payload: T;
}

export type ConnectionState = 'CONNECTING' | 'CONNECTED' | 'RECONNECTING' | 'DISCONNECTED';
