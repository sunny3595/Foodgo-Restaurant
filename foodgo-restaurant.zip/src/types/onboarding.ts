// ============================================================================
// FoodGo Restaurant - Onboarding Domain Types (Phase 3)
// ============================================================================

export type OnboardingVerificationStatus =
  | 'NOT_STARTED'
  | 'IN_PROGRESS'
  | 'PENDING_VERIFICATION'
  | 'APPROVED'
  | 'REJECTED'
  | 'REQUIRES_CHANGES';

export type RestaurantType =
  | 'DINE_IN_RESTAURANT'
  | 'CLOUD_KITCHEN'
  | 'CAFE_AND_BAKERY'
  | 'FAST_FOOD_QSR'
  | 'SWEETS_AND_SNACKS'
  | 'GROCERY_AND_GOURMET';

export interface UploadedDocument {
  id: string;
  name: string;
  type: 'FSSAI_LICENSE' | 'GST_CERTIFICATE' | 'PAN_CARD' | 'CANCELLED_CHEQUE' | 'KITCHEN_PHOTO';
  fileSizeMb: number;
  uploadedAt: string;
  verificationStatus: 'PENDING' | 'VERIFIED' | 'REJECTED';
}

export interface OnboardingData {
  step: number; // 1 to 6
  account: {
    name: string;
    email: string;
    phone: string;
    role: string;
  };
  restaurant: {
    name: string;
    type: RestaurantType;
    description: string;
    logoUrl: string;
    coverImageUrl: string;
    phone: string;
    email: string;
  };
  location: {
    address: string;
    landmark?: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
    latitude: number;
    longitude: number;
  };
  business: {
    cuisines: string[];
    openTime: string;
    closeTime: string;
    deliveryRadiusKm: number;
    minimumOrderAmount: number;
    averagePrepTimeMinutes: number;
    hasMultipleShifts?: boolean;
  };
  legal: {
    businessRegistrationNumber: string;
    taxId: string; // GST/VAT
    bankHolderName: string;
    bankName: string;
    accountNumber: string;
    ifscOrRoutingCode: string;
    documents: UploadedDocument[];
  };
  verification: {
    status: OnboardingVerificationStatus;
    submittedAt?: string;
    reviewedAt?: string;
    reviewerNotes?: string;
    rejectionReason?: string;
  };
}
