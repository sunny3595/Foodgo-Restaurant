// ============================================================================
// FoodGo Restaurant - Authentication Domain Types
// ============================================================================

import { UserProfile, UserRole } from './index';

export type AuthScreenState =
  | 'SPLASH'
  | 'LOGIN'
  | 'REGISTER'
  | 'OTP_VERIFY'
  | 'FORGOT_PASSWORD'
  | 'RESET_PASSWORD';

export interface DeviceSession {
  id: string;
  deviceName: string;
  deviceType: 'IOS' | 'ANDROID' | 'WEB' | 'TABLET';
  browserOrOs: string;
  ipAddress: string;
  location: string;
  isCurrentDevice: boolean;
  lastActiveAt: string;
  createdAt: string;
}

export interface LoginCredentials {
  email: string;
  password?: string;
  phone?: string;
  otp?: string;
  method: 'PASSWORD' | 'OTP' | 'BIOMETRIC' | 'GOOGLE' | 'APPLE';
}

export interface RegisterCredentials {
  name: string;
  email: string;
  phone: string;
  password: string;
  role: UserRole;
  restaurantName?: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresInSeconds: number;
}

export interface AuthResponse {
  user: UserProfile;
  tokens: AuthTokens;
  activeSessions: DeviceSession[];
}

export interface PasswordChangePayload {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}
