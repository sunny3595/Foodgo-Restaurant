// ============================================================================
// FoodGo Restaurant - Dashboard Domain Types (Phase 4)
// Directly implements Master Prompt Section 6: Metrics & Quick Actions
// ============================================================================

export type RevenueTimeframe = 'HOURLY' | 'DAILY' | 'WEEKLY' | 'MONTHLY';

export interface RevenueDataPoint {
  label: string;
  revenue: number;
  orders: number;
}

export interface TopSellingItem {
  id: string;
  name: string;
  category: string;
  quantitySold: number;
  revenue: number;
  growthPercent: number;
  imageUrl: string;
}

export interface LowStockAlertItem {
  id: string;
  name: string;
  category: string;
  currentStock: number;
  minimumThreshold: number;
  unit: string;
  isSoldOut: boolean;
}

export interface RatingSummary {
  averageRating: number;
  totalReviews: number;
  satisfactionRate: number; // e.g. 96%
  breakdown: {
    stars: 1 | 2 | 3 | 4 | 5;
    count: number;
    percentage: number;
  }[];
  topCompliments: {
    tag: string;
    count: number;
  }[];
}

export interface PauseStoreConfig {
  isPaused: boolean;
  pausedUntil: string | null;
  durationLabel: string | null;
  reason: string | null;
}

export interface EmergencyCloseConfig {
  isEmergencyClosed: boolean;
  closedAt: string | null;
  reason: string | null;
}

export interface DashboardMetrics {
  todaySales: number;
  ordersCount: number;
  averageOrderValue: number;
  pendingOrdersCount: number;
  preparingOrdersCount: number;
  readyOrdersCount: number;
  completedOrdersCount: number;
  cancelledOrdersCount: number;
  salesGrowthPercent: number;
  ordersGrowthPercent: number;
}
