// ============================================================================
// FoodGo Restaurant - API Client Architecture & Security Interceptors
// ============================================================================

import { APP_CONFIG } from '../config/appConfig';

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
  timestamp: string;
}

export interface RequestOptions extends RequestInit {
  idempotencyKey?: string;
  skipAuth?: boolean;
}

class ApiClient {
  private baseUrl: string = APP_CONFIG.apiUrl;
  private authToken: string | null = null;
  private refreshToken: string | null = null;
  private isRefreshing = false;

  constructor() {
    // Initialize token from storage if present
    if (typeof window !== 'undefined') {
      this.authToken = localStorage.getItem('foodgo_auth_token');
      this.refreshToken = localStorage.getItem('foodgo_refresh_token');
    }
  }

  public setTokens(token: string | null, refreshToken: string | null) {
    this.authToken = token;
    this.refreshToken = refreshToken;
    if (typeof window !== 'undefined') {
      if (token) {
        localStorage.setItem('foodgo_auth_token', token);
      } else {
        localStorage.removeItem('foodgo_auth_token');
      }
      if (refreshToken) {
        localStorage.setItem('foodgo_refresh_token', refreshToken);
      } else {
        localStorage.removeItem('foodgo_refresh_token');
      }
    }
  }

  public getAuthToken(): string | null {
    return this.authToken;
  }

  /**
   * Generates a cryptographically strong UUID for request idempotency
   */
  public generateIdempotencyKey(): string {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      return crypto.randomUUID();
    }
    return `idem_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  }

  /**
   * Universal Request Handler
   */
  public async request<T>(
    endpoint: string,
    options: RequestOptions = {}
  ): Promise<ApiResponse<T>> {
    // Check client connectivity
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      return {
        success: false,
        error: {
          code: 'NETWORK_OFFLINE',
          message: 'No internet connection. Please check your network and retry.',
        },
        timestamp: new Date().toISOString(),
      };
    }

    const headers = new Headers(options.headers || {});
    headers.set('Content-Type', 'application/json');
    headers.set('X-App-Version', APP_CONFIG.version);
    headers.set('X-Client-Platform', 'Mobile-Web-PWA');

    // Injects Idempotency key for mutation safety
    if (options.idempotencyKey) {
      headers.set('X-Idempotency-Key', options.idempotencyKey);
    } else if (options.method && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(options.method)) {
      headers.set('X-Idempotency-Key', this.generateIdempotencyKey());
    }

    // Inject Bearer token
    if (!options.skipAuth && this.authToken) {
      headers.set('Authorization', `Bearer ${this.authToken}`);
    }

    const url = endpoint.startsWith('http') ? endpoint : `${this.baseUrl}${endpoint}`;

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      // Handle 401 Unauthorized token refresh
      if (response.status === 401 && !options.skipAuth && this.refreshToken && !this.isRefreshing) {
        const refreshed = await this.attemptTokenRefresh();
        if (refreshed) {
          // Retry original request with renewed token
          return this.request<T>(endpoint, options);
        }
      }

      const json = await response.json().catch(() => null);

      if (!response.ok) {
        return {
          success: false,
          error: {
            code: json?.error?.code || `HTTP_${response.status}`,
            message: json?.error?.message || response.statusText || 'Server error occurred',
            details: json?.error?.details,
          },
          timestamp: new Date().toISOString(),
        };
      }

      return {
        success: true,
        data: json?.data ?? (json as T),
        timestamp: new Date().toISOString(),
      };
    } catch (err: unknown) {
      const errMessage = err instanceof Error ? err.message : 'Network request failed';
      return {
        success: false,
        error: {
          code: 'FETCH_ERROR',
          message: errMessage,
        },
        timestamp: new Date().toISOString(),
      };
    }
  }

  private async attemptTokenRefresh(): Promise<boolean> {
    this.isRefreshing = true;
    try {
      const res = await fetch(`${this.baseUrl}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: this.refreshToken }),
      });
      const data = await res.json().catch(() => null);
      if (res.ok && data?.token) {
        this.setTokens(data.token, data.refreshToken || this.refreshToken);
        this.isRefreshing = false;
        return true;
      }
    } catch {
      // refresh failure
    }
    this.isRefreshing = false;
    this.setTokens(null, null);
    return false;
  }
}

export const apiClient = new ApiClient();
