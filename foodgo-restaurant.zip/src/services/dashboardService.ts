// ============================================================================
// FoodGo Restaurant - Dashboard Analytics & Metrics Service
// Aggregates real-time sales, order funnels, charts, and inventory alerts
// ============================================================================

import {
  DashboardMetrics,
  LowStockAlertItem,
  RatingSummary,
  RevenueDataPoint,
  RevenueTimeframe,
  TopSellingItem,
} from '../types/dashboard';
import { Order } from '../types';

export const INITIAL_TOP_SELLERS: TopSellingItem[] = [
  {
    id: 'top_01',
    name: 'Royal Hyderabadi Mutton Dum Biryani',
    category: 'Dum Biryani',
    quantitySold: 142,
    revenue: 69438,
    growthPercent: 18.4,
    imageUrl: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=400&q=80',
  },
  {
    id: 'top_02',
    name: 'Special Chicken Dum Biryani (Handi)',
    category: 'Dum Biryani',
    quantitySold: 188,
    revenue: 69372,
    growthPercent: 12.1,
    imageUrl: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=400&q=80',
  },
  {
    id: 'top_03',
    name: 'Galouti Mutton Kebabs (6 Pcs)',
    category: 'Kebabs & Starters',
    quantitySold: 94,
    revenue: 39386,
    growthPercent: 24.5,
    imageUrl: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?auto=format&fit=crop&w=400&q=80',
  },
  {
    id: 'top_04',
    name: 'Authentic Hyderabadi Double Ka Meetha',
    category: 'Desserts',
    quantitySold: 110,
    revenue: 20900,
    growthPercent: 8.7,
    imageUrl: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=400&q=80',
  },
];

export const INITIAL_LOW_STOCK_ITEMS: LowStockAlertItem[] = [
  {
    id: 'low_01',
    name: 'Zaffrani Basmati Long Grain Rice',
    category: 'Pantry Ingredients',
    currentStock: 4,
    minimumThreshold: 15,
    unit: 'kg bags',
    isSoldOut: false,
  },
  {
    id: 'low_02',
    name: 'Special Biryani Masala Potli Spices',
    category: 'Secret Spice Blends',
    currentStock: 2,
    minimumThreshold: 10,
    unit: 'pouches',
    isSoldOut: false,
  },
  {
    id: 'low_03',
    name: 'Clay Handi Pots (Single Serve)',
    category: 'Packaging Materials',
    currentStock: 12,
    minimumThreshold: 50,
    unit: 'pots',
    isSoldOut: false,
  },
  {
    id: 'low_04',
    name: 'Pure Desi Ghee (Cultured A2)',
    category: 'Dairy',
    currentStock: 0,
    minimumThreshold: 5,
    unit: 'liters',
    isSoldOut: true,
  },
];

export const INITIAL_RATING_SUMMARY: RatingSummary = {
  averageRating: 4.86,
  totalReviews: 1248,
  satisfactionRate: 97.2,
  breakdown: [
    { stars: 5, count: 1060, percentage: 85 },
    { stars: 4, count: 137, percentage: 11 },
    { stars: 3, count: 32, percentage: 2.5 },
    { stars: 2, count: 12, percentage: 1 },
    { stars: 1, count: 7, percentage: 0.5 },
  ],
  topCompliments: [
    { tag: 'Aromatic & Authentic Taste', count: 742 },
    { tag: 'Piping Hot Packaging', count: 618 },
    { tag: 'Tender Slow-Cooked Meat', count: 580 },
    { tag: 'Generous Portions', count: 495 },
  ],
};

class DashboardService {
  private lowStockItems: LowStockAlertItem[] = [...INITIAL_LOW_STOCK_ITEMS];

  /**
   * Calculates live KPIs based on active and historical orders
   */
  public calculateMetrics(orders: Order[]): DashboardMetrics {
    const validOrders = orders.filter((o) => o.status !== 'CANCELLED');
    const todaySales = validOrders.reduce((sum, o) => sum + o.financials.restaurantNetEarnings, 0);
    const ordersCount = orders.length;
    const averageOrderValue = ordersCount > 0 ? Math.round(todaySales / (validOrders.length || 1)) : 0;

    return {
      todaySales,
      ordersCount,
      averageOrderValue,
      pendingOrdersCount: orders.filter((o) => o.status === 'NEW').length,
      preparingOrdersCount: orders.filter((o) => o.status === 'PREPARING').length,
      readyOrdersCount: orders.filter((o) => o.status === 'READY_FOR_PICKUP').length,
      completedOrdersCount: orders.filter((o) => o.status === 'DELIVERED').length,
      cancelledOrdersCount: orders.filter((o) => o.status === 'CANCELLED').length,
      salesGrowthPercent: 14.8,
      ordersGrowthPercent: 9.2,
    };
  }

  /**
   * Generates interactive revenue series data for the visual chart
   */
  public getRevenueSeries(timeframe: RevenueTimeframe, orders: Order[]): RevenueDataPoint[] {
    const baseRevenue = orders
      .filter((o) => o.status !== 'CANCELLED')
      .reduce((sum, o) => sum + o.financials.restaurantNetEarnings, 0);

    if (timeframe === 'HOURLY') {
      return [
        { label: '11:00', revenue: 1450, orders: 3 },
        { label: '12:00', revenue: 3200, orders: 7 },
        { label: '13:00', revenue: 6850, orders: 14 },
        { label: '14:00', revenue: 5400, orders: 11 },
        { label: '15:00', revenue: 2100, orders: 4 },
        { label: '16:00', revenue: 1800, orders: 4 },
        { label: '17:00', revenue: 2900, orders: 6 },
        { label: '18:00', revenue: 4200, orders: 9 },
        { label: '19:00', revenue: 7600, orders: 16 },
        { label: '20:00', revenue: 9800, orders: 20 },
        { label: '21:00', revenue: 8400, orders: 17 },
        { label: '22:00', revenue: 4100, orders: 8 },
      ];
    }

    if (timeframe === 'DAILY') {
      return [
        { label: 'Mon', revenue: 28400, orders: 58 },
        { label: 'Tue', revenue: 31200, orders: 64 },
        { label: 'Wed', revenue: 29800, orders: 61 },
        { label: 'Thu', revenue: 34500, orders: 70 },
        { label: 'Fri', revenue: 48900, orders: 98 },
        { label: 'Sat', revenue: 62400, orders: 124 },
        { label: 'Sun (Today)', revenue: Math.max(baseRevenue, 57800), orders: 118 },
      ];
    }

    if (timeframe === 'WEEKLY') {
      return [
        { label: 'Week 1', revenue: 198400, orders: 410 },
        { label: 'Week 2', revenue: 215600, orders: 442 },
        { label: 'Week 3', revenue: 234800, orders: 480 },
        { label: 'Week 4 (Cur)', revenue: 268900, orders: 535 },
      ];
    }

    // MONTHLY
    return [
      { label: 'Oct', revenue: 780000, orders: 1620 },
      { label: 'Nov', revenue: 840000, orders: 1750 },
      { label: 'Dec', revenue: 990000, orders: 2080 },
      { label: 'Jan', revenue: 890000, orders: 1840 },
      { label: 'Feb', revenue: 920000, orders: 1910 },
      { label: 'Mar', revenue: 1050000, orders: 2190 },
    ];
  }

  public getTopSellingItems(): TopSellingItem[] {
    return [...INITIAL_TOP_SELLERS];
  }

  public getLowStockAlerts(): LowStockAlertItem[] {
    return [...this.lowStockItems];
  }

  public restockItem(itemId: string, addQuantity: number): LowStockAlertItem[] {
    this.lowStockItems = this.lowStockItems.map((item) => {
      if (item.id === itemId) {
        const nextStock = item.currentStock + addQuantity;
        return {
          ...item,
          currentStock: nextStock,
          isSoldOut: nextStock <= 0,
        };
      }
      return item;
    });
    return [...this.lowStockItems];
  }

  public markSoldOut(itemId: string): LowStockAlertItem[] {
    this.lowStockItems = this.lowStockItems.map((item) => {
      if (item.id === itemId) {
        return {
          ...item,
          currentStock: 0,
          isSoldOut: true,
        };
      }
      return item;
    });
    return [...this.lowStockItems];
  }

  public getRatingSummary(): RatingSummary {
    return { ...INITIAL_RATING_SUMMARY };
  }
}

export const dashboardService = new DashboardService();
