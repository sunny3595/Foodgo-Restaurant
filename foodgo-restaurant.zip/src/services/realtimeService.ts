// ============================================================================
// FoodGo Restaurant - Real-Time Event Architecture & WebSocket Manager
// ============================================================================

import { ConnectionState, RealtimeEvent, RealtimeEventType } from '../types';
import { soundManager } from '../utils/sound';

type EventListener<T = unknown> = (event: RealtimeEvent<T>) => void;

class RealtimeService {
  private listeners: Map<RealtimeEventType | '*', Set<EventListener>> = new Map();
  private connectionState: ConnectionState = 'DISCONNECTED';
  private connectionListeners: Set<(state: ConnectionState) => void> = new Set();
  private reconnectTimer: NodeJS.Timeout | null = null;
  private heartbeatTimer: NodeJS.Timeout | null = null;

  public connect(restaurantId: string) {
    if (this.connectionState === 'CONNECTED' || this.connectionState === 'CONNECTING') {
      return;
    }

    this.setConnectionState('CONNECTING');

    // Simulate resilient WebSocket connection handshake
    setTimeout(() => {
      this.setConnectionState('CONNECTED');
      this.startHeartbeat();
      console.log(`[RealtimeService] Connected for restaurant: ${restaurantId}`);
    }, 600);
  }

  public disconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.setConnectionState('DISCONNECTED');
  }

  public getConnectionState(): ConnectionState {
    return this.connectionState;
  }

  public onConnectionChange(callback: (state: ConnectionState) => void): () => void {
    this.connectionListeners.add(callback);
    callback(this.connectionState);
    return () => {
      this.connectionListeners.delete(callback);
    };
  }

  /**
   * Subscribe to specific or wildcard real-time events
   */
  public subscribe<T = unknown>(
    eventType: RealtimeEventType | '*',
    listener: EventListener<T>
  ): () => void {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, new Set());
    }
    const set = this.listeners.get(eventType)!;
    set.add(listener as EventListener);

    return () => {
      set.delete(listener as EventListener);
    };
  }

  /**
   * Dispatches incoming event across subscribers & handles notification/audio
   */
  public dispatch<T = unknown>(event: RealtimeEvent<T>) {
    // If incoming new order, trigger urgent audio chime
    if (event.type === 'order.created') {
      soundManager.playNewOrderAlert();
    } else if (event.type === 'order.accepted' || event.type === 'order.ready') {
      soundManager.playSuccessChime();
    } else if (event.type === 'order.cancelled' || event.type === 'order.rejected') {
      soundManager.playWarningTone();
    }

    // Notify specific listeners
    const specificListeners = this.listeners.get(event.type);
    if (specificListeners) {
      specificListeners.forEach((listener) => {
        try {
          listener(event as RealtimeEvent);
        } catch (err) {
          console.error(`[RealtimeService] Error executing listener for ${event.type}:`, err);
        }
      });
    }

    // Notify wildcard listeners
    const wildcardListeners = this.listeners.get('*');
    if (wildcardListeners) {
      wildcardListeners.forEach((listener) => {
        try {
          listener(event as RealtimeEvent);
        } catch (err) {
          console.error('[RealtimeService] Error executing wildcard listener:', err);
        }
      });
    }
  }

  private setConnectionState(state: ConnectionState) {
    this.connectionState = state;
    this.connectionListeners.forEach((cb) => cb(state));
  }

  private startHeartbeat() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = setInterval(() => {
      if (this.connectionState === 'CONNECTED') {
        // Ping-pong heartbeat keeps connection healthy
      }
    }, 25000);
  }
}

export const realtimeService = new RealtimeService();
