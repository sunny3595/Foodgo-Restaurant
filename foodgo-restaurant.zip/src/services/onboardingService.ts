// ============================================================================
// FoodGo Restaurant - Onboarding & Merchant Verification Service
// ============================================================================

import {
  OnboardingData,
  OnboardingVerificationStatus,
  UploadedDocument,
} from '../types/onboarding';

export const INITIAL_ONBOARDING_STATE: OnboardingData = {
  step: 1,
  account: {
    name: 'Vikramaditya Rao',
    email: 'vikram.owner@royalhyderabad.com',
    phone: '+91 98765 43210',
    role: 'RESTAURANT_OWNER',
  },
  restaurant: {
    name: 'Royal Hyderabad Dum Biryani & Kebabs',
    type: 'CLOUD_KITCHEN',
    description: 'Authentic charcoal kebabs and handi dum biryani prepared fresh daily.',
    logoUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=200&q=80',
    coverImageUrl: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&w=1200&q=80',
    phone: '+91 40 2345 6789',
    email: 'contact@royalhyderabad.com',
  },
  location: {
    address: 'Plot 42, Silicon Valley Avenue, Madhapur',
    landmark: 'Opposite Cyber Towers',
    city: 'Hyderabad',
    state: 'Telangana',
    country: 'India',
    postalCode: '500081',
    latitude: 17.4483,
    longitude: 78.3915,
  },
  business: {
    cuisines: ['Hyderabadi', 'Biryani', 'Mughlai', 'Tandoor'],
    openTime: '11:00',
    closeTime: '23:30',
    deliveryRadiusKm: 8.5,
    minimumOrderAmount: 200,
    averagePrepTimeMinutes: 22,
  },
  legal: {
    businessRegistrationNumber: 'U55101TG2022PTC160124',
    taxId: '36AAAAA0000A1Z5', // GSTIN
    bankHolderName: 'Royal Hyderabad Kitchens Pvt Ltd',
    bankName: 'HDFC Bank Ltd',
    accountNumber: '501002348914589',
    ifscOrRoutingCode: 'HDFC0001248',
    documents: [
      {
        id: 'doc_fssai_01',
        name: 'FSSAI_Food_Safety_License_2026.pdf',
        type: 'FSSAI_LICENSE',
        fileSizeMb: 1.8,
        uploadedAt: '2024-03-01T12:00:00.000Z',
        verificationStatus: 'VERIFIED',
      },
      {
        id: 'doc_gst_02',
        name: 'GST_Registration_Certificate.pdf',
        type: 'GST_CERTIFICATE',
        fileSizeMb: 1.2,
        uploadedAt: '2024-03-01T12:05:00.000Z',
        verificationStatus: 'VERIFIED',
      },
    ],
  },
  verification: {
    status: 'APPROVED',
    submittedAt: '2024-03-01T12:10:00.000Z',
    reviewedAt: '2024-03-01T14:30:00.000Z',
    reviewerNotes: 'All food safety compliance certificates and merchant bank KYC verified.',
  },
};

class OnboardingService {
  private currentData: OnboardingData = { ...INITIAL_ONBOARDING_STATE };

  public getOnboardingData(): OnboardingData {
    return JSON.parse(JSON.stringify(this.currentData));
  }

  public saveStepData(partial: Partial<OnboardingData>): OnboardingData {
    this.currentData = {
      ...this.currentData,
      ...partial,
      step: partial.step ?? this.currentData.step,
    };
    return this.getOnboardingData();
  }

  public async uploadDocument(
    type: UploadedDocument['type'],
    fileName: string,
    sizeMb: number
  ): Promise<UploadedDocument> {
    await new Promise((resolve) => setTimeout(resolve, 300));

    const uniqueId = `doc_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const newDoc: UploadedDocument = {
      id: uniqueId,
      name: fileName,
      type,
      fileSizeMb: sizeMb,
      uploadedAt: new Date().toISOString(),
      verificationStatus: 'PENDING',
    };

    // Replace documents array with deduplicated copy
    const currentDocs = this.currentData.legal.documents || [];
    this.currentData.legal = {
      ...this.currentData.legal,
      documents: [...currentDocs.filter((d) => d.id !== uniqueId), newDoc],
    };
    return newDoc;
  }

  public async submitForVerification(): Promise<OnboardingData> {
    await new Promise((resolve) => setTimeout(resolve, 800));

    this.currentData = {
      ...this.currentData,
      step: 6,
      verification: {
        status: 'PENDING_VERIFICATION',
        submittedAt: new Date().toISOString(),
        reviewerNotes: 'Application submitted for KYC & food safety compliance audit.',
      },
    };

    return { ...this.currentData };
  }

  public setVerificationStatus(
    status: OnboardingVerificationStatus,
    notes?: string,
    rejectionReason?: string
  ): OnboardingData {
    this.currentData = {
      ...this.currentData,
      verification: {
        status,
        submittedAt: this.currentData.verification.submittedAt || new Date().toISOString(),
        reviewedAt: new Date().toISOString(),
        reviewerNotes: notes || (status === 'APPROVED' ? 'Merchant KYC verified.' : 'Changes requested.'),
        rejectionReason,
      },
    };

    return { ...this.currentData };
  }

  public resetToFreshOnboarding(): OnboardingData {
    this.currentData = {
      ...INITIAL_ONBOARDING_STATE,
      step: 1,
      restaurant: {
        ...INITIAL_ONBOARDING_STATE.restaurant,
        name: '',
        description: '',
      },
      legal: {
        ...INITIAL_ONBOARDING_STATE.legal,
        documents: [],
      },
      verification: {
        status: 'NOT_STARTED',
      },
    };
    return { ...this.currentData };
  }
}

export const onboardingService = new OnboardingService();
