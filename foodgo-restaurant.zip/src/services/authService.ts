// ============================================================================
// FoodGo Restaurant - Authentication & Security Service
// Handles Login, Register, OTP, Sessions, Devices, Passwords, Biometrics
// ============================================================================

import {
  AuthResponse,
  AuthTokens,
  DeviceSession,
  LoginCredentials,
  PasswordChangePayload,
  RegisterCredentials,
} from '../types/auth';
import { UserProfile, UserRole } from '../types';
import { apiClient } from './apiClient';
import { INITIAL_USER } from './mockData';
import { secureStorage } from './secureStorage';

export const INITIAL_DEVICES: DeviceSession[] = [
  {
    id: 'dev_iphone_01',
    deviceName: 'iPhone 16 Pro (Current)',
    deviceType: 'IOS',
    browserOrOs: 'iOS 18.2 · FoodGo App',
    ipAddress: '152.57.19.42',
    location: 'Hyderabad, India',
    isCurrentDevice: true,
    lastActiveAt: 'Just now',
    createdAt: '2024-03-01T10:15:00.000Z',
  },
  {
    id: 'dev_tablet_02',
    deviceName: 'Kitchen iPad Pro 12.9"',
    deviceType: 'TABLET',
    browserOrOs: 'iPadOS 17.5 · Kitchen Display',
    ipAddress: '152.57.19.43',
    location: 'Kitchen Counter, Hyderabad',
    isCurrentDevice: false,
    lastActiveAt: '12m ago',
    createdAt: '2024-02-14T08:30:00.000Z',
  },
  {
    id: 'dev_mac_03',
    deviceName: 'MacBook Pro 16"',
    deviceType: 'WEB',
    browserOrOs: 'macOS 15.1 · Chrome 132',
    ipAddress: '152.57.19.88',
    location: 'Office Desk, Hyderabad',
    isCurrentDevice: false,
    lastActiveAt: 'Yesterday at 06:40 PM',
    createdAt: '2024-01-20T12:00:00.000Z',
  },
];

class AuthService {
  private activeDevices: DeviceSession[] = INITIAL_DEVICES;
  private pendingOtpMap: Map<string, { code: string; expiresAt: number }> = new Map();

  /**
   * Login with email and password
   */
  public async loginWithPassword(email: string, password?: string): Promise<AuthResponse> {
    // Basic validation
    if (!email || !password) {
      throw new Error('Please enter both email and password.');
    }
    if (password.length < 6) {
      throw new Error('Password must be at least 6 characters long.');
    }

    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 600));

    // Demo role assignment based on email or default to Owner
    let role: UserRole = 'RESTAURANT_OWNER';
    if (email.includes('manager')) role = 'RESTAURANT_MANAGER';
    if (email.includes('staff') || email.includes('kitchen')) role = 'RESTAURANT_STAFF';
    if (email.includes('admin')) role = 'RESTAURANT_ADMIN';

    const user: UserProfile = {
      ...INITIAL_USER,
      email,
      role,
      name: email.split('@')[0].replace(/[\._]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()) || 'Vikram Rao',
    };

    const tokens: AuthTokens = {
      accessToken: `foodgo_jwt_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      refreshToken: `foodgo_refresh_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      expiresInSeconds: 86400,
    };

    // Store securely in encrypted vault
    await secureStorage.setItem('access_token', tokens.accessToken);
    await secureStorage.setItem('refresh_token', tokens.refreshToken);
    await secureStorage.setItem('user_session', JSON.stringify(user));
    apiClient.setTokens(tokens.accessToken, tokens.refreshToken);

    return {
      user,
      tokens,
      activeSessions: this.activeDevices,
    };
  }

  /**
   * Request 6-digit phone OTP
   */
  public async requestPhoneOtp(phone: string): Promise<{ success: boolean; message: string; demoOtp: string }> {
    const cleanPhone = phone.replace(/[\s\-\(\)\+]/g, '');
    if (cleanPhone.length < 10) {
      throw new Error('Please enter a valid 10-digit phone number.');
    }

    await new Promise((resolve) => setTimeout(resolve, 500));

    // Generate reliable demo code 458921 or deterministic code
    const generatedCode = '458921';
    this.pendingOtpMap.set(phone, {
      code: generatedCode,
      expiresAt: Date.now() + 5 * 60 * 1000,
    });

    return {
      success: true,
      message: `OTP sent to ${phone}`,
      demoOtp: generatedCode,
    };
  }

  /**
   * Verify phone OTP and log in
   */
  public async verifyPhoneOtp(phone: string, otp: string): Promise<AuthResponse> {
    if (!otp || otp.length !== 6) {
      throw new Error('Please enter a valid 6-digit OTP code.');
    }

    await new Promise((resolve) => setTimeout(resolve, 500));

    // Accept demo OTP '458921' or previously requested OTP
    const pending = this.pendingOtpMap.get(phone);
    if (otp !== '458921' && (!pending || pending.code !== otp)) {
      throw new Error('Invalid or expired OTP. Please try code 458921 or request a new one.');
    }

    const user: UserProfile = {
      ...INITIAL_USER,
      phone,
      name: 'Restaurant Operator',
    };

    const tokens: AuthTokens = {
      accessToken: `foodgo_jwt_otp_${Date.now()}`,
      refreshToken: `foodgo_refresh_otp_${Date.now()}`,
      expiresInSeconds: 86400,
    };

    await secureStorage.setItem('access_token', tokens.accessToken);
    await secureStorage.setItem('refresh_token', tokens.refreshToken);
    await secureStorage.setItem('user_session', JSON.stringify(user));
    apiClient.setTokens(tokens.accessToken, tokens.refreshToken);

    return {
      user,
      tokens,
      activeSessions: this.activeDevices,
    };
  }

  /**
   * Register a new restaurant merchant account
   */
  public async register(payload: RegisterCredentials): Promise<AuthResponse> {
    if (!payload.name || payload.name.trim().length < 2) {
      throw new Error('Full name is required (minimum 2 characters).');
    }
    if (!payload.email || !payload.email.includes('@')) {
      throw new Error('Valid email address is required.');
    }
    if (!payload.password || payload.password.length < 8) {
      throw new Error('Password must be at least 8 characters long.');
    }

    await new Promise((resolve) => setTimeout(resolve, 700));

    const user: UserProfile = {
      id: `usr_${Date.now()}`,
      name: payload.name,
      email: payload.email,
      phone: payload.phone || '+91 98765 00000',
      role: payload.role || 'RESTAURANT_OWNER',
      restaurantId: 'rest_hyd_001',
      avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(payload.name)}`,
      createdAt: new Date().toISOString(),
    };

    const tokens: AuthTokens = {
      accessToken: `foodgo_jwt_reg_${Date.now()}`,
      refreshToken: `foodgo_refresh_reg_${Date.now()}`,
      expiresInSeconds: 86400,
    };

    await secureStorage.setItem('access_token', tokens.accessToken);
    await secureStorage.setItem('refresh_token', tokens.refreshToken);
    await secureStorage.setItem('user_session', JSON.stringify(user));
    apiClient.setTokens(tokens.accessToken, tokens.refreshToken);

    return {
      user,
      tokens,
      activeSessions: this.activeDevices,
    };
  }

  /**
   * Biometric Authentication (Face ID / Fingerprint / WebAuthn)
   */
  public async biometricAuthenticate(): Promise<AuthResponse> {
    await new Promise((resolve) => setTimeout(resolve, 600));

    const savedUserJson = await secureStorage.getItem('user_session');
    let user: UserProfile = INITIAL_USER;
    if (savedUserJson) {
      try {
        user = JSON.parse(savedUserJson);
      } catch {
        user = INITIAL_USER;
      }
    }

    const tokens: AuthTokens = {
      accessToken: `foodgo_jwt_bio_${Date.now()}`,
      refreshToken: `foodgo_refresh_bio_${Date.now()}`,
      expiresInSeconds: 86400,
    };

    await secureStorage.setItem('access_token', tokens.accessToken);
    apiClient.setTokens(tokens.accessToken, tokens.refreshToken);

    return {
      user,
      tokens,
      activeSessions: this.activeDevices,
    };
  }

  /**
   * Request password reset link / email
   */
  public async requestPasswordReset(email: string): Promise<{ success: boolean; message: string }> {
    if (!email || !email.includes('@')) {
      throw new Error('Please enter a valid registered email address.');
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
    return {
      success: true,
      message: `Password reset instructions sent to ${email}. Check your inbox.`,
    };
  }

  /**
   * Reset password with token
   */
  public async resetPassword(token: string, newPass: string): Promise<boolean> {
    if (newPass.length < 8) {
      throw new Error('New password must be at least 8 characters long.');
    }
    await new Promise((resolve) => setTimeout(resolve, 600));
    return true;
  }

  /**
   * Change password for logged-in user (requires re-auth of current password)
   */
  public async changePassword(payload: PasswordChangePayload): Promise<boolean> {
    if (!payload.currentPassword) {
      throw new Error('Current password is required to verify identity.');
    }
    if (payload.newPassword.length < 8) {
      throw new Error('New password must be at least 8 characters long.');
    }
    if (payload.newPassword !== payload.confirmPassword) {
      throw new Error('New passwords do not match.');
    }

    await new Promise((resolve) => setTimeout(resolve, 600));
    return true;
  }

  /**
   * Get active device sessions
   */
  public getActiveDevices(): DeviceSession[] {
    return [...this.activeDevices];
  }

  /**
   * Revoke a specific device session
   */
  public revokeDevice(deviceId: string): DeviceSession[] {
    this.activeDevices = this.activeDevices.filter((d) => d.id !== deviceId);
    return [...this.activeDevices];
  }

  /**
   * Logout from all devices
   */
  public logoutAllDevices(): void {
    this.activeDevices = this.activeDevices.filter((d) => d.isCurrentDevice);
    this.logout();
  }

  /**
   * Standard logout
   */
  public logout(): void {
    secureStorage.clearAll();
    apiClient.setTokens(null, null);
  }

  /**
   * Delete account (Section 4 & 62 requirement)
   */
  public async deleteAccount(passwordConfirmation: string): Promise<boolean> {
    if (!passwordConfirmation || passwordConfirmation.length < 6) {
      throw new Error('Please confirm your current password to proceed with deletion.');
    }
    await new Promise((resolve) => setTimeout(resolve, 800));
    this.logout();
    return true;
  }
}

export const authService = new AuthService();
