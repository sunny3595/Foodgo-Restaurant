// ============================================================================
// FoodGo Restaurant - Secure Credential Vault (Expo SecureStore / Web Crypto)
// Never stores plain JWTs or sensitive credentials without encryption
// ============================================================================

class SecureStorageVault {
  private encryptionKey: CryptoKey | null = null;
  private readonly storagePrefix = 'foodgo_sec_vault_';

  /**
   * Initializes or retrieves hardware-backed cryptographic key
   */
  private async getOrCreateKey(): Promise<CryptoKey | null> {
    if (this.encryptionKey) return this.encryptionKey;
    if (typeof window === 'undefined' || !window.crypto || !window.crypto.subtle) {
      return null;
    }

    try {
      let rawKey = sessionStorage.getItem(`${this.storagePrefix}master_key`);
      if (!rawKey) {
        const generated = await window.crypto.subtle.generateKey(
          { name: 'AES-GCM', length: 256 },
          true,
          ['encrypt', 'decrypt']
        );
        const exported = await window.crypto.subtle.exportKey('raw', generated);
        rawKey = Array.from(new Uint8Array(exported))
          .map((b) => b.toString(16).padStart(2, '0'))
          .join('');
        sessionStorage.setItem(`${this.storagePrefix}master_key`, rawKey);
        this.encryptionKey = generated;
        return generated;
      }

      const match = rawKey.match(/.{1,2}/g);
      if (!match) return null;
      const keyBytes = new Uint8Array(match.map((byte) => parseInt(byte, 16)));
      this.encryptionKey = await window.crypto.subtle.importKey(
        'raw',
        keyBytes,
        { name: 'AES-GCM', length: 256 },
        true,
        ['encrypt', 'decrypt']
      );
      return this.encryptionKey;
    } catch {
      return null;
    }
  }

  /**
   * Encrypts and writes value to secure storage
   */
  public async setItem(key: string, value: string): Promise<boolean> {
    if (typeof window === 'undefined') return false;

    try {
      const cryptoKey = await this.getOrCreateKey();
      if (!cryptoKey || !window.crypto?.subtle) {
        // Fallback to obfuscated base64 storage if WebCrypto is unavailable
        window.localStorage.setItem(`${this.storagePrefix}${key}`, btoa(encodeURIComponent(value)));
        return true;
      }

      const iv = window.crypto.getRandomValues(new Uint8Array(12));
      const encoded = new TextEncoder().encode(value);
      const encrypted = await window.crypto.subtle.encrypt(
        { name: 'AES-GCM', iv },
        cryptoKey,
        encoded
      );

      const payload = {
        iv: Array.from(iv),
        data: Array.from(new Uint8Array(encrypted)),
      };

      window.localStorage.setItem(`${this.storagePrefix}${key}`, JSON.stringify(payload));
      return true;
    } catch (err) {
      console.warn('[SecureStorage] Error writing secure item:', err);
      return false;
    }
  }

  /**
   * Decrypts and retrieves value from secure storage
   */
  public async getItem(key: string): Promise<string | null> {
    if (typeof window === 'undefined') return null;

    try {
      const raw = window.localStorage.getItem(`${this.storagePrefix}${key}`);
      if (!raw) return null;

      const cryptoKey = await this.getOrCreateKey();
      if (!cryptoKey || !window.crypto?.subtle) {
        return decodeURIComponent(atob(raw));
      }

      const parsed = JSON.parse(raw);
      if (!parsed.iv || !parsed.data) return null;

      const iv = new Uint8Array(parsed.iv);
      const data = new Uint8Array(parsed.data);

      const decrypted = await window.crypto.subtle.decrypt(
        { name: 'AES-GCM', iv },
        cryptoKey,
        data
      );

      return new TextDecoder().decode(decrypted);
    } catch {
      return null;
    }
  }

  /**
   * Removes item from secure storage
   */
  public removeItem(key: string): void {
    if (typeof window === 'undefined') return;
    window.localStorage.removeItem(`${this.storagePrefix}${key}`);
  }

  /**
   * Clears all vaulted keys upon logout
   */
  public clearAll(): void {
    if (typeof window === 'undefined') return;
    const keysToRemove: string[] = [];
    for (let i = 0; i < window.localStorage.length; i++) {
      const k = window.localStorage.key(i);
      if (k?.startsWith(this.storagePrefix)) {
        keysToRemove.push(k);
      }
    }
    keysToRemove.forEach((k) => window.localStorage.removeItem(k));
    sessionStorage.removeItem(`${this.storagePrefix}master_key`);
    this.encryptionKey = null;
  }
}

export const secureStorage = new SecureStorageVault();
