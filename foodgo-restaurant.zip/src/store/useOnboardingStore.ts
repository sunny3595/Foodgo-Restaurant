// ============================================================================
// FoodGo Restaurant - Onboarding Store
// Manages Step-by-Step Merchant Registration & Verification Flow
// ============================================================================

import { create } from 'zustand';
import { INITIAL_ONBOARDING_STATE, onboardingService } from '../services/onboardingService';
import {
  OnboardingData,
  OnboardingVerificationStatus,
  RestaurantType,
  UploadedDocument,
} from '../types/onboarding';

interface OnboardingStoreState {
  data: OnboardingData;
  isLoading: boolean;
  error: string | null;
  isOpenModal: boolean;

  // Navigation
  setIsOpenModal: (open: boolean) => void;
  setStep: (step: number) => void;
  nextStep: () => boolean;
  prevStep: () => void;

  // Step Updates
  updateAccount: (account: Partial<OnboardingData['account']>) => void;
  updateRestaurant: (restaurant: Partial<OnboardingData['restaurant']>) => void;
  updateLocation: (location: Partial<OnboardingData['location']>) => void;
  updateBusiness: (business: Partial<OnboardingData['business']>) => void;
  updateLegal: (legal: Partial<OnboardingData['legal']>) => void;

  // Actions
  uploadDocument: (type: UploadedDocument['type'], fileName: string, sizeMb: number) => Promise<void>;
  submitForVerification: () => Promise<boolean>;
  setVerificationStatus: (status: OnboardingVerificationStatus, notes?: string, reason?: string) => void;
  resetOnboarding: () => void;

  // Step Validation
  isStepValid: (step: number) => { valid: boolean; error?: string };
}

export const useOnboardingStore = create<OnboardingStoreState>((set, get) => ({
  data: JSON.parse(JSON.stringify(INITIAL_ONBOARDING_STATE)),
  isLoading: false,
  error: null,
  isOpenModal: false,

  setIsOpenModal: (open) => set({ isOpenModal: open }),
  setStep: (step) => set((state) => ({ data: { ...state.data, step }, error: null })),

  isStepValid: (step: number) => {
    const data = get().data;
    if (step === 1) {
      if (!data.account.name || data.account.name.trim().length < 2) {
        return { valid: false, error: 'Full name is required (min 2 characters).' };
      }
      if (!data.account.email || !data.account.email.includes('@')) {
        return { valid: false, error: 'Valid business email is required.' };
      }
      if (!data.account.phone || data.account.phone.length < 10) {
        return { valid: false, error: 'Valid 10-digit phone number is required.' };
      }
      return { valid: true };
    }

    if (step === 2) {
      if (!data.restaurant.name || data.restaurant.name.trim().length < 3) {
        return { valid: false, error: 'Restaurant name is required (min 3 characters).' };
      }
      if (!data.restaurant.description) {
        return { valid: false, error: 'Please enter a brief restaurant description.' };
      }
      return { valid: true };
    }

    if (step === 3) {
      if (!data.location.address || data.location.address.trim().length < 5) {
        return { valid: false, error: 'Street address is required.' };
      }
      if (!data.location.city || !data.location.postalCode) {
        return { valid: false, error: 'City and postal code are required.' };
      }
      return { valid: true };
    }

    if (step === 4) {
      if (!data.business.cuisines || data.business.cuisines.length === 0) {
        return { valid: false, error: 'Please select at least one cuisine type.' };
      }
      if (data.business.deliveryRadiusKm <= 0) {
        return { valid: false, error: 'Delivery radius must be greater than 0 km.' };
      }
      return { valid: true };
    }

    if (step === 5) {
      if (!data.legal.taxId) {
        return { valid: false, error: 'Tax ID / GST number is required.' };
      }
      if (!data.legal.accountNumber || !data.legal.ifscOrRoutingCode) {
        return { valid: false, error: 'Bank account number and IFSC/routing code are required.' };
      }
      return { valid: true };
    }

    return { valid: true };
  },

  nextStep: () => {
    const currentStep = get().data.step;
    const check = get().isStepValid(currentStep);
    if (!check.valid) {
      set({ error: check.error || 'Please fill in required fields.' });
      return false;
    }

    if (currentStep < 6) {
      set((state) => ({
        data: { ...state.data, step: currentStep + 1 },
        error: null,
      }));
      return true;
    }
    return false;
  },

  prevStep: () => {
    set((state) => ({
      data: { ...state.data, step: Math.max(1, state.data.step - 1) },
      error: null,
    }));
  },

  updateAccount: (account) =>
    set((state) => ({
      data: { ...state.data, account: { ...state.data.account, ...account } },
    })),

  updateRestaurant: (restaurant) =>
    set((state) => ({
      data: { ...state.data, restaurant: { ...state.data.restaurant, ...restaurant } },
    })),

  updateLocation: (location) =>
    set((state) => ({
      data: { ...state.data, location: { ...state.data.location, ...location } },
    })),

  updateBusiness: (business) =>
    set((state) => ({
      data: { ...state.data, business: { ...state.data.business, ...business } },
    })),

  updateLegal: (legal) =>
    set((state) => ({
      data: { ...state.data, legal: { ...state.data.legal, ...legal } },
    })),

  uploadDocument: async (type, fileName, sizeMb) => {
    const doc = await onboardingService.uploadDocument(type, fileName, sizeMb);
    set((state) => {
      const existing = state.data.legal.documents || [];
      const filtered = existing.filter((d) => d.id !== doc.id);
      return {
        data: {
          ...state.data,
          legal: {
            ...state.data.legal,
            documents: [...filtered, doc],
          },
        },
      };
    });
  },

  submitForVerification: async () => {
    set({ isLoading: true, error: null });
    try {
      const updated = await onboardingService.submitForVerification();
      set({ data: updated, isLoading: false, error: null });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Submission failed';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  setVerificationStatus: (status, notes, reason) => {
    const updated = onboardingService.setVerificationStatus(status, notes, reason);
    set({ data: updated });
  },

  resetOnboarding: () => {
    const reset = onboardingService.resetToFreshOnboarding();
    set({ data: reset, error: null });
  },
}));
