// ============================================================================
// FoodGo Restaurant - Order Management & State Machine Store
// ============================================================================

import { create } from 'zustand';
import { INITIAL_ORDERS } from '../services/mockData';
import { realtimeService } from '../services/realtimeService';
import {
  Order,
  OrderRejectionReason,
  OrderStatus,
  OrderTimelineEvent,
} from '../types';
import { canTransitionOrder } from '../utils/validators';

interface OrderState {
  orders: Order[];
  activeTab: OrderStatus | 'ALL';
  selectedOrderId: string | null;
  incomingNewOrder: Order | null;
  isSimulating: boolean;

  // Actions
  setActiveTab: (tab: OrderStatus | 'ALL') => void;
  selectOrder: (orderId: string | null) => void;
  setIncomingOrder: (order: Order | null) => void;

  // State Machine Order Transitions
  acceptOrder: (orderId: string, prepTimeMinutes: number) => { success: boolean; error?: string };
  rejectOrder: (orderId: string, reason: OrderRejectionReason, note?: string) => { success: boolean; error?: string };
  startPreparing: (orderId: string) => { success: boolean; error?: string };
  markReady: (orderId: string) => { success: boolean; error?: string };
  confirmHandover: (orderId: string) => { success: boolean; error?: string };
  cancelOrder: (orderId: string, reason: string) => { success: boolean; error?: string };

  // Real-time Order Simulation
  simulateIncomingOrder: () => Order;
}

export const useOrderStore = create<OrderState>((set, get) => ({
  orders: INITIAL_ORDERS,
  activeTab: 'ALL',
  selectedOrderId: null,
  incomingNewOrder: INITIAL_ORDERS.find((o) => o.status === 'NEW') || null,
  isSimulating: false,

  setActiveTab: (tab) => set({ activeTab: tab }),
  selectOrder: (id) => set({ selectedOrderId: id }),
  setIncomingOrder: (order) => set({ incomingNewOrder: order }),

  acceptOrder: (orderId, prepTimeMinutes) => {
    const orders = get().orders;
    const order = orders.find((o) => o.id === orderId);

    if (!order) return { success: false, error: 'Order not found' };

    const validation = canTransitionOrder(order.status, 'ACCEPTED');
    if (!validation.allowed) return { success: false, error: validation.reason };

    const readyTime = new Date(Date.now() + prepTimeMinutes * 60000).toISOString();
    const event: OrderTimelineEvent = {
      status: 'ACCEPTED',
      timestamp: new Date().toISOString(),
      title: `Accepted with ${prepTimeMinutes}m preparation time`,
      description: 'Kitchen acknowledged order receipt.',
    };

    const updatedOrders = orders.map((o) => {
      if (o.id === orderId) {
        return {
          ...o,
          status: 'ACCEPTED' as OrderStatus,
          confirmedPrepTimeMinutes: prepTimeMinutes,
          expectedReadyTime: readyTime,
          timeline: [...o.timeline, event],
        };
      }
      return o;
    });

    set({
      orders: updatedOrders,
      incomingNewOrder: get().incomingNewOrder?.id === orderId ? null : get().incomingNewOrder,
    });

    realtimeService.dispatch({
      id: `evt_${Date.now()}`,
      type: 'order.accepted',
      restaurantId: order.restaurantId,
      timestamp: new Date().toISOString(),
      payload: { orderId, prepTimeMinutes },
    });

    return { success: true };
  },

  rejectOrder: (orderId, reason, note) => {
    const orders = get().orders;
    const order = orders.find((o) => o.id === orderId);

    if (!order) return { success: false, error: 'Order not found' };

    const validation = canTransitionOrder(order.status, 'CANCELLED');
    if (!validation.allowed) return { success: false, error: validation.reason };

    const event: OrderTimelineEvent = {
      status: 'CANCELLED',
      timestamp: new Date().toISOString(),
      title: `Order Rejected: ${reason.replace(/_/g, ' ')}`,
      description: note || 'Restaurant unable to fulfill this order at this time.',
    };

    const updatedOrders = orders.map((o) => {
      if (o.id === orderId) {
        return {
          ...o,
          status: 'CANCELLED' as OrderStatus,
          rejectionReason: reason,
          rejectionNote: note,
          timeline: [...o.timeline, event],
        };
      }
      return o;
    });

    set({
      orders: updatedOrders,
      incomingNewOrder: get().incomingNewOrder?.id === orderId ? null : get().incomingNewOrder,
    });

    realtimeService.dispatch({
      id: `evt_${Date.now()}`,
      type: 'order.rejected',
      restaurantId: order.restaurantId,
      timestamp: new Date().toISOString(),
      payload: { orderId, reason, note },
    });

    return { success: true };
  },

  startPreparing: (orderId) => {
    const orders = get().orders;
    const order = orders.find((o) => o.id === orderId);
    if (!order) return { success: false, error: 'Order not found' };

    const validation = canTransitionOrder(order.status, 'PREPARING');
    if (!validation.allowed) return { success: false, error: validation.reason };

    const event: OrderTimelineEvent = {
      status: 'PREPARING',
      timestamp: new Date().toISOString(),
      title: 'Kitchen Started Cooking',
      description: 'Chef has initiated cooking and grilling.',
    };

    const updatedOrders = orders.map((o) => {
      if (o.id === orderId) {
        return {
          ...o,
          status: 'PREPARING' as OrderStatus,
          timeline: [...o.timeline, event],
        };
      }
      return o;
    });

    set({ orders: updatedOrders });

    realtimeService.dispatch({
      id: `evt_${Date.now()}`,
      type: 'order.preparing',
      restaurantId: order.restaurantId,
      timestamp: new Date().toISOString(),
      payload: { orderId },
    });

    return { success: true };
  },

  markReady: (orderId) => {
    const orders = get().orders;
    const order = orders.find((o) => o.id === orderId);
    if (!order) return { success: false, error: 'Order not found' };

    const validation = canTransitionOrder(order.status, 'READY_FOR_PICKUP');
    if (!validation.allowed) return { success: false, error: validation.reason };

    const event: OrderTimelineEvent = {
      status: 'READY_FOR_PICKUP',
      timestamp: new Date().toISOString(),
      title: 'Packed & Ready for Handover',
      description: 'Waiting at the pickup counter.',
    };

    const updatedOrders = orders.map((o) => {
      if (o.id === orderId) {
        return {
          ...o,
          status: 'READY_FOR_PICKUP' as OrderStatus,
          timeline: [...o.timeline, event],
        };
      }
      return o;
    });

    set({ orders: updatedOrders });

    realtimeService.dispatch({
      id: `evt_${Date.now()}`,
      type: 'order.ready',
      restaurantId: order.restaurantId,
      timestamp: new Date().toISOString(),
      payload: { orderId },
    });

    return { success: true };
  },

  confirmHandover: (orderId) => {
    const orders = get().orders;
    const order = orders.find((o) => o.id === orderId);
    if (!order) return { success: false, error: 'Order not found' };

    const validation = canTransitionOrder(order.status, 'PICKED_UP');
    if (!validation.allowed) return { success: false, error: validation.reason };

    const event: OrderTimelineEvent = {
      status: 'PICKED_UP',
      timestamp: new Date().toISOString(),
      title: 'Order Handed Over',
      description: `Rider ${order.rider?.name || 'Assigned Rider'} verified OTP and departed.`,
    };

    const updatedOrders = orders.map((o) => {
      if (o.id === orderId) {
        return {
          ...o,
          status: 'PICKED_UP' as OrderStatus,
          timeline: [...o.timeline, event],
        };
      }
      return o;
    });

    set({ orders: updatedOrders });

    realtimeService.dispatch({
      id: `evt_${Date.now()}`,
      type: 'order.picked_up',
      restaurantId: order.restaurantId,
      timestamp: new Date().toISOString(),
      payload: { orderId },
    });

    return { success: true };
  },

  cancelOrder: (orderId, reason) => {
    const orders = get().orders;
    const order = orders.find((o) => o.id === orderId);
    if (!order) return { success: false, error: 'Order not found' };

    const validation = canTransitionOrder(order.status, 'CANCELLED');
    if (!validation.allowed) return { success: false, error: validation.reason };

    const event: OrderTimelineEvent = {
      status: 'CANCELLED',
      timestamp: new Date().toISOString(),
      title: 'Cancelled',
      description: reason,
    };

    const updatedOrders = orders.map((o) => {
      if (o.id === orderId) {
        return {
          ...o,
          status: 'CANCELLED' as OrderStatus,
          rejectionNote: reason,
          timeline: [...o.timeline, event],
        };
      }
      return o;
    });

    set({ orders: updatedOrders });

    realtimeService.dispatch({
      id: `evt_${Date.now()}`,
      type: 'order.cancelled',
      restaurantId: order.restaurantId,
      timestamp: new Date().toISOString(),
      payload: { orderId, reason },
    });

    return { success: true };
  },

  simulateIncomingOrder: () => {
    const randomNum = Math.floor(1025 + Math.random() * 8900);
    const newOrder: Order = {
      id: `ord_${Date.now()}`,
      orderNumber: `#FG-${randomNum}`,
      restaurantId: 'rest_hyd_001',
      status: 'NEW',
      deliveryType: 'DELIVERY',
      customer: {
        id: `cust_${Math.floor(Math.random() * 1000)}`,
        name: ['Tanvi Sethi', 'Sameer Verma', 'Kunal Shah', 'Aarav Patel', 'Neha Kapoor'][
          Math.floor(Math.random() * 5)
        ],
        phone: '+91 98112 33445',
        deliveryAddress: 'Flat 501, Fortune Horizon Tower, Gachibowli',
        totalPreviousOrders: Math.floor(Math.random() * 15) + 1,
      },
      items: [
        {
          id: `item_${Date.now()}`,
          foodId: 'food_001',
          name: 'Special Mutton Dum Biryani (Zafrani)',
          quantity: 1,
          unitPrice: 460,
          totalPrice: 460,
          selectedAddons: [{ addonId: 'add_egg', name: 'Extra Boiled Egg (x2)', price: 40 }],
          specialInstructions: 'Extra spicy please, contactless handover',
        },
      ],
      financials: {
        subtotal: 500,
        discountAmount: 50,
        taxAmount: 25,
        deliveryFee: 40,
        platformCommission: 75,
        platformCommissionRate: 0.15,
        restaurantNetEarnings: 400,
        customerTotal: 515,
      },
      paymentMethod: 'ONLINE_UPI',
      paymentStatus: 'PAID',
      createdAt: new Date().toISOString(),
      timeline: [
        {
          status: 'NEW',
          timestamp: new Date().toISOString(),
          title: 'Order Placed',
          description: 'Payment verified via UPI',
        },
      ],
    };

    set((state) => ({
      orders: [newOrder, ...state.orders],
      incomingNewOrder: newOrder,
    }));

    realtimeService.dispatch({
      id: `evt_${Date.now()}`,
      type: 'order.created',
      restaurantId: newOrder.restaurantId,
      timestamp: new Date().toISOString(),
      payload: newOrder,
    });

    return newOrder;
  },
}));
