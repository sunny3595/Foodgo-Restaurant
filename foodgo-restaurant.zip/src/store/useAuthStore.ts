// ============================================================================
// FoodGo Restaurant - Authentication & RBAC Store (Phase 2 Enhanced)
// ============================================================================

import { create } from 'zustand';
import { authService, INITIAL_DEVICES } from '../services/authService';
import { INITIAL_USER } from '../services/mockData';
import { Permission, UserProfile, UserRole } from '../types';
import {
  AuthScreenState,
  DeviceSession,
  PasswordChangePayload,
  RegisterCredentials,
} from '../types/auth';
import { hasPermission } from '../utils/validators';

interface AuthState {
  currentUser: UserProfile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  token: string | null;
  authScreen: AuthScreenState;
  tempPhoneForOtp: string | null;
  demoOtpHint: string | null;
  activeDevices: DeviceSession[];
  isBiometricsEnabled: boolean;

  // Screen Navigation
  setAuthScreen: (screen: AuthScreenState) => void;
  clearError: () => void;

  // Core Auth Flows
  loginWithPassword: (email: string, password?: string) => Promise<boolean>;
  requestPhoneOtp: (phone: string) => Promise<boolean>;
  verifyPhoneOtp: (otp: string) => Promise<boolean>;
  register: (payload: RegisterCredentials) => Promise<boolean>;
  biometricLogin: () => Promise<boolean>;
  requestPasswordReset: (email: string) => Promise<boolean>;
  resetPassword: (token: string, newPass: string) => Promise<boolean>;
  changePassword: (payload: PasswordChangePayload) => Promise<boolean>;

  // Session & Devices
  logout: () => void;
  logoutAllDevices: () => void;
  revokeDevice: (deviceId: string) => void;
  toggleBiometrics: () => void;
  deleteAccount: (passwordConfirmation: string) => Promise<boolean>;

  // Testing & Fast Switcher
  switchRole: (newRole: UserRole) => void;
  quickDemoLogin: (role: UserRole) => void;
  hasPermission: (permission: Permission) => boolean;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  currentUser: INITIAL_USER,
  isAuthenticated: true,
  isLoading: false,
  error: null,
  token: 'foodgo_secure_jwt_token_initial',
  authScreen: 'LOGIN',
  tempPhoneForOtp: null,
  demoOtpHint: null,
  activeDevices: INITIAL_DEVICES,
  isBiometricsEnabled: true,

  setAuthScreen: (screen) => set({ authScreen: screen, error: null }),
  clearError: () => set({ error: null }),

  loginWithPassword: async (email, password) => {
    set({ isLoading: true, error: null });
    try {
      const res = await authService.loginWithPassword(email, password);
      set({
        currentUser: res.user,
        isAuthenticated: true,
        token: res.tokens.accessToken,
        activeDevices: res.activeSessions,
        isLoading: false,
        error: null,
      });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Login failed';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  requestPhoneOtp: async (phone) => {
    set({ isLoading: true, error: null });
    try {
      const res = await authService.requestPhoneOtp(phone);
      set({
        tempPhoneForOtp: phone,
        demoOtpHint: res.demoOtp,
        authScreen: 'OTP_VERIFY',
        isLoading: false,
        error: null,
      });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to send OTP';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  verifyPhoneOtp: async (otp) => {
    const phone = get().tempPhoneForOtp || '+91 98765 43210';
    set({ isLoading: true, error: null });
    try {
      const res = await authService.verifyPhoneOtp(phone, otp);
      set({
        currentUser: res.user,
        isAuthenticated: true,
        token: res.tokens.accessToken,
        activeDevices: res.activeSessions,
        isLoading: false,
        error: null,
      });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Invalid OTP code';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  register: async (payload) => {
    set({ isLoading: true, error: null });
    try {
      const res = await authService.register(payload);
      set({
        currentUser: res.user,
        isAuthenticated: true,
        token: res.tokens.accessToken,
        activeDevices: res.activeSessions,
        isLoading: false,
        error: null,
      });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Registration failed';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  biometricLogin: async () => {
    set({ isLoading: true, error: null });
    try {
      const res = await authService.biometricAuthenticate();
      set({
        currentUser: res.user,
        isAuthenticated: true,
        token: res.tokens.accessToken,
        isLoading: false,
        error: null,
      });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Biometric authentication failed';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  requestPasswordReset: async (email) => {
    set({ isLoading: true, error: null });
    try {
      await authService.requestPasswordReset(email);
      set({ isLoading: false, error: null, authScreen: 'LOGIN' });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Password reset failed';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  resetPassword: async (token, newPass) => {
    set({ isLoading: true, error: null });
    try {
      await authService.resetPassword(token, newPass);
      set({ isLoading: false, error: null, authScreen: 'LOGIN' });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to update password';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  changePassword: async (payload) => {
    set({ isLoading: true, error: null });
    try {
      await authService.changePassword(payload);
      set({ isLoading: false, error: null });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to change password';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  logout: () => {
    authService.logout();
    set({
      currentUser: null,
      isAuthenticated: false,
      token: null,
      authScreen: 'LOGIN',
      error: null,
    });
  },

  logoutAllDevices: () => {
    authService.logoutAllDevices();
    set({
      currentUser: null,
      isAuthenticated: false,
      token: null,
      authScreen: 'LOGIN',
      activeDevices: [],
    });
  },

  revokeDevice: (deviceId) => {
    const updated = authService.revokeDevice(deviceId);
    set({ activeDevices: updated });
  },

  toggleBiometrics: () => {
    set((state) => ({ isBiometricsEnabled: !state.isBiometricsEnabled }));
  },

  deleteAccount: async (passwordConfirmation) => {
    set({ isLoading: true, error: null });
    try {
      await authService.deleteAccount(passwordConfirmation);
      set({
        currentUser: null,
        isAuthenticated: false,
        token: null,
        authScreen: 'LOGIN',
        isLoading: false,
      });
      return true;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to delete account';
      set({ error: msg, isLoading: false });
      return false;
    }
  },

  switchRole: (newRole) => {
    const current = get().currentUser;
    if (current) {
      set({
        currentUser: {
          ...current,
          role: newRole,
        },
      });
    }
  },

  quickDemoLogin: (role) => {
    const roleProfiles: Record<UserRole, UserProfile> = {
      RESTAURANT_OWNER: {
        ...INITIAL_USER,
        name: 'Vikramaditya Rao',
        email: 'vikram.owner@royalhyderabad.com',
        role: 'RESTAURANT_OWNER',
      },
      RESTAURANT_ADMIN: {
        ...INITIAL_USER,
        id: 'usr_admin_002',
        name: 'Karthik Sen (Admin)',
        email: 'karthik.admin@royalhyderabad.com',
        role: 'RESTAURANT_ADMIN',
      },
      RESTAURANT_MANAGER: {
        ...INITIAL_USER,
        id: 'usr_mgr_003',
        name: 'Priya Nair (Manager)',
        email: 'priya.manager@royalhyderabad.com',
        role: 'RESTAURANT_MANAGER',
      },
      RESTAURANT_STAFF: {
        ...INITIAL_USER,
        id: 'usr_staff_004',
        name: 'Chef Ramesh (Kitchen)',
        email: 'ramesh.chef@royalhyderabad.com',
        role: 'RESTAURANT_STAFF',
      },
    };

    const targetUser = roleProfiles[role];
    set({
      currentUser: targetUser,
      isAuthenticated: true,
      token: `demo_token_${role.toLowerCase()}`,
      error: null,
    });
  },

  hasPermission: (permission) => {
    const user = get().currentUser;
    if (!user) return false;
    return hasPermission(user.role, permission);
  },
}));
