// ============================================================================
// FoodGo Restaurant - UI & Shell State Store
// ============================================================================

import { create } from 'zustand';
import { soundManager } from '../utils/sound';

export type DeviceFrameType = 'IPHONE' | 'PIXEL' | 'FULL_RESPONSIVE';
export type NavTab = 'home' | 'orders' | 'kitchen' | 'menu' | 'more';
export type MoreSubView = 'MENU' | 'STATS' | 'SETTLEMENT' | 'KYC';

interface UIState {
  deviceFrame: DeviceFrameType;
  activeNavTab: NavTab;
  moreSubView: MoreSubView;
  isKitchenMode: boolean;
  soundEnabled: boolean;
  isOfflineSimulated: boolean;

  // Actions
  setDeviceFrame: (frame: DeviceFrameType) => void;
  setActiveNavTab: (tab: NavTab) => void;
  setMoreSubView: (view: MoreSubView) => void;
  openStats: () => void;
  toggleKitchenMode: () => void;
  toggleSound: () => void;
  toggleOfflineSimulation: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  deviceFrame: 'IPHONE',
  activeNavTab: 'home',
  moreSubView: 'MENU',
  isKitchenMode: false,
  soundEnabled: true,
  isOfflineSimulated: false,

  setDeviceFrame: (frame) => set({ deviceFrame: frame }),
  setActiveNavTab: (tab) => set({ activeNavTab: tab }),
  setMoreSubView: (view) => set({ moreSubView: view }),
  openStats: () => set({ activeNavTab: 'more', moreSubView: 'STATS' }),

  toggleKitchenMode: () =>
    set((state) => {
      const next = !state.isKitchenMode;
      return {
        isKitchenMode: next,
        activeNavTab: next ? 'kitchen' : 'orders',
      };
    }),

  toggleSound: () =>
    set((state) => {
      const next = !state.soundEnabled;
      soundManager.setSoundEnabled(next);
      if (next) soundManager.playSuccessChime();
      return { soundEnabled: next };
    }),

  toggleOfflineSimulation: () =>
    set((state) => ({ isOfflineSimulated: !state.isOfflineSimulated })),
}));
