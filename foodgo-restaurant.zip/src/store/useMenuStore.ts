// ============================================================================
// FoodGo Restaurant - Menu & Inventory State Store
// ============================================================================

import { create } from 'zustand';
import { INITIAL_CATEGORIES, INITIAL_FOOD_ITEMS } from '../services/mockData';
import { Category, FoodItem } from '../types';

interface MenuState {
  categories: Category[];
  foodItems: FoodItem[];
  selectedCategoryId: string | null;

  // Actions
  setSelectedCategory: (categoryId: string | null) => void;
  toggleFoodAvailability: (foodId: string) => void;
  updateStock: (foodId: string, newStock: number) => void;
  addCategory: (category: Omit<Category, 'id'>) => void;
  addFoodItem: (item: Omit<FoodItem, 'id'>) => void;
}

export const useMenuStore = create<MenuState>((set) => ({
  categories: INITIAL_CATEGORIES,
  foodItems: INITIAL_FOOD_ITEMS,
  selectedCategoryId: null,

  setSelectedCategory: (categoryId) => set({ selectedCategoryId: categoryId }),

  toggleFoodAvailability: (foodId) => {
    set((state) => ({
      foodItems: state.foodItems.map((item) => {
        if (item.id === foodId) {
          const isAvailable = !item.isAvailable;
          return {
            ...item,
            isAvailable,
            currentStock: !isAvailable ? 0 : item.currentStock,
          };
        }
        return item;
      }),
    }));
  },

  updateStock: (foodId, newStock) => {
    set((state) => ({
      foodItems: state.foodItems.map((item) => {
        if (item.id === foodId) {
          return {
            ...item,
            currentStock: Math.max(0, newStock),
            isAvailable: newStock > 0,
          };
        }
        return item;
      }),
    }));
  },

  addCategory: (categoryData) => {
    const newCategory: Category = {
      ...categoryData,
      id: `cat_${Date.now()}`,
    };
    set((state) => ({ categories: [...state.categories, newCategory] }));
  },

  addFoodItem: (itemData) => {
    const newItem: FoodItem = {
      ...itemData,
      id: `food_${Date.now()}`,
    };
    set((state) => ({ foodItems: [...state.foodItems, newItem] }));
  },
}));
