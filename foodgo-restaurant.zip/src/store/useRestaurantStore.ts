// ============================================================================
// FoodGo Restaurant - Availability & Profile Store
// ============================================================================

import { create } from 'zustand';
import { INITIAL_RESTAURANT } from '../services/mockData';
import { PauseReason, RestaurantAvailabilityStatus, RestaurantProfile } from '../types';

interface RestaurantState {
  profile: RestaurantProfile;
  status: RestaurantAvailabilityStatus;
  isOnline: boolean;
  pauseReason?: PauseReason;
  pausedUntil?: string;

  // Actions
  setStatus: (status: RestaurantAvailabilityStatus) => void;
  toggleOnline: () => void;
  pauseOrders: (reason: PauseReason, durationMinutes: number) => void;
  resumeOrders: () => void;
  updateProfile: (partial: Partial<RestaurantProfile>) => void;
}

export const useRestaurantStore = create<RestaurantState>((set, get) => ({
  profile: INITIAL_RESTAURANT,
  status: INITIAL_RESTAURANT.status,
  isOnline: INITIAL_RESTAURANT.status === 'OPEN',
  pauseReason: undefined,
  pausedUntil: undefined,

  setStatus: (status) => {
    set((state) => ({
      status,
      isOnline: status === 'OPEN' || status === 'BUSY',
      profile: { ...state.profile, status },
      pauseReason: status === 'PAUSED' ? state.pauseReason : undefined,
      pausedUntil: status === 'PAUSED' ? state.pausedUntil : undefined,
    }));
  },

  toggleOnline: () => {
    const nextOnline = !get().isOnline;
    const nextStatus: RestaurantAvailabilityStatus = nextOnline ? 'OPEN' : 'CLOSED';
    set((state) => ({
      isOnline: nextOnline,
      status: nextStatus,
      profile: { ...state.profile, status: nextStatus },
    }));
  },

  pauseOrders: (reason, durationMinutes) => {
    const resumeTime = new Date(Date.now() + durationMinutes * 60000).toISOString();
    set((state) => ({
      status: 'PAUSED',
      pauseReason: reason,
      pausedUntil: resumeTime,
      profile: {
        ...state.profile,
        status: 'PAUSED',
        pauseReason: reason,
        pausedUntil: resumeTime,
      },
    }));
  },

  resumeOrders: () => {
    get().setStatus('OPEN');
  },

  updateProfile: (partial) => {
    set((state) => ({
      profile: {
        ...state.profile,
        ...partial,
      },
    }));
  },
}));
