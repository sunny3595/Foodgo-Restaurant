// ============================================================================
// FoodGo Restaurant - Dashboard & Store Operations State Store
// ============================================================================

import { create } from 'zustand';
import {
  dashboardService,
  INITIAL_LOW_STOCK_ITEMS,
  INITIAL_RATING_SUMMARY,
  INITIAL_TOP_SELLERS,
} from '../services/dashboardService';
import {
  EmergencyCloseConfig,
  LowStockAlertItem,
  PauseStoreConfig,
  RatingSummary,
  RevenueTimeframe,
  TopSellingItem,
} from '../types/dashboard';

interface DashboardStoreState {
  timeframe: RevenueTimeframe;
  setTimeframe: (timeframe: RevenueTimeframe) => void;

  // Store Pause Operations
  pauseConfig: PauseStoreConfig;
  pauseStore: (minutes: number, label: string, reason?: string) => void;
  resumeStore: () => void;

  // Emergency Close Operations
  emergencyConfig: EmergencyCloseConfig;
  triggerEmergencyClose: (reason: string) => void;
  reopenFromEmergency: () => void;

  // Modals Visibility
  isPauseModalOpen: boolean;
  setIsPauseModalOpen: (open: boolean) => void;
  isEmergencyModalOpen: boolean;
  setIsEmergencyModalOpen: (open: boolean) => void;
  isQuickAddItemOpen: boolean;
  setIsQuickAddItemOpen: (open: boolean) => void;
  isQuickPromotionOpen: boolean;
  setIsQuickPromotionOpen: (open: boolean) => void;

  // Inventory & Analytics
  lowStockItems: LowStockAlertItem[];
  restockItem: (itemId: string, addQty: number) => void;
  markSoldOut: (itemId: string) => void;
  topSellers: TopSellingItem[];
  ratingSummary: RatingSummary;
}

export const useDashboardStore = create<DashboardStoreState>((set, get) => ({
  timeframe: 'HOURLY',
  setTimeframe: (timeframe) => set({ timeframe }),

  pauseConfig: {
    isPaused: false,
    pausedUntil: null,
    durationLabel: null,
    reason: null,
  },

  pauseStore: (minutes, label, reason) => {
    const until = new Date(Date.now() + minutes * 60 * 1000).toISOString();
    set({
      pauseConfig: {
        isPaused: true,
        pausedUntil: until,
        durationLabel: label,
        reason: reason || 'Kitchen Rush / Peak Load',
      },
      isPauseModalOpen: false,
    });
  },

  resumeStore: () => {
    set({
      pauseConfig: {
        isPaused: false,
        pausedUntil: null,
        durationLabel: null,
        reason: null,
      },
    });
  },

  emergencyConfig: {
    isEmergencyClosed: false,
    closedAt: null,
    reason: null,
  },

  triggerEmergencyClose: (reason) => {
    set({
      emergencyConfig: {
        isEmergencyClosed: true,
        closedAt: new Date().toISOString(),
        reason,
      },
      isEmergencyModalOpen: false,
    });
  },

  reopenFromEmergency: () => {
    set({
      emergencyConfig: {
        isEmergencyClosed: false,
        closedAt: null,
        reason: null,
      },
    });
  },

  isPauseModalOpen: false,
  setIsPauseModalOpen: (open) => set({ isPauseModalOpen: open }),
  isEmergencyModalOpen: false,
  setIsEmergencyModalOpen: (open) => set({ isEmergencyModalOpen: open }),
  isQuickAddItemOpen: false,
  setIsQuickAddItemOpen: (open) => set({ isQuickAddItemOpen: open }),
  isQuickPromotionOpen: false,
  setIsQuickPromotionOpen: (open) => set({ isQuickPromotionOpen: open }),

  lowStockItems: INITIAL_LOW_STOCK_ITEMS,
  restockItem: (itemId, qty) => {
    const updated = dashboardService.restockItem(itemId, qty);
    set({ lowStockItems: updated });
  },
  markSoldOut: (itemId) => {
    const updated = dashboardService.markSoldOut(itemId);
    set({ lowStockItems: updated });
  },

  topSellers: INITIAL_TOP_SELLERS,
  ratingSummary: INITIAL_RATING_SUMMARY,
}));
